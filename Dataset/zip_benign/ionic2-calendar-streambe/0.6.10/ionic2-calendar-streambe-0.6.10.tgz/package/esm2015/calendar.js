import { Component, EventEmitter, Input, Output, Inject, LOCALE_ID } from '@angular/core';
import { CalendarService } from './calendar.service';
export var Step;
(function (Step) {
    Step[Step["QuarterHour"] = 15] = "QuarterHour";
    Step[Step["HalfHour"] = 30] = "HalfHour";
    Step[Step["Hour"] = 60] = "Hour";
})(Step || (Step = {}));
export class CalendarComponent {
    constructor(calendarService, appLocale) {
        this.calendarService = calendarService;
        this.appLocale = appLocale;
        this.eventSource = [];
        this.calendarMode = 'month';
        this.formatDay = 'd';
        this.formatDayHeader = 'EEE';
        this.formatDayTitle = 'MMMM dd, yyyy';
        this.formatWeekTitle = 'MMMM yyyy, \'Week\' w';
        this.formatMonthTitle = 'MMMM yyyy';
        this.formatWeekViewDayHeader = 'EEE d';
        this.formatHourColumn = 'ha';
        this.showEventDetail = true;
        this.startingDayMonth = 0;
        this.startingDayWeek = 0;
        this.allDayLabel = 'all day';
        this.noEventsLabel = 'No Events';
        this.queryMode = 'local';
        this.step = Step.Hour;
        this.timeInterval = 60;
        this.autoSelect = true;
        this.dir = "";
        this.scrollToHour = 0;
        this.preserveScrollPosition = false;
        this.lockSwipeToPrev = false;
        this.lockSwipeToNext = false;
        this.lockSwipes = false;
        this.locale = "";
        this.startHour = 0;
        this.endHour = 24;
        this.onCurrentDateChanged = new EventEmitter();
        this.onRangeChanged = new EventEmitter();
        this.onEventSelected = new EventEmitter();
        this.onTimeSelected = new EventEmitter();
        this.onDayHeaderSelected = new EventEmitter();
        this.onTitleChanged = new EventEmitter();
        this.hourParts = 1;
        this.hourSegments = 1;
        this.locale = appLocale;
    }
    get currentDate() {
        return this._currentDate;
    }
    set currentDate(val) {
        if (!val) {
            val = new Date();
        }
        this._currentDate = val;
        this.calendarService.setCurrentDate(val, true);
        this.onCurrentDateChanged.emit(this._currentDate);
    }
    ngOnInit() {
        if (this.autoSelect) {
            if (this.autoSelect.toString() === 'false') {
                this.autoSelect = false;
            }
            else {
                this.autoSelect = true;
            }
        }
        this.hourSegments = 60 / this.timeInterval;
        this.hourParts = 60 / this.step;
        if (this.hourParts <= this.hourSegments) {
            this.hourParts = 1;
        }
        else {
            this.hourParts = this.hourParts / this.hourSegments;
        }
        this.startHour = parseInt(this.startHour.toString());
        this.endHour = parseInt(this.endHour.toString());
        this.calendarService.queryMode = this.queryMode;
        this.currentDateChangedFromChildrenSubscription = this.calendarService.currentDateChangedFromChildren$.subscribe(currentDate => {
            this._currentDate = currentDate;
            this.onCurrentDateChanged.emit(currentDate);
        });
    }
    ngOnDestroy() {
        if (this.currentDateChangedFromChildrenSubscription) {
            this.currentDateChangedFromChildrenSubscription.unsubscribe();
            this.currentDateChangedFromChildrenSubscription = null;
        }
    }
    rangeChanged(range) {
        this.onRangeChanged.emit(range);
    }
    eventSelected(event) {
        this.onEventSelected.emit(event);
    }
    timeSelected(timeSelected) {
        this.onTimeSelected.emit(timeSelected);
    }
    daySelected(daySelected) {
        this.onDayHeaderSelected.emit(daySelected);
    }
    titleChanged(title) {
        this.onTitleChanged.emit(title);
    }
    loadEvents() {
        this.calendarService.loadEvents();
    }
    slideNext() {
        this.calendarService.slide(1);
    }
    slidePrev() {
        this.calendarService.slide(-1);
    }
    update() {
        this.calendarService.update();
    }
}
CalendarComponent.decorators = [
    { type: Component, args: [{
                selector: 'calendar',
                template: `
        <ng-template #monthviewDefaultDisplayEventTemplate let-view="view" let-row="row" let-col="col">
            {{view.dates[row*7+col].label}}
        </ng-template>
        <ng-template #monthviewDefaultEventDetailTemplate let-showEventDetail="showEventDetail" let-selectedDate="selectedDate" let-noEventsLabel="noEventsLabel">
            <ion-list class="event-detail-container" has-bouncing="false" *ngIf="showEventDetail" overflow-scroll="false">
                <ion-item *ngFor="let event of selectedDate?.events" (click)="eventSelected(event)">
                        <span *ngIf="!event.allDay" class="monthview-eventdetail-timecolumn">{{event.startTime|date: 'HH:mm'}}
                            -
                            {{event.endTime|date: 'HH:mm'}}
                        </span>
                    <span *ngIf="event.allDay" class="monthview-eventdetail-timecolumn">{{allDayLabel}}</span>
                    <span class="event-detail">  |  {{event.title}}</span>
                </ion-item>
                <ion-item *ngIf="selectedDate?.events.length==0">
                    <div class="no-events-label">{{noEventsLabel}}</div>
                </ion-item>
            </ion-list>
        </ng-template>
        <ng-template #defaultWeekviewHeaderTemplate let-viewDate="viewDate">
            {{ viewDate.dayHeader }}
        </ng-template>
        <ng-template #defaultAllDayEventTemplate let-displayEvent="displayEvent">
            <div class="calendar-event-inner">{{displayEvent.event.title}}</div>
        </ng-template>
        <ng-template #defaultNormalEventTemplate let-displayEvent="displayEvent">
            <div class="calendar-event-inner">{{displayEvent.event.title}}</div>
        </ng-template>
        <ng-template #defaultWeekViewAllDayEventSectionTemplate let-day="day" let-eventTemplate="eventTemplate">
            <div [ngClass]="{'calendar-event-wrap': day.events}" *ngIf="day.events"
                 [ngStyle]="{height: 25*day.events.length+'px'}">
                <div *ngFor="let displayEvent of day.events" class="calendar-event" tappable
                     (click)="eventSelected(displayEvent.event)"
                     [ngStyle]="{top: 25*displayEvent.position+'px', width: 100*(displayEvent.endIndex-displayEvent.startIndex)+'%', height: '25px'}">
                    <ng-template [ngTemplateOutlet]="eventTemplate"
                                 [ngTemplateOutletContext]="{displayEvent:displayEvent}">
                    </ng-template>
                </div>
            </div>
        </ng-template>
        <ng-template #defaultDayViewAllDayEventSectionTemplate let-allDayEvents="allDayEvents" let-eventTemplate="eventTemplate">
            <div *ngFor="let displayEvent of allDayEvents; let eventIndex=index"
                 class="calendar-event" tappable
                 (click)="eventSelected(displayEvent.event)"
                 [ngStyle]="{top: 25*eventIndex+'px',width: '100%',height:'25px'}">
                <ng-template [ngTemplateOutlet]="eventTemplate"
                             [ngTemplateOutletContext]="{displayEvent:displayEvent}">
                </ng-template>
            </div>
        </ng-template>
        <ng-template #defaultNormalEventSectionTemplate let-tm="tm" let-hourParts="hourParts" let-eventTemplate="eventTemplate">
            <div [ngClass]="{'calendar-event-wrap': tm.events}" *ngIf="tm.events">
                <div *ngFor="let displayEvent of tm.events" class="calendar-event" tappable
                     (click)="eventSelected(displayEvent.event)"
                     [ngStyle]="{top: (37*displayEvent.startOffset/hourParts)+'px',left: 100/displayEvent.overlapNumber*displayEvent.position+'%', width: 100/displayEvent.overlapNumber+'%', height: 37*(displayEvent.endIndex -displayEvent.startIndex - (displayEvent.endOffset + displayEvent.startOffset)/hourParts)+'px'}">
                    <ng-template [ngTemplateOutlet]="eventTemplate"
                                 [ngTemplateOutletContext]="{displayEvent:displayEvent}">
                    </ng-template>
                </div>
            </div>
        </ng-template>
        <ng-template #defaultInactiveAllDayEventSectionTemplate>
        </ng-template>
        <ng-template #defaultInactiveNormalEventSectionTemplate>
        </ng-template>

        <div [ngSwitch]="calendarMode" class="{{calendarMode}}view-container">
            <monthview *ngSwitchCase="'month'"
                [formatDay]="formatDay"
                [formatDayHeader]="formatDayHeader"
                [formatMonthTitle]="formatMonthTitle"
                [startingDayMonth]="startingDayMonth"
                [showEventDetail]="showEventDetail"
                [noEventsLabel]="noEventsLabel"
                [autoSelect]="autoSelect"
                [eventSource]="eventSource"
                [markDisabled]="markDisabled"
                [monthviewDisplayEventTemplate]="monthviewDisplayEventTemplate||monthviewDefaultDisplayEventTemplate"
                [monthviewInactiveDisplayEventTemplate]="monthviewInactiveDisplayEventTemplate||monthviewDefaultDisplayEventTemplate"
                [monthviewEventDetailTemplate]="monthviewEventDetailTemplate||monthviewDefaultEventDetailTemplate"
                [locale]="locale"
                [dateFormatter]="dateFormatter"
                [dir]="dir"
                [lockSwipeToPrev]="lockSwipeToPrev"
                [lockSwipeToNext]="lockSwipeToNext"
                [lockSwipes]="lockSwipes"
                [sliderOptions]="sliderOptions"
                (onRangeChanged)="rangeChanged($event)"
                (onEventSelected)="eventSelected($event)"
                (onTimeSelected)="timeSelected($event)"
                (onTitleChanged)="titleChanged($event)">
            </monthview>
            <weekview *ngSwitchCase="'week'"
                [formatWeekTitle]="formatWeekTitle"
                [formatWeekViewDayHeader]="formatWeekViewDayHeader"
                [formatHourColumn]="formatHourColumn"
                [startingDayWeek]="startingDayWeek"
                [allDayLabel]="allDayLabel"
                [hourParts]="hourParts"
                [autoSelect]="autoSelect"
                [hourSegments]="hourSegments"
                [eventSource]="eventSource"
                [markDisabled]="markDisabled"
                [weekviewHeaderTemplate]="weekviewHeaderTemplate||defaultWeekviewHeaderTemplate"
                [weekviewAllDayEventTemplate]="weekviewAllDayEventTemplate||defaultAllDayEventTemplate"
                [weekviewNormalEventTemplate]="weekviewNormalEventTemplate||defaultNormalEventTemplate"
                [weekviewAllDayEventSectionTemplate]="weekviewAllDayEventSectionTemplate||defaultWeekViewAllDayEventSectionTemplate"
                [weekviewNormalEventSectionTemplate]="weekviewNormalEventSectionTemplate||defaultNormalEventSectionTemplate"
                [weekviewInactiveAllDayEventSectionTemplate]="weekviewInactiveAllDayEventSectionTemplate||defaultInactiveAllDayEventSectionTemplate"
                [weekviewInactiveNormalEventSectionTemplate]="weekviewInactiveNormalEventSectionTemplate||defaultInactiveNormalEventSectionTemplate"
                [locale]="locale"
                [dateFormatter]="dateFormatter"
                [dir]="dir"
                [scrollToHour]="scrollToHour"
                [preserveScrollPosition]="preserveScrollPosition"
                [lockSwipeToPrev]="lockSwipeToPrev"
                [lockSwipeToNext]="lockSwipeToNext"
                [lockSwipes]="lockSwipes"
                [startHour]="startHour"
                [endHour]="endHour"
                [sliderOptions]="sliderOptions"
                (onRangeChanged)="rangeChanged($event)"
                (onEventSelected)="eventSelected($event)"
                (onDayHeaderSelected)="daySelected($event)"
                (onTimeSelected)="timeSelected($event)"
                (onTitleChanged)="titleChanged($event)">
            </weekview>
            <dayview *ngSwitchCase="'day'"
                [formatDayTitle]="formatDayTitle"
                [formatHourColumn]="formatHourColumn"
                [allDayLabel]="allDayLabel"
                [hourParts]="hourParts"
                [hourSegments]="hourSegments"
                [eventSource]="eventSource"
                [markDisabled]="markDisabled"
                [dayviewAllDayEventTemplate]="dayviewAllDayEventTemplate||defaultAllDayEventTemplate"
                [dayviewNormalEventTemplate]="dayviewNormalEventTemplate||defaultNormalEventTemplate"
                [dayviewAllDayEventSectionTemplate]="dayviewAllDayEventSectionTemplate||defaultDayViewAllDayEventSectionTemplate"
                [dayviewNormalEventSectionTemplate]="dayviewNormalEventSectionTemplate||defaultNormalEventSectionTemplate"
                [dayviewInactiveAllDayEventSectionTemplate]="dayviewInactiveAllDayEventSectionTemplate||defaultInactiveAllDayEventSectionTemplate"
                [dayviewInactiveNormalEventSectionTemplate]="dayviewInactiveNormalEventSectionTemplate||defaultInactiveNormalEventSectionTemplate"
                [locale]="locale"
                [dateFormatter]="dateFormatter"
                [dir]="dir"
                [scrollToHour]="scrollToHour"
                [preserveScrollPosition]="preserveScrollPosition"
                [lockSwipeToPrev]="lockSwipeToPrev"
                [lockSwipeToNext]="lockSwipeToNext"
                [lockSwipes]="lockSwipes"
                [startHour]="startHour"
                [endHour]="endHour"
                [sliderOptions]="sliderOptions"
                (onRangeChanged)="rangeChanged($event)"
                (onEventSelected)="eventSelected($event)"
                (onTimeSelected)="timeSelected($event)"
                (onTitleChanged)="titleChanged($event)">
            </dayview>
        </div>
    `,
                providers: [CalendarService],
                styles: [`
        :host > div { height: 100%; }

        .event-detail-container {
          border-top: 2px darkgrey solid;
        }

        .no-events-label {
          font-weight: bold;
          color: darkgrey;
          text-align: center;
        }

        .event-detail {
          cursor: pointer;
          white-space: nowrap;
          text-overflow: ellipsis;
        }

        .monthview-eventdetail-timecolumn {
          width: 110px;
          overflow: hidden;
        }

        .calendar-event-inner {
          overflow: hidden;
          background-color: #3a87ad;
          color: white;
          height: 100%;
          width: 100%;
          padding: 2px;
          line-height: 15px;
          text-align: initial;
        }

        @media (max-width: 750px) {
          .calendar-event-inner {
            font-size: 12px;
          }
        }
    `]
            },] }
];
CalendarComponent.ctorParameters = () => [
    { type: CalendarService },
    { type: String, decorators: [{ type: Inject, args: [LOCALE_ID,] }] }
];
CalendarComponent.propDecorators = {
    currentDate: [{ type: Input }],
    eventSource: [{ type: Input }],
    calendarMode: [{ type: Input }],
    formatDay: [{ type: Input }],
    formatDayHeader: [{ type: Input }],
    formatDayTitle: [{ type: Input }],
    formatWeekTitle: [{ type: Input }],
    formatMonthTitle: [{ type: Input }],
    formatWeekViewDayHeader: [{ type: Input }],
    formatHourColumn: [{ type: Input }],
    showEventDetail: [{ type: Input }],
    startingDayMonth: [{ type: Input }],
    startingDayWeek: [{ type: Input }],
    allDayLabel: [{ type: Input }],
    noEventsLabel: [{ type: Input }],
    queryMode: [{ type: Input }],
    step: [{ type: Input }],
    timeInterval: [{ type: Input }],
    autoSelect: [{ type: Input }],
    markDisabled: [{ type: Input }],
    monthviewDisplayEventTemplate: [{ type: Input }],
    monthviewInactiveDisplayEventTemplate: [{ type: Input }],
    monthviewEventDetailTemplate: [{ type: Input }],
    weekviewHeaderTemplate: [{ type: Input }],
    weekviewAllDayEventTemplate: [{ type: Input }],
    weekviewNormalEventTemplate: [{ type: Input }],
    dayviewAllDayEventTemplate: [{ type: Input }],
    dayviewNormalEventTemplate: [{ type: Input }],
    weekviewAllDayEventSectionTemplate: [{ type: Input }],
    weekviewNormalEventSectionTemplate: [{ type: Input }],
    dayviewAllDayEventSectionTemplate: [{ type: Input }],
    dayviewNormalEventSectionTemplate: [{ type: Input }],
    weekviewInactiveAllDayEventSectionTemplate: [{ type: Input }],
    weekviewInactiveNormalEventSectionTemplate: [{ type: Input }],
    dayviewInactiveAllDayEventSectionTemplate: [{ type: Input }],
    dayviewInactiveNormalEventSectionTemplate: [{ type: Input }],
    dateFormatter: [{ type: Input }],
    dir: [{ type: Input }],
    scrollToHour: [{ type: Input }],
    preserveScrollPosition: [{ type: Input }],
    lockSwipeToPrev: [{ type: Input }],
    lockSwipeToNext: [{ type: Input }],
    lockSwipes: [{ type: Input }],
    locale: [{ type: Input }],
    startHour: [{ type: Input }],
    endHour: [{ type: Input }],
    sliderOptions: [{ type: Input }],
    onCurrentDateChanged: [{ type: Output }],
    onRangeChanged: [{ type: Output }],
    onEventSelected: [{ type: Output }],
    onTimeSelected: [{ type: Output }],
    onDayHeaderSelected: [{ type: Output }],
    onTitleChanged: [{ type: Output }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2FsZW5kYXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9zcmMvY2FsZW5kYXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFNBQVMsRUFBRSxZQUFZLEVBQUUsS0FBSyxFQUFVLE1BQU0sRUFBZSxNQUFNLEVBQUUsU0FBUyxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBRy9HLE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQztBQWlKckQsTUFBTSxDQUFOLElBQVksSUFJWDtBQUpELFdBQVksSUFBSTtJQUNaLDhDQUFnQixDQUFBO0lBQ2hCLHdDQUFhLENBQUE7SUFDYixnQ0FBUyxDQUFBO0FBQ2IsQ0FBQyxFQUpXLElBQUksS0FBSixJQUFJLFFBSWY7QUE4TUQsTUFBTSxPQUFPLGlCQUFpQjtJQTJFMUIsWUFBb0IsZUFBK0IsRUFBNkIsU0FBZ0I7UUFBNUUsb0JBQWUsR0FBZixlQUFlLENBQWdCO1FBQTZCLGNBQVMsR0FBVCxTQUFTLENBQU87UUEzRHZGLGdCQUFXLEdBQVksRUFBRSxDQUFDO1FBQzFCLGlCQUFZLEdBQWdCLE9BQU8sQ0FBQztRQUNwQyxjQUFTLEdBQVUsR0FBRyxDQUFDO1FBQ3ZCLG9CQUFlLEdBQVUsS0FBSyxDQUFDO1FBQy9CLG1CQUFjLEdBQVUsZUFBZSxDQUFDO1FBQ3hDLG9CQUFlLEdBQVUsdUJBQXVCLENBQUM7UUFDakQscUJBQWdCLEdBQVUsV0FBVyxDQUFDO1FBQ3RDLDRCQUF1QixHQUFVLE9BQU8sQ0FBQztRQUN6QyxxQkFBZ0IsR0FBVSxJQUFJLENBQUM7UUFDL0Isb0JBQWUsR0FBVyxJQUFJLENBQUM7UUFDL0IscUJBQWdCLEdBQVUsQ0FBQyxDQUFDO1FBQzVCLG9CQUFlLEdBQVUsQ0FBQyxDQUFDO1FBQzNCLGdCQUFXLEdBQVUsU0FBUyxDQUFDO1FBQy9CLGtCQUFhLEdBQVUsV0FBVyxDQUFDO1FBQ25DLGNBQVMsR0FBYSxPQUFPLENBQUM7UUFDOUIsU0FBSSxHQUFRLElBQUksQ0FBQyxJQUFJLENBQUM7UUFDdEIsaUJBQVksR0FBVSxFQUFFLENBQUM7UUFDekIsZUFBVSxHQUFXLElBQUksQ0FBQztRQW1CMUIsUUFBRyxHQUFVLEVBQUUsQ0FBQztRQUNoQixpQkFBWSxHQUFVLENBQUMsQ0FBQztRQUN4QiwyQkFBc0IsR0FBVyxLQUFLLENBQUM7UUFDdkMsb0JBQWUsR0FBVyxLQUFLLENBQUM7UUFDaEMsb0JBQWUsR0FBVyxLQUFLLENBQUM7UUFDaEMsZUFBVSxHQUFXLEtBQUssQ0FBQztRQUMzQixXQUFNLEdBQVUsRUFBRSxDQUFDO1FBQ25CLGNBQVMsR0FBVSxDQUFDLENBQUM7UUFDckIsWUFBTyxHQUFVLEVBQUUsQ0FBQztRQUduQix5QkFBb0IsR0FBRyxJQUFJLFlBQVksRUFBUSxDQUFDO1FBQ2hELG1CQUFjLEdBQUcsSUFBSSxZQUFZLEVBQVUsQ0FBQztRQUM1QyxvQkFBZSxHQUFHLElBQUksWUFBWSxFQUFVLENBQUM7UUFDN0MsbUJBQWMsR0FBRyxJQUFJLFlBQVksRUFBaUIsQ0FBQztRQUNuRCx3QkFBbUIsR0FBRyxJQUFJLFlBQVksRUFBaUIsQ0FBQztRQUN4RCxtQkFBYyxHQUFHLElBQUksWUFBWSxFQUFVLENBQUM7UUFHL0MsY0FBUyxHQUFHLENBQUMsQ0FBQztRQUNkLGlCQUFZLEdBQUcsQ0FBQyxDQUFDO1FBSXBCLElBQUksQ0FBQyxNQUFNLEdBQUcsU0FBUyxDQUFDO0lBQzVCLENBQUM7SUE1RUQsSUFDSSxXQUFXO1FBQ1gsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDO0lBQzdCLENBQUM7SUFFRCxJQUFJLFdBQVcsQ0FBQyxHQUFRO1FBQ3BCLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDTixHQUFHLEdBQUcsSUFBSSxJQUFJLEVBQUUsQ0FBQztTQUNwQjtRQUVELElBQUksQ0FBQyxZQUFZLEdBQUcsR0FBRyxDQUFDO1FBQ3hCLElBQUksQ0FBQyxlQUFlLENBQUMsY0FBYyxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUMsQ0FBQztRQUMvQyxJQUFJLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQztJQUN0RCxDQUFDO0lBaUVELFFBQVE7UUFDSixJQUFJLElBQUksQ0FBQyxVQUFVLEVBQUU7WUFDakIsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsRUFBRSxLQUFLLE9BQU8sRUFBRTtnQkFDeEMsSUFBSSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7YUFDM0I7aUJBQU07Z0JBQ0gsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUM7YUFDMUI7U0FDSjtRQUNELElBQUksQ0FBQyxZQUFZLEdBQUcsRUFBRSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUM7UUFDM0MsSUFBSSxDQUFDLFNBQVMsR0FBRyxFQUFFLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQztRQUNoQyxJQUFHLElBQUksQ0FBQyxTQUFTLElBQUksSUFBSSxDQUFDLFlBQVksRUFBRTtZQUNwQyxJQUFJLENBQUMsU0FBUyxHQUFHLENBQUMsQ0FBQztTQUN0QjthQUFNO1lBQ0gsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUM7U0FDdkQ7UUFDRCxJQUFJLENBQUMsU0FBUyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUM7UUFDckQsSUFBSSxDQUFDLE9BQU8sR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDO1FBQ2pELElBQUksQ0FBQyxlQUFlLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUM7UUFFaEQsSUFBSSxDQUFDLDBDQUEwQyxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsK0JBQStCLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxFQUFFO1lBQzNILElBQUksQ0FBQyxZQUFZLEdBQUcsV0FBVyxDQUFDO1lBQ2hDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7UUFDaEQsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRUQsV0FBVztRQUNQLElBQUksSUFBSSxDQUFDLDBDQUEwQyxFQUFFO1lBQ2pELElBQUksQ0FBQywwQ0FBMEMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUM5RCxJQUFJLENBQUMsMENBQTBDLEdBQUcsSUFBSSxDQUFDO1NBQzFEO0lBQ0wsQ0FBQztJQUVELFlBQVksQ0FBQyxLQUFZO1FBQ3JCLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ3BDLENBQUM7SUFFRCxhQUFhLENBQUMsS0FBWTtRQUN0QixJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUNyQyxDQUFDO0lBRUQsWUFBWSxDQUFDLFlBQTBCO1FBQ25DLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO0lBQzNDLENBQUM7SUFFRCxXQUFXLENBQUMsV0FBeUI7UUFDakMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztJQUMvQyxDQUFDO0lBRUQsWUFBWSxDQUFDLEtBQVk7UUFDckIsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDcEMsQ0FBQztJQUVELFVBQVU7UUFDTixJQUFJLENBQUMsZUFBZSxDQUFDLFVBQVUsRUFBRSxDQUFDO0lBQ3RDLENBQUM7SUFFRCxTQUFTO1FBQ0wsSUFBSSxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDbEMsQ0FBQztJQUVELFNBQVM7UUFDTCxJQUFJLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ25DLENBQUM7SUFFRCxNQUFNO1FBQ0YsSUFBSSxDQUFDLGVBQWUsQ0FBQyxNQUFNLEVBQUUsQ0FBQztJQUNsQyxDQUFDOzs7WUE3VkosU0FBUyxTQUFDO2dCQUNQLFFBQVEsRUFBRSxVQUFVO2dCQUNwQixRQUFRLEVBQUU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0tBOEpUO2dCQTBDRCxTQUFTLEVBQUUsQ0FBQyxlQUFlLENBQUM7eUJBekNuQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztLQXdDUjthQUVKOzs7WUFsV1EsZUFBZTt5Q0E4YWtDLE1BQU0sU0FBQyxTQUFTOzs7MEJBMUVyRSxLQUFLOzBCQWVMLEtBQUs7MkJBQ0wsS0FBSzt3QkFDTCxLQUFLOzhCQUNMLEtBQUs7NkJBQ0wsS0FBSzs4QkFDTCxLQUFLOytCQUNMLEtBQUs7c0NBQ0wsS0FBSzsrQkFDTCxLQUFLOzhCQUNMLEtBQUs7K0JBQ0wsS0FBSzs4QkFDTCxLQUFLOzBCQUNMLEtBQUs7NEJBQ0wsS0FBSzt3QkFDTCxLQUFLO21CQUNMLEtBQUs7MkJBQ0wsS0FBSzt5QkFDTCxLQUFLOzJCQUNMLEtBQUs7NENBQ0wsS0FBSztvREFDTCxLQUFLOzJDQUNMLEtBQUs7cUNBQ0wsS0FBSzswQ0FDTCxLQUFLOzBDQUNMLEtBQUs7eUNBQ0wsS0FBSzt5Q0FDTCxLQUFLO2lEQUNMLEtBQUs7aURBQ0wsS0FBSztnREFDTCxLQUFLO2dEQUNMLEtBQUs7eURBQ0wsS0FBSzt5REFDTCxLQUFLO3dEQUNMLEtBQUs7d0RBQ0wsS0FBSzs0QkFDTCxLQUFLO2tCQUNMLEtBQUs7MkJBQ0wsS0FBSztxQ0FDTCxLQUFLOzhCQUNMLEtBQUs7OEJBQ0wsS0FBSzt5QkFDTCxLQUFLO3FCQUNMLEtBQUs7d0JBQ0wsS0FBSztzQkFDTCxLQUFLOzRCQUNMLEtBQUs7bUNBRUwsTUFBTTs2QkFDTixNQUFNOzhCQUNOLE1BQU07NkJBQ04sTUFBTTtrQ0FDTixNQUFNOzZCQUNOLE1BQU0iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQsIEV2ZW50RW1pdHRlciwgSW5wdXQsIE9uSW5pdCwgT3V0cHV0LCBUZW1wbGF0ZVJlZiwgSW5qZWN0LCBMT0NBTEVfSUQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IFN1YnNjcmlwdGlvbiB9IGZyb20gJ3J4anMnO1xuXG5pbXBvcnQgeyBDYWxlbmRhclNlcnZpY2UgfSBmcm9tICcuL2NhbGVuZGFyLnNlcnZpY2UnO1xuXG5leHBvcnQgaW50ZXJmYWNlIElFdmVudCB7XG4gICAgYWxsRGF5OiBib29sZWFuO1xuICAgIGVuZFRpbWU6IERhdGU7XG4gICAgc3RhcnRUaW1lOiBEYXRlO1xuICAgIHRpdGxlOiBzdHJpbmc7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgSVJhbmdlIHtcbiAgICBzdGFydFRpbWU6IERhdGU7XG4gICAgZW5kVGltZTogRGF0ZTtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBJVmlldyB7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgSURheVZpZXcgZXh0ZW5kcyBJVmlldyB7XG4gICAgYWxsRGF5RXZlbnRzOiBJRGlzcGxheUFsbERheUV2ZW50W107XG4gICAgcm93czogSURheVZpZXdSb3dbXTtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBJRGF5Vmlld1JvdyB7XG4gICAgZXZlbnRzOiBJRGlzcGxheUV2ZW50W107XG4gICAgdGltZTogRGF0ZTtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBJTW9udGhWaWV3IGV4dGVuZHMgSVZpZXcge1xuICAgIGRhdGVzOiBJTW9udGhWaWV3Um93W107XG4gICAgZGF5SGVhZGVyczogc3RyaW5nW107XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgSU1vbnRoVmlld1JvdyB7XG4gICAgY3VycmVudD86IGJvb2xlYW47XG4gICAgZGF0ZTogRGF0ZTtcbiAgICBldmVudHM6IElFdmVudFtdO1xuICAgIGhhc0V2ZW50PzogYm9vbGVhbjtcbiAgICBsYWJlbDogc3RyaW5nO1xuICAgIHNlY29uZGFyeTogYm9vbGVhbjtcbiAgICBzZWxlY3RlZD86IGJvb2xlYW47XG4gICAgZGlzYWJsZWQ6IGJvb2xlYW47XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgSVdlZWtWaWV3IGV4dGVuZHMgSVZpZXcge1xuICAgIGRhdGVzOiBJV2Vla1ZpZXdEYXRlUm93W107XG4gICAgcm93czogSVdlZWtWaWV3Um93W11bXTtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBJV2Vla1ZpZXdEYXRlUm93IHtcbiAgICBjdXJyZW50PzogYm9vbGVhbjtcbiAgICBkYXRlOiBEYXRlO1xuICAgIGV2ZW50czogSURpc3BsYXlFdmVudFtdO1xuICAgIGhhc0V2ZW50PzogYm9vbGVhbjtcbiAgICBzZWxlY3RlZD86IGJvb2xlYW47XG4gICAgZGF5SGVhZGVyOiBzdHJpbmc7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgSVdlZWtWaWV3Um93IHtcbiAgICBldmVudHM6IElEaXNwbGF5RXZlbnRbXTtcbiAgICB0aW1lOiBEYXRlO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIElEaXNwbGF5RXZlbnQge1xuICAgIGVuZEluZGV4OiBudW1iZXI7XG4gICAgZW5kT2Zmc2V0PzogbnVtYmVyO1xuICAgIGV2ZW50OiBJRXZlbnQ7XG4gICAgc3RhcnRJbmRleDogbnVtYmVyO1xuICAgIHN0YXJ0T2Zmc2V0PzogbnVtYmVyO1xuICAgIG92ZXJsYXBOdW1iZXI/OiBudW1iZXI7XG4gICAgcG9zaXRpb24/OiBudW1iZXI7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgSURpc3BsYXlXZWVrVmlld0hlYWRlciB7XG4gICAgdmlld0RhdGU6IElXZWVrVmlld0RhdGVSb3c7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgSURpc3BsYXlBbGxEYXlFdmVudCB7XG4gICAgZXZlbnQ6IElFdmVudDtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBJQ2FsZW5kYXJDb21wb25lbnQge1xuICAgIGN1cnJlbnRWaWV3SW5kZXg6IG51bWJlcjtcbiAgICBkaXJlY3Rpb246IG51bWJlcjtcbiAgICBldmVudFNvdXJjZTogSUV2ZW50W107XG4gICAgZ2V0UmFuZ2U6IHsgKGRhdGU6RGF0ZSk6IElSYW5nZTsgfTtcbiAgICBnZXRWaWV3RGF0YTogeyAoZGF0ZTpEYXRlKTogSVZpZXcgfTtcbiAgICBtb2RlOiBDYWxlbmRhck1vZGU7XG4gICAgcmFuZ2U6IElSYW5nZTtcbiAgICB2aWV3czogSVZpZXdbXTtcbiAgICBvbkRhdGFMb2FkZWQ6IHsgKCk6IHZvaWQgfTtcbiAgICBvblJhbmdlQ2hhbmdlZDogRXZlbnRFbWl0dGVyPElSYW5nZT47XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgSVRpbWVTZWxlY3RlZCB7XG4gICAgZXZlbnRzOiBJRXZlbnRbXTtcbiAgICBzZWxlY3RlZFRpbWU6IERhdGU7XG4gICAgZGlzYWJsZWQ6IGJvb2xlYW47XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgSU1vbnRoVmlld0Rpc3BsYXlFdmVudFRlbXBsYXRlQ29udGV4dCB7XG4gICAgdmlldzogSVZpZXc7XG4gICAgcm93OiBudW1iZXI7XG4gICAgY29sOiBudW1iZXI7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgSU1vbnRoVmlld0V2ZW50RGV0YWlsVGVtcGxhdGVDb250ZXh0IHtcbiAgICBzZWxlY3RlZERhdGU6IElUaW1lU2VsZWN0ZWQ7XG4gICAgbm9FdmVudHNMYWJlbDogc3RyaW5nO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIElXZWVrVmlld0FsbERheUV2ZW50U2VjdGlvblRlbXBsYXRlQ29udGV4dCB7XG4gICAgZGF5OiBJV2Vla1ZpZXdEYXRlUm93LFxuICAgIGV2ZW50VGVtcGxhdGU6IFRlbXBsYXRlUmVmPElEaXNwbGF5QWxsRGF5RXZlbnQ+XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgSVdlZWtWaWV3Tm9ybWFsRXZlbnRTZWN0aW9uVGVtcGxhdGVDb250ZXh0IHtcbiAgICB0bTogSVdlZWtWaWV3Um93LFxuICAgIGV2ZW50VGVtcGxhdGU6IFRlbXBsYXRlUmVmPElEaXNwbGF5RXZlbnQ+XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgSURheVZpZXdBbGxEYXlFdmVudFNlY3Rpb25UZW1wbGF0ZUNvbnRleHQge1xuICAgIGFsbGRheUV2ZW50czogSURpc3BsYXlBbGxEYXlFdmVudFtdLFxuICAgIGV2ZW50VGVtcGxhdGU6IFRlbXBsYXRlUmVmPElEaXNwbGF5QWxsRGF5RXZlbnQ+XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgSURheVZpZXdOb3JtYWxFdmVudFNlY3Rpb25UZW1wbGF0ZUNvbnRleHQge1xuICAgIHRtOiBJRGF5Vmlld1JvdyxcbiAgICBldmVudFRlbXBsYXRlOiBUZW1wbGF0ZVJlZjxJRGlzcGxheUV2ZW50PlxufVxuXG5leHBvcnQgaW50ZXJmYWNlIElEYXRlRm9ybWF0dGVyIHtcbiAgICBmb3JtYXRNb250aFZpZXdEYXk/OiB7IChkYXRlOkRhdGUpOiBzdHJpbmc7IH07XG4gICAgZm9ybWF0TW9udGhWaWV3RGF5SGVhZGVyPzogeyAoZGF0ZTpEYXRlKTogc3RyaW5nOyB9O1xuICAgIGZvcm1hdE1vbnRoVmlld1RpdGxlPzogeyAoZGF0ZTpEYXRlKTogc3RyaW5nOyB9O1xuICAgIGZvcm1hdFdlZWtWaWV3RGF5SGVhZGVyPzogeyAoZGF0ZTpEYXRlKTogc3RyaW5nOyB9O1xuICAgIGZvcm1hdFdlZWtWaWV3VGl0bGU/OiB7IChkYXRlOkRhdGUpOiBzdHJpbmc7IH07XG4gICAgZm9ybWF0V2Vla1ZpZXdIb3VyQ29sdW1uPzogeyAoZGF0ZTpEYXRlKTogc3RyaW5nOyB9O1xuICAgIGZvcm1hdERheVZpZXdUaXRsZT86IHsgKGRhdGU6RGF0ZSk6IHN0cmluZzsgfTtcbiAgICBmb3JtYXREYXlWaWV3SG91ckNvbHVtbj86IHsgKGRhdGU6RGF0ZSk6IHN0cmluZzsgfTtcbn1cblxuZXhwb3J0IHR5cGUgQ2FsZW5kYXJNb2RlID0gJ2RheScgfCAnbW9udGgnIHwgJ3dlZWsnO1xuXG5leHBvcnQgdHlwZSBRdWVyeU1vZGUgPSAnbG9jYWwnIHwgJ3JlbW90ZSc7XG5cbmV4cG9ydCBlbnVtIFN0ZXAge1xuICAgIFF1YXJ0ZXJIb3VyID0gMTUsXG4gICAgSGFsZkhvdXIgPSAzMCxcbiAgICBIb3VyID0gNjBcbn1cblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdjYWxlbmRhcicsXG4gICAgdGVtcGxhdGU6IGBcbiAgICAgICAgPG5nLXRlbXBsYXRlICNtb250aHZpZXdEZWZhdWx0RGlzcGxheUV2ZW50VGVtcGxhdGUgbGV0LXZpZXc9XCJ2aWV3XCIgbGV0LXJvdz1cInJvd1wiIGxldC1jb2w9XCJjb2xcIj5cbiAgICAgICAgICAgIHt7dmlldy5kYXRlc1tyb3cqNytjb2xdLmxhYmVsfX1cbiAgICAgICAgPC9uZy10ZW1wbGF0ZT5cbiAgICAgICAgPG5nLXRlbXBsYXRlICNtb250aHZpZXdEZWZhdWx0RXZlbnREZXRhaWxUZW1wbGF0ZSBsZXQtc2hvd0V2ZW50RGV0YWlsPVwic2hvd0V2ZW50RGV0YWlsXCIgbGV0LXNlbGVjdGVkRGF0ZT1cInNlbGVjdGVkRGF0ZVwiIGxldC1ub0V2ZW50c0xhYmVsPVwibm9FdmVudHNMYWJlbFwiPlxuICAgICAgICAgICAgPGlvbi1saXN0IGNsYXNzPVwiZXZlbnQtZGV0YWlsLWNvbnRhaW5lclwiIGhhcy1ib3VuY2luZz1cImZhbHNlXCIgKm5nSWY9XCJzaG93RXZlbnREZXRhaWxcIiBvdmVyZmxvdy1zY3JvbGw9XCJmYWxzZVwiPlxuICAgICAgICAgICAgICAgIDxpb24taXRlbSAqbmdGb3I9XCJsZXQgZXZlbnQgb2Ygc2VsZWN0ZWREYXRlPy5ldmVudHNcIiAoY2xpY2spPVwiZXZlbnRTZWxlY3RlZChldmVudClcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuICpuZ0lmPVwiIWV2ZW50LmFsbERheVwiIGNsYXNzPVwibW9udGh2aWV3LWV2ZW50ZGV0YWlsLXRpbWVjb2x1bW5cIj57e2V2ZW50LnN0YXJ0VGltZXxkYXRlOiAnSEg6bW0nfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAtXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3tldmVudC5lbmRUaW1lfGRhdGU6ICdISDptbSd9fVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiAqbmdJZj1cImV2ZW50LmFsbERheVwiIGNsYXNzPVwibW9udGh2aWV3LWV2ZW50ZGV0YWlsLXRpbWVjb2x1bW5cIj57e2FsbERheUxhYmVsfX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiZXZlbnQtZGV0YWlsXCI+ICB8ICB7e2V2ZW50LnRpdGxlfX08L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9pb24taXRlbT5cbiAgICAgICAgICAgICAgICA8aW9uLWl0ZW0gKm5nSWY9XCJzZWxlY3RlZERhdGU/LmV2ZW50cy5sZW5ndGg9PTBcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cIm5vLWV2ZW50cy1sYWJlbFwiPnt7bm9FdmVudHNMYWJlbH19PC9kaXY+XG4gICAgICAgICAgICAgICAgPC9pb24taXRlbT5cbiAgICAgICAgICAgIDwvaW9uLWxpc3Q+XG4gICAgICAgIDwvbmctdGVtcGxhdGU+XG4gICAgICAgIDxuZy10ZW1wbGF0ZSAjZGVmYXVsdFdlZWt2aWV3SGVhZGVyVGVtcGxhdGUgbGV0LXZpZXdEYXRlPVwidmlld0RhdGVcIj5cbiAgICAgICAgICAgIHt7IHZpZXdEYXRlLmRheUhlYWRlciB9fVxuICAgICAgICA8L25nLXRlbXBsYXRlPlxuICAgICAgICA8bmctdGVtcGxhdGUgI2RlZmF1bHRBbGxEYXlFdmVudFRlbXBsYXRlIGxldC1kaXNwbGF5RXZlbnQ9XCJkaXNwbGF5RXZlbnRcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjYWxlbmRhci1ldmVudC1pbm5lclwiPnt7ZGlzcGxheUV2ZW50LmV2ZW50LnRpdGxlfX08L2Rpdj5cbiAgICAgICAgPC9uZy10ZW1wbGF0ZT5cbiAgICAgICAgPG5nLXRlbXBsYXRlICNkZWZhdWx0Tm9ybWFsRXZlbnRUZW1wbGF0ZSBsZXQtZGlzcGxheUV2ZW50PVwiZGlzcGxheUV2ZW50XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY2FsZW5kYXItZXZlbnQtaW5uZXJcIj57e2Rpc3BsYXlFdmVudC5ldmVudC50aXRsZX19PC9kaXY+XG4gICAgICAgIDwvbmctdGVtcGxhdGU+XG4gICAgICAgIDxuZy10ZW1wbGF0ZSAjZGVmYXVsdFdlZWtWaWV3QWxsRGF5RXZlbnRTZWN0aW9uVGVtcGxhdGUgbGV0LWRheT1cImRheVwiIGxldC1ldmVudFRlbXBsYXRlPVwiZXZlbnRUZW1wbGF0ZVwiPlxuICAgICAgICAgICAgPGRpdiBbbmdDbGFzc109XCJ7J2NhbGVuZGFyLWV2ZW50LXdyYXAnOiBkYXkuZXZlbnRzfVwiICpuZ0lmPVwiZGF5LmV2ZW50c1wiXG4gICAgICAgICAgICAgICAgIFtuZ1N0eWxlXT1cIntoZWlnaHQ6IDI1KmRheS5ldmVudHMubGVuZ3RoKydweCd9XCI+XG4gICAgICAgICAgICAgICAgPGRpdiAqbmdGb3I9XCJsZXQgZGlzcGxheUV2ZW50IG9mIGRheS5ldmVudHNcIiBjbGFzcz1cImNhbGVuZGFyLWV2ZW50XCIgdGFwcGFibGVcbiAgICAgICAgICAgICAgICAgICAgIChjbGljayk9XCJldmVudFNlbGVjdGVkKGRpc3BsYXlFdmVudC5ldmVudClcIlxuICAgICAgICAgICAgICAgICAgICAgW25nU3R5bGVdPVwie3RvcDogMjUqZGlzcGxheUV2ZW50LnBvc2l0aW9uKydweCcsIHdpZHRoOiAxMDAqKGRpc3BsYXlFdmVudC5lbmRJbmRleC1kaXNwbGF5RXZlbnQuc3RhcnRJbmRleCkrJyUnLCBoZWlnaHQ6ICcyNXB4J31cIj5cbiAgICAgICAgICAgICAgICAgICAgPG5nLXRlbXBsYXRlIFtuZ1RlbXBsYXRlT3V0bGV0XT1cImV2ZW50VGVtcGxhdGVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW25nVGVtcGxhdGVPdXRsZXRDb250ZXh0XT1cIntkaXNwbGF5RXZlbnQ6ZGlzcGxheUV2ZW50fVwiPlxuICAgICAgICAgICAgICAgICAgICA8L25nLXRlbXBsYXRlPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvbmctdGVtcGxhdGU+XG4gICAgICAgIDxuZy10ZW1wbGF0ZSAjZGVmYXVsdERheVZpZXdBbGxEYXlFdmVudFNlY3Rpb25UZW1wbGF0ZSBsZXQtYWxsRGF5RXZlbnRzPVwiYWxsRGF5RXZlbnRzXCIgbGV0LWV2ZW50VGVtcGxhdGU9XCJldmVudFRlbXBsYXRlXCI+XG4gICAgICAgICAgICA8ZGl2ICpuZ0Zvcj1cImxldCBkaXNwbGF5RXZlbnQgb2YgYWxsRGF5RXZlbnRzOyBsZXQgZXZlbnRJbmRleD1pbmRleFwiXG4gICAgICAgICAgICAgICAgIGNsYXNzPVwiY2FsZW5kYXItZXZlbnRcIiB0YXBwYWJsZVxuICAgICAgICAgICAgICAgICAoY2xpY2spPVwiZXZlbnRTZWxlY3RlZChkaXNwbGF5RXZlbnQuZXZlbnQpXCJcbiAgICAgICAgICAgICAgICAgW25nU3R5bGVdPVwie3RvcDogMjUqZXZlbnRJbmRleCsncHgnLHdpZHRoOiAnMTAwJScsaGVpZ2h0OicyNXB4J31cIj5cbiAgICAgICAgICAgICAgICA8bmctdGVtcGxhdGUgW25nVGVtcGxhdGVPdXRsZXRdPVwiZXZlbnRUZW1wbGF0ZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtuZ1RlbXBsYXRlT3V0bGV0Q29udGV4dF09XCJ7ZGlzcGxheUV2ZW50OmRpc3BsYXlFdmVudH1cIj5cbiAgICAgICAgICAgICAgICA8L25nLXRlbXBsYXRlPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvbmctdGVtcGxhdGU+XG4gICAgICAgIDxuZy10ZW1wbGF0ZSAjZGVmYXVsdE5vcm1hbEV2ZW50U2VjdGlvblRlbXBsYXRlIGxldC10bT1cInRtXCIgbGV0LWhvdXJQYXJ0cz1cImhvdXJQYXJ0c1wiIGxldC1ldmVudFRlbXBsYXRlPVwiZXZlbnRUZW1wbGF0ZVwiPlxuICAgICAgICAgICAgPGRpdiBbbmdDbGFzc109XCJ7J2NhbGVuZGFyLWV2ZW50LXdyYXAnOiB0bS5ldmVudHN9XCIgKm5nSWY9XCJ0bS5ldmVudHNcIj5cbiAgICAgICAgICAgICAgICA8ZGl2ICpuZ0Zvcj1cImxldCBkaXNwbGF5RXZlbnQgb2YgdG0uZXZlbnRzXCIgY2xhc3M9XCJjYWxlbmRhci1ldmVudFwiIHRhcHBhYmxlXG4gICAgICAgICAgICAgICAgICAgICAoY2xpY2spPVwiZXZlbnRTZWxlY3RlZChkaXNwbGF5RXZlbnQuZXZlbnQpXCJcbiAgICAgICAgICAgICAgICAgICAgIFtuZ1N0eWxlXT1cInt0b3A6ICgzNypkaXNwbGF5RXZlbnQuc3RhcnRPZmZzZXQvaG91clBhcnRzKSsncHgnLGxlZnQ6IDEwMC9kaXNwbGF5RXZlbnQub3ZlcmxhcE51bWJlcipkaXNwbGF5RXZlbnQucG9zaXRpb24rJyUnLCB3aWR0aDogMTAwL2Rpc3BsYXlFdmVudC5vdmVybGFwTnVtYmVyKyclJywgaGVpZ2h0OiAzNyooZGlzcGxheUV2ZW50LmVuZEluZGV4IC1kaXNwbGF5RXZlbnQuc3RhcnRJbmRleCAtIChkaXNwbGF5RXZlbnQuZW5kT2Zmc2V0ICsgZGlzcGxheUV2ZW50LnN0YXJ0T2Zmc2V0KS9ob3VyUGFydHMpKydweCd9XCI+XG4gICAgICAgICAgICAgICAgICAgIDxuZy10ZW1wbGF0ZSBbbmdUZW1wbGF0ZU91dGxldF09XCJldmVudFRlbXBsYXRlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtuZ1RlbXBsYXRlT3V0bGV0Q29udGV4dF09XCJ7ZGlzcGxheUV2ZW50OmRpc3BsYXlFdmVudH1cIj5cbiAgICAgICAgICAgICAgICAgICAgPC9uZy10ZW1wbGF0ZT5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L25nLXRlbXBsYXRlPlxuICAgICAgICA8bmctdGVtcGxhdGUgI2RlZmF1bHRJbmFjdGl2ZUFsbERheUV2ZW50U2VjdGlvblRlbXBsYXRlPlxuICAgICAgICA8L25nLXRlbXBsYXRlPlxuICAgICAgICA8bmctdGVtcGxhdGUgI2RlZmF1bHRJbmFjdGl2ZU5vcm1hbEV2ZW50U2VjdGlvblRlbXBsYXRlPlxuICAgICAgICA8L25nLXRlbXBsYXRlPlxuXG4gICAgICAgIDxkaXYgW25nU3dpdGNoXT1cImNhbGVuZGFyTW9kZVwiIGNsYXNzPVwie3tjYWxlbmRhck1vZGV9fXZpZXctY29udGFpbmVyXCI+XG4gICAgICAgICAgICA8bW9udGh2aWV3ICpuZ1N3aXRjaENhc2U9XCInbW9udGgnXCJcbiAgICAgICAgICAgICAgICBbZm9ybWF0RGF5XT1cImZvcm1hdERheVwiXG4gICAgICAgICAgICAgICAgW2Zvcm1hdERheUhlYWRlcl09XCJmb3JtYXREYXlIZWFkZXJcIlxuICAgICAgICAgICAgICAgIFtmb3JtYXRNb250aFRpdGxlXT1cImZvcm1hdE1vbnRoVGl0bGVcIlxuICAgICAgICAgICAgICAgIFtzdGFydGluZ0RheU1vbnRoXT1cInN0YXJ0aW5nRGF5TW9udGhcIlxuICAgICAgICAgICAgICAgIFtzaG93RXZlbnREZXRhaWxdPVwic2hvd0V2ZW50RGV0YWlsXCJcbiAgICAgICAgICAgICAgICBbbm9FdmVudHNMYWJlbF09XCJub0V2ZW50c0xhYmVsXCJcbiAgICAgICAgICAgICAgICBbYXV0b1NlbGVjdF09XCJhdXRvU2VsZWN0XCJcbiAgICAgICAgICAgICAgICBbZXZlbnRTb3VyY2VdPVwiZXZlbnRTb3VyY2VcIlxuICAgICAgICAgICAgICAgIFttYXJrRGlzYWJsZWRdPVwibWFya0Rpc2FibGVkXCJcbiAgICAgICAgICAgICAgICBbbW9udGh2aWV3RGlzcGxheUV2ZW50VGVtcGxhdGVdPVwibW9udGh2aWV3RGlzcGxheUV2ZW50VGVtcGxhdGV8fG1vbnRodmlld0RlZmF1bHREaXNwbGF5RXZlbnRUZW1wbGF0ZVwiXG4gICAgICAgICAgICAgICAgW21vbnRodmlld0luYWN0aXZlRGlzcGxheUV2ZW50VGVtcGxhdGVdPVwibW9udGh2aWV3SW5hY3RpdmVEaXNwbGF5RXZlbnRUZW1wbGF0ZXx8bW9udGh2aWV3RGVmYXVsdERpc3BsYXlFdmVudFRlbXBsYXRlXCJcbiAgICAgICAgICAgICAgICBbbW9udGh2aWV3RXZlbnREZXRhaWxUZW1wbGF0ZV09XCJtb250aHZpZXdFdmVudERldGFpbFRlbXBsYXRlfHxtb250aHZpZXdEZWZhdWx0RXZlbnREZXRhaWxUZW1wbGF0ZVwiXG4gICAgICAgICAgICAgICAgW2xvY2FsZV09XCJsb2NhbGVcIlxuICAgICAgICAgICAgICAgIFtkYXRlRm9ybWF0dGVyXT1cImRhdGVGb3JtYXR0ZXJcIlxuICAgICAgICAgICAgICAgIFtkaXJdPVwiZGlyXCJcbiAgICAgICAgICAgICAgICBbbG9ja1N3aXBlVG9QcmV2XT1cImxvY2tTd2lwZVRvUHJldlwiXG4gICAgICAgICAgICAgICAgW2xvY2tTd2lwZVRvTmV4dF09XCJsb2NrU3dpcGVUb05leHRcIlxuICAgICAgICAgICAgICAgIFtsb2NrU3dpcGVzXT1cImxvY2tTd2lwZXNcIlxuICAgICAgICAgICAgICAgIFtzbGlkZXJPcHRpb25zXT1cInNsaWRlck9wdGlvbnNcIlxuICAgICAgICAgICAgICAgIChvblJhbmdlQ2hhbmdlZCk9XCJyYW5nZUNoYW5nZWQoJGV2ZW50KVwiXG4gICAgICAgICAgICAgICAgKG9uRXZlbnRTZWxlY3RlZCk9XCJldmVudFNlbGVjdGVkKCRldmVudClcIlxuICAgICAgICAgICAgICAgIChvblRpbWVTZWxlY3RlZCk9XCJ0aW1lU2VsZWN0ZWQoJGV2ZW50KVwiXG4gICAgICAgICAgICAgICAgKG9uVGl0bGVDaGFuZ2VkKT1cInRpdGxlQ2hhbmdlZCgkZXZlbnQpXCI+XG4gICAgICAgICAgICA8L21vbnRodmlldz5cbiAgICAgICAgICAgIDx3ZWVrdmlldyAqbmdTd2l0Y2hDYXNlPVwiJ3dlZWsnXCJcbiAgICAgICAgICAgICAgICBbZm9ybWF0V2Vla1RpdGxlXT1cImZvcm1hdFdlZWtUaXRsZVwiXG4gICAgICAgICAgICAgICAgW2Zvcm1hdFdlZWtWaWV3RGF5SGVhZGVyXT1cImZvcm1hdFdlZWtWaWV3RGF5SGVhZGVyXCJcbiAgICAgICAgICAgICAgICBbZm9ybWF0SG91ckNvbHVtbl09XCJmb3JtYXRIb3VyQ29sdW1uXCJcbiAgICAgICAgICAgICAgICBbc3RhcnRpbmdEYXlXZWVrXT1cInN0YXJ0aW5nRGF5V2Vla1wiXG4gICAgICAgICAgICAgICAgW2FsbERheUxhYmVsXT1cImFsbERheUxhYmVsXCJcbiAgICAgICAgICAgICAgICBbaG91clBhcnRzXT1cImhvdXJQYXJ0c1wiXG4gICAgICAgICAgICAgICAgW2F1dG9TZWxlY3RdPVwiYXV0b1NlbGVjdFwiXG4gICAgICAgICAgICAgICAgW2hvdXJTZWdtZW50c109XCJob3VyU2VnbWVudHNcIlxuICAgICAgICAgICAgICAgIFtldmVudFNvdXJjZV09XCJldmVudFNvdXJjZVwiXG4gICAgICAgICAgICAgICAgW21hcmtEaXNhYmxlZF09XCJtYXJrRGlzYWJsZWRcIlxuICAgICAgICAgICAgICAgIFt3ZWVrdmlld0hlYWRlclRlbXBsYXRlXT1cIndlZWt2aWV3SGVhZGVyVGVtcGxhdGV8fGRlZmF1bHRXZWVrdmlld0hlYWRlclRlbXBsYXRlXCJcbiAgICAgICAgICAgICAgICBbd2Vla3ZpZXdBbGxEYXlFdmVudFRlbXBsYXRlXT1cIndlZWt2aWV3QWxsRGF5RXZlbnRUZW1wbGF0ZXx8ZGVmYXVsdEFsbERheUV2ZW50VGVtcGxhdGVcIlxuICAgICAgICAgICAgICAgIFt3ZWVrdmlld05vcm1hbEV2ZW50VGVtcGxhdGVdPVwid2Vla3ZpZXdOb3JtYWxFdmVudFRlbXBsYXRlfHxkZWZhdWx0Tm9ybWFsRXZlbnRUZW1wbGF0ZVwiXG4gICAgICAgICAgICAgICAgW3dlZWt2aWV3QWxsRGF5RXZlbnRTZWN0aW9uVGVtcGxhdGVdPVwid2Vla3ZpZXdBbGxEYXlFdmVudFNlY3Rpb25UZW1wbGF0ZXx8ZGVmYXVsdFdlZWtWaWV3QWxsRGF5RXZlbnRTZWN0aW9uVGVtcGxhdGVcIlxuICAgICAgICAgICAgICAgIFt3ZWVrdmlld05vcm1hbEV2ZW50U2VjdGlvblRlbXBsYXRlXT1cIndlZWt2aWV3Tm9ybWFsRXZlbnRTZWN0aW9uVGVtcGxhdGV8fGRlZmF1bHROb3JtYWxFdmVudFNlY3Rpb25UZW1wbGF0ZVwiXG4gICAgICAgICAgICAgICAgW3dlZWt2aWV3SW5hY3RpdmVBbGxEYXlFdmVudFNlY3Rpb25UZW1wbGF0ZV09XCJ3ZWVrdmlld0luYWN0aXZlQWxsRGF5RXZlbnRTZWN0aW9uVGVtcGxhdGV8fGRlZmF1bHRJbmFjdGl2ZUFsbERheUV2ZW50U2VjdGlvblRlbXBsYXRlXCJcbiAgICAgICAgICAgICAgICBbd2Vla3ZpZXdJbmFjdGl2ZU5vcm1hbEV2ZW50U2VjdGlvblRlbXBsYXRlXT1cIndlZWt2aWV3SW5hY3RpdmVOb3JtYWxFdmVudFNlY3Rpb25UZW1wbGF0ZXx8ZGVmYXVsdEluYWN0aXZlTm9ybWFsRXZlbnRTZWN0aW9uVGVtcGxhdGVcIlxuICAgICAgICAgICAgICAgIFtsb2NhbGVdPVwibG9jYWxlXCJcbiAgICAgICAgICAgICAgICBbZGF0ZUZvcm1hdHRlcl09XCJkYXRlRm9ybWF0dGVyXCJcbiAgICAgICAgICAgICAgICBbZGlyXT1cImRpclwiXG4gICAgICAgICAgICAgICAgW3Njcm9sbFRvSG91cl09XCJzY3JvbGxUb0hvdXJcIlxuICAgICAgICAgICAgICAgIFtwcmVzZXJ2ZVNjcm9sbFBvc2l0aW9uXT1cInByZXNlcnZlU2Nyb2xsUG9zaXRpb25cIlxuICAgICAgICAgICAgICAgIFtsb2NrU3dpcGVUb1ByZXZdPVwibG9ja1N3aXBlVG9QcmV2XCJcbiAgICAgICAgICAgICAgICBbbG9ja1N3aXBlVG9OZXh0XT1cImxvY2tTd2lwZVRvTmV4dFwiXG4gICAgICAgICAgICAgICAgW2xvY2tTd2lwZXNdPVwibG9ja1N3aXBlc1wiXG4gICAgICAgICAgICAgICAgW3N0YXJ0SG91cl09XCJzdGFydEhvdXJcIlxuICAgICAgICAgICAgICAgIFtlbmRIb3VyXT1cImVuZEhvdXJcIlxuICAgICAgICAgICAgICAgIFtzbGlkZXJPcHRpb25zXT1cInNsaWRlck9wdGlvbnNcIlxuICAgICAgICAgICAgICAgIChvblJhbmdlQ2hhbmdlZCk9XCJyYW5nZUNoYW5nZWQoJGV2ZW50KVwiXG4gICAgICAgICAgICAgICAgKG9uRXZlbnRTZWxlY3RlZCk9XCJldmVudFNlbGVjdGVkKCRldmVudClcIlxuICAgICAgICAgICAgICAgIChvbkRheUhlYWRlclNlbGVjdGVkKT1cImRheVNlbGVjdGVkKCRldmVudClcIlxuICAgICAgICAgICAgICAgIChvblRpbWVTZWxlY3RlZCk9XCJ0aW1lU2VsZWN0ZWQoJGV2ZW50KVwiXG4gICAgICAgICAgICAgICAgKG9uVGl0bGVDaGFuZ2VkKT1cInRpdGxlQ2hhbmdlZCgkZXZlbnQpXCI+XG4gICAgICAgICAgICA8L3dlZWt2aWV3PlxuICAgICAgICAgICAgPGRheXZpZXcgKm5nU3dpdGNoQ2FzZT1cIidkYXknXCJcbiAgICAgICAgICAgICAgICBbZm9ybWF0RGF5VGl0bGVdPVwiZm9ybWF0RGF5VGl0bGVcIlxuICAgICAgICAgICAgICAgIFtmb3JtYXRIb3VyQ29sdW1uXT1cImZvcm1hdEhvdXJDb2x1bW5cIlxuICAgICAgICAgICAgICAgIFthbGxEYXlMYWJlbF09XCJhbGxEYXlMYWJlbFwiXG4gICAgICAgICAgICAgICAgW2hvdXJQYXJ0c109XCJob3VyUGFydHNcIlxuICAgICAgICAgICAgICAgIFtob3VyU2VnbWVudHNdPVwiaG91clNlZ21lbnRzXCJcbiAgICAgICAgICAgICAgICBbZXZlbnRTb3VyY2VdPVwiZXZlbnRTb3VyY2VcIlxuICAgICAgICAgICAgICAgIFttYXJrRGlzYWJsZWRdPVwibWFya0Rpc2FibGVkXCJcbiAgICAgICAgICAgICAgICBbZGF5dmlld0FsbERheUV2ZW50VGVtcGxhdGVdPVwiZGF5dmlld0FsbERheUV2ZW50VGVtcGxhdGV8fGRlZmF1bHRBbGxEYXlFdmVudFRlbXBsYXRlXCJcbiAgICAgICAgICAgICAgICBbZGF5dmlld05vcm1hbEV2ZW50VGVtcGxhdGVdPVwiZGF5dmlld05vcm1hbEV2ZW50VGVtcGxhdGV8fGRlZmF1bHROb3JtYWxFdmVudFRlbXBsYXRlXCJcbiAgICAgICAgICAgICAgICBbZGF5dmlld0FsbERheUV2ZW50U2VjdGlvblRlbXBsYXRlXT1cImRheXZpZXdBbGxEYXlFdmVudFNlY3Rpb25UZW1wbGF0ZXx8ZGVmYXVsdERheVZpZXdBbGxEYXlFdmVudFNlY3Rpb25UZW1wbGF0ZVwiXG4gICAgICAgICAgICAgICAgW2RheXZpZXdOb3JtYWxFdmVudFNlY3Rpb25UZW1wbGF0ZV09XCJkYXl2aWV3Tm9ybWFsRXZlbnRTZWN0aW9uVGVtcGxhdGV8fGRlZmF1bHROb3JtYWxFdmVudFNlY3Rpb25UZW1wbGF0ZVwiXG4gICAgICAgICAgICAgICAgW2RheXZpZXdJbmFjdGl2ZUFsbERheUV2ZW50U2VjdGlvblRlbXBsYXRlXT1cImRheXZpZXdJbmFjdGl2ZUFsbERheUV2ZW50U2VjdGlvblRlbXBsYXRlfHxkZWZhdWx0SW5hY3RpdmVBbGxEYXlFdmVudFNlY3Rpb25UZW1wbGF0ZVwiXG4gICAgICAgICAgICAgICAgW2RheXZpZXdJbmFjdGl2ZU5vcm1hbEV2ZW50U2VjdGlvblRlbXBsYXRlXT1cImRheXZpZXdJbmFjdGl2ZU5vcm1hbEV2ZW50U2VjdGlvblRlbXBsYXRlfHxkZWZhdWx0SW5hY3RpdmVOb3JtYWxFdmVudFNlY3Rpb25UZW1wbGF0ZVwiXG4gICAgICAgICAgICAgICAgW2xvY2FsZV09XCJsb2NhbGVcIlxuICAgICAgICAgICAgICAgIFtkYXRlRm9ybWF0dGVyXT1cImRhdGVGb3JtYXR0ZXJcIlxuICAgICAgICAgICAgICAgIFtkaXJdPVwiZGlyXCJcbiAgICAgICAgICAgICAgICBbc2Nyb2xsVG9Ib3VyXT1cInNjcm9sbFRvSG91clwiXG4gICAgICAgICAgICAgICAgW3ByZXNlcnZlU2Nyb2xsUG9zaXRpb25dPVwicHJlc2VydmVTY3JvbGxQb3NpdGlvblwiXG4gICAgICAgICAgICAgICAgW2xvY2tTd2lwZVRvUHJldl09XCJsb2NrU3dpcGVUb1ByZXZcIlxuICAgICAgICAgICAgICAgIFtsb2NrU3dpcGVUb05leHRdPVwibG9ja1N3aXBlVG9OZXh0XCJcbiAgICAgICAgICAgICAgICBbbG9ja1N3aXBlc109XCJsb2NrU3dpcGVzXCJcbiAgICAgICAgICAgICAgICBbc3RhcnRIb3VyXT1cInN0YXJ0SG91clwiXG4gICAgICAgICAgICAgICAgW2VuZEhvdXJdPVwiZW5kSG91clwiXG4gICAgICAgICAgICAgICAgW3NsaWRlck9wdGlvbnNdPVwic2xpZGVyT3B0aW9uc1wiXG4gICAgICAgICAgICAgICAgKG9uUmFuZ2VDaGFuZ2VkKT1cInJhbmdlQ2hhbmdlZCgkZXZlbnQpXCJcbiAgICAgICAgICAgICAgICAob25FdmVudFNlbGVjdGVkKT1cImV2ZW50U2VsZWN0ZWQoJGV2ZW50KVwiXG4gICAgICAgICAgICAgICAgKG9uVGltZVNlbGVjdGVkKT1cInRpbWVTZWxlY3RlZCgkZXZlbnQpXCJcbiAgICAgICAgICAgICAgICAob25UaXRsZUNoYW5nZWQpPVwidGl0bGVDaGFuZ2VkKCRldmVudClcIj5cbiAgICAgICAgICAgIDwvZGF5dmlldz5cbiAgICAgICAgPC9kaXY+XG4gICAgYCxcbiAgICBzdHlsZXM6IFtgXG4gICAgICAgIDpob3N0ID4gZGl2IHsgaGVpZ2h0OiAxMDAlOyB9XG5cbiAgICAgICAgLmV2ZW50LWRldGFpbC1jb250YWluZXIge1xuICAgICAgICAgIGJvcmRlci10b3A6IDJweCBkYXJrZ3JleSBzb2xpZDtcbiAgICAgICAgfVxuXG4gICAgICAgIC5uby1ldmVudHMtbGFiZWwge1xuICAgICAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgICAgICAgIGNvbG9yOiBkYXJrZ3JleTtcbiAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgICAgIH1cblxuICAgICAgICAuZXZlbnQtZGV0YWlsIHtcbiAgICAgICAgICBjdXJzb3I6IHBvaW50ZXI7XG4gICAgICAgICAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcbiAgICAgICAgICB0ZXh0LW92ZXJmbG93OiBlbGxpcHNpcztcbiAgICAgICAgfVxuXG4gICAgICAgIC5tb250aHZpZXctZXZlbnRkZXRhaWwtdGltZWNvbHVtbiB7XG4gICAgICAgICAgd2lkdGg6IDExMHB4O1xuICAgICAgICAgIG92ZXJmbG93OiBoaWRkZW47XG4gICAgICAgIH1cblxuICAgICAgICAuY2FsZW5kYXItZXZlbnQtaW5uZXIge1xuICAgICAgICAgIG92ZXJmbG93OiBoaWRkZW47XG4gICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogIzNhODdhZDtcbiAgICAgICAgICBjb2xvcjogd2hpdGU7XG4gICAgICAgICAgaGVpZ2h0OiAxMDAlO1xuICAgICAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgICAgIHBhZGRpbmc6IDJweDtcbiAgICAgICAgICBsaW5lLWhlaWdodDogMTVweDtcbiAgICAgICAgICB0ZXh0LWFsaWduOiBpbml0aWFsO1xuICAgICAgICB9XG5cbiAgICAgICAgQG1lZGlhIChtYXgtd2lkdGg6IDc1MHB4KSB7XG4gICAgICAgICAgLmNhbGVuZGFyLWV2ZW50LWlubmVyIHtcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMTJweDtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICBgXSxcbiAgICBwcm92aWRlcnM6IFtDYWxlbmRhclNlcnZpY2VdXG59KVxuZXhwb3J0IGNsYXNzIENhbGVuZGFyQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcbiAgICBASW5wdXQoKVxuICAgIGdldCBjdXJyZW50RGF0ZSgpOkRhdGUge1xuICAgICAgICByZXR1cm4gdGhpcy5fY3VycmVudERhdGU7XG4gICAgfVxuXG4gICAgc2V0IGN1cnJlbnREYXRlKHZhbDpEYXRlKSB7XG4gICAgICAgIGlmICghdmFsKSB7XG4gICAgICAgICAgICB2YWwgPSBuZXcgRGF0ZSgpO1xuICAgICAgICB9XG5cbiAgICAgICAgdGhpcy5fY3VycmVudERhdGUgPSB2YWw7XG4gICAgICAgIHRoaXMuY2FsZW5kYXJTZXJ2aWNlLnNldEN1cnJlbnREYXRlKHZhbCwgdHJ1ZSk7XG4gICAgICAgIHRoaXMub25DdXJyZW50RGF0ZUNoYW5nZWQuZW1pdCh0aGlzLl9jdXJyZW50RGF0ZSk7XG4gICAgfVxuXG4gICAgQElucHV0KCkgZXZlbnRTb3VyY2U6SUV2ZW50W10gPSBbXTtcbiAgICBASW5wdXQoKSBjYWxlbmRhck1vZGU6Q2FsZW5kYXJNb2RlID0gJ21vbnRoJztcbiAgICBASW5wdXQoKSBmb3JtYXREYXk6c3RyaW5nID0gJ2QnO1xuICAgIEBJbnB1dCgpIGZvcm1hdERheUhlYWRlcjpzdHJpbmcgPSAnRUVFJztcbiAgICBASW5wdXQoKSBmb3JtYXREYXlUaXRsZTpzdHJpbmcgPSAnTU1NTSBkZCwgeXl5eSc7XG4gICAgQElucHV0KCkgZm9ybWF0V2Vla1RpdGxlOnN0cmluZyA9ICdNTU1NIHl5eXksIFxcJ1dlZWtcXCcgdyc7XG4gICAgQElucHV0KCkgZm9ybWF0TW9udGhUaXRsZTpzdHJpbmcgPSAnTU1NTSB5eXl5JztcbiAgICBASW5wdXQoKSBmb3JtYXRXZWVrVmlld0RheUhlYWRlcjpzdHJpbmcgPSAnRUVFIGQnO1xuICAgIEBJbnB1dCgpIGZvcm1hdEhvdXJDb2x1bW46c3RyaW5nID0gJ2hhJztcbiAgICBASW5wdXQoKSBzaG93RXZlbnREZXRhaWw6Ym9vbGVhbiA9IHRydWU7XG4gICAgQElucHV0KCkgc3RhcnRpbmdEYXlNb250aDpudW1iZXIgPSAwO1xuICAgIEBJbnB1dCgpIHN0YXJ0aW5nRGF5V2VlazpudW1iZXIgPSAwO1xuICAgIEBJbnB1dCgpIGFsbERheUxhYmVsOnN0cmluZyA9ICdhbGwgZGF5JztcbiAgICBASW5wdXQoKSBub0V2ZW50c0xhYmVsOnN0cmluZyA9ICdObyBFdmVudHMnO1xuICAgIEBJbnB1dCgpIHF1ZXJ5TW9kZTpRdWVyeU1vZGUgPSAnbG9jYWwnO1xuICAgIEBJbnB1dCgpIHN0ZXA6U3RlcCA9IFN0ZXAuSG91cjtcbiAgICBASW5wdXQoKSB0aW1lSW50ZXJ2YWw6bnVtYmVyID0gNjA7XG4gICAgQElucHV0KCkgYXV0b1NlbGVjdDpib29sZWFuID0gdHJ1ZTtcbiAgICBASW5wdXQoKSBtYXJrRGlzYWJsZWQ6KGRhdGU6RGF0ZSkgPT4gYm9vbGVhbjtcbiAgICBASW5wdXQoKSBtb250aHZpZXdEaXNwbGF5RXZlbnRUZW1wbGF0ZTpUZW1wbGF0ZVJlZjxJTW9udGhWaWV3RGlzcGxheUV2ZW50VGVtcGxhdGVDb250ZXh0PjtcbiAgICBASW5wdXQoKSBtb250aHZpZXdJbmFjdGl2ZURpc3BsYXlFdmVudFRlbXBsYXRlOlRlbXBsYXRlUmVmPElNb250aFZpZXdEaXNwbGF5RXZlbnRUZW1wbGF0ZUNvbnRleHQ+O1xuICAgIEBJbnB1dCgpIG1vbnRodmlld0V2ZW50RGV0YWlsVGVtcGxhdGU6VGVtcGxhdGVSZWY8SU1vbnRoVmlld0V2ZW50RGV0YWlsVGVtcGxhdGVDb250ZXh0PjtcbiAgICBASW5wdXQoKSB3ZWVrdmlld0hlYWRlclRlbXBsYXRlOlRlbXBsYXRlUmVmPElEaXNwbGF5V2Vla1ZpZXdIZWFkZXI+O1xuICAgIEBJbnB1dCgpIHdlZWt2aWV3QWxsRGF5RXZlbnRUZW1wbGF0ZTpUZW1wbGF0ZVJlZjxJRGlzcGxheUFsbERheUV2ZW50PjtcbiAgICBASW5wdXQoKSB3ZWVrdmlld05vcm1hbEV2ZW50VGVtcGxhdGU6VGVtcGxhdGVSZWY8SURpc3BsYXlFdmVudD47XG4gICAgQElucHV0KCkgZGF5dmlld0FsbERheUV2ZW50VGVtcGxhdGU6VGVtcGxhdGVSZWY8SURpc3BsYXlBbGxEYXlFdmVudD47XG4gICAgQElucHV0KCkgZGF5dmlld05vcm1hbEV2ZW50VGVtcGxhdGU6VGVtcGxhdGVSZWY8SURpc3BsYXlFdmVudD47XG4gICAgQElucHV0KCkgd2Vla3ZpZXdBbGxEYXlFdmVudFNlY3Rpb25UZW1wbGF0ZTpUZW1wbGF0ZVJlZjxJV2Vla1ZpZXdBbGxEYXlFdmVudFNlY3Rpb25UZW1wbGF0ZUNvbnRleHQ+O1xuICAgIEBJbnB1dCgpIHdlZWt2aWV3Tm9ybWFsRXZlbnRTZWN0aW9uVGVtcGxhdGU6VGVtcGxhdGVSZWY8SVdlZWtWaWV3Tm9ybWFsRXZlbnRTZWN0aW9uVGVtcGxhdGVDb250ZXh0PjtcbiAgICBASW5wdXQoKSBkYXl2aWV3QWxsRGF5RXZlbnRTZWN0aW9uVGVtcGxhdGU6VGVtcGxhdGVSZWY8SURheVZpZXdBbGxEYXlFdmVudFNlY3Rpb25UZW1wbGF0ZUNvbnRleHQ+O1xuICAgIEBJbnB1dCgpIGRheXZpZXdOb3JtYWxFdmVudFNlY3Rpb25UZW1wbGF0ZTpUZW1wbGF0ZVJlZjxJRGF5Vmlld05vcm1hbEV2ZW50U2VjdGlvblRlbXBsYXRlQ29udGV4dD47XG4gICAgQElucHV0KCkgd2Vla3ZpZXdJbmFjdGl2ZUFsbERheUV2ZW50U2VjdGlvblRlbXBsYXRlOlRlbXBsYXRlUmVmPElXZWVrVmlld0FsbERheUV2ZW50U2VjdGlvblRlbXBsYXRlQ29udGV4dD47XG4gICAgQElucHV0KCkgd2Vla3ZpZXdJbmFjdGl2ZU5vcm1hbEV2ZW50U2VjdGlvblRlbXBsYXRlOlRlbXBsYXRlUmVmPElXZWVrVmlld05vcm1hbEV2ZW50U2VjdGlvblRlbXBsYXRlQ29udGV4dD47XG4gICAgQElucHV0KCkgZGF5dmlld0luYWN0aXZlQWxsRGF5RXZlbnRTZWN0aW9uVGVtcGxhdGU6VGVtcGxhdGVSZWY8SURheVZpZXdBbGxEYXlFdmVudFNlY3Rpb25UZW1wbGF0ZUNvbnRleHQ+O1xuICAgIEBJbnB1dCgpIGRheXZpZXdJbmFjdGl2ZU5vcm1hbEV2ZW50U2VjdGlvblRlbXBsYXRlOlRlbXBsYXRlUmVmPElEYXlWaWV3Tm9ybWFsRXZlbnRTZWN0aW9uVGVtcGxhdGVDb250ZXh0PjtcbiAgICBASW5wdXQoKSBkYXRlRm9ybWF0dGVyOklEYXRlRm9ybWF0dGVyO1xuICAgIEBJbnB1dCgpIGRpcjpzdHJpbmcgPSBcIlwiO1xuICAgIEBJbnB1dCgpIHNjcm9sbFRvSG91cjpudW1iZXIgPSAwO1xuICAgIEBJbnB1dCgpIHByZXNlcnZlU2Nyb2xsUG9zaXRpb246Ym9vbGVhbiA9IGZhbHNlO1xuICAgIEBJbnB1dCgpIGxvY2tTd2lwZVRvUHJldjpib29sZWFuID0gZmFsc2U7XG4gICAgQElucHV0KCkgbG9ja1N3aXBlVG9OZXh0OmJvb2xlYW4gPSBmYWxzZTtcbiAgICBASW5wdXQoKSBsb2NrU3dpcGVzOmJvb2xlYW4gPSBmYWxzZTtcbiAgICBASW5wdXQoKSBsb2NhbGU6c3RyaW5nID0gXCJcIjtcbiAgICBASW5wdXQoKSBzdGFydEhvdXI6bnVtYmVyID0gMDtcbiAgICBASW5wdXQoKSBlbmRIb3VyOm51bWJlciA9IDI0O1xuICAgIEBJbnB1dCgpIHNsaWRlck9wdGlvbnM6YW55O1xuXG4gICAgQE91dHB1dCgpIG9uQ3VycmVudERhdGVDaGFuZ2VkID0gbmV3IEV2ZW50RW1pdHRlcjxEYXRlPigpO1xuICAgIEBPdXRwdXQoKSBvblJhbmdlQ2hhbmdlZCA9IG5ldyBFdmVudEVtaXR0ZXI8SVJhbmdlPigpO1xuICAgIEBPdXRwdXQoKSBvbkV2ZW50U2VsZWN0ZWQgPSBuZXcgRXZlbnRFbWl0dGVyPElFdmVudD4oKTtcbiAgICBAT3V0cHV0KCkgb25UaW1lU2VsZWN0ZWQgPSBuZXcgRXZlbnRFbWl0dGVyPElUaW1lU2VsZWN0ZWQ+KCk7XG4gICAgQE91dHB1dCgpIG9uRGF5SGVhZGVyU2VsZWN0ZWQgPSBuZXcgRXZlbnRFbWl0dGVyPElUaW1lU2VsZWN0ZWQ+KCk7XG4gICAgQE91dHB1dCgpIG9uVGl0bGVDaGFuZ2VkID0gbmV3IEV2ZW50RW1pdHRlcjxzdHJpbmc+KCk7XG5cbiAgICBwcml2YXRlIF9jdXJyZW50RGF0ZTpEYXRlO1xuICAgIHB1YmxpYyBob3VyUGFydHMgPSAxO1xuICAgIHB1YmxpYyBob3VyU2VnbWVudHMgPSAxO1xuICAgIHByaXZhdGUgY3VycmVudERhdGVDaGFuZ2VkRnJvbUNoaWxkcmVuU3Vic2NyaXB0aW9uOlN1YnNjcmlwdGlvbjtcblxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgY2FsZW5kYXJTZXJ2aWNlOkNhbGVuZGFyU2VydmljZSwgQEluamVjdChMT0NBTEVfSUQpIHByaXZhdGUgYXBwTG9jYWxlOnN0cmluZykge1xuICAgICAgICB0aGlzLmxvY2FsZSA9IGFwcExvY2FsZTtcbiAgICB9XG5cbiAgICBuZ09uSW5pdCgpIHtcbiAgICAgICAgaWYgKHRoaXMuYXV0b1NlbGVjdCkge1xuICAgICAgICAgICAgaWYgKHRoaXMuYXV0b1NlbGVjdC50b1N0cmluZygpID09PSAnZmFsc2UnKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5hdXRvU2VsZWN0ID0gZmFsc2U7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHRoaXMuYXV0b1NlbGVjdCA9IHRydWU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5ob3VyU2VnbWVudHMgPSA2MCAvIHRoaXMudGltZUludGVydmFsO1xuICAgICAgICB0aGlzLmhvdXJQYXJ0cyA9IDYwIC8gdGhpcy5zdGVwO1xuICAgICAgICBpZih0aGlzLmhvdXJQYXJ0cyA8PSB0aGlzLmhvdXJTZWdtZW50cykge1xuICAgICAgICAgICAgdGhpcy5ob3VyUGFydHMgPSAxO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5ob3VyUGFydHMgPSB0aGlzLmhvdXJQYXJ0cyAvIHRoaXMuaG91clNlZ21lbnRzO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuc3RhcnRIb3VyID0gcGFyc2VJbnQodGhpcy5zdGFydEhvdXIudG9TdHJpbmcoKSk7XG4gICAgICAgIHRoaXMuZW5kSG91ciA9IHBhcnNlSW50KHRoaXMuZW5kSG91ci50b1N0cmluZygpKTtcbiAgICAgICAgdGhpcy5jYWxlbmRhclNlcnZpY2UucXVlcnlNb2RlID0gdGhpcy5xdWVyeU1vZGU7XG5cbiAgICAgICAgdGhpcy5jdXJyZW50RGF0ZUNoYW5nZWRGcm9tQ2hpbGRyZW5TdWJzY3JpcHRpb24gPSB0aGlzLmNhbGVuZGFyU2VydmljZS5jdXJyZW50RGF0ZUNoYW5nZWRGcm9tQ2hpbGRyZW4kLnN1YnNjcmliZShjdXJyZW50RGF0ZSA9PiB7XG4gICAgICAgICAgICB0aGlzLl9jdXJyZW50RGF0ZSA9IGN1cnJlbnREYXRlO1xuICAgICAgICAgICAgdGhpcy5vbkN1cnJlbnREYXRlQ2hhbmdlZC5lbWl0KGN1cnJlbnREYXRlKTtcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgbmdPbkRlc3Ryb3koKSB7XG4gICAgICAgIGlmICh0aGlzLmN1cnJlbnREYXRlQ2hhbmdlZEZyb21DaGlsZHJlblN1YnNjcmlwdGlvbikge1xuICAgICAgICAgICAgdGhpcy5jdXJyZW50RGF0ZUNoYW5nZWRGcm9tQ2hpbGRyZW5TdWJzY3JpcHRpb24udW5zdWJzY3JpYmUoKTtcbiAgICAgICAgICAgIHRoaXMuY3VycmVudERhdGVDaGFuZ2VkRnJvbUNoaWxkcmVuU3Vic2NyaXB0aW9uID0gbnVsbDtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIHJhbmdlQ2hhbmdlZChyYW5nZTpJUmFuZ2UpIHtcbiAgICAgICAgdGhpcy5vblJhbmdlQ2hhbmdlZC5lbWl0KHJhbmdlKTtcbiAgICB9XG5cbiAgICBldmVudFNlbGVjdGVkKGV2ZW50OklFdmVudCkge1xuICAgICAgICB0aGlzLm9uRXZlbnRTZWxlY3RlZC5lbWl0KGV2ZW50KTtcbiAgICB9XG5cbiAgICB0aW1lU2VsZWN0ZWQodGltZVNlbGVjdGVkOklUaW1lU2VsZWN0ZWQpIHtcbiAgICAgICAgdGhpcy5vblRpbWVTZWxlY3RlZC5lbWl0KHRpbWVTZWxlY3RlZCk7XG4gICAgfVxuXG4gICAgZGF5U2VsZWN0ZWQoZGF5U2VsZWN0ZWQ6SVRpbWVTZWxlY3RlZCkge1xuICAgICAgICB0aGlzLm9uRGF5SGVhZGVyU2VsZWN0ZWQuZW1pdChkYXlTZWxlY3RlZCk7XG4gICAgfVxuXG4gICAgdGl0bGVDaGFuZ2VkKHRpdGxlOnN0cmluZykge1xuICAgICAgICB0aGlzLm9uVGl0bGVDaGFuZ2VkLmVtaXQodGl0bGUpO1xuICAgIH1cblxuICAgIGxvYWRFdmVudHMoKSB7XG4gICAgICAgIHRoaXMuY2FsZW5kYXJTZXJ2aWNlLmxvYWRFdmVudHMoKTtcbiAgICB9XG5cbiAgICBzbGlkZU5leHQoKSB7XG4gICAgICAgIHRoaXMuY2FsZW5kYXJTZXJ2aWNlLnNsaWRlKDEpO1xuICAgIH1cblxuICAgIHNsaWRlUHJldigpIHtcbiAgICAgICAgdGhpcy5jYWxlbmRhclNlcnZpY2Uuc2xpZGUoLTEpO1xuICAgIH1cblxuICAgIHVwZGF0ZSgpIHtcbiAgICAgICAgdGhpcy5jYWxlbmRhclNlcnZpY2UudXBkYXRlKCk7XG4gICAgfVxufVxuIl19