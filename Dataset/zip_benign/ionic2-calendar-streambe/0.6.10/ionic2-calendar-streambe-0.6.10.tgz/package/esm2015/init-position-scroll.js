import { Component, Input, Output, EventEmitter, ElementRef, ViewEncapsulation } from '@angular/core';
export class initPositionScrollComponent {
    constructor(el) {
        this.onScroll = new EventEmitter();
        this.listenerAttached = false;
        this.element = el;
    }
    ngOnChanges(changes) {
        let initPosition = changes['initPosition'];
        if (initPosition && initPosition.currentValue !== undefined && this.scrollContent) {
            const me = this;
            setTimeout(function () {
                me.scrollContent.scrollTop = initPosition.currentValue;
            }, 0);
        }
    }
    ngAfterViewInit() {
        const scrollContent = this.scrollContent = this.element.nativeElement.querySelector('.scroll-content');
        if (this.initPosition !== undefined) {
            scrollContent.scrollTop = this.initPosition;
        }
        if (this.emitEvent && !this.listenerAttached) {
            let onScroll = this.onScroll;
            this.handler = function () {
                onScroll.emit(scrollContent.scrollTop);
            };
            this.listenerAttached = true;
            scrollContent.addEventListener('scroll', this.handler);
        }
    }
    ngOnDestroy() {
        if (this.listenerAttached) {
            this.scrollContent.removeEventListener('scroll', this.handler);
        }
    }
}
initPositionScrollComponent.decorators = [
    { type: Component, args: [{
                selector: 'init-position-scroll',
                template: `
        <div class="scroll-content" style="height:100%">
            <ng-content></ng-content>
        </div>
    `,
                encapsulation: ViewEncapsulation.None,
                styles: [`
        .scroll-content {
            overflow-y: auto;
            overflow-x: hidden;
        }        
    `]
            },] }
];
initPositionScrollComponent.ctorParameters = () => [
    { type: ElementRef }
];
initPositionScrollComponent.propDecorators = {
    initPosition: [{ type: Input }],
    emitEvent: [{ type: Input }],
    onScroll: [{ type: Output }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5pdC1wb3NpdGlvbi1zY3JvbGwuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9zcmMvaW5pdC1wb3NpdGlvbi1zY3JvbGwudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUNILFNBQVMsRUFDVCxLQUFLLEVBQ0wsTUFBTSxFQUNOLFlBQVksRUFDWixVQUFVLEVBS1YsaUJBQWlCLEVBQ3BCLE1BQU0sZUFBZSxDQUFDO0FBaUJ2QixNQUFNLE9BQU8sMkJBQTJCO0lBVXBDLFlBQVksRUFBYTtRQVBmLGFBQVEsR0FBRyxJQUFJLFlBQVksRUFBVSxDQUFDO1FBS3hDLHFCQUFnQixHQUFXLEtBQUssQ0FBQztRQUdyQyxJQUFJLENBQUMsT0FBTyxHQUFHLEVBQUUsQ0FBQztJQUN0QixDQUFDO0lBRUQsV0FBVyxDQUFDLE9BQXFCO1FBQzdCLElBQUksWUFBWSxHQUFHLE9BQU8sQ0FBQyxjQUFjLENBQUMsQ0FBQztRQUMzQyxJQUFJLFlBQVksSUFBSSxZQUFZLENBQUMsWUFBWSxLQUFLLFNBQVMsSUFBSSxJQUFJLENBQUMsYUFBYSxFQUFFO1lBQy9FLE1BQU0sRUFBRSxHQUFFLElBQUksQ0FBQztZQUNmLFVBQVUsQ0FBQztnQkFDUCxFQUFFLENBQUMsYUFBYSxDQUFDLFNBQVMsR0FBRyxZQUFZLENBQUMsWUFBWSxDQUFDO1lBQzNELENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztTQUNUO0lBQ0wsQ0FBQztJQUVELGVBQWU7UUFDWCxNQUFNLGFBQWEsR0FBRyxJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO1FBQ3ZHLElBQUksSUFBSSxDQUFDLFlBQVksS0FBSyxTQUFTLEVBQUU7WUFDakMsYUFBYSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDO1NBQy9DO1FBRUQsSUFBSSxJQUFJLENBQUMsU0FBUyxJQUFJLENBQUMsSUFBSSxDQUFDLGdCQUFnQixFQUFFO1lBQzFDLElBQUksUUFBUSxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUM7WUFDN0IsSUFBSSxDQUFDLE9BQU8sR0FBRztnQkFDWCxRQUFRLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUMsQ0FBQztZQUMzQyxDQUFDLENBQUM7WUFDRixJQUFJLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDO1lBQzdCLGFBQWEsQ0FBQyxnQkFBZ0IsQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1NBQzFEO0lBQ0wsQ0FBQztJQUVELFdBQVc7UUFDUCxJQUFJLElBQUksQ0FBQyxnQkFBZ0IsRUFBRTtZQUN2QixJQUFJLENBQUMsYUFBYSxDQUFDLG1CQUFtQixDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7U0FDbEU7SUFDTCxDQUFDOzs7WUEzREosU0FBUyxTQUFDO2dCQUNQLFFBQVEsRUFBRSxzQkFBc0I7Z0JBQ2hDLFFBQVEsRUFBRTs7OztLQUlUO2dCQU9ELGFBQWEsRUFBRSxpQkFBaUIsQ0FBQyxJQUFJO3lCQU41Qjs7Ozs7S0FLUjthQUVKOzs7WUF0QkcsVUFBVTs7OzJCQXdCVCxLQUFLO3dCQUNMLEtBQUs7dUJBQ0wsTUFBTSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG4gICAgQ29tcG9uZW50LFxuICAgIElucHV0LFxuICAgIE91dHB1dCxcbiAgICBFdmVudEVtaXR0ZXIsXG4gICAgRWxlbWVudFJlZixcbiAgICBTaW1wbGVDaGFuZ2VzLFxuICAgIE9uQ2hhbmdlcyxcbiAgICBBZnRlclZpZXdJbml0LFxuICAgIE9uRGVzdHJveSxcbiAgICBWaWV3RW5jYXBzdWxhdGlvblxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdpbml0LXBvc2l0aW9uLXNjcm9sbCcsXG4gICAgdGVtcGxhdGU6IGBcbiAgICAgICAgPGRpdiBjbGFzcz1cInNjcm9sbC1jb250ZW50XCIgc3R5bGU9XCJoZWlnaHQ6MTAwJVwiPlxuICAgICAgICAgICAgPG5nLWNvbnRlbnQ+PC9uZy1jb250ZW50PlxuICAgICAgICA8L2Rpdj5cbiAgICBgLFxuICAgIHN0eWxlczogW2BcbiAgICAgICAgLnNjcm9sbC1jb250ZW50IHtcbiAgICAgICAgICAgIG92ZXJmbG93LXk6IGF1dG87XG4gICAgICAgICAgICBvdmVyZmxvdy14OiBoaWRkZW47XG4gICAgICAgIH0gICAgICAgIFxuICAgIGBdLFxuICAgIGVuY2Fwc3VsYXRpb246IFZpZXdFbmNhcHN1bGF0aW9uLk5vbmVcbn0pXG5leHBvcnQgY2xhc3MgaW5pdFBvc2l0aW9uU2Nyb2xsQ29tcG9uZW50IGltcGxlbWVudHMgT25DaGFuZ2VzLCBBZnRlclZpZXdJbml0LCBPbkRlc3Ryb3kge1xuICAgIEBJbnB1dCgpIGluaXRQb3NpdGlvbjpudW1iZXI7XG4gICAgQElucHV0KCkgZW1pdEV2ZW50OmJvb2xlYW47XG4gICAgQE91dHB1dCgpIG9uU2Nyb2xsID0gbmV3IEV2ZW50RW1pdHRlcjxudW1iZXI+KCk7XG5cbiAgICBwcml2YXRlIGVsZW1lbnQ6RWxlbWVudFJlZjtcbiAgICBwcml2YXRlIHNjcm9sbENvbnRlbnQ6SFRNTEVsZW1lbnQ7XG4gICAgcHJpdmF0ZSBoYW5kbGVyOigpPT52b2lkO1xuICAgIHByaXZhdGUgbGlzdGVuZXJBdHRhY2hlZDpib29sZWFuID0gZmFsc2U7XG5cbiAgICBjb25zdHJ1Y3RvcihlbDpFbGVtZW50UmVmKSB7XG4gICAgICAgIHRoaXMuZWxlbWVudCA9IGVsO1xuICAgIH1cblxuICAgIG5nT25DaGFuZ2VzKGNoYW5nZXM6U2ltcGxlQ2hhbmdlcykge1xuICAgICAgICBsZXQgaW5pdFBvc2l0aW9uID0gY2hhbmdlc1snaW5pdFBvc2l0aW9uJ107XG4gICAgICAgIGlmIChpbml0UG9zaXRpb24gJiYgaW5pdFBvc2l0aW9uLmN1cnJlbnRWYWx1ZSAhPT0gdW5kZWZpbmVkICYmIHRoaXMuc2Nyb2xsQ29udGVudCkge1xuICAgICAgICAgICAgY29uc3QgbWUgPXRoaXM7XG4gICAgICAgICAgICBzZXRUaW1lb3V0KGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgICAgIG1lLnNjcm9sbENvbnRlbnQuc2Nyb2xsVG9wID0gaW5pdFBvc2l0aW9uLmN1cnJlbnRWYWx1ZTtcbiAgICAgICAgICAgIH0sIDApO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgbmdBZnRlclZpZXdJbml0KCkge1xuICAgICAgICBjb25zdCBzY3JvbGxDb250ZW50ID0gdGhpcy5zY3JvbGxDb250ZW50ID0gdGhpcy5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvcignLnNjcm9sbC1jb250ZW50Jyk7XG4gICAgICAgIGlmICh0aGlzLmluaXRQb3NpdGlvbiAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICBzY3JvbGxDb250ZW50LnNjcm9sbFRvcCA9IHRoaXMuaW5pdFBvc2l0aW9uO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKHRoaXMuZW1pdEV2ZW50ICYmICF0aGlzLmxpc3RlbmVyQXR0YWNoZWQpIHtcbiAgICAgICAgICAgIGxldCBvblNjcm9sbCA9IHRoaXMub25TY3JvbGw7XG4gICAgICAgICAgICB0aGlzLmhhbmRsZXIgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgb25TY3JvbGwuZW1pdChzY3JvbGxDb250ZW50LnNjcm9sbFRvcCk7XG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgdGhpcy5saXN0ZW5lckF0dGFjaGVkID0gdHJ1ZTtcbiAgICAgICAgICAgIHNjcm9sbENvbnRlbnQuYWRkRXZlbnRMaXN0ZW5lcignc2Nyb2xsJywgdGhpcy5oYW5kbGVyKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIG5nT25EZXN0cm95KCkge1xuICAgICAgICBpZiAodGhpcy5saXN0ZW5lckF0dGFjaGVkKSB7XG4gICAgICAgICAgICB0aGlzLnNjcm9sbENvbnRlbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcignc2Nyb2xsJywgdGhpcy5oYW5kbGVyKTtcbiAgICAgICAgfVxuICAgIH1cbn1cbiJdfQ==