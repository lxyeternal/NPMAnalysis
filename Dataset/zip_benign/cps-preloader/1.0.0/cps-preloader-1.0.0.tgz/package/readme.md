# Preloader Web Component

## Install

```bash
npm install cps-preloader
```

## Usage

```html
<cps-preloader-circle></cps-preloader-circle>
```

## Properties

| Property   | Attribute  | Description | Type     | Default     |
| ---------- | ---------- | ----------- | -------- | ----------- |
| `color`    | `color`    |             | `string` | `'#de7c0c'` |
| `duration` | `duration` |             | `string` | `'0.7s'`    |
| `opacity`  | `opacity`  |             | `string` | `'0.4'`     |
| `size`     | `size`     |             | `number` | `60`        |

## Browser compatibility

- Chrome
- Edge
- Firefox
- Safari
- Opera

## Changelog

### 1.0.0

- **Release 11.05.2020**

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
