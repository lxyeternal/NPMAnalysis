// This basic example shows how to parse a phyloXML formatted String
// into to a object representing a phylogenetic tree.
// Followed by printing some elements and then converting the object
// back to a phyloXML formatted String.
// phyloXML website: http://www.phyloxml.org/
//
// Change './phyloxml' to 'phyloxml' if you use this code outside of this package

var phyloXml = require('./phyloxml').phyloXml;

phlyoXmlFormattedString = '<phyloxml xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" ' +
    'xmlns="http://www.phyloxml.org" ' +
    'xsi:schemaLocation="http://www.phyloxml.org http://www.phyloxml.org/1.10/phyloxml.xsd">' +
    '<phylogeny rooted="true" rerootable="false">' +
    '<clade><branch_length>0.2</branch_length>' +
    '<clade><branch_length>0.4</branch_length><name>A</name></clade>' +
    '<clade><branch_length>0.6</branch_length><name>B</name></clade>' +
    '</clade>' +
    '</phylogeny>' +
    '</phyloxml>';

var phylogeneticTree = phyloXml.parse(phlyoXmlFormattedString, {trim: true, normalize: true})[0];

console.log('Root branch length  : ' + phylogeneticTree.children[0].branch_length);
console.log('Node A name         : ' + phylogeneticTree.children[0].children[0].name);
console.log('Node A branch length: ' + phylogeneticTree.children[0].children[0].branch_length);
console.log('Node B name         : ' + phylogeneticTree.children[0].children[1].name);
console.log('Node B branch length: ' + phylogeneticTree.children[0].children[1].branch_length);

console.log('Entire tree in phyloXML format:');
console.log(phyloXml.toPhyloXML(phylogeneticTree, 4));
