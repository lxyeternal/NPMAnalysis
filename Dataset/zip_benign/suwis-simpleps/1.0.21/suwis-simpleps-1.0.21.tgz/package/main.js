import Simpleps from './index'
window.Simpleps = Simpleps
