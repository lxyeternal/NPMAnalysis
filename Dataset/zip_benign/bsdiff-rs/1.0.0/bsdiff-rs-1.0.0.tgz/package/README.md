# bsdiff-rs
> Using rust to implement an binary diff and patch library based on bsdiff algorithm for NodeJS (Windows, Mac, Linux).

<br>
<hr>
<p align="center">
If you find this package useful, please don't forget to star ⭐️ the repo, as this will help to promote the project.<br>
</p>
<hr>


## Installation

Install as a dependency for your project:

```bash
npm i bsdiff-rs
```

## Usage

```javascript
const bsdiff = require('bsdiff-rs');
bsdiff.diff(oldFile, newFile, patchFile); // Async
bsdiff.patch(oldfile, newfile, patchfile); // Async
```

For example:

```javascript
const path = require('path');

const oldFile = path.join(__dirname, 'resources/react-0.3-stable.zip');
const newFile = path.join(__dirname, 'resources/react-0.4-stable.zip');
const patchFile = path.join(__dirname, 'resources/react.patch');
const generatedFile = path.join(__dirname, 'resources/react-generated.zip');

async function asyncCall() {
    await bsdiff.diff(oldFile, newFile, patchFile);

    await bsdiff.patch(oldFile, generatedFile, patchFile);
}
  
asyncCall();
```

Copyright 2003-2005 Colin Percival  
MIT © Dezeiraud
