/**
 * asynchronous Generate incremental files by file comparison
 *
 * @param oldFile old file path
 * @param newFile new file path
 * @param patchFile will ceated patch file path
 *
 * example:
 * ```js
 *  await bsdiff.diff(oldFile, newFile, patchFile);
 * ```
 */
export function diff(
  oldFile: string,
  newFile: string,
  patchFile: string
): Promise<boolean>;

/**
 * asynchronous generate target files from delta files and old version files
 *
 * @param oldFile old file path
 * @param generatedFile will ceated target file path
 * @param patchFile patch file path
 *
 * example:
 * ```js
 *  bsdiff.patch(oldfile, generatedFile, patchfile);
 * ```
 */
export function patch(
  oldFile: string,
  generatedFile: string,
  patchFile: string
): Promise<boolean>;
