const { diff, patch } = require("./index.node");

exports.diff = (oldFile, newFile, patchFile) => {
  if (!oldFile || !newFile || !patchFile) {
    return Promise.reject("parameter error");
  }
  return new Promise((resolve, reject) => {
    try {
      diff(oldFile, newFile, patchFile, function (err) {
        err ? reject(err) : resolve(true);
      });
    } catch (error) {
      reject(error);
    }
  });
};

exports.patch = (oldFile, generatedFile, patchFile) => {
  if (!oldFile || !generatedFile || !patchFile) {
    return Promise.reject("parameter error");
  }
  return new Promise((resolve, reject) => {
    try {
      patch(oldFile, generatedFile, patchFile, function (err) {
        err ? reject(err) : resolve(true);
      });
    } catch (error) {
      console.log("error: ", error);
      reject(error);
    }
  });
};
