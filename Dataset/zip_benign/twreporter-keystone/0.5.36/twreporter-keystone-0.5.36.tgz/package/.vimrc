" Modeline and Notes {
" vim: set sw=4 ts=4 sts=4 et tw=78 foldmarker={,} foldlevel=0 foldmethod=marker spell:
"
"   This is the personal .vimrc file inspired by Steve Francia(http://spf13.com).
" }

" Environment {

    " Basics {
        set nocompatible        " Must be first line
    " }

    " Windows Compatible {
        " On Windows, also use '.vim' instead of 'vimfiles'; this makes synchronization
        " across (heterogeneous) systems easier.
        if has('win32') || has('win64')
          set runtimepath=$HOME/.vim,$VIM/vimfiles,$VIMRUNTIME,$VIM/vimfiles/after,$HOME/.vim/after
        endif
    " }
" }

" Bundles {

    " setup bundles{
        let g:vundle_default_git_proto = 'git'
        filetype off
        set rtp+=~/.vim/bundle/Vundle.vim
        call vundle#begin()
        " Bundles {
        " list only the plugin groups you will use
        if !exists('g:Plugin_groups')
            let g:Plugin_groups=['general', 'snipmate', 'programming', 'javascript', 'misc', 'html', 'git']
        endif

        " general
        if count(g:Plugin_groups, 'general')
            " let Vundle manage Vundle, required
            Plugin 'VundleVim/Vundle.vim'
            Plugin 'vim-scripts/the-nerd-tree'
            Plugin 'altercation/vim-colors-solarized'
            Plugin 'vim-scripts/ctrlp.vim'
            Plugin 'vim-scripts/matchit.zip'
            Plugin 'lokaltog/vim-powerline'
            Plugin 'vim-scripts/csapprox'
            Plugin 'jistr/vim-nerdtree-tabs'
            Plugin 'bootleq/vim-tabline'
        endif

        " general programming
        if count(g:Plugin_groups, 'programming')
            Plugin 'vim-scripts/checksyntax-b'
            Plugin 'vim-scripts/easygrep'
            if executable('ctags')
                Plugin 'vim-scripts/tagbar'
                Plugin 'vim-scripts/srcexpl'
            endif

            Plugin 'scrooloose/syntastic'

        endif

        " snippets & autocomplete
        if count(g:Plugin_groups, 'snipmate')
            Plugin 'ervandew/supertab'

            " vim-react-snippets:
            Plugin 'bentayloruk/vim-react-es6-snippets'
            Plugin 'justinj/vim-react-snippets'

            " SnipMate and its dependencies:
            Plugin 'MarcWeber/vim-addon-mw-utils'
            Plugin 'tomtom/tlib_vim'
            Plugin 'garbas/vim-snipmate'
            
        endif

        " javascript
        if count(g:Plugin_groups, 'javascript')
            Plugin 'maksimr/vim-jsbeautify'
            Plugin 'einars/js-beautify'
            Plugin 'mxw/vim-jsx'
            Plugin 'pangloss/vim-javascript'
        endif

        " html
        if count(g:Plugin_groups, 'html')
            Plugin 'hail2u/vim-css3-syntax'
            Plugin 'mattn/emmet-vim'
            Plugin 'amirh/html-autoclosetag'
        endif
        " git
        if count(g:Plugin_groups, 'git')
            Plugin 'tpope/vim-fugitive'
        endif
        " misc
        if count(g:Plugin_groups, 'misc')
        endif
        " }

        call vundle#end()            " required
        filetype plugin indent on 
    " }
" }

" General {

    set background=dark         " Assume a dark background
    if !has('gui')
        "set term=$TERM          " Make arrow and other keys work
    endif
    filetype plugin indent on   " Automatically detect file types.
    syntax on                   " Syntax highlighting
    set noswapfile              " Disable swap file.
    set mousehide               " Hide the mouse cursor while typing
    scriptencoding utf-8

    if has ('x') && has ('gui') " On Linux use + register for copy-paste
        set clipboard=unnamedplus
    elseif has ('gui')          " On mac and Windows, use * register for copy-paste
        set clipboard=unnamed
    endif

    set shortmess+=filmnrxoOtT          " Abbrev. of messages (avoids 'hit enter')
    set viewoptions=folds,options,cursor,unix,slash " Better Unix / Windows compatibility

" }

" Vim UI {

    if filereadable(expand("~/.vim/bundle/vim-colors-solarized/colors/solarized.vim"))
        let g:solarized_termcolors=256
        color solarized                 " Load a colorscheme
    endif
        let g:solarized_termtrans=1
        let g:solarized_contrast="high"
        let g:solarized_visibility="high"
    set tabpagemax=15               " Only show 15 tabs
    set showmode                    " Display the current mode

    set cursorline                  " Highlight current line

    if has('cmdline_info')
        set ruler                   " Show the ruler
        set rulerformat=%30(%=\:b%n%y%m%r%w\ %l,%c%V\ %P%) " A ruler on steroids
        set showcmd                 " Show partial commands in status line and
                                    " Selected characters/lines in visual mode
    endif

    if has('statusline')
        set laststatus=2

        " Broken down into easily includeable segments
        set statusline=%<%f\                     " Filename
        set statusline+=%w%h%m%r                 " Options
        set statusline+=\ [%{&ff}/%Y]            " Filetype
        set statusline+=\ [%{getcwd()}]          " Current dir
        set statusline+=%=%-14.(%l,%c%V%)\ %p%%  " Right aligned file nav info
    endif

    set backspace=indent,eol,start  " Backspace for dummies
    set linespace=0                 " No extra spaces between rows
    set nonu                        " Line numbers off
    set showmatch                   " Show matching brackets/parenthesis
    set incsearch                   " Find as you type search
    set hlsearch                    " Highlight search terms
    set winminheight=0              " Windows can be 0 line high
    set ignorecase                  " Case insensitive search
    set smartcase                   " Case sensitive when uc present
    set wildmenu                    " Show list instead of just completing
    set wildmode=list:longest,full  " Command <Tab> completion, list matches, then longest common part, then all.
    set scrolljump=5                " Lines to scroll when cursor leaves screen
    set scrolloff=3                 " Minimum lines to keep above and below cursor

" }

" Formatting {
    set autoindent                  " Indent at the same level of the previous line
    set shiftwidth=2                " Use indents of 2 spaces
    set tabstop=2                   " An indentation every four columns
    set softtabstop=2               " Let backspace delete indent
    set pastetoggle=<F6>            " pastetoggle (sane indentation on pastes)
    " Remove trailing whitespaces and ^M chars
    autocmd FileType c,cpp,java,php,javascript,xml,yml autocmd BufWritePre <buffer> call StripTrailingWhitespace()
    autocmd BufNewFile,BufRead *.html.twig set filetype=html.twig
" }

" Key (re)Mappings {

    " Easier entering commands
    nnoremap ; :
    " Easier creating tabs
    map <C-T> :tabnew<CR>

    " The default leader is '\', but many people prefer ',' as it's in a standard
    " location. To override this behavior and set it back to '\' (or any other
    " character) add the following let g:leader='\'
    if !exists('g:leader')
        let mapleader = ','
    else
        let mapleader=g:leader
    endif

    " Easier moving in tabs
    " The lines conflict with the default digraph mapping of <C-K>
    " If you prefer that functionality, add let g:no_easyWindows = 1

    if !exists('g:no_easyWindows')
        map <C-J> <C-W>j
        map <C-K> <C-W>k
        map <C-L> <C-W>l
        map <C-H> <C-W>h
    endif

    " Easier moving in tabs
    " The following two lines conflict with moving to top and
    " bottom of the screen
    " If you prefer that functionality, add the following line
    "   let g:no_fastTabs = 1
    if !exists('g:no_fastTabs')
        map <S-H> gT
        map <S-L> gt
    endif

    " Wrapped lines goes down/up to next row, rather than next line in file.
    nnoremap j gj
    nnoremap k gk

    " Stupid shift key fixes
    if !exists('g:no_keyfixes')
        if has("user_commands")
            command! -bang -nargs=* -complete=file E e<bang> <args>
            command! -bang -nargs=* -complete=file W w<bang> <args>
            command! -bang -nargs=* -complete=file Wq wq<bang> <args>
            command! -bang -nargs=* -complete=file WQ wq<bang> <args>
            command! -bang Wa wa<bang>
            command! -bang WA wa<bang>
            command! -bang Q q<bang>
            command! -bang QA qa<bang>
            command! -bang Qa qa<bang>
        endif

        cmap Tabe tabe
    endif

    " Yank from the cursor to the end of the line, to be consistent with C and D.
    nnoremap Y y$

    " Toggle search highlighting
    nmap <silent> <leader>/ :set invhlsearch<CR>

    " Shortcuts
    " Change Working Directory to that of the current file
    cmap cwd lcd %:p:h
    cmap cd. lcd %:p:h

    " Visual shifting (does not exit Visual mode)
    vnoremap < <gv
    vnoremap > >gv

    " Fix home and end keybindings for screen, particularly on mac
    " - for some reason this fixes the arrow keys too. huh.
    map [F $
    imap [F $
    map [H g0
    imap [H g0

    " For when you forget to sudo.. Really Write the file.
    cmap w!! w !sudo tee % >/dev/null

    " Adjust viewports to the same size
    map <Leader>= <C-w>=

    " Map <Leader>ff to display all lines with keyword under cursor
    " and ask which one to jump to
    nmap <Leader>ff [I:let nr = input("Which one: ")<Bar>exe "normal " . nr ."[\t"<CR>

    " Map <leader>fr to find and replace all words under the cursor in this file with 's'
    nmap <Leader>fr :%s/\<<C-r><C-w>\>/s/gc

    " Easier horizontal scrolling
    map zl zL
    map zh zH

" }

" Plugins {

    " Misc {
        let g:NERDShutUp=1
        let b:match_ignorecase = 1
    " }

    " Ctags {
        set tags=./tags;/,~/.vimtags
    " }

    " AutoCloseTag {
        " Make it so AutoCloseTag works for xml and xhtml files as well
        au FileType xhtml,xml ru ftplugin/html/autoclosetag.vim
        nmap <Leader>ac <Plug>ToggleAutoCloseMappings
    " }

    " SrcExpl {
        map <C-x> :SrcExplToggle<CR>
        let g:SrcExpl_isUpdateTags = 0 
        let g:SrcExpl_updateTagsKey = "<F5>" 
    " }

    " NerdTree {
        map <C-n> :NERDTreeToggle<CR>:NERDTreeMirror<CR>
        map <leader>e :NERDTreeFind<CR>
        nmap <leader>nt :NERDTreeFind<CR>

        let NERDTreeShowBookmarks=1
        let NERDTreeIgnore=['\.pyc', '\~$', '\.swo$', '\.swp$', '\.git', '\.hg', '\.svn', '\.bzr']
        let NERDTreeChDirMode=0
        let NERDTreeMouseMode=2
        let NERDTreeShowHidden=1
        let NERDTreeKeepTreeInNewTab=1
        let g:nerdtree_tabs_open_on_gui_startup=0
        let g:NERDTreeWinSize = 45
    " }

    " ctrlp {
        let g:ctrlp_working_path_mode = 'ra'
        let g:ctrlp_custom_ignore = {
            \ 'dir':  '\.git$\|\.hg$\|\.svn$',
            \ 'file': '\.exe$\|\.so$\|\.dll$' }

        let g:ctrlp_user_command = {
            \ 'types': {
                \ 1: ['.git', 'cd %s && git ls-files . --cached --exclude-standard --others'],
                \ 2: ['.hg', 'hg --cwd %s locate -I .'],
            \ },
            \ 'fallback': 'find %s -type f'
        \ }
    "}

    " EasyGrep {
        let g:EasyGrepRecursive = 1
    "}

    " Powerline {
        let g:Powerline_stl_path_style = 'short'
    "}

    " TagBar {
        nnoremap <silent> <leader>tt :TagbarToggle<CR>
    "}

    " vim-jsx {
        let g:jsx_ext_required = 0
    " }
    " JsBeautify {
        map <c-f> :call JsBeautify()<cr>
        " or
        autocmd FileType javascript noremap <buffer>  <c-f> :call JsBeautify()<cr>
        " for json
        autocmd FileType json noremap <buffer> <c-f> :call JsonBeautify()<cr>
        " for jsx
        autocmd FileType jsx noremap <buffer> <c-f> :call JsxBeautify()<cr>
        " for html
        autocmd FileType html noremap <buffer> <c-f> :call HtmlBeautify()<cr>
        " for css or scss
        autocmd FileType css noremap <buffer> <c-f> :call CSSBeautify()<cr>
        "nnoremap <C-F> :!js-beautify -r %<CR>"
    " }

    " indent_guides {
        if !exists('g:no_indent_guides_autocolor')
            let g:indent_guides_auto_colors = 1
        else
            " For some colorschemes, autocolor will not work (eg: 'desert', 'ir_black')
            autocmd VimEnter,Colorscheme * :hi IndentGuidesOdd  guibg=#212121 ctermbg=3
            autocmd VimEnter,Colorscheme * :hi IndentGuidesEven guibg=#404040 ctermbg=4
        endif
        let g:indent_guides_start_level = 2
        let g:indent_guides_guide_size = 1
    " }
    " emmet {
        let g:user_emmet_install_global = 0
        autocmd FileType html,css,jsx, js EmmetInstall
        let g:user_emmet_leader_key='<C-Z>'
    " }
    " CSApprox {
        "avoiding annoying CSApprox warning message
        let g:CSApprox_verbose_level = 0
    " }
    
    " Syntastic {
        set statusline+=%#warningmsg#
        set statusline+=%{SyntasticStatuslineFlag()}
        set statusline+=%*
        let g:syntastic_always_populate_loc_list = 1
        let g:syntastic_auto_loc_list = 1
        let g:syntastic_check_on_open = 1
        let g:syntastic_check_on_wq = 0
        let g:syntastic_javascript_checkers = ['eslint']
    " }

" }

" GUI Settings {

    " GVIM- (here instead of .gvimrc)
    if has('gui_running')
        set guioptions-=T           " Remove the toolbar
        set lines=40                " 40 lines of text instead of 24
        if has("gui_gtk2")
            set guifont=Andale\ Mono\ Regular\ 16,Menlo\ Regular\ 15,Consolas\ Regular\ 16,Courier\ New\ Regular\ 18
        else
            set guifont=Andale\ Mono\ Regular:h16,Menlo\ Regular:h15,Consolas\ Regular:h16,Courier\ New\ Regular:h18
        endif
        if has('gui_macvim')
            set transparency=5      " Make the window slightly transparent
        endif
    else
        if &term == 'xterm' || &term == 'screen'
            set t_Co=256            " Enable 256 colors to stop the CSApprox warning and make xterm vim shine
        endif
        "set term=builtin_ansi       " Make arrow and other keys work
    endif

" }

" Functions {

    " UnBundle {
    function! UnBundle(arg, ...)
      let bundle = vundle#config#init_bundle(a:arg, a:000)
      call filter(g:bundles, 'v:val["name_spec"] != "' . a:arg . '"')
    endfunction

    com! -nargs=+         UnBundle
    \ call UnBundle(<args>)
    " }

    " Strip whitespace {
    function! StripTrailingWhitespace()
        " To disable the stripping of whitespace, add the following to your
        " .vimrc file:
        "   let g:keep_trailing_whitespace = 1
        if !exists('g:keep_trailing_whitespace')
            " Preparation: save last search, and cursor position.
            let _s=@/
            let l = line(".")
            let c = col(".")
            " do the business:
            %s/\s\+$//e
            " clean up: restore previous search history, and cursor position
            let @/=_s
            call cursor(l, c)
        endif
    endfunction
    " }

" }
