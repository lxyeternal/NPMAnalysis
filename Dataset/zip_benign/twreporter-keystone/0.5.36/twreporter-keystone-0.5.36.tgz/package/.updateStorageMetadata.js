var gcsHelper = require('./lib/gcsHelper');
var _ = require('lodash');

var bucket = gcsHelper.initBucket({
  projectId: 'coastal-run-106202',
  keyFilename: __dirname + '/../plate/gcskeyfile.json'
}, 'twreporter-multimedia');

  /*
var metadata = {};
metadata.cacheControl = 'public, max-age=31536000';
bucket.setMetadata(metadata, function(err, apiResponse) {
  if (err) {
    return console.log(err);
  }
  console.log(apiResponse);
});
*/
bucket.getFiles({prefix: 'images/201611'}, function(err, files, apiResponse) {
  if (err) {
    return console.log(err);
  }
  console.log('apiResponse:', apiResponse);
  _.forEach(files, function(ele, index) {
    ele.setMetadata({
      cacheControl: 'public, max-age=31536000'
    })
  })
});
