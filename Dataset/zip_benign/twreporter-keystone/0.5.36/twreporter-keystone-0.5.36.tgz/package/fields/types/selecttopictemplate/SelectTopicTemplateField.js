import Field from '../Field';
import React from 'react';
import Select from 'react-select';
import { FormInput } from 'elemental';
/**
 * TODO:
 * - Custom path support
 */


class RadioButtons extends React.Component {

  constructor(props=null) {
    super(props)
    this.state = {
      selected: props.defaultValue
    }
  }

  render() {
    return (
      <div>
        <div styles={{display: 'inlineBlock'}}>
          <img src="http://www.twreporter.org/dist/8af1a9a3d631ae693c9c7742866dd282.svg"/>
        </div>
        <div styles={{display: 'inlineBlock'}}>
          <img src="http://www.twreporter.org/dist/8af1a9a3d631ae693c9c7742866dd282.svg"/>
        </div>
        <div styles={{display: 'inlineBlock'}}>
          <img src="http://www.twreporter.org/dist/8af1a9a3d631ae693c9c7742866dd282.svg"/>
        </div>
      </div>
    )
  }

}

module.exports = Field.create({

	displayName: 'SelectTopicTemplateField',

	valueChanged (newValue) {
		// TODO: This should be natively handled by the Select component
		if (this.props.numeric && typeof newValue === 'string') {
			newValue = newValue ? Number(newValue) : undefined;
		}
		this.props.onChange({
			path: this.props.path,
			value: newValue,
		});
	},

	renderValue () {
    console.log('renderValue:')
		var selected = this.props.ops.find(option => option.value === this.props.value);
		return <FormInput noedit>{selected ? selected.label : null}</FormInput>;
	},

	renderField () {
		// TODO: This should be natively handled by the Select component
		var ops = (this.props.numeric) ? this.props.ops.map(function (i) { return { label: i.label, value: String(i.value) }; }) : this.props.ops;
		var value = (typeof this.props.value === 'number') ? String(this.props.value) : this.props.value;
    console.log('value:', value)
    console.log('ops:', ops)


    const _radio1 = (
      <img src="http://www.twreporter.org/dist/8af1a9a3d631ae693c9c7742866dd282.svg" width="100" height="100" />
    )

    return (
      <form>
        <div className="radio">
          <label>
            <input type="radio" value="option1" checked={true} />
          <img src="http://www.twreporter.org/dist/8af1a9a3d631ae693c9c7742866dd282.svg"/>
          </label>
        </div>
        <div className="radio">
          <label>
            <input type="radio" value="option2" />
          <img src="http://www.twreporter.org/dist/8af1a9a3d631ae693c9c7742866dd282.svg"/>
          </label>
        </div>
        <div className="radio">
          <label>
            <input type="radio" value="option3" />
          <img src="http://www.twreporter.org/dist/8af1a9a3d631ae693c9c7742866dd282.svg"/>
          </label>
        </div>
      </form>
    )

    // return <Select simpleValue name={this.props.path} value={value} options={ops} onChange={this.valueChanged} />;
	},

});
