(function (global, factory) {
	typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/core'), require('@angular/common'), require('rxjs/BehaviorSubject')) :
	typeof define === 'function' && define.amd ? define(['exports', '@angular/core', '@angular/common', 'rxjs/BehaviorSubject'], factory) :
	(factory((global['ngx-loader'] = {}),global.core,global.common,global.BehaviorSubject));
}(this, (function (exports,core,common,BehaviorSubject) { 'use strict';

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
var UohLoaderService = (function () {
    function UohLoaderService() {
        this.loading = new BehaviorSubject.BehaviorSubject(false);
    }
    /**
     * @return {?}
     */
    UohLoaderService.prototype.show = /**
     * @return {?}
     */
    function () {
        this.loading.next(true);
    };
    /**
     * @return {?}
     */
    UohLoaderService.prototype.hide = /**
     * @return {?}
     */
    function () {
        this.loading.next(false);
    };
    UohLoaderService.decorators = [
        { type: core.Injectable },
    ];
    /** @nocollapse */
    UohLoaderService.ctorParameters = function () { return []; };
    return UohLoaderService;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @record
 */

/**
 * @record
 */

/**
 * @record
 */

var UohLoaderComponent = (function () {
    function UohLoaderComponent(_loader) {
        this._loader = _loader;
        this.duration = 2000;
        this.fps = 60;
        this.minStrokeWidth = 15;
        this.maxStrokeWidth = 50;
        this.circle = { stop1: 0.35, stop2: 0.85 };
        this.path = 'M 0,101 120,0 180,50.5 240,0 300,50.5 360,0 360,59 335.05078,80 360,101 360,160 240,59 215.04883,80 240,101 240,160' +
            ' 180,109.5 120,160 120,101 144.95117,80 120,59 0,160 0,101 Z';
        this.visible = false;
        this._frame = 0;
        this._svgSize = { width: 360, height: 160 };
        this._defaultSize = { width: 180, height: 80 };
    }
    /**
     * @return {?}
     */
    UohLoaderComponent.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
        var _this = this;
        this.size = (this.size) ? this.calcSize(this.size, this._svgSize) : this._defaultSize;
        this.viewBox = "0 0 " + (this._svgSize.width + this.maxStrokeWidth) + " " + (this._svgSize.height + this.maxStrokeWidth);
        var /** @type {?} */ pos = this.maxStrokeWidth / 2;
        this.groupTransform = "translate(" + pos + ", " + pos + ")";
        this._frameInterval = 1000 / this.fps;
        this._points = this.parsePoints(this.path);
        this._perimeter = this.calcPerimeter(this._points);
        this._strokeInc = this.getStrokeIncrement(this.duration, this.circle, this.minStrokeWidth, this.maxStrokeWidth);
        this._loading$ = this._loader.loading
            .subscribe(function (loading) {
            if (loading) {
                _this.startAnimation();
            }
            else {
                _this.stopAnimation();
            }
        });
    };
    /**
     * @return {?}
     */
    UohLoaderComponent.prototype.ngOnDestroy = /**
     * @return {?}
     */
    function () {
        if (this._loading$) {
            this._loading$.unsubscribe();
        }
    };
    /**
     * @return {?}
     */
    UohLoaderComponent.prototype.startAnimation = /**
     * @return {?}
     */
    function () {
        var _this = this;
        this.resetParams();
        this._requestID = window.requestAnimationFrame(function (time) {
            var /** @type {?} */ startTime = _this.correctTime(time);
            _this.draw(startTime, startTime);
        });
        this.visible = true;
    };
    /**
     * @return {?}
     */
    UohLoaderComponent.prototype.stopAnimation = /**
     * @return {?}
     */
    function () {
        this.visible = false;
        this.cancelRequestID();
    };
    /**
     * @return {?}
     */
    UohLoaderComponent.prototype.resetParams = /**
     * @return {?}
     */
    function () {
        this._frame = 0;
        this.strokeWidth = this.maxStrokeWidth;
    };
    /**
     * @return {?}
     */
    UohLoaderComponent.prototype.cancelRequestID = /**
     * @return {?}
     */
    function () {
        if (this._requestID !== undefined) {
            window.cancelAnimationFrame(this._requestID);
        }
    };
    /**
     * @param {?} time
     * @param {?} startTime
     * @return {?}
     */
    UohLoaderComponent.prototype.draw = /**
     * @param {?} time
     * @param {?} startTime
     * @return {?}
     */
    function (time, startTime) {
        var _this = this;
        var /** @type {?} */ timeElapsed = time - startTime;
        var /** @type {?} */ percent = timeElapsed / this.duration;
        if (percent >= 1) {
            this._frame = 0;
            startTime = time;
            percent = 1;
        }
        if (percent >= this.circle.stop2) {
            this.strokeWidth = this.minStrokeWidth + (timeElapsed - (this.duration * this.circle.stop2)) * this._strokeInc.stop2;
        }
        else if (percent <= this.circle.stop1) {
            this.strokeWidth = this.maxStrokeWidth - timeElapsed * this._strokeInc.stop1;
        }
        var /** @type {?} */ loader = this.easeInOut(percent) * this._perimeter;
        this.dashArray = loader + "," + this._perimeter;
        this.dashOffset = (loader - 1) * -1;
        this._requestID = window.requestAnimationFrame(function (nextTime) {
            _this.draw(_this.correctTime(nextTime), startTime);
        });
    };
    /**
     * @param {?} time
     * @return {?}
     */
    UohLoaderComponent.prototype.correctTime = /**
     * @param {?} time
     * @return {?}
     */
    function (time) {
        return time - (time % this._frameInterval);
    };
    /**
     * @param {?} currSize
     * @param {?} origSize
     * @return {?}
     */
    UohLoaderComponent.prototype.calcSize = /**
     * @param {?} currSize
     * @param {?} origSize
     * @return {?}
     */
    function (currSize, origSize) {
        if (currSize.width) {
            currSize.height = (origSize.width / currSize.width) * origSize.height;
        }
        else {
            currSize.width = (origSize.height / currSize.height) * origSize.width;
        }
        return currSize;
    };
    /**
     * @param {?} points
     * @return {?}
     */
    UohLoaderComponent.prototype.calcPerimeter = /**
     * @param {?} points
     * @return {?}
     */
    function (points) {
        return points.reduce(function (accum, currPoint, currIndex) {
            var /** @type {?} */ nextIndex = (currIndex + 1 >= points.length) ? 0 : currIndex + 1;
            var /** @type {?} */ nextPoint = points[nextIndex];
            var /** @type {?} */ diffX = currPoint.x - nextPoint.x;
            var /** @type {?} */ diffY = currPoint.y - nextPoint.y;
            return accum + Math.sqrt((diffX * diffX) + (diffY * diffY));
        }, 0);
    };
    /**
     * @param {?} path
     * @return {?}
     */
    UohLoaderComponent.prototype.parsePoints = /**
     * @param {?} path
     * @return {?}
     */
    function (path) {
        return path
            .replace(/M\s|\sZ/g, '')
            .split(' ')
            .map(function (point) {
            var /** @type {?} */ coords = point.split(',');
            return { x: +coords[0], y: +coords[1] };
        });
    };
    /**
     * @param {?} duration
     * @param {?} stops
     * @param {?} min
     * @param {?} max
     * @return {?}
     */
    UohLoaderComponent.prototype.getStrokeIncrement = /**
     * @param {?} duration
     * @param {?} stops
     * @param {?} min
     * @param {?} max
     * @return {?}
     */
    function (duration, stops, min, max) {
        var /** @type {?} */ steps1 = (duration * stops.stop1);
        var /** @type {?} */ steps2 = (duration * (1 - stops.stop2));
        var /** @type {?} */ increment1 = (max - min) / steps1;
        var /** @type {?} */ increment2 = (max - min) / steps2;
        return {
            stop1: increment1,
            stop2: increment2
        };
    };
    /**
     * @param {?} time
     * @return {?}
     */
    UohLoaderComponent.prototype.easeInOut = /**
     * @param {?} time
     * @return {?}
     */
    function (time) {
        var /** @type {?} */ timeSqr = time * time;
        return timeSqr / (2 * (timeSqr - time) + 1);
    };
    UohLoaderComponent.decorators = [
        { type: core.Component, args: [{
                    selector: 'uoh-loader',
                    template: "<div *ngIf=\"visible\" [style.width.px]=\"size.width\" [style.height.px]=\"size.height\" class=\"wrapper\"> <svg xmlns:svg=\"http://www.w3.org/2000/svg\" xmlns=\"http://www.w3.org/2000/svg\" [attr.viewBox]=\"viewBox\" id=\"logo\" version=\"1.1\"> <svg:g id=\"loaderGroup\" [attr.transform]=\"groupTransform\"> <svg:path [style.stroke-dasharray]=\"dashArray\" [style.stroke-dashoffset]=\"dashOffset\" [style.stroke-width]=\"strokeWidth\" style=\"fill:none;fill-rule:evenodd;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:4;stroke-opacity:1\" [attr.d]=\"path\" transform=\"translate(0,0)\" id=\"loaderPath\" /> <svg:path [style.stroke-width]=\"minStrokeWidth\" style=\"fill:none;fill-rule:evenodd;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:4;stroke-opacity:1\" [attr.d]=\"path\" transform=\"translate(0,0)\" id=\"bgPath\" /> </g> </svg> </div>",
                    styles: ["@keyframes scaling { 0% { transform: scale(1); } 50% { transform: scale(0.95); } 100% { transform: scale(1); } } .wrapper { border: none; position: fixed; z-index: 1000; margin: auto; top: 0; left: 0; bottom: 0; right: 0; } .wrapper:before { content: ''; display: block; position: fixed; overflow: hidden; top: 0; left: 0; width: 100vw; height: 100vh; text-align: center; background-color: rgba(0, 0, 0, 0.3); } #logo { position: absolute; width: 100%; height: 100%; top: 0; left: 0; animation-name: scaling; animation-iteration-count: infinite; animation-duration: 2s; animation-timing-function: ease-in-out; } #loaderPath { stroke: #d51111; } #bgPath { stroke: rgba(213, 17, 17, 0.1); }"]
                },] },
    ];
    /** @nocollapse */
    UohLoaderComponent.ctorParameters = function () { return [
        { type: UohLoaderService, },
    ]; };
    UohLoaderComponent.propDecorators = {
        "size": [{ type: core.Input },],
        "duration": [{ type: core.Input },],
        "fps": [{ type: core.Input },],
        "minStrokeWidth": [{ type: core.Input },],
        "maxStrokeWidth": [{ type: core.Input },],
        "circle": [{ type: core.Input },],
        "path": [{ type: core.Input },],
    };
    return UohLoaderComponent;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
var UohLoaderModule = (function () {
    function UohLoaderModule() {
    }
    /**
     * @return {?}
     */
    UohLoaderModule.forRoot = /**
     * @return {?}
     */
    function () {
        return {
            ngModule: UohLoaderModule,
            providers: [UohLoaderService]
        };
    };
    UohLoaderModule.decorators = [
        { type: core.NgModule, args: [{
                    imports: [
                        common.CommonModule
                    ],
                    declarations: [
                        UohLoaderComponent
                    ],
                    exports: [
                        UohLoaderComponent
                    ]
                },] },
    ];
    /** @nocollapse */
    UohLoaderModule.ctorParameters = function () { return []; };
    return UohLoaderModule;
}());

exports.UohLoaderModule = UohLoaderModule;
exports.UohLoaderComponent = UohLoaderComponent;
exports.UohLoaderService = UohLoaderService;

Object.defineProperty(exports, '__esModule', { value: true });

})));
