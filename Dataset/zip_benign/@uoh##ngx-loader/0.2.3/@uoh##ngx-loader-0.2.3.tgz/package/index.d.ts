import { ModuleWithProviders } from '@angular/core';
export * from './uoh-loader.component';
export * from './uoh-loader.service';
export declare class UohLoaderModule {
    static forRoot(): ModuleWithProviders;
}
