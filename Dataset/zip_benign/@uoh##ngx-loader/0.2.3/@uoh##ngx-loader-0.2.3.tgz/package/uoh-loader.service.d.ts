import { BehaviorSubject } from 'rxjs/BehaviorSubject';
export declare class UohLoaderService {
    loading: BehaviorSubject<boolean>;
    constructor();
    show(): void;
    hide(): void;
}
