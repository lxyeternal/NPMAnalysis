import { OnInit, OnDestroy } from '@angular/core';
import { UohLoaderService } from './uoh-loader.service';
export interface Size {
    width?: number;
    height?: number;
}
export interface Stops {
    stop1: number;
    stop2: number;
}
export interface Point {
    x: number;
    y: number;
}
export declare class UohLoaderComponent implements OnInit, OnDestroy {
    private _loader;
    size: Size;
    duration: number;
    fps: number;
    minStrokeWidth: number;
    maxStrokeWidth: number;
    circle: Stops;
    path: string;
    dashArray: string;
    dashOffset: number;
    strokeWidth: number;
    viewBox: string;
    groupTransform: string;
    visible: boolean;
    private _frameInterval;
    private _strokeInc;
    private _points;
    private _perimeter;
    private _frame;
    private _svgSize;
    private _defaultSize;
    private _requestID;
    private _loading$;
    constructor(_loader: UohLoaderService);
    ngOnInit(): void;
    ngOnDestroy(): void;
    private startAnimation();
    private stopAnimation();
    private resetParams();
    private cancelRequestID();
    private draw(time, startTime);
    private correctTime(time);
    private calcSize(currSize, origSize);
    private calcPerimeter(points);
    private parsePoints(path);
    private getStrokeIncrement(duration, stops, min, max);
    private easeInOut(time);
}
