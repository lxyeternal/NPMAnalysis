/// <reference types="node" />
import sharp from 'sharp';
import { Options } from './typings';
declare type InputImage = Buffer | string | ImageSrc;
declare type ImageSrc = {
    offsetX?: number;
    offsetY?: number;
    src: InputImage;
};
export declare function joinImages(images: InputImage[], { direction, color, align, offset, margin, }?: Options): Promise<sharp.Sharp>;
export default joinImages;
