# router-testing
[![Licensed under MPL 2.0](https://img.shields.io/badge/license-MPL_2.0-green.svg)](https://www.mozilla.org/en-US/MPL/2.0/)
[![Build Status](https://github.com/servall/router-testing/workflows/CI/badge.svg)](https://github.com/servall/router-testing/actions)
[![npm](https://img.shields.io/npm/v/@lcdev/router-testing.svg)](https://www.npmjs.com/package/@lcdev/router-testing)

Testing framework for @lcdev/router.

```bash
# replace VERSION below with the most recent major version above (eg. 0.5.1 -> 0.5, 1.2.3 -> 1)
yarn add @lcdev/router-testing@VERSION
```

Basic usage, assuming you're using jest:

```typescript
import MyRouteFactory from '../routes/my-route';
import { routerTest } from '@lcdev/router-testing';

test('router does things', async () => {
  await routerTest(MyRouteFactory, { dependency: 'value' }, async (test) => {
    await test.get('/my/route')
      .expect(200).expect({ foo: 23 });

    await test.post('/my/route').send({ values: [11] })
      .expect(200).expect({ dependency: 'value' });

    await test.get('/foo')
      .expect(404);
  });
});
```

The `test` object is an instance of [supertest](https://github.com/visionmedia/supertest)
with a koa server running only that particular factory.
