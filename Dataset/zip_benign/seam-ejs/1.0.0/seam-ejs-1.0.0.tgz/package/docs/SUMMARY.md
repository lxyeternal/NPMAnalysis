# Summary

## Introduction

* [Install](./files.md)
* [Getting Started](./files.md)
* [Concepts](./files.md)

## Codebase

<!-- * [Referance Documentation]() -->
* [Files](./files.md)
* [Assets](./styles.md)
* [Componenets](./components.md)
* [Design Patterns](./design-patterns.md)

## Deployment Requierments

* [Overview](./deployment.md)