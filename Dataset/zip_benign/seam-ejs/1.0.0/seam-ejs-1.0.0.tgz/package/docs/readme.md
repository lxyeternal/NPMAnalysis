# EJS Static Site Generator

## Features

> To be published as a npm/yarn package https://docs.npmjs.com/getting-started/creating-node-modules

MoSCoW method of priority

- [x] **M** 0.1 Component Directory CommonJS
- [ ] **M** 0.2 Translations
- [ ] **M** 0.3 add support for index at just the root path and none .html file ending when serving via express
- [ ] **M** 0.4 Webpack Global Styles (sass, less, stylus, css)
- [ ] **M** 0.5 Webpack Assets Build (fonts, favicons, images)
- [ ] **M** 0.6 Webpack Preporcessors (auto prefix, uglify, minify)
- [ ] **C** 0.7 Bower support for front end Libraries
- [ ] **S** 0.8 Stylelint
- [ ] **S** 0.9 ESLint
- [ ] **C** 1.0 Layouts
- [ ] **S** 1.1 JQuery like JS framework or PureJS?
- [ ] **C** 1.2 PWA checklist
- [ ] **C** 1.3 Progressive enhancement focused
- [ ] **S** 1.4 Sitemap Generator
- [ ] **S** 1.5 Open Graph data
- [ ] **S** 1.6 Social metadata
- [ ] **C** 1.7 Services: WebWorker API (serverless functions as backend)
- [ ] **C** 1.8 Services: Push Notifications
- [ ] **W** 1.9 Session Storage site avalible offline
- [ ] **W** 2.0 CLI Tool

# Issues/Notes

1. Why is it requier and not include as written in the ejs docs

2. can we add support for index at just the root path and none .html file ending when serving via express

# Changelog

## 0.1
- Duplicated scripts to add support for `yarn serve` to serve over express and `yarn static` to build out static files.
- Add gitbook for project documentation