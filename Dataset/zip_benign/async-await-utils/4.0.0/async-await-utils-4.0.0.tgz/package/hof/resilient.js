"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = resilient;

var _verror = require("verror");

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var DEFAULT_CONFIG = {
  task: 'promise resolution',
  attempts: 3,
  context: null
};

function resilient(asyncFn, config) {
  config = _objectSpread(_objectSpread({}, DEFAULT_CONFIG), config || {});
  var maxAttempts = config.attempts;

  function resilientFn() {
    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    var errors = [];
    var currentAttempts = 0; // recursive "catcher"

    function statefulCatch(err) {
      if (currentAttempts >= config.attempts) {
        // give up
        throw new _verror.VError({
          name: 'ResilientPromiseFailed',
          //
          cause: new _verror.MultiError(errors),
          info: {
            task: config.task,
            maxAttempts: maxAttempts
          }
        }, "Resilient ".concat(config.task, " failed after ").concat(maxAttempts));
      } else {
        currentAttempts += 1;
        errors.push(err);
        return asyncFn.apply(config.context, args)["catch"](statefulCatch);
      }
    } // kick off the chain


    return asyncFn.apply(config.context, args)["catch"](statefulCatch);
  }

  return resilientFn;
}

module.exports = exports.default;