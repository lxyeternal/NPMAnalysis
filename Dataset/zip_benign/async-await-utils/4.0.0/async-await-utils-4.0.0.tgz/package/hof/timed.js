"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = timed;

var _simple = require("../simple");

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var DEFAULT_CONFIG = {
  task: 'promise resolution',
  timeout: 1000,
  context: null
}; // decorates a promise generating function such that if it takes too long to
// complete, it will time out.

function timed(asyncFn, config) {
  config = _objectSpread(_objectSpread({}, DEFAULT_CONFIG), config || {});
  return function timedFn() {
    var pacer = (0, _simple.sleep)(config.timeout).then(function () {
      return Promise.reject(new Error("".concat(config.task, " timed out")));
    });

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return Promise.race([asyncFn.apply(config.context, args), pacer]);
  };
}

module.exports = exports.default;