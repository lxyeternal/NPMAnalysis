"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = guarded;

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var DEFAULT_CONFIG = {
  context: null,
  log: function log() {
    var _console;

    return (_console = console).error.apply(_console, arguments);
  }
};

function logError(log, err) {
  log(err.stack || err);

  for (var key in err) {
    if (key !== 'stack') {
      log("".concat(key, " = ").concat(err[key]));
    }
  }
} // returns a guarded version of a given async function.
// Errors are logged during synchronous or asynchronous execution


function guarded(asyncFn, config) {
  config = _objectSpread(_objectSpread({}, DEFAULT_CONFIG), config || {});
  return function guardedFn() {
    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return asyncFn.apply(config.context, args)["catch"](function (err) {
      logError(config.log, err);
      throw err;
    });
  };
}

module.exports = exports.default;