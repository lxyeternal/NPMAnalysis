"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = reuseInFlight;

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var DEFAULT_CONFIG = {
  createKey: function createKey(args) {
    return JSON.stringify(args);
  },
  ignoreSingleUndefined: false
}; // for a given Promise-generating function, track each execution by the stringified
// arguments. if the function is called again with the same arguments, then instead
// of generating a new promise, an existing in-flight promise is used instead. This
// prevents unnecessary repetition of async function calls while the same function
// is still in flight.

function reuseInFlight(asyncFn, config) {
  config = _objectSpread(_objectSpread({}, DEFAULT_CONFIG), config || {});
  var inflight = {};
  return function debounced() {
    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    if (config.ignoreSingleUndefined && args.length === 1 && args[0] === undefined) {
      console.warn('Ignoring single undefined arg (reuseInFlight)');
      args = [];
    }

    var key = config.createKey(args);

    if (!Object.prototype.hasOwnProperty.call(inflight, key)) {
      // WE DO NOT AWAIT, we are storing the promise itself
      inflight[key] = asyncFn.apply(this, args).then(function (results) {
        // self invalidate
        delete inflight[key];
        return results;
      }, function (err) {
        // still self-invalidate, then rethrow
        delete inflight[key];
        throw err;
      });
    }

    return inflight[key];
  };
}

module.exports = exports.default;