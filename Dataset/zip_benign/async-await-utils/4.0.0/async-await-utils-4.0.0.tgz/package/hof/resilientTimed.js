"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = resilientTimed;

var _resilient = _interopRequireDefault(require("./resilient"));

var _timed = _interopRequireDefault(require("./timed"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

// convenience composition of resilient, timed function - the function will time out
// after the given timeout, but will retry itself attempts times. The same
// config will be passed to both the timed and resilient functions.
function resilientTimed(asyncFn, config) {
  return (0, _resilient["default"])((0, _timed["default"])(asyncFn, config), config);
}

module.exports = exports.default;