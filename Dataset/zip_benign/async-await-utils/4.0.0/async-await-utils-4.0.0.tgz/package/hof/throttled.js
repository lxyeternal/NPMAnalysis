"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = throttled;

var _simple = require("../simple");

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var DEFAULT_CONFIG = {
  batchSize: 100,
  delay: 0,
  log: function log() {
    var _console;

    return (_console = console).log.apply(_console, arguments);
  }
}; // throttles the number of promises a promise generating function can execute. This is useful
// when you are firing off a large number of promises without waiting for them to be complete.
//
// the decorator maintains a count of the number of executions, and if the count hits a defined
// batch size, it blocks all subsequent promises until the current batch of promises complete.

function throttled(asyncFn, config) {
  var count = 0;
  var waitChain = Promise.resolve();
  var promiseQueue = [];
  config = _objectSpread(_objectSpread({}, DEFAULT_CONFIG), config || {});
  return function () {
    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    if (count % config.batchSize === 0) {
      // replaces the current wait chain with a Promise
      // that waits for the current set of Promises to complete
      // first before allowing any more promises to execute
      //
      // awkward, because of the mutable aspect of promiseQueue
      // and count, we use an immediately executing function
      // block where they do not mutate.
      waitChain = function (queue, count) {
        return waitChain.then(function () {
          config.log("Completed ".concat(count));

          if (config.delay === 0) {
            return Promise.all(queue);
          } else {
            return Promise.all(queue).then(_simple.sleep.bind(null, config.delay));
          }
        });
      }(promiseQueue, count);

      promiseQueue = [];
    } // we always return the tail.


    var tail = waitChain.then(function () {
      return asyncFn.apply(void 0, args);
    });
    promiseQueue.push(tail);
    count += 1;
    return tail;
  };
}

module.exports = exports.default;