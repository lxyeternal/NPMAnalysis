"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = sleep;

function sleep(duration) {
  return new Promise(function (ok) {
    return setTimeout(ok, duration);
  });
}

module.exports = exports.default;