"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = execute;

var _guarded = _interopRequireDefault(require("../hof/guarded"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function execute(fn) {
  var guardedFn = (0, _guarded["default"])(fn);

  for (var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
    args[_key - 1] = arguments[_key];
  }

  return guardedFn.apply(void 0, args);
}

module.exports = exports.default;