const errCode = require("../config/error_code");
const WATER_MARKER_TYPE = ['full', 'center']
const assert = require('assert') // 断言

function isWaterMarkerTypeParametersCorrectly(waterMarkerType) {
    assert(WATER_MARKER_TYPE.includes(waterMarkerType), errCode.WATER_MARKER_TYPE_ERR)
}

const WaterMarker = {
    WATER_MARKER_TYPE,
    isWaterMarkerTypeParametersCorrectly,
}
module.exports = WaterMarker
