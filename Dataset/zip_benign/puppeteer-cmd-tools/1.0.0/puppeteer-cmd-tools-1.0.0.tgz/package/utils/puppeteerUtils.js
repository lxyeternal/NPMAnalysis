// 更具值抛出错误
const colors = require("colors-console");

function assert(value, message) {
    if (!value)
        throw new Error(colors('red', message));
}

const helper = {
    assert,
}
module.exports = helper
