#!/usr/bin/env node

const puppeteer = require('puppeteer');
const fs = require("fs");
const errCode = require('./config/error_code');
const utils = require('./utils/puppeteerUtils');
const waterMarker = require('./utils/waterMarker');
const shell = require('shelljs');
const {program} = require('commander');
const pkgJson = require("./package.json");
const assert = require('assert') // 断言

// 版本信息
program.version(pkgJson.version)
    .description('A cmd script for screenshot from html page');

// 参数配置
program
    .option('-url, --url [string]', 'resource link, html page url, local file will be a absolute path')
    .option('-content, --content ', 'resource content, could be html text')
    .requiredOption('-o, --out-path <string>', 'output file path')

    .requiredOption('-vw, --viewport-width <number>', 'The page width in pixels', '1200')
    .requiredOption('-vh, --viewport-height <number>', 'The page height in pixels', '800')

    .option('-wm, --water-marker [string]', 'add watermark to output file')
    .option('-wmt, --water-marker-type [full|center]', 'watermark type, [full、center]', 'full')
    .option('-wma, --watermark-alpha [number]', 'the watermark alpha, [0 - 1.0], default 0.2', '0.2')
    .option('-wmx, --watermark-x [number]', 'only support [--water-marker-type = full] model, this watermark begin x Coords', '-20')
    .option('-wmy, --watermark-y [number]', 'only support [--water-marker-type = full] model, this watermark begin y Coords', '-20')
    .option('-wmxs, --watermark-x-space [number]', 'only support [--water-marker-type = full] model, this watermark x axis gap', '50')
    .option('-wmys, --watermark-y-space [number]', 'only support [--water-marker-type = full] model, this watermark y axis gap', '50')
    .option('-wmfs, --watermark-fontsize [string]', 'watermark fontsize, like this:18px、18pt, default 18px', '18px')

    .option('-proxy, --proxy [options]', 'proxy host and port, example 127.0.0.1:8080')
    .option('-timeout, --timeout [number]', 'max exec time limit, default 30s', '30')
    .option('-mob, --is-mobile [bool]', 'mobile viewport mode.', false)
    .option('-full, --full-page [bool]', 'when the value is true, will screenshot the full page even if have a page scrollbar', false)
    .option('-ca, --clip-area [numbers...]', 'appoint screenshot area, 0 0 100 100 : x y width width')
    .option('-cd, --clip-dom [string]', 'screenshot appoint dom block, example body、#top')
    .option('-d, --debug', 'output extra debugging', false)

// 校验参数
program.parse()
const options = program.opts();

// 调试模式，打印参数
if (options['debug']) {
    console.log(options)
}

// 校验参数
{
    assert(!(options['url'] && options['content']), errCode.SCREEN_SHOT_URL_AND_CONTENT_CANT_BOTH_EXIST)
    assert(!(!options['url'] && !options['content']), errCode.SCREEN_SHOT_SOURCE_NOT_SET)
    assert(options.hasOwnProperty('viewportWidth') && !isNaN(options['viewportWidth']), "--viewport-width value type is number!")
    assert(options.hasOwnProperty('viewportHeight') && !isNaN(options['viewportHeight']), "--viewport-height value type is number!")
    assert(options.hasOwnProperty('watermarkXSpace') && !isNaN(options['watermarkXSpace']), "--watermark-x-space value type is number!")
    assert(options.hasOwnProperty('watermarkYSpace') && !isNaN(options['watermarkYSpace']), "--watermark-y-space value type is number!")

    // 判断是否需要添加水印
    if (options['waterMarker']) {
        if (options['waterMarkerType']) {
            waterMarker.isWaterMarkerTypeParametersCorrectly(options['waterMarkerType'])
        }
    }

    // 截图区域
    if (options['clipArea']) {
        let clipOpts = options['clipArea'];
        assert(clipOpts.length === 4, errCode.CLIP_AREA_SCREEN_SHOT_ARGS_ERR)
    }
}

(async () => {
    // 启动浏览器
    let launchAdditionalArgs = [
        '--no-sandbox',
        '--start-maximized',
    ]

    if (options['proxy']) {
        launchAdditionalArgs['--proxy-server'] = options['proxy']
    }
    const browser = await puppeteer.launch({
        headless: false,
        args: launchAdditionalArgs,
        defaultViewport: {
            width: parseInt(options['viewportWidth']),
            height: parseInt(options['viewportHeight'])
        },
    });

    // 打开新标签页
    const page = await browser.newPage();
    // await page.setViewport({ width: 2000, height: 800 })
    // await page.setViewport({width: parseInt(options['viewportWidth']), height: parseInt(options['viewportHeight'])})

    if (options['isMobile'])
        await page.emulate(puppeteer.devices['iPhone X']); // 手机模式

    if (options['url']) {
        await page.goto(options['url'], { // 导航到资源页
            waitUntil: 'networkidle2',
        })
    } else {
        await page.setContent(options['content']) // 渲染指定html
    }

    // 添加水印
    if (options['waterMarker']) {
        await page.addScriptTag({path: fs.realpathSync('./js/addWaterMarker.js')})
        // evaluate中只能调用内部的函数，或者通过addScriptTag添加到页面中的函数
        await page.evaluate((options) => {
            if (options['waterMarkerType'] === 'full') {
                fullPageWaterMarker({
                    watermark_txt: options['waterMarker'],
                    watermark_x_space: options['watermarkXSpace'],//水印x轴间隔
                    watermark_y_space: options['watermarkYSpace'],//水印y轴间隔
                    watermark_fontsize: options['watermarkFontsize'],
                })
            } else {
                centerWaterMarker({
                    watermark_txt: options['waterMarker'],
                    watermark_fontsize: options['watermarkFontsize'],
                    watermark_padding: '30px 70px',
                }, options['fullPage'])
            }
        }, options);
    }

    // 针对元素块进行截图
    let screenShotOptions = {
        path: options['outPath'],
        fullPage: options['fullPage']
    }

    if (options['clipArea']) {
        screenShotOptions['clip'] = {
            x: parseFloat(options['clipArea'][0]),
            y: parseFloat(options['clipArea'][1]),
            width: parseFloat(options['clipArea'][2]),
            height: parseFloat(options['clipArea'][3]),
        }
    }

    if (options['clipDom']) { // 区域截图
        let screenShotArea = await page.$(options['clipDom']);
        await page.waitForSelector(options['clipDom'])
        await screenShotArea.screenshot(screenShotOptions);
    } else { // 全页截图
        await page.screenshot(screenShotOptions);
    }

    await page.close();
    await browser.close();
})();



