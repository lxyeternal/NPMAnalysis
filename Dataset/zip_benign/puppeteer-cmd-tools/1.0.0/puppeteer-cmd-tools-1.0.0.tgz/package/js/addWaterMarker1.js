function watermark(settings) {
    //默认设置
    var defaultSettings = {
        markerText: "text",
        watermarkX: 20,//水印起始位置x轴坐标
        watermarkY: 20,//水印起始位置Y轴坐标
        rows: 20,//水印行数
        cols: 20,//水印列数
        XSpacing: 100,//水印x轴间隔
        YSpacing: 50,//水印y轴间隔
        textColor: '#000000',//水印字体颜色
        opacity: 0.3,//水印透明度
        fontSize: '18px',//水印字体大小
        fontFamily: '微软雅黑',//水印字体
        markWidth: 120,//水印宽度
        markHeight: 80,//水印长度
        rotateAngle: 15//水印倾斜度数
    };

    defaultSettings = Object.assign(defaultSettings, settings)

    var oTemp = document.createDocumentFragment();

    //获取页面最大宽度
    var page_width = Math.max(document.body.clientWidth);
    //获取页面最大长度
    var page_height = Math.max(document.body.clientHeight);

    //如果将水印列数设置为0，或水印列数设置过大，超过页面最大宽度，则重新计算水印列数和水印x轴间隔
    if (defaultSettings.cols == 0 || (parseInt(defaultSettings.watermarkX + defaultSettings.markWidth * defaultSettings.cols + defaultSettings.XSpacing * (defaultSettings.cols - 1)) > page_width)) {
        defaultSettings.cols = parseInt((page_width - defaultSettings.watermarkX + defaultSettings.XSpacing) / (defaultSettings.markWidth + defaultSettings.XSpacing));
        defaultSettings.XSpacing = parseInt((page_width - defaultSettings.watermarkX - defaultSettings.markWidth * defaultSettings.cols) / (defaultSettings.cols - 1));
    }
    //如果将水印行数设置为0，或水印行数设置过大，超过页面最大长度，则重新计算水印行数和水印y轴间隔
    if (defaultSettings.rows == 0 || (parseInt(defaultSettings.watermarkY + defaultSettings.markHeight * defaultSettings.rows + defaultSettings.YSpacing * (defaultSettings.rows - 1)) > page_height)) {
        defaultSettings.rows = parseInt((defaultSettings.YSpacing + page_height - defaultSettings.watermarkY) / (defaultSettings.markHeight + defaultSettings.YSpacing));
        defaultSettings.YSpacing = parseInt((page_height - defaultSettings.watermarkY - defaultSettings.markHeight * defaultSettings.rows) / (defaultSettings.rows - 1));
    }

    var x;
    var y;

    for (var i = 0; i < defaultSettings.rows; i++) {
        y = defaultSettings.watermarkY + (defaultSettings.markHeight + defaultSettings.YSpacing) * i;
        for (var j = 0; j < defaultSettings.cols; j++) {
            x = defaultSettings.watermarkX + (defaultSettings.markWidth + defaultSettings.XSpacing) * j;

            var mask_div = document.createElement('div');
            mask_div.id = 'mask_div' + i + j;
            // mask_div.appendChild(document.createTextNode(defaultSettings.markerText));
            mask_div.innerHTML = defaultSettings.markerText
            //设置水印div倾斜显示
            mask_div.style.webkitTransform = "rotate(-" + defaultSettings.rotateAngle + "deg)";
            mask_div.style.MozTransform = "rotate(-" + defaultSettings.rotateAngle + "deg)";
            mask_div.style.msTransform = "rotate(-" + defaultSettings.rotateAngle + "deg)";
            mask_div.style.OTransform = "rotate(-" + defaultSettings.rotateAngle + "deg)";
            mask_div.style.transform = "rotate(-" + defaultSettings.rotateAngle + "deg)";
            mask_div.style.visibility = "";
            mask_div.style.position = "fixed";
            mask_div.style.left = x + 'px';
            mask_div.style.top = y + 'px';
            mask_div.style.overflow = "hidden";
            mask_div.style.zIndex = "9999";
            mask_div.style.opacity = defaultSettings.opacity;
            mask_div.style.fontSize = defaultSettings.fontSize;
            mask_div.style.fontFamily = defaultSettings.fontFamily;
            mask_div.style.color = defaultSettings.textColor;
            mask_div.style.textAlign = "center";
            mask_div.style.width = defaultSettings.markWidth + 'px';
            mask_div.style.height = defaultSettings.markHeight + 'px';
            mask_div.style.lineHeight = defaultSettings.markHeight + 'px';
            mask_div.style.padding = "10px";
            mask_div.style.display = "block";

            mask_div.style.margin = 'auto';

            mask_div.style.borderColor = '#008000';
            mask_div.style.borderStyle = 'solid';
            mask_div.style.borderWidth = '6px';
            mask_div.style.borderRadius = '8px';

            oTemp.appendChild(mask_div);
        }
    }
    document.body.appendChild(oTemp);
}

