function fullPageWaterMarker(settings) {

    //默认设置
    let defaultSettings = {
        watermark_txt: "text",
        watermark_x: -20,//水印起始位置x轴坐标
        watermark_y: -20,//水印起始位置Y轴坐标
        watermark_rows: 0,//水印行数
        watermark_cols: 0,//水印列数
        watermark_x_space: 50,//水印x轴间隔
        watermark_y_space: 50,//水印y轴间隔
        watermark_color: '#000000',//水印字体颜色
        watermark_alpha: 0.3,//水印透明度
        watermark_fontsize: '18px',//水印字体大小
        watermark_font: '微软雅黑',//水印字体
        watermark_width: 120,//水印宽度
        watermark_height: 80,//水印长度
        watermark_angle: 45//水印倾斜度数
    };

    defaultSettings = Object.assign(defaultSettings, settings);

    defaultSettings.watermark_x_space = parseInt(defaultSettings.watermark_x_space);
    defaultSettings.watermark_y_space = parseInt(defaultSettings.watermark_y_space);

    let oTemp = document.createDocumentFragment();

    //获取页面最大宽度
    let page_width = Math.max(document.body.scrollWidth, document.body.clientWidth) + 200;
    //获取页面最大长度
    let page_height = Math.max(document.body.scrollHeight, document.body.clientHeight) + 200;

    //如果将水印列数设置为0，或水印列数设置过大，超过页面最大宽度，则重新计算水印列数和水印x轴间隔
    if (defaultSettings.watermark_cols == 0 || (parseInt(defaultSettings.watermark_x + defaultSettings.watermark_width * defaultSettings.watermark_cols + defaultSettings.watermark_x_space * (defaultSettings.watermark_cols - 1)) > page_width)) {
        defaultSettings.watermark_cols = parseInt((page_width - defaultSettings.watermark_x + parseInt(defaultSettings.watermark_x_space)) / (defaultSettings.watermark_width + parseInt(defaultSettings.watermark_x_space)));
        // defaultSettings.watermark_x_space = parseInt((page_width - defaultSettings.watermark_x - defaultSettings.watermark_width * defaultSettings.watermark_cols) / (defaultSettings.watermark_cols - 1));
    }
    //如果将水印行数设置为0，或水印行数设置过大，超过页面最大长度，则重新计算水印行数和水印y轴间隔
    if (defaultSettings.watermark_rows == 0 || (parseInt(defaultSettings.watermark_y + defaultSettings.watermark_height * defaultSettings.watermark_rows + defaultSettings.watermark_y_space * (defaultSettings.watermark_rows - 1)) > page_height)) {
        defaultSettings.watermark_rows = parseInt((parseInt(defaultSettings.watermark_y_space) + page_height - defaultSettings.watermark_y) / (defaultSettings.watermark_height + parseInt(defaultSettings.watermark_y_space)));
        // defaultSettings.watermark_y_space = parseInt((page_height - defaultSettings.watermark_y - defaultSettings.watermark_height * defaultSettings.watermark_rows) / (defaultSettings.watermark_rows - 1));
    }

    let x;
    let y;
    for (let i = 0; i <= defaultSettings.watermark_rows; i++) {
        y = defaultSettings.watermark_y + (defaultSettings.watermark_y_space + defaultSettings.watermark_height) * i;
        for (let j = 0; j <= defaultSettings.watermark_cols; j++) {
            x = defaultSettings.watermark_x + (defaultSettings.watermark_width + defaultSettings.watermark_x_space) * j;

            let mask_div = document.createElement('div');
            mask_div.id = 'mask_div' + i + j;
            mask_div.appendChild(document.createTextNode(defaultSettings.watermark_txt + defaultSettings.watermark_width + defaultSettings.watermark_height));
            //设置水印div倾斜显示
            mask_div.style.webkitTransform = "rotate(-" + defaultSettings.watermark_angle + "deg)";
            mask_div.style.MozTransform = "rotate(-" + defaultSettings.watermark_angle + "deg)";
            mask_div.style.msTransform = "rotate(-" + defaultSettings.watermark_angle + "deg)";
            mask_div.style.OTransform = "rotate(-" + defaultSettings.watermark_angle + "deg)";
            mask_div.style.transform = "rotate(-" + defaultSettings.watermark_angle + "deg)";
            mask_div.style.visibility = "";
            mask_div.style.position = "fixed";
            mask_div.style.left = x + 'px';
            mask_div.style.top = y + 'px';
            mask_div.style.overflow = "hidden";
            mask_div.style.zIndex = "9999";
            //mask_div.style.border="solid #eee 1px";
            mask_div.style.opacity = defaultSettings.watermark_alpha;
            mask_div.style.fontSize = defaultSettings.watermark_fontsize;
            mask_div.style.fontFamily = defaultSettings.watermark_font;
            mask_div.style.color = defaultSettings.watermark_color;
            mask_div.style.textAlign = "center";
            // mask_div.style.width = defaultSettings.watermark_width + 'px';
            // mask_div.style.height = defaultSettings.watermark_height + 'px';
            mask_div.style.width = 'max-content';
            mask_div.style.height = 'max-content';
            mask_div.style.display = "block";
            oTemp.appendChild(mask_div);
        }
    }

    console.log(oTemp)
    document.body.appendChild(oTemp);
}

// 中心水印
function centerWaterMarker(settings, is_full_page = false) {
    //默认设置
    let defaultSettings = {
        watermark_txt: "text",
        watermark_color: '#008000',//水印字体颜色
        watermark_alpha: 0.5,//水印透明度
        watermark_fontsize: '18px',//水印字体大小
        watermark_font: '微软雅黑',//水印字体
        watermark_width: 'max-content',//水印宽度
        watermark_height: 'max-content',//水印长度
        watermark_angle: 15, //水印倾斜度数
        watermark_border_color: '#008000', // 水印边框颜色
        watermark_border_width: 6, // 水印边框宽度
        watermark_border_style: 'solid', // 水印边框类型
        watermark_padding: '30px', // 内边距
    };

    defaultSettings = Object.assign(defaultSettings, settings)

    let mask_div = document.createElement('div');
    mask_div.appendChild(document.createTextNode(defaultSettings.watermark_txt));

    mask_div.id = 'centerMaskDom';
    mask_div.style.padding = defaultSettings.watermark_padding;
    mask_div.style.borderWidth = defaultSettings.watermark_border_width + 'px';
    mask_div.style.borderStyle = defaultSettings.watermark_border_style;
    mask_div.style.borderColor = defaultSettings.watermark_border_color;
    mask_div.style.borderRadius = '8px';
    mask_div.style.opacity = defaultSettings.watermark_alpha;
    mask_div.style.position = 'fixed';
    mask_div.style.zIndex = "9999";
    mask_div.style.webkitTransform = "rotate(-45deg)";
    mask_div.style.transform = "rotate(-45deg)";
    mask_div.style.MozTransform = "rotate(-45deg)";
    mask_div.style.msTransform = "rotate(-45deg)";
    mask_div.style.OTransform = "rotate(-45deg)";
    mask_div.style.fontSize = defaultSettings.watermark_fontsize;
    mask_div.style.margin = 'auto';
    mask_div.style.left = '0';
    mask_div.style.right = '0';
    mask_div.style.top = '0';
    mask_div.style.bottom = '0';
    mask_div.style.textAlign = 'center';
    mask_div.style.width = defaultSettings.watermark_width;
    mask_div.style.height = defaultSettings.watermark_height;
    mask_div.style.color = defaultSettings.watermark_color;
    mask_div.style.fontFamily = 'font-family: Helvetica Neue, Helvetica, Helvetica, Arial, sans-serif;';

    // 这里先放进去渲染，获取到渲染后的高度之后再重新渲染
    document.body.appendChild(mask_div);
    let top = Math.max(document.body.scrollHeight, document.body.clientHeight) / 2 + document.querySelector('#centerMaskDom').offsetHeight / 2;
    document.body.removeChild(mask_div);

    if (is_full_page) {
        mask_div.style.top = top + 'px';
    }

    document.body.appendChild(mask_div);
}
