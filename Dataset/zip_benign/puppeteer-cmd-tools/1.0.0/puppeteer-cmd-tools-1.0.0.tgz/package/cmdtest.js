const { program } = require('commander');
const pkgJson = require("./package.json");

console.log(pkgJson.version)
program.version(pkgJson.version)
    .description('A cli application named pro');

program
    .option('--first')
    .option('-s, --separator <char>');

program.parse();

const options = program.opts();
const limit = options.first ? 1 : undefined;
console.log(program.args[0].split(options.separator, limit));
