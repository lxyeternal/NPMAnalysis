const colors = require('colors-console')

const ErrorCode = {
    VALUE_EMPTY: colors('red', 'args is empty'),
    URL_EMPTY: colors('red', 'resource link url is empty'),
    SCREEN_SHOT_URL_AND_CONTENT_CANT_BOTH_EXIST: colors('red', "resource link url and content can't exist both"),
    SCREEN_SHOT_SOURCE_NOT_SET: colors('red', 'resource link url or content at least exist one'),
    WATER_MARKER_TYPE_ERR: colors('red', 'water marker type is not support, (full、center)'),
    CLIP_AREA_SCREEN_SHOT_ARGS_ERR: colors('red', 'appoint screenshot area args err'),
    OUT_FILE_PATH_IS_EMPTY: colors('red', 'out file path is empty'),
}
module.exports = ErrorCode
