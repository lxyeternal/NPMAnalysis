const expect = require('chai').expect
const check = require("../index")
var i = 0
do{
    hash,
    txHash,
    fullName,
    denomination,
    checkNumber,
    emissionDate,
    payDate,
    discountTax
    
    const nominalQty = Math.random() * 10000000000
    const commision = Math.random() + 0.00001
    const discountTax = Math.random() + 0.00001
    const newCheck = new check.check(nominalQty, commision, expiration, discountTax)
    expect(newCheck.nominalQty).to.equal(nominalQty);
    expect(newCheck.commision).to.equal(commision);
    expect(newCheck.expiration).to.equal(expiration);
    expect(newCheck.discountTax).to.equal(discountTax);
    i++
} while(i<1000)
const othnominalValue = 100000
const othcommision = 0.03
const othexpiration = 90
const othdiscountTax = 0.3
const otherCheck = new check.check(othnominalValue, othcommision, othexpiration, othdiscountTax)
expect(otherCheck.netValue()).to.equal(97000);
expect(otherCheck.minValue()).to.equal(89725);
