declare type Optional<Type> = {
    [Property in keyof Type]+?: Type[Property];
};
interface ShadowParams {
    xAngleDeg: number;
    yAngleDeg: number;
    resolution: number;
    crispness: number;
    useSpread: boolean;
    useStroke: boolean;
    useDebug: boolean;
    rgbPartialShadowColor: string;
    baseElevation: number;
    elevations: number[];
}
declare const supershad: (paramsIn?: Optional<ShadowParams>) => string[];

export { supershad as default, supershad };
