/**
 * @since 0.6.3
 */
import { flow, identity, pipe } from 'fp-ts/function';
import { bind as bind_, chainFirst as chainFirst_ } from 'fp-ts/Chain';
import * as TE from 'fp-ts/TaskEither';
import * as M from './Middleware';
import { bindTo as bindTo_ } from 'fp-ts/Functor';
import { apS as apS_, apFirst as apFirst_, apSecond as apSecond_ } from 'fp-ts/Apply';
import { chainEitherK as chainEitherK_, chainOptionK as chainOptionK_, fromPredicate as fromPredicate_, fromEitherK as fromEitherK_, fromOption as fromOption_, fromOptionK as fromOptionK_, filterOrElse as filterOrElse_, } from 'fp-ts/FromEither';
import { fromIOK as fromIOK_, chainIOK as chainIOK_, chainFirstIOK as chainFirstIOK_ } from 'fp-ts/FromIO';
import { fromTaskK as fromTaskK_, chainTaskK as chainTaskK_, chainFirstTaskK as chainFirstTaskK_, } from 'fp-ts/FromTask';
/**
 * @category instances
 * @since 0.6.3
 */
export const URI = 'ReaderMiddleware';
/**
 * @category natural transformations
 * @since 0.6.3
 */
export function fromTaskEither(fa) {
    return () => M.fromTaskEither(fa);
}
/**
 * @category natural transformations
 * @since 0.7.9
 */
export const fromTaskOption = (onNone) => (fa) => () => M.fromTaskOption(onNone)(fa);
/**
 * @category natural transformations
 * @since 0.7.9
 */
export function fromReaderEither(fa) {
    return (r) => M.fromEither(fa(r));
}
/**
 * @category natural transformations
 * @since 0.7.9
 */
export function fromReaderIO(fa) {
    return (r) => M.fromIO(fa(r));
}
/**
 * @category natural transformations
 * @since 0.7.9
 */
export function fromReaderTask(fa) {
    return (r) => M.fromTask(fa(r));
}
/**
 * @category natural transformations
 * @since 0.6.3
 */
export function fromReaderTaskEither(fa) {
    return (r) => M.fromTaskEither(fa(r));
}
/**
 * @category natural transformations
 * @since 0.6.3
 */
export const fromMiddleware = (fa) => () => fa;
/**
 * @category constructors
 * @since 0.7.0
 */
export function gets(f) {
    return fromMiddleware(M.gets(f));
}
/**
 * @category constructors
 * @since 0.7.0
 */
export function fromConnection(f) {
    return fromMiddleware(M.fromConnection(f));
}
/**
 * @category constructors
 * @since 0.7.0
 */
export function modifyConnection(f) {
    return fromMiddleware(M.modifyConnection(f));
}
/**
 * @category constructors
 * @since 0.6.3
 */
export function right(a) {
    return fromMiddleware(M.right(a));
}
/**
 * @category constructors
 * @since 0.6.3
 */
export function left(e) {
    return fromMiddleware(M.left(e));
}
/**
 * @category constructors
 * @since 0.6.3
 */
export function rightTask(fa) {
    return fromMiddleware(M.rightTask(fa));
}
/**
 * @category constructors
 * @since 0.6.3
 */
export function leftTask(te) {
    return fromMiddleware(M.leftTask(te));
}
/**
 * @category constructors
 * @since 0.6.3
 */
export function rightIO(fa) {
    return fromMiddleware(M.rightIO(fa));
}
/**
 * @category constructors
 * @since 0.6.3
 */
export function leftIO(fe) {
    return fromMiddleware(M.leftIO(fe));
}
/**
 * @category natural transformations
 * @since 0.7.0
 */
export const fromEither = (e) => fromMiddleware(M.fromEither(e));
/**
 * @category natural transformations
 * @since 0.6.3
 */
export function fromIOEither(fa) {
    return fromMiddleware(M.fromIOEither(fa));
}
/**
 * @category constructors
 * @since 0.6.3
 */
export const rightReader = (ma) => (r) => M.right(ma(r));
/**
 * @category constructors
 * @since 0.6.3
 */
export function leftReader(me) {
    return (r) => M.left(me(r));
}
/**
 * @category constructors
 * @since 0.7.9
 */
export const rightReaderIO = (ma) => (r) => M.rightIO(ma(r));
/**
 * @category constructors
 * @since 0.7.9
 */
export const leftReaderIO = (me) => (r) => M.leftIO(me(r));
/**
 * @category constructors
 * @since 0.7.7
 */
export const rightReaderTask = (ma) => (r) => M.rightTask(ma(r));
/**
 * @category constructors
 * @since 0.7.7
 */
export const leftReaderTask = (me) => (r) => M.leftTask(me(r));
/**
 * @category constructors
 * @since 0.6.3
 */
export const ask = () => M.right;
/**
 * @category constructors
 * @since 0.6.3
 */
export const asks = (f) => flow(f, M.right);
/**
 * Less strict version of [`asksReaderMiddleware`](#asksreadermiddleware).
 *
 * @category combinators
 * @since 0.7.9
 */
// TODO: use R.asksReaderW when fp-ts version >= 2.11.0
export const asksReaderMiddlewareW = (f) => (r) => f(r)(r);
/**
 * Effectfully accesses the environment.
 *
 * @category combinators
 * @since 0.7.9
 */
export const asksReaderMiddleware = asksReaderMiddlewareW;
/**
 * @category combinators
 * @since 0.7.9
 */
export const fromReaderK = (f) => (...a) => rightReader(f(...a));
/**
 * @category combinators
 * @since 0.7.9
 */
export const fromReaderIOK = (f) => (...a) => rightReaderIO(f(...a));
/**
 * @category combinators
 * @since 0.7.8
 */
export const fromReaderTaskK = (f) => (...a) => rightReaderTask(f(...a));
/**
 * @category combinators
 * @since 0.7.9
 */
export const fromReaderEitherK = (f) => (...a) => fromReaderEither(f(...a));
/**
 * @category combinators
 * @since 0.7.8
 */
export const fromReaderTaskEitherK = (f) => (...a) => fromReaderTaskEither(f(...a));
/**
 * Less strict version of [`orElse`](#orelse).
 *
 * @category combinators
 * @since 0.6.4
 */
export const orElseW = (f) => (ma) => (r) => (c) => pipe(ma(r)(c), TE.orElseW((e) => f(e)(r)(c)));
/**
 * @category combinators
 * @since 0.6.3
 */
export const orElse = orElseW;
/**
 * Less strict version of [`orElseMiddlewareK`](#orelsemiddlewarek).
 *
 * @category combinators
 * @since 0.7.7
 */
export const orElseMiddlewareKW = (f) => (ma) => flow(ma, M.orElseW(f));
/**
 * @category combinators
 * @since 0.7.7
 */
export const orElseMiddlewareK = orElseMiddlewareKW;
/**
 * @category constructors
 * @since 0.6.3
 */
export function status(status) {
    return () => M.status(status);
}
/**
 * @category constructors
 * @since 0.6.3
 */
export function header(name, value) {
    return () => M.header(name, value);
}
/**
 * @category constructors
 * @since 0.6.3
 */
export function contentType(mediaType) {
    return header('Content-Type', mediaType);
}
/**
 * @category constructors
 * @since 0.6.3
 */
export function cookie(name, value, options) {
    return () => M.cookie(name, value, options);
}
/**
 * @category constructors
 * @since 0.6.3
 */
export function clearCookie(name, options) {
    return () => M.clearCookie(name, options);
}
const closedHeaders = iof(undefined);
/**
 * @category constructors
 * @since 0.6.3
 */
export function closeHeaders() {
    return closedHeaders;
}
/**
 * @category constructors
 * @since 0.6.3
 */
export function send(body) {
    return () => M.send(body);
}
/**
 * @category constructors
 * @since 0.6.3
 */
export function end() {
    return M.end;
}
/**
 * @category constructors
 * @since 0.6.3
 */
export function json(body, onError) {
    return () => M.json(body, onError);
}
/**
 * @category constructors
 * @since 0.6.3
 */
export function redirect(uri) {
    return () => M.redirect(uri);
}
/**
 * Returns a `ReaderMiddleware` that pipes a stream to the response object.
 *
 * @category constructors
 * @since 0.7.3
 */
export function pipeStream(stream, onError) {
    return pipe(ask(), ichain((r) => modifyConnection((c) => c.pipeStream(stream, (err) => onError(err)(r)))));
}
/**
 * @category constructors
 * @since 0.6.3
 */
export function decodeParam(name, f) {
    return () => M.decodeParam(name, f);
}
/**
 * @category constructors
 * @since 0.6.3
 */
export function decodeParams(f) {
    return () => M.decodeParams(f);
}
/**
 * @category constructors
 * @since 0.6.3
 */
export function decodeQuery(f) {
    return () => M.decodeQuery(f);
}
/**
 * @category constructors
 * @since 0.6.3
 */
export function decodeBody(f) {
    return () => M.decodeBody(f);
}
/**
 * @category constructors
 * @since 0.6.3
 */
export function decodeMethod(f) {
    return () => M.decodeMethod(f);
}
/**
 * @category constructors
 * @since 0.6.3
 */
export function decodeHeader(name, f) {
    return () => M.decodeHeader(name, f);
}
const _map = (fa, f) => (r) => pipe(fa(r), M.map(f));
const _apPar = (fab, fa) => pipe(fab, ap(fa));
const _apSeq = (fab, fa) => _chain(fab, (f) => _map(fa, (a) => f(a)));
const _chain = (ma, f) => (r) => pipe(ma(r), M.chain((a) => f(a)(r)));
const _alt = (fx, f) => (r) => (c) => pipe(fx(r)(c), TE.alt(() => f()(r)(c)));
const _bimap = (fea, f, g) => (r) => (c) => pipe(fea(r)(c), TE.bimap(f, ([a, c]) => [g(a), c]));
const _mapLeft = (fea, f) => (r) => (c) => pipe(fea(r)(c), TE.mapLeft(f));
/**
 * `map` can be used to turn functions `(a: A) => B` into functions `(fa: F<A>) => F<B>` whose argument and return types
 * use the type constructor `F` to represent some computational context.
 *
 * @category Functor
 * @since 0.6.3
 */
export const map = (f) => (fa) => _map(fa, f);
/**
 * Indexed version of [`map`](#map).
 *
 * @category IxFunctor
 * @since 0.7.0
 */
export const imap = (f) => (fa) => (r) => pipe(fa(r), M.imap(f));
/**
 * Map a pair of functions over the two last type arguments of the bifunctor.
 *
 * @category Bifunctor
 * @since 0.6.3
 */
export const bimap = (f, g) => (fa) => _bimap(fa, f, g);
/**
 * Map a function over the second type argument of a bifunctor.
 *
 * @category Bifunctor
 * @since 0.6.3
 */
export const mapLeft = (f) => (fa) => _mapLeft(fa, f);
/**
 * Apply a function to an argument under a type constructor.
 *
 * @category Apply
 * @since 0.6.3
 */
export const ap = (fa) => (fab) => (r) => pipe(fab(r), M.ap(fa(r)));
/**
 * Less strict version of [`ap`](#ap).
 *
 * @category Apply
 * @since 0.6.3
 */
export const apW = ap;
/**
 * Indexed version of [`ap`](#ap).
 *
 * @category Apply
 * @since 0.7.9
 */
export const iap = (fa) => (fab) => (r) => pipe(fab(r), M.iap(fa(r)));
/**
 * Less strict version of [`iap`](#iap).
 *
 * @category Apply
 * @since 0.6.3
 */
export const iapW = iap;
/**
 * @category Pointed
 * @since 0.6.3
 */
export const of = right;
/**
 * @category IxPointed
 * @since 0.6.3
 */
export function iof(a) {
    return () => M.iof(a);
}
/**
 * Composes computations in sequence, using the return value of one computation to determine the next computation.
 *
 * @category Monad
 * @since 0.6.3
 */
export const chain = (f) => (ma) => _chain(ma, f);
/**
 * Less strict version of [`chain`](#chain).
 *
 * @category Monad
 * @since 0.6.3
 */
export const chainW = chain;
/**
 * Less strict version of [`flatten`](#flatten).
 *
 * @category combinators
 * @since 0.7.2
 */
export const flattenW = chainW(identity);
/**
 * Derivable from `Chain`.
 *
 * @category combinators
 * @since 0.7.2
 */
export const flatten = flattenW;
/**
 * Indexed version of [`chain`](#chain).
 *
 * @category IxMonad
 * @since 0.6.3
 */
export const ichain = ichainW;
/**
 * Less strict version of [`ichain`](#ichain).
 *
 * @category IxMonad
 * @since 0.6.3
 */
export function ichainW(f) {
    return (ma) => (r) => (ci) => pipe(ma(r)(ci), TE.chainW(([a, co]) => f(a)(r)(co)));
}
/**
 * Indexed version of [`chainFirst`](#chainfirst).
 *
 * @category IxMonad
 * @since 0.7.6
 */
export const ichainFirst = ichainFirstW;
/**
 * Less strict version of [`ichainFirst`](#ichainfirst).
 *
 * @category IxMonad
 * @since 0.7.6
 */
export function ichainFirstW(f) {
    return (ma) => (r) => pipe(ma(r), M.ichainFirstW((a) => f(a)(r)));
}
/**
 * Less strict version of [`iflatten`](#iflatten).
 *
 * @category combinators
 * @since 0.7.2
 */
export const iflattenW = ichainW(identity);
/**
 * Derivable from indexed version of `Chain`.
 *
 * @category combinators
 * @since 0.7.2
 */
export const iflatten = iflattenW;
/**
 * @category Alt
 * @since 0.7.5
 */
export const alt = (that) => (fa) => _alt(fa, that);
/**
 * Less strict version of [`alt`](#alt).
 *
 * @category Alt
 * @since 0.7.5
 */
export const altW = alt;
/**
 * Less strict version of [`chainMiddlewareK`](#chainmiddlewarek).
 *
 * @category combinators
 * @since 0.7.9
 */
export const chainMiddlewareKW = (f) => (ma) => pipe(ma, chainW((a) => fromMiddleware(f(a))));
/**
 * @category combinators
 * @since 0.7.9
 */
export const fromMiddlewareK = (f) => (...a) => fromMiddleware(f(...a));
/**
 * @category combinators
 * @since 0.6.5
 */
export const ichainMiddlewareKW = (f) => (ma) => pipe(ma, ichainW(fromMiddlewareK(f)));
/**
 * @category combinators
 * @since 0.6.3
 */
export const ichainMiddlewareK = ichainMiddlewareKW;
/**
 * @category combinators
 * @since 0.6.3
 */
export const chainMiddlewareK = chainMiddlewareKW;
/**
 * @category combinators
 * @since 0.6.3
 */
export const chainTaskEitherK = (f) => (ma) => (r) => pipe(ma(r), M.chain((a) => M.fromTaskEither(f(a))));
/**
 * @category combinators
 * @since 0.6.3
 */
export const chainTaskEitherKW = chainTaskEitherK;
/**
 * Less strict version of [`chainTaskOptionK`](#chaintaskoptionk).
 *
 * @category combinators
 * @since 0.7.9
 */
export const chainTaskOptionKW = (onNone) => (f) => chainW((a) => fromTaskOption(onNone)(f(a)));
/**
 * @category combinators
 * @since 0.7.9
 */
export const chainTaskOptionK = chainTaskOptionKW;
/**
 * Less strict version of [`chainReaderK`](#chainreaderk).
 *
 * @category combinators
 * @since 0.7.9
 */
export const chainReaderKW = (f) => chainW(fromReaderK(f));
/**
 * @category combinators
 * @since 0.7.9
 */
export const chainReaderK = chainReaderKW;
/**
 * Less strict version of [`chainReaderTaskK`](#chainreadertaskk).
 *
 * @category combinators
 * @since 0.7.8
 */
export const chainReaderTaskKW = (f) => chainW(fromReaderTaskK(f));
/**
 * @category combinators
 * @since 0.7.8
 */
export const chainReaderTaskK = chainReaderTaskKW;
/**
 * @category combinators
 * @since 0.6.3
 */
export const chainReaderTaskEitherKW = (f) => chainW(fromReaderTaskEitherK(f));
/**
 * @category combinators
 * @since 0.6.3
 */
export const chainReaderTaskEitherK = chainReaderTaskEitherKW;
/**
 * Less strict version of [`chainFirstReaderTaskK`](#chainfirstreadertaskk).
 *
 * @category combinators
 * @since 0.7.8
 */
export const chainFirstReaderTaskKW = (f) => chainFirstW(fromReaderTaskK(f));
/**
 * @category combinators
 * @since 0.7.8
 */
export const chainFirstReaderTaskK = chainFirstReaderTaskKW;
/**
 * Less strict version of [`chainFirstReaderTaskEitherK`](#chainfirstreadertaskeitherk).
 *
 * @category combinators
 * @since 0.7.0
 */
export const chainFirstReaderTaskEitherKW = (f) => chainFirstW(fromReaderTaskEitherK(f));
/**
 * @category combinators
 * @since 0.7.0
 */
export const chainFirstReaderTaskEitherK = chainFirstReaderTaskEitherKW;
/**
 * @category instances
 * @since 0.6.3
 */
export const Functor = {
    URI,
    map: _map,
};
/**
 * @category instances
 * @since 0.7.0
 */
export const ApplyPar = Object.assign(Object.assign({}, Functor), { ap: _apPar });
/**
 * @category instances
 * @since 0.7.0
 */
export const ApplySeq = Object.assign(Object.assign({}, Functor), { ap: _apSeq });
/**
 * Use [`ApplySeq`](./ReaderMiddleware.ts.html#ApplySeq) instead.
 *
 * @category instances
 * @since 0.6.3
 * @deprecated
 */
export const Apply = ApplySeq;
/**
 * @category instances
 * @since 0.7.0
 */
export const ApplicativePar = Object.assign(Object.assign({}, ApplyPar), { of });
/**
 * @category instances
 * @since 0.7.0
 */
export const ApplicativeSeq = Object.assign(Object.assign({}, ApplySeq), { of });
/**
 * Use [`ApplicativeSeq`](./ReaderMiddleware.ts.html#ApplicativeSeq) instead.
 *
 * @category instances
 * @since 0.6.3
 * @deprecated
 */
export const Applicative = ApplicativeSeq;
/**
 * @category instances
 * @since 0.7.0
 */
export const Chain = Object.assign(Object.assign({}, ApplyPar), { chain: _chain });
/**
 * @category instances
 * @since 0.6.3
 */
export const Monad = Object.assign(Object.assign({}, ApplicativeSeq), { chain: _chain });
/**
 * @category instances
 * @since 0.6.3
 */
export const MonadThrow = Object.assign(Object.assign({}, Monad), { throwError: left });
/**
 * @category instances
 * @since 0.6.3
 */
export const Alt = Object.assign(Object.assign({}, Functor), { alt: _alt });
/**
 * @category instances
 * @since 0.6.3
 */
export const Bifunctor = {
    URI,
    bimap: _bimap,
    mapLeft: _mapLeft,
};
/**
 * @category instances
 * @since 0.7.0
 */
export const FromEither = {
    URI,
    fromEither,
};
/**
 * @category combinators
 * @since 0.7.0
 */
export const apFirst = apFirst_(ApplyPar);
/**
 * Less strict version of [`apFirst`](#apfirst).
 *
 * @category combinators
 * @since 0.7.1
 */
export const apFirstW = apFirst;
/**
 * Indexed version of [`apFirst`](#apfirst).
 *
 * @category combinators
 * @since 0.7.9
 */
export const iapFirst = apFirst;
/**
 * Less strict version of [`iapFirst`](#iapfirst).
 *
 * @category combinators
 * @since 0.7.9
 */
export const iapFirstW = iapFirst;
/**
 * @category combinators
 * @since 0.7.0
 */
export const apSecond = apSecond_(ApplyPar);
/**
 * Less strict version of [`apSecond`](#apsecond).
 *
 * @category combinators
 * @since 0.7.1
 */
export const apSecondW = apSecond;
/**
 * Indexed version of [`apSecond`](#apsecond).
 *
 * @category combinators
 * @since 0.7.9
 */
export const iapSecond = apSecond;
/**
 * Less strict version of [`iapSecond`](#iapsecond).
 *
 * @category combinators
 * @since 0.7.9
 */
export const iapSecondW = iapSecond;
/**
 * Composes computations in sequence, using the return value of one computation to determine
 * the next computation and keeping only the result of the first.
 *
 * Derivable from `Chain`.
 *
 * @category combinators
 * @since 0.7.0
 */
export const chainFirst = chainFirst_(Chain);
/**
 * Less strict version of [`chainFirst`](#chainfirst).
 *
 * Derivable from `Chain`.
 *
 * @category combinators
 * @since 0.7.0
 */
export const chainFirstW = chainFirst;
/**
 * @category constructors
 * @since 0.7.0
 */
export const fromPredicate = fromPredicate_(FromEither);
/**
 * @category combinators
 * @since 0.7.0
 */
export const filterOrElse = filterOrElse_(FromEither, Chain);
/**
 * Less strict version of [`filterOrElse`](#filterorelse).
 *
 * @category combinators
 * @since 0.7.0
 */
export const filterOrElseW = filterOrElse;
/**
 * @category natural transformations
 * @since 0.7.9
 */
export const fromOption = fromOption_(FromEither);
/**
 * @category combinators
 * @since 0.7.9
 */
export const fromEitherK = fromEitherK_(FromEither);
/**
 * @category combinators
 * @since 0.7.9
 */
export const fromOptionK = fromOptionK_(FromEither);
/**
 * @category combinators
 * @since 0.7.0
 */
export const chainEitherK = chainEitherK_(FromEither, Chain);
/**
 * Less strict version of [`chainEitherK`](#chaineitherk).
 *
 * @category combinators
 * @since 0.7.0
 */
export const chainEitherKW = chainEitherK;
/**
 * @category combinators
 * @since 0.7.9
 */
export const chainOptionK = chainOptionK_(FromEither, Chain);
/**
 * Less strict version of [`chainOptionK`](#chainoptionk).
 *
 * @category combinators
 * @since 0.7.9
 */
export const chainOptionKW = chainOptionK;
/**
 * @category natural transformations
 * @since 0.7.0
 */
export const fromIO = rightIO;
/**
 * @category instances
 * @since 0.7.0
 */
export const FromIO = {
    URI,
    fromIO,
};
/**
 * @category combinators
 * @since 0.7.0
 */
export const fromIOK = fromIOK_(FromIO);
/**
 * @category combinators
 * @since 0.7.0
 */
export const chainIOK = chainIOK_(FromIO, Chain);
/**
 * @category combinators
 * @since 0.7.0
 */
export const chainFirstIOK = chainFirstIOK_(FromIO, Chain);
/**
 * @category natural transformations
 * @since 0.7.0
 */
export const fromTask = rightTask;
/**
 * @category instances
 * @since 0.7.0
 */
export const FromTask = Object.assign(Object.assign({}, FromIO), { fromTask });
/**
 * @category combinators
 * @since 0.7.0
 */
export const fromTaskK = fromTaskK_(FromTask);
/**
 * @category combinators
 * @since 0.7.0
 */
export const chainTaskK = chainTaskK_(FromTask, Chain);
/**
 * @category combinators
 * @since 0.7.0
 */
export const chainFirstTaskK = chainFirstTaskK_(FromTask, Chain);
/**
 * Less strict version of [`chainFirstTaskEitherK`](#chainfirsttaskeitherk).
 *
 * @category combinators
 * @since 0.7.0
 */
export const chainFirstTaskEitherKW = (f) => chainFirstW((a) => fromTaskEither(f(a)));
/**
 * @category combinators
 * @since 0.7.0
 */
export const chainFirstTaskEitherK = chainFirstTaskEitherKW;
/**
 * Less strict version of [`chainFirstTaskOptionK`](#chainfirsttaskoptionk).
 *
 * @category combinators
 * @since 0.7.9
 */
export const chainFirstTaskOptionKW = (onNone) => (f) => chainFirstW((a) => fromTaskOption(onNone)(f(a)));
/**
 * @category combinators
 * @since 0.7.9
 */
export const chainFirstTaskOptionK = chainFirstTaskOptionKW;
/**
 * Phantom type can't be infered properly, use [`bindTo`](#bindto) instead.
 *
 * @since 0.6.3
 * @deprecated
 */
export const Do = iof({});
/**
 * @since 0.6.3
 */
export const bindTo = bindTo_(Functor);
/**
 * Indexed version of [`bindTo`](#bindto).
 *
 * @since 0.7.0
 */
export const ibindTo = bindTo;
/**
 * @since 0.6.3
 */
export const bind = bind_(Chain);
/**
 * @since 0.6.3
 */
export const bindW = bind;
/**
 * Less strict version of [`ibind`](#ibind).
 *
 * @since 0.7.0
 */
export const ibindW = bindW;
/**
 * @since 0.7.0
 */
export const ibind = ibindW;
/**
 * @since 0.7.0
 */
export const apS = apS_(ApplyPar);
/**
 * Less strict version of [`apS`](#aps).
 *
 * @since 0.7.0
 */
export const apSW = apS;
/**
 * Less strict version of [`iapS`](#iaps).
 *
 * @since 0.7.0
 */
export const iapSW = apS;
/**
 * @since 0.7.0
 */
export const iapS = iapSW;
