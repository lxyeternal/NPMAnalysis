/// <reference types="node" />
/**
 * @since 0.5.0
 */
import { Request, RequestHandler, ErrorRequestHandler, Response } from 'express'
import { IncomingMessage } from 'http'
import { Connection, CookieOptions, HeadersOpen, ResponseEnded, Status, StatusOpen } from '.'
import { Middleware } from './Middleware'
import * as E from 'fp-ts/Either'
import * as L from 'fp-ts-contrib/List'
import * as IO from 'fp-ts/IO'
/**
 * @internal
 */
export declare type Action =
  | {
      type: 'setBody'
      body: unknown
    }
  | {
      type: 'endResponse'
    }
  | {
      type: 'setStatus'
      status: Status
    }
  | {
      type: 'setHeader'
      name: string
      value: string
    }
  | {
      type: 'clearCookie'
      name: string
      options: CookieOptions
    }
  | {
      type: 'setCookie'
      name: string
      value: string
      options: CookieOptions
    }
  | {
      type: 'pipeStream'
      stream: NodeJS.ReadableStream
      onError: (e: unknown) => IO.IO<void>
    }
/**
 * @category model
 * @since 0.5.0
 */
export declare class ExpressConnection<S> implements Connection<S> {
  readonly req: Request
  readonly res: Response
  readonly actions: L.List<Action>
  readonly ended: boolean
  /**
   * @since 0.5.0
   */
  readonly _S: S
  constructor(req: Request, res: Response, actions?: L.List<Action>, ended?: boolean)
  /**
   * @since 0.5.0
   */
  chain<T>(action: Action, ended?: boolean): ExpressConnection<T>
  /**
   * @since 0.5.0
   */
  getRequest(): IncomingMessage
  /**
   * @since 0.5.0
   */
  getBody(): unknown
  /**
   * @since 0.5.0
   */
  getHeader(name: string): unknown
  /**
   * @since 0.5.0
   */
  getParams(): unknown
  /**
   * @since 0.5.0
   */
  getQuery(): unknown
  /**
   * @since 0.5.0
   */
  getOriginalUrl(): string
  /**
   * @since 0.5.0
   */
  getMethod(): string
  /**
   * @since 0.5.0
   */
  setCookie(name: string, value: string, options: CookieOptions): ExpressConnection<HeadersOpen>
  /**
   * @since 0.5.0
   */
  clearCookie(name: string, options: CookieOptions): ExpressConnection<HeadersOpen>
  /**
   * @since 0.5.0
   */
  setHeader(name: string, value: string): ExpressConnection<HeadersOpen>
  /**
   * @since 0.5.0
   */
  setStatus(status: Status): ExpressConnection<HeadersOpen>
  /**
   * @since 0.5.0
   */
  setBody(body: string | Buffer): ExpressConnection<ResponseEnded>
  /**
   * @since 0.6.2
   */
  pipeStream(stream: NodeJS.ReadableStream, onError: (e: unknown) => IO.IO<void>): ExpressConnection<ResponseEnded>
  /**
   * @since 0.5.0
   */
  endResponse(): ExpressConnection<ResponseEnded>
}
/**
 * @since 0.5.0
 */
export declare function toRequestHandler<I, O, E>(middleware: Middleware<I, O, E, void>): RequestHandler
/**
 * @since 0.5.0
 */
export declare function toErrorRequestHandler<I, O, E>(
  f: (err: unknown) => Middleware<I, O, E, void>
): ErrorRequestHandler
/**
 * The overload without error handler is unsafe and deprecated, use the one with
 * the error handler instead.
 *
 * @since 0.5.0
 */
export declare function fromRequestHandler<I = StatusOpen, E = never, A = never>(
  requestHandler: RequestHandler,
  f: (req: Request) => A
): Middleware<I, I, E, A>
export declare function fromRequestHandler<I = StatusOpen, E = never, A = never>(
  requestHandler: RequestHandler,
  f: (req: Request) => E.Either<E, A>,
  onError: (reason: unknown) => E
): Middleware<I, I, E, A>
