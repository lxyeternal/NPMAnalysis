/// <reference types="node" />
/**
 * A middleware is an indexed monadic action transforming one `Connection` to another `Connection`.
 * It operates in the `TaskEither` monad, and is indexed by `I` and `O`, the input and output
 * `Connection` types of the middleware action.
 *
 * @since 0.7.0
 */
import * as TE from 'fp-ts/TaskEither'
import * as TO from 'fp-ts/TaskOption'
import { Alt3 } from 'fp-ts/Alt'
import { Apply3 } from 'fp-ts/Apply'
import { Chain3 } from 'fp-ts/Chain'
import { Bifunctor3 } from 'fp-ts/Bifunctor'
import { Lazy } from 'fp-ts/function'
import { Functor3 } from 'fp-ts/Functor'
import { Monad3 } from 'fp-ts/Monad'
import { BodyOpen, Connection, CookieOptions, HeadersOpen, MediaType, ResponseEnded, Status, StatusOpen } from '.'
import * as T from 'fp-ts/Task'
import { IO } from 'fp-ts/IO'
import { IOEither } from 'fp-ts/IOEither'
import { Applicative3 } from 'fp-ts/Applicative'
import { MonadThrow3 } from 'fp-ts/MonadThrow'
import { MonadTask3 } from 'fp-ts/MonadTask'
import * as E from 'fp-ts/Either'
import { Pointed3 } from 'fp-ts/Pointed'
import { FromEither3 } from 'fp-ts/FromEither'
import * as O from 'fp-ts/Option'
import { FromIO3 } from 'fp-ts/FromIO'
import { FromTask3 } from 'fp-ts/FromTask'
import { Refinement } from 'fp-ts/Refinement'
import { Predicate } from 'fp-ts/Predicate'
declare module 'fp-ts/HKT' {
  interface URItoKind3<R, E, A> {
    Middleware: Middleware<R, R, E, A>
  }
}
/**
 * @category instances
 * @since 0.7.0
 */
export declare const URI = 'Middleware'
/**
 * @category instances
 * @since 0.7.0
 */
export declare type URI = typeof URI
/**
 * A middleware is an indexed monadic action transforming one `Connection` to another `Connection`. It operates
 * in the `TaskEither` monad, and is indexed by `I` and `O`, the input and output `Connection` types of the
 * middleware action.
 *
 * @category model
 * @since 0.7.0
 */
export interface Middleware<I, O, E, A> {
  (c: Connection<I>): TE.TaskEither<E, [A, Connection<O>]>
}
/**
 * @category constructors
 * @since 0.7.0
 */
export declare function gets<I = StatusOpen, E = never, A = never>(f: (c: Connection<I>) => A): Middleware<I, I, E, A>
/**
 * @category constructors
 * @since 0.7.0
 */
export declare function fromConnection<I = StatusOpen, E = never, A = never>(
  f: (c: Connection<I>) => E.Either<E, A>
): Middleware<I, I, E, A>
/**
 * @category constructors
 * @since 0.7.0
 */
export declare function modifyConnection<I, O, E>(f: (c: Connection<I>) => Connection<O>): Middleware<I, O, E, void>
/**
 * `map` can be used to turn functions `(a: A) => B` into functions `(fa: F<A>) => F<B>` whose argument and return types
 * use the type constructor `F` to represent some computational context.
 *
 * @category Functor
 * @since 0.7.0
 */
export declare const map: <A, B>(f: (a: A) => B) => <I, E>(fa: Middleware<I, I, E, A>) => Middleware<I, I, E, B>
/**
 * Indexed version of [`map`](#map).
 *
 * @category IxFunctor
 * @since 0.7.0
 */
export declare const imap: <A, B>(f: (a: A) => B) => <I, O, E>(fa: Middleware<I, O, E, A>) => Middleware<I, O, E, B>
/**
 * Map a pair of functions over the two last type arguments of the bifunctor.
 *
 * @category Bifunctor
 * @since 0.7.0
 */
export declare const bimap: <E, G, A, B>(
  f: (e: E) => G,
  g: (a: A) => B
) => <I>(fa: Middleware<I, I, E, A>) => Middleware<I, I, G, B>
/**
 * Map a function over the second type argument of a bifunctor.
 *
 * @category Bifunctor
 * @since 0.7.0
 */
export declare const mapLeft: <E, G>(f: (e: E) => G) => <I, A>(fa: Middleware<I, I, E, A>) => Middleware<I, I, G, A>
/**
 * Apply a function to an argument under a type constructor.
 *
 * @category Apply
 * @since 0.7.0
 */
export declare const ap: <I, E, A>(
  fa: Middleware<I, I, E, A>
) => <B>(fab: Middleware<I, I, E, (a: A) => B>) => Middleware<I, I, E, B>
/**
 * Less strict version of [`ap`](#ap).
 *
 * @category Apply
 * @since 0.7.0
 */
export declare const apW: <I, E2, A>(
  fa: Middleware<I, I, E2, A>
) => <E1, B>(fab: Middleware<I, I, E1, (a: A) => B>) => Middleware<I, I, E1 | E2, B>
/**
 * Indexed version of [`ap`](#ap).
 *
 * @category Apply
 * @since 0.7.9
 */
export declare const iap: <O, Z, E, A>(
  fa: Middleware<O, Z, E, A>
) => <I, B>(fab: Middleware<I, O, E, (a: A) => B>) => Middleware<I, Z, E, B>
/**
 * Less strict version of [`iap`](#iap).
 *
 * @category Apply
 * @since 0.7.9
 */
export declare const iapW: <O, Z, E2, A>(
  fa: Middleware<O, Z, E2, A>
) => <I, E1, B>(fab: Middleware<I, O, E1, (a: A) => B>) => Middleware<I, Z, E1 | E2, B>
/**
 * @category Pointed
 * @since 0.7.0
 */
export declare const of: <I = StatusOpen, E = never, A = never>(a: A) => Middleware<I, I, E, A>
/**
 * @category IxPointed
 * @since 0.7.0
 */
export declare function iof<I = StatusOpen, O = StatusOpen, E = never, A = never>(a: A): Middleware<I, O, E, A>
/**
 * Composes computations in sequence, using the return value of one computation to determine the next computation.
 *
 * @category Monad
 * @since 0.7.0
 */
export declare const chain: <I, E, A, B>(
  f: (a: A) => Middleware<I, I, E, B>
) => (ma: Middleware<I, I, E, A>) => Middleware<I, I, E, B>
/**
 * Less strict version of [`chain`](#chain).
 *
 * @category Monad
 * @since 0.7.0
 */
export declare const chainW: <I, E2, A, B>(
  f: (a: A) => Middleware<I, I, E2, B>
) => <E1>(ma: Middleware<I, I, E1, A>) => Middleware<I, I, E1 | E2, B>
/**
 * Less strict version of [`flatten`](#flatten).
 *
 * @category combinators
 * @since 0.7.2
 */
export declare const flattenW: <I, E1, E2, A>(
  mma: Middleware<I, I, E1, Middleware<I, I, E2, A>>
) => Middleware<I, I, E1 | E2, A>
/**
 * Derivable from `Chain`.
 *
 * @category combinators
 * @since 0.7.0
 */
export declare const flatten: <I, E, A>(mma: Middleware<I, I, E, Middleware<I, I, E, A>>) => Middleware<I, I, E, A>
/**
 * Less strict version of [`ichain`](#ichain).
 *
 * @category IxMonad
 * @since 0.7.0
 */
export declare function ichainW<A, O, Z, E, B>(
  f: (a: A) => Middleware<O, Z, E, B>
): <I, D>(ma: Middleware<I, O, D, A>) => Middleware<I, Z, D | E, B>
/**
 * Indexed version of [`chain`](#chain).
 *
 * @category IxMonad
 * @since 0.7.0
 */
export declare const ichain: <A, O, Z, E, B>(
  f: (a: A) => Middleware<O, Z, E, B>
) => <I>(ma: Middleware<I, O, E, A>) => Middleware<I, Z, E, B>
/**
 * Less strict version of [`ichainFirst`](#ichainfirst).
 *
 * @category combinators
 * @since 0.7.6
 */
export declare function ichainFirstW<A, O, Z, E, B>(
  f: (a: A) => Middleware<O, Z, E, B>
): <I, D>(ma: Middleware<I, O, D, A>) => Middleware<I, Z, D | E, A>
/**
 * Indexed version of [`chainFirst`](#chainfirst).
 *
 * @category combinators
 * @since 0.7.6
 */
export declare const ichainFirst: <A, O, Z, E, B>(
  f: (a: A) => Middleware<O, Z, E, B>
) => <I>(ma: Middleware<I, O, E, A>) => Middleware<I, Z, E, A>
/**
 * Less strict version of [`iflatten`](#iflatten).
 *
 * @category combinators
 * @since 0.7.2
 */
export declare const iflattenW: <I, O, Z, E1, E2, A>(
  mma: Middleware<I, O, E1, Middleware<O, Z, E2, A>>
) => Middleware<I, Z, E1 | E2, A>
/**
 * Derivable from indexed version of `Chain`.
 *
 * @category combinators
 * @since 0.7.2
 */
export declare const iflatten: <I, O, Z, E, A>(
  mma: Middleware<I, O, E, Middleware<O, Z, E, A>>
) => Middleware<I, Z, E, A>
/**
 * @category Alt
 * @since 0.7.0
 */
export declare const alt: <I, E, A>(
  that: Lazy<Middleware<I, I, E, A>>
) => (fa: Middleware<I, I, E, A>) => Middleware<I, I, E, A>
/**
 * Less strict version of [`alt`](#alt).
 *
 * @category Alt
 * @since 0.7.5
 */
export declare const altW: <I, E2, A>(
  that: Lazy<Middleware<I, I, E2, A>>
) => <E1>(fa: Middleware<I, I, E1, A>) => Middleware<I, I, E1 | E2, A>
/**
 * @since 0.7.0
 */
export declare function evalMiddleware<I, O, E, A>(ma: Middleware<I, O, E, A>, c: Connection<I>): TE.TaskEither<E, A>
/**
 * @since 0.7.0
 */
export declare function execMiddleware<I, O, E, A>(
  ma: Middleware<I, O, E, A>,
  c: Connection<I>
): TE.TaskEither<E, Connection<O>>
/**
 * Less strict version of [`orElse`](#orelse).
 *
 * @category combinators
 * @since 0.7.5
 */
export declare const orElseW: <E, I, O, M, B>(
  f: (e: E) => Middleware<I, O, M, B>
) => <A>(ma: Middleware<I, O, E, A>) => Middleware<I, O, M, B | A>
/**
 * @category combinators
 * @since 0.7.0
 */
export declare const orElse: <E, I, O, M, A>(
  f: (e: E) => Middleware<I, O, M, A>
) => (ma: Middleware<I, O, E, A>) => Middleware<I, O, M, A>
/**
 * @category interop
 * @since 0.7.0
 */
export declare function tryCatch<I = StatusOpen, E = never, A = never>(
  f: () => Promise<A>,
  onRejected: (reason: unknown) => E
): Middleware<I, I, E, A>
/**
 * @category natural transformations
 * @since 0.7.0
 */
export declare function fromTaskEither<I = StatusOpen, E = never, A = never>(
  fa: TE.TaskEither<E, A>
): Middleware<I, I, E, A>
/**
 * @category natural transformations
 * @since 0.7.9
 */
export declare const fromTaskOption: <E>(
  onNone: Lazy<E>
) => <I = StatusOpen, A = never>(fa: TO.TaskOption<A>) => Middleware<I, I, E, A>
/**
 * @category constructors
 * @since 0.7.0
 */
export declare function right<I = StatusOpen, E = never, A = never>(a: A): Middleware<I, I, E, A>
/**
 * @category constructors
 * @since 0.7.0
 */
export declare function left<I = StatusOpen, E = never, A = never>(e: E): Middleware<I, I, E, A>
/**
 * @category constructors
 * @since 0.7.0
 */
export declare function rightTask<I = StatusOpen, E = never, A = never>(fa: T.Task<A>): Middleware<I, I, E, A>
/**
 * @category constructors
 * @since 0.7.0
 */
export declare function leftTask<I = StatusOpen, E = never, A = never>(te: T.Task<E>): Middleware<I, I, E, A>
/**
 * @category constructors
 * @since 0.7.0
 */
export declare function rightIO<I = StatusOpen, E = never, A = never>(fa: IO<A>): Middleware<I, I, E, A>
/**
 * @category constructors
 * @since 0.7.0
 */
export declare function leftIO<I = StatusOpen, E = never, A = never>(fe: IO<E>): Middleware<I, I, E, A>
/**
 * @category natural transformations
 * @since 0.7.0
 */
export declare const fromEither: <I = StatusOpen, E = never, A = never>(fa: E.Either<E, A>) => Middleware<I, I, E, A>
/**
 * @category natural transformations
 * @since 0.7.0
 */
export declare function fromIOEither<I = StatusOpen, E = never, A = never>(fa: IOEither<E, A>): Middleware<I, I, E, A>
/**
 * Returns a middleware that writes the response status
 *
 * @category constructors
 * @since 0.7.0
 */
export declare function status<E = never>(status: Status): Middleware<StatusOpen, HeadersOpen, E, void>
/**
 * Returns a middleware that writes the given header
 *
 * @category constructors
 * @since 0.7.0
 */
export declare function header<E = never>(name: string, value: string): Middleware<HeadersOpen, HeadersOpen, E, void>
/**
 * Returns a middleware that sets the given `mediaType`
 *
 * @category constructors
 * @since 0.7.0
 */
export declare function contentType<E = never>(mediaType: MediaType): Middleware<HeadersOpen, HeadersOpen, E, void>
/**
 * Returns a middleware that sets the cookie `name` to `value`, with the given `options`
 *
 * @category constructors
 * @since 0.7.0
 */
export declare function cookie<E = never>(
  name: string,
  value: string,
  options: CookieOptions
): Middleware<HeadersOpen, HeadersOpen, E, void>
/**
 * Returns a middleware that clears the cookie `name`
 *
 * @category constructors
 * @since 0.7.0
 */
export declare function clearCookie<E = never>(
  name: string,
  options: CookieOptions
): Middleware<HeadersOpen, HeadersOpen, E, void>
/**
 * Returns a middleware that changes the connection status to `BodyOpen`
 *
 * @category constructors
 * @since 0.7.0
 */
export declare function closeHeaders<E = never>(): Middleware<HeadersOpen, BodyOpen, E, void>
/**
 * Returns a middleware that sends `body` as response body
 *
 * @category constructors
 * @since 0.7.0
 */
export declare function send<E = never>(body: string | Buffer): Middleware<BodyOpen, ResponseEnded, E, void>
/**
 * Returns a middleware that ends the response without sending any response body
 *
 * @category constructors
 * @since 0.7.0
 */
export declare function end<E = never>(): Middleware<BodyOpen, ResponseEnded, E, void>
/**
 * Returns a middleware that sends `body` as JSON
 *
 * @category constructors
 * @since 0.7.0
 */
export declare function json<E>(
  body: unknown,
  onError: (reason: unknown) => E
): Middleware<HeadersOpen, ResponseEnded, E, void>
/**
 * Returns a middleware that sends a redirect to `uri`
 *
 * @category constructors
 * @since 0.7.0
 */
export declare function redirect<E = never>(
  uri:
    | string
    | {
        href: string
      }
): Middleware<StatusOpen, HeadersOpen, E, void>
/**
 * Returns a middleware that pipes a stream to the response object.
 *
 * @category constructors
 * @since 0.7.0
 */
export declare function pipeStream<E>(
  stream: NodeJS.ReadableStream,
  onError: (err: unknown) => IO<void>
): Middleware<BodyOpen, ResponseEnded, E, void>
/**
 * Returns a middleware that tries to decode `connection.getParams()[name]`
 *
 * @category constructors
 * @since 0.7.0
 */
export declare function decodeParam<I = StatusOpen, E = never, A = never>(
  name: string,
  f: (input: unknown) => E.Either<E, A>
): Middleware<I, I, E, A>
/**
 * Returns a middleware that tries to decode `connection.getParams()`
 *
 * @category constructors
 * @since 0.7.0
 */
export declare function decodeParams<I = StatusOpen, E = never, A = never>(
  f: (input: unknown) => E.Either<E, A>
): Middleware<I, I, E, A>
/**
 * Returns a middleware that tries to decode `connection.getQuery()`
 *
 * @category constructors
 * @since 0.7.0
 */
export declare function decodeQuery<I = StatusOpen, E = never, A = never>(
  f: (input: unknown) => E.Either<E, A>
): Middleware<I, I, E, A>
/**
 * Returns a middleware that tries to decode `connection.getBody()`
 *
 * @category constructors
 * @since 0.7.0
 */
export declare function decodeBody<I = StatusOpen, E = never, A = never>(
  f: (input: unknown) => E.Either<E, A>
): Middleware<I, I, E, A>
/**
 * Returns a middleware that tries to decode `connection.getMethod()`
 *
 * @category constructors
 * @since 0.7.0
 */
export declare function decodeMethod<I = StatusOpen, E = never, A = never>(
  f: (method: string) => E.Either<E, A>
): Middleware<I, I, E, A>
/**
 * Returns a middleware that tries to decode `connection.getHeader(name)`
 *
 * @category constructors
 * @since 0.7.0
 */
export declare function decodeHeader<I = StatusOpen, E = never, A = never>(
  name: string,
  f: (input: unknown) => E.Either<E, A>
): Middleware<I, I, E, A>
/**
 * @category instances
 * @since 0.7.0
 */
export declare const Functor: Functor3<URI>
/**
 * @category instances
 * @since 0.7.0
 */
export declare const Pointed: Pointed3<URI>
/**
 * @category instances
 * @since 0.7.0
 */
export declare const ApplyPar: Apply3<URI>
/**
 * @category instances
 * @since 0.7.0
 */
export declare const ApplySeq: Apply3<URI>
/**
 * @category instances
 * @since 0.7.0
 */
export declare const ApplicativePar: Applicative3<URI>
/**
 * @category instances
 * @since 0.7.0
 */
export declare const ApplicativeSeq: Applicative3<URI>
/**
 * @category instances
 * @since 0.7.0
 */
export declare const Chain: Chain3<URI>
/**
 * @category instances
 * @since 0.7.0
 */
export declare const Monad: Monad3<URI>
/**
 * @category instances
 * @since 0.7.0
 */
export declare const MonadThrow: MonadThrow3<URI>
/**
 * @category instances
 * @since 0.7.0
 */
export declare const Alt: Alt3<URI>
/**
 * @category instances
 * @since 0.7.0
 */
export declare const FromEither: FromEither3<URI>
/**
 * @category instances
 * @since 0.7.0
 */
export declare const Bifunctor: Bifunctor3<URI>
/**
 * @category instances
 * @since 0.7.0
 */
export declare const MonadTask: MonadTask3<URI>
/**
 * @category combinators
 * @since 0.7.0
 */
export declare const apFirst: <R, E, B>(
  second: Middleware<R, R, E, B>
) => <A>(first: Middleware<R, R, E, A>) => Middleware<R, R, E, A>
/**
 * Less strict version of [`apFirst`](#apfirst).
 *
 * @category combinators
 * @since 0.7.1
 */
export declare const apFirstW: <I, E2, B>(
  second: Middleware<I, I, E2, B>
) => <E1, A>(first: Middleware<I, I, E1, A>) => Middleware<I, I, E1 | E2, A>
/**
 * Indexed version of [`apFirst`](#apfirst).
 *
 * @category combinators
 * @since 0.7.9
 */
export declare const iapFirst: <O, Z, E, B>(
  second: Middleware<O, Z, E, B>
) => <I, A>(first: Middleware<I, O, E, A>) => Middleware<I, Z, E, A>
/**
 * Less strict version of [`iapFirst`](#iapfirst).
 *
 * @category combinators
 * @since 0.7.1
 */
export declare const iapFirstW: <O, Z, E2, B>(
  second: Middleware<O, Z, E2, B>
) => <I, E1, A>(first: Middleware<I, O, E1, A>) => Middleware<I, Z, E1 | E2, A>
/**
 * @category combinators
 * @since 0.7.0
 */
export declare const apSecond: <R, E, B>(
  second: Middleware<R, R, E, B>
) => <A>(first: Middleware<R, R, E, A>) => Middleware<R, R, E, B>
/**
 * Less strict version of [`apSecond`](#apsecond).
 *
 * @category combinators
 * @since 0.7.1
 */
export declare const apSecondW: <I, E2, B>(
  second: Middleware<I, I, E2, B>
) => <E1, A>(first: Middleware<I, I, E1, A>) => Middleware<I, I, E1 | E2, B>
/**
 * Indexed version of [`apSecond`](#apsecond).
 *
 * @category combinators
 * @since 0.7.9
 */
export declare const iapSecond: <O, Z, E, B>(
  second: Middleware<O, Z, E, B>
) => <I, A>(first: Middleware<I, O, E, A>) => Middleware<I, Z, E, B>
/**
 * Less strict version of [`iapSecond`](#iapsecond).
 *
 * @category combinators
 * @since 0.7.9
 */
export declare const iapSecondW: <O, Z, E2, B>(
  second: Middleware<O, Z, E2, B>
) => <I, E1, A>(first: Middleware<I, O, E1, A>) => Middleware<I, Z, E1 | E2, B>
/**
 * Composes computations in sequence, using the return value of one computation to determine the next computation and
 * keeping only the result of the first.
 *
 * Derivable from `Chain`.
 *
 * @category combinators
 * @since 0.7.0
 */
export declare const chainFirst: <A, R, E, _>(
  f: (a: A) => Middleware<R, R, E, _>
) => (first: Middleware<R, R, E, A>) => Middleware<R, R, E, A>
/**
 * Less strict version of [`chainFirst`](#chainfirst).
 *
 * Derivable from `Chain`.
 *
 * @category combinators
 * @since 0.7.0
 */
export declare const chainFirstW: <I, E2, A, B>(
  f: (a: A) => Middleware<I, I, E2, B>
) => <E1>(ma: Middleware<I, I, E1, A>) => Middleware<I, I, E1 | E2, A>
/**
 * @category constructors
 * @since 0.7.0
 */
export declare const fromPredicate: {
  <E, A, B extends A>(refinement: Refinement<A, B>, onFalse: (a: A) => E): <I>(a: A) => Middleware<I, I, E, B>
  <E, A>(predicate: Predicate<A>, onFalse: (a: A) => E): <I>(a: A) => Middleware<I, I, E, A>
}
/**
 * @category combinators
 * @since 0.7.0
 */
export declare const filterOrElse: {
  <E, A, B extends A>(refinement: Refinement<A, B>, onFalse: (a: A) => E): <I>(
    ma: Middleware<I, I, E, A>
  ) => Middleware<I, I, E, B>
  <E, A>(predicate: Predicate<A>, onFalse: (a: A) => E): <I>(ma: Middleware<I, I, E, A>) => Middleware<I, I, E, A>
}
/**
 * Less strict version of [`filterOrElse`](#filterorelse).
 *
 * @category combinators
 * @since 0.7.0
 */
export declare const filterOrElseW: {
  <A, B extends A, E2>(refinement: Refinement<A, B>, onFalse: (a: A) => E2): <I, E1>(
    ma: Middleware<I, I, E1, A>
  ) => Middleware<I, I, E1 | E2, B>
  <A, E2>(predicate: Predicate<A>, onFalse: (a: A) => E2): <I, E1>(
    ma: Middleware<I, I, E1, A>
  ) => Middleware<I, I, E1 | E2, A>
}
/**
 * @category natural transformations
 * @since 0.7.0
 */
export declare const fromOption: <E>(onNone: Lazy<E>) => <I, A>(ma: O.Option<A>) => Middleware<I, I, E, A>
/**
 * @category combinators
 * @since 0.7.9
 */
export declare const fromEitherK: <E, A extends ReadonlyArray<unknown>, B>(
  f: (...a: A) => E.Either<E, B>
) => <I>(...a: A) => Middleware<I, I, E, B>
/**
 * @category combinators
 * @since 0.7.9
 */
export declare const fromOptionK: <E>(
  onNone: Lazy<E>
) => <A extends ReadonlyArray<unknown>, B>(f: (...a: A) => O.Option<B>) => <I>(...a: A) => Middleware<I, I, E, B>
/**
 * @category combinators
 * @since 0.7.0
 */
export declare const chainEitherK: <E, A, B>(
  f: (a: A) => E.Either<E, B>
) => <I>(ma: Middleware<I, I, E, A>) => Middleware<I, I, E, B>
/**
 * Less strict version of [`chainEitherK`](#chaineitherk).
 *
 * @category combinators
 * @since 0.7.0
 */
export declare const chainEitherKW: <E2, A, B>(
  f: (a: A) => E.Either<E2, B>
) => <I, E1>(ma: Middleware<I, I, E1, A>) => Middleware<I, I, E1 | E2, B>
/**
 * @category combinators
 * @since 0.7.9
 */
export declare const chainOptionK: <E>(
  onNone: Lazy<E>
) => <A, B>(f: (a: A) => O.Option<B>) => <I>(ma: Middleware<I, I, E, A>) => Middleware<I, I, E, B>
/**
 * Less strict version of [`chainOptionK`](#chainoptionk).
 *
 * @category combinators
 * @since 0.7.9
 */
export declare const chainOptionKW: <E2>(
  onNone: Lazy<E2>
) => <A, B>(f: (a: A) => O.Option<B>) => <I, E1>(ma: Middleware<I, I, E1, A>) => Middleware<I, I, E1 | E2, B>
/**
 * @category natural transformations
 * @since 0.7.0
 */
export declare const fromIO: FromIO3<URI>['fromIO']
/**
 * @category instances
 * @since 0.7.0
 */
export declare const FromIO: FromIO3<URI>
/**
 * @category combinators
 * @since 0.7.0
 */
export declare const fromIOK: <A extends readonly unknown[], B>(
  f: (...a: A) => IO<B>
) => <R, E>(...a: A) => Middleware<R, R, E, B>
/**
 * @category combinators
 * @since 0.7.0
 */
export declare const chainIOK: <A, B>(
  f: (a: A) => IO<B>
) => <R, E>(first: Middleware<R, R, E, A>) => Middleware<R, R, E, B>
/**
 * @category combinators
 * @since 0.7.0
 */
export declare const chainFirstIOK: <A, B>(
  f: (a: A) => IO<B>
) => <R, E>(first: Middleware<R, R, E, A>) => Middleware<R, R, E, A>
/**
 * @category natural transformations
 * @since 0.7.0
 */
export declare const fromTask: FromTask3<URI>['fromTask']
/**
 * @category instances
 * @since 0.7.0
 */
export declare const FromTask: FromTask3<URI>
/**
 * @category combinators
 * @since 0.7.0
 */
export declare const fromTaskK: <A extends readonly unknown[], B>(
  f: (...a: A) => T.Task<B>
) => <R, E>(...a: A) => Middleware<R, R, E, B>
/**
 * @category combinators
 * @since 0.7.0
 */
export declare const chainTaskK: <A, B>(
  f: (a: A) => T.Task<B>
) => <R, E>(first: Middleware<R, R, E, A>) => Middleware<R, R, E, B>
/**
 * @category combinators
 * @since 0.7.0
 */
export declare const chainFirstTaskK: <A, B>(
  f: (a: A) => T.Task<B>
) => <R, E>(first: Middleware<R, R, E, A>) => Middleware<R, R, E, A>
/**
 * Less strict version of [`chainTaskEitherK`](#chaintaskeitherk).
 *
 * @category combinators
 * @since 0.7.0
 */
export declare const chainTaskEitherKW: <E2, A, B>(
  f: (a: A) => TE.TaskEither<E2, B>
) => <I, E1>(ma: Middleware<I, I, E1, A>) => Middleware<I, I, E1 | E2, B>
/**
 * @category combinators
 * @since 0.7.0
 */
export declare const chainTaskEitherK: <E, A, B>(
  f: (a: A) => TE.TaskEither<E, B>
) => <I>(ma: Middleware<I, I, E, A>) => Middleware<I, I, E, B>
/**
 * Less strict version of [`chainFirstTaskEitherK`](#chainfirsttaskeitherk).
 *
 * @category combinators
 * @since 0.7.0
 */
export declare const chainFirstTaskEitherKW: <E2, A, B>(
  f: (a: A) => TE.TaskEither<E2, B>
) => <I, E1>(ma: Middleware<I, I, E1, A>) => Middleware<I, I, E1 | E2, A>
/**
 * @category combinators
 * @since 0.7.0
 */
export declare const chainFirstTaskEitherK: <E, A, B>(
  f: (a: A) => TE.TaskEither<E, B>
) => <I>(ma: Middleware<I, I, E, A>) => Middleware<I, I, E, A>
/**
 * Less strict version of [`chainTaskOptionK`](#chaintaskoptionk).
 *
 * @category combinators
 * @since 0.7.9
 */
export declare const chainTaskOptionKW: <E2>(
  onNone: Lazy<E2>
) => <A, B>(f: (a: A) => TO.TaskOption<B>) => <I, E1>(ma: Middleware<I, I, E1, A>) => Middleware<I, I, E1 | E2, B>
/**
 * @category combinators
 * @since 0.7.9
 */
export declare const chainTaskOptionK: <E>(
  onNone: Lazy<E>
) => <A, B>(f: (a: A) => TO.TaskOption<B>) => <I>(ma: Middleware<I, I, E, A>) => Middleware<I, I, E, B>
/**
 * Less strict version of [`chainFirstTaskOptionK`](#chainfirsttaskoptionk).
 *
 * @category combinators
 * @since 0.7.9
 */
export declare const chainFirstTaskOptionKW: <E2>(
  onNone: Lazy<E2>
) => <A, B>(f: (a: A) => TO.TaskOption<B>) => <I, E1>(ma: Middleware<I, I, E1, A>) => Middleware<I, I, E1 | E2, A>
/**
 * @category combinators
 * @since 0.7.9
 */
export declare const chainFirstTaskOptionK: <E>(
  onNone: Lazy<E>
) => <A, B>(f: (a: A) => TO.TaskOption<B>) => <I>(ma: Middleware<I, I, E, A>) => Middleware<I, I, E, A>
/**
 * Phantom type can't be infered properly, use [`bindTo`](#bindto) instead.
 *
 * @since 0.7.0
 * @deprecated
 */
export declare const Do: Middleware<unknown, unknown, never, {}>
/**
 * @since 0.7.0
 */
export declare const bindTo: <N extends string>(
  name: N
) => <R, E, A>(fa: Middleware<R, R, E, A>) => Middleware<R, R, E, { readonly [K in N]: A }>
/**
 * Indexed version of [`bindTo`](#bindto).
 *
 * @since 0.7.0
 */
export declare const ibindTo: <N extends string>(
  name: N
) => <I, O, E, A>(
  fa: Middleware<I, O, E, A>
) => Middleware<
  I,
  O,
  E,
  {
    readonly [K in N]: A
  }
>
/**
 * @since 0.7.0
 */
export declare const bind: <N extends string, A, R, E, B>(
  name: Exclude<N, keyof A>,
  f: (a: A) => Middleware<R, R, E, B>
) => (ma: Middleware<R, R, E, A>) => Middleware<R, R, E, { readonly [K in N | keyof A]: K extends keyof A ? A[K] : B }>
/**
 * @since 0.7.0
 */
export declare const bindW: <N extends string, I, A, E2, B>(
  name: Exclude<N, keyof A>,
  f: (a: A) => Middleware<I, I, E2, B>
) => <E1>(fa: Middleware<I, I, E1, A>) => Middleware<
  I,
  I,
  E1 | E2,
  {
    [K in keyof A | N]: K extends keyof A ? A[K] : B
  }
>
/**
 * Less strict version of [`ibind`](#ibind).
 *
 * @since 0.7.0
 */
export declare const ibindW: <N extends string, A, O, Z, E2, B>(
  name: Exclude<N, keyof A>,
  f: (a: A) => Middleware<O, Z, E2, B>
) => <I, E1>(
  ma: Middleware<I, O, E1, A>
) => Middleware<
  I,
  Z,
  E1 | E2,
  {
    readonly [K in N | keyof A]: K extends keyof A ? A[K] : B
  }
>
/**
 * @since 0.7.0
 */
export declare const ibind: <N extends string, A, O, Z, E, B>(
  name: Exclude<N, keyof A>,
  f: (a: A) => Middleware<O, Z, E, B>
) => <I>(ma: Middleware<I, O, E, A>) => Middleware<
  I,
  Z,
  E,
  {
    readonly [K in N | keyof A]: K extends keyof A ? A[K] : B
  }
>
/**
 * @since 0.7.0
 */
export declare const apS: <N extends string, A, R, E, B>(
  name: Exclude<N, keyof A>,
  fb: Middleware<R, R, E, B>
) => (fa: Middleware<R, R, E, A>) => Middleware<R, R, E, { readonly [K in N | keyof A]: K extends keyof A ? A[K] : B }>
/**
 * Less strict version of [`apS`](#aps).
 *
 * @since 0.7.0
 */
export declare const apSW: <N extends string, A, I, E2, B>(
  name: Exclude<N, keyof A>,
  fb: Middleware<I, I, E2, B>
) => <E1>(fa: Middleware<I, I, E1, A>) => Middleware<
  I,
  I,
  E1 | E2,
  {
    readonly [K in keyof A | N]: K extends keyof A ? A[K] : B
  }
>
/**
 * Less strict version of [`iapS`](#iaps).
 *
 * @since 0.7.0
 */
export declare const iapSW: <N extends string, A, I, O, E2, B>(
  name: Exclude<N, keyof A>,
  fb: Middleware<I, O, E2, B>
) => <E1>(fa: Middleware<I, O, E1, A>) => Middleware<
  I,
  O,
  E1 | E2,
  {
    readonly [K in keyof A | N]: K extends keyof A ? A[K] : B
  }
>
/**
 * @since 0.7.0
 */
export declare const iapS: <N extends string, A, I, O, E, B>(
  name: Exclude<N, keyof A>,
  fb: Middleware<I, O, E, B>
) => (fa: Middleware<I, O, E, A>) => Middleware<
  I,
  O,
  E,
  {
    readonly [K in N | keyof A]: K extends keyof A ? A[K] : B
  }
>
