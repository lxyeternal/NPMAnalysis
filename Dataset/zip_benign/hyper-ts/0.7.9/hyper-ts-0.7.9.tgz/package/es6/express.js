import { execMiddleware } from './Middleware';
import * as E from 'fp-ts/Either';
import { pipe } from 'fp-ts/function';
import * as L from 'fp-ts-contrib/List';
import { pipeline } from 'stream';
import * as IO from 'fp-ts/IO';
import * as O from 'fp-ts/Option';
const endResponse = { type: 'endResponse' };
/**
 * @category model
 * @since 0.5.0
 */
export class ExpressConnection {
    constructor(req, res, actions = L.nil, ended = false) {
        this.req = req;
        this.res = res;
        this.actions = actions;
        this.ended = ended;
    }
    /**
     * @since 0.5.0
     */
    chain(action, ended = false) {
        return new ExpressConnection(this.req, this.res, L.cons(action, this.actions), ended);
    }
    /**
     * @since 0.5.0
     */
    getRequest() {
        return this.req;
    }
    /**
     * @since 0.5.0
     */
    getBody() {
        return this.req.body;
    }
    /**
     * @since 0.5.0
     */
    getHeader(name) {
        return this.req.header(name);
    }
    /**
     * @since 0.5.0
     */
    getParams() {
        return this.req.params;
    }
    /**
     * @since 0.5.0
     */
    getQuery() {
        return this.req.query;
    }
    /**
     * @since 0.5.0
     */
    getOriginalUrl() {
        return this.req.originalUrl;
    }
    /**
     * @since 0.5.0
     */
    getMethod() {
        return this.req.method;
    }
    /**
     * @since 0.5.0
     */
    setCookie(name, value, options) {
        return this.chain({ type: 'setCookie', name, value, options });
    }
    /**
     * @since 0.5.0
     */
    clearCookie(name, options) {
        return this.chain({ type: 'clearCookie', name, options });
    }
    /**
     * @since 0.5.0
     */
    setHeader(name, value) {
        return this.chain({ type: 'setHeader', name, value });
    }
    /**
     * @since 0.5.0
     */
    setStatus(status) {
        return this.chain({ type: 'setStatus', status });
    }
    /**
     * @since 0.5.0
     */
    setBody(body) {
        return this.chain({ type: 'setBody', body }, true);
    }
    /**
     * @since 0.6.2
     */
    pipeStream(stream, onError) {
        return this.chain({ type: 'pipeStream', stream, onError }, true);
    }
    /**
     * @since 0.5.0
     */
    endResponse() {
        return this.chain(endResponse, true);
    }
}
function run(res, action) {
    switch (action.type) {
        case 'clearCookie':
            return res.clearCookie(action.name, action.options);
        case 'endResponse':
            res.end();
            return res;
        case 'setBody':
            return res.send(action.body);
        case 'setCookie':
            return res.cookie(action.name, action.value, action.options);
        case 'setHeader':
            res.setHeader(action.name, action.value);
            return res;
        case 'setStatus':
            return res.status(action.status);
        case 'pipeStream':
            return pipeline(action.stream, res, (err) => pipe(err, O.fromNullable, O.traverse(IO.Applicative)(action.onError))());
    }
}
function exec(middleware, req, res, next) {
    return execMiddleware(middleware, new ExpressConnection(req, res))().then((e) => pipe(e, E.fold((e) => next(e), (c) => {
        const { actions: list, res, ended } = c;
        const len = list.length;
        const actions = L.toReversedArray(list);
        for (let i = 0; i < len; i++) {
            run(res, actions[i]);
        }
        if (!ended) {
            next();
        }
    })));
}
/**
 * @since 0.5.0
 */
export function toRequestHandler(middleware) {
    return (req, res, next) => exec(middleware, req, res, next);
}
/**
 * @since 0.5.0
 */
export function toErrorRequestHandler(f) {
    return (err, req, res, next) => exec(f(err), req, res, next);
}
export function fromRequestHandler(requestHandler, f, onError) {
    return (c) => () => new Promise((resolve) => {
        const { req, res } = c;
        // tslint:disable-next-line strict-boolean-expressions
        const cb = onError
            ? (err) => 
            // tslint:disable-next-line strict-boolean-expressions
            err
                ? resolve(E.left(onError(err)))
                : pipe(req, f, E.map((a) => [a, c]), resolve)
            : () => resolve(E.right([f(req), c]));
        requestHandler(req, res, cb);
    });
}
