/// <reference types="node" />
/**
 * @since 0.6.3
 */
import { Lazy } from 'fp-ts/function'
import { Chain4 } from 'fp-ts/Chain'
import { ReaderTask } from 'fp-ts/ReaderTask'
import { Task } from 'fp-ts/Task'
import * as TE from 'fp-ts/TaskEither'
import * as TO from 'fp-ts/TaskOption'
import * as H from '.'
import * as M from './Middleware'
import { IO } from 'fp-ts/IO'
import { IOEither } from 'fp-ts/IOEither'
import * as E from 'fp-ts/Either'
import * as O from 'fp-ts/Option'
import { Monad4 } from 'fp-ts/Monad'
import { Alt4 } from 'fp-ts/Alt'
import { Bifunctor4 } from 'fp-ts/Bifunctor'
import { MonadThrow4 } from 'fp-ts/MonadThrow'
import { Functor4 } from 'fp-ts/Functor'
import { Apply4 } from 'fp-ts/Apply'
import { Applicative4 } from 'fp-ts/Applicative'
import { ReaderEither } from 'fp-ts/ReaderEither'
import { ReaderTaskEither } from 'fp-ts/ReaderTaskEither'
import { Reader } from 'fp-ts/Reader'
import { FromEither4 } from 'fp-ts/FromEither'
import { FromIO4 } from 'fp-ts/FromIO'
import { FromTask4 } from 'fp-ts/FromTask'
import { ReaderIO } from 'fp-ts/ReaderIO'
import { Refinement } from 'fp-ts/Refinement'
import { Predicate } from 'fp-ts/Predicate'
/**
 * @category instances
 * @since 0.6.3
 */
export declare const URI = 'ReaderMiddleware'
/**
 * @category instances
 * @since 0.6.3
 */
export declare type URI = typeof URI
declare module 'fp-ts/HKT' {
  interface URItoKind4<S, R, E, A> {
    readonly [URI]: ReaderMiddleware<S, R, R, E, A>
  }
}
/**
 * @category model
 * @since 0.6.3
 */
export interface ReaderMiddleware<R, I, O, E, A> {
  (r: R): M.Middleware<I, O, E, A>
}
/**
 * @category natural transformations
 * @since 0.6.3
 */
export declare function fromTaskEither<R, I = H.StatusOpen, E = never, A = never>(
  fa: TE.TaskEither<E, A>
): ReaderMiddleware<R, I, I, E, A>
/**
 * @category natural transformations
 * @since 0.7.9
 */
export declare const fromTaskOption: <E>(
  onNone: Lazy<E>
) => <R, I = H.StatusOpen, A = never>(fa: TO.TaskOption<A>) => ReaderMiddleware<R, I, I, E, A>
/**
 * @category natural transformations
 * @since 0.7.9
 */
export declare function fromReaderEither<R, I = H.StatusOpen, E = never, A = never>(
  fa: ReaderEither<R, E, A>
): ReaderMiddleware<R, I, I, E, A>
/**
 * @category natural transformations
 * @since 0.7.9
 */
export declare function fromReaderIO<R, I = H.StatusOpen, A = never>(
  fa: ReaderIO<R, A>
): ReaderMiddleware<R, I, I, never, A>
/**
 * @category natural transformations
 * @since 0.7.9
 */
export declare function fromReaderTask<R, I = H.StatusOpen, A = never>(
  fa: ReaderTask<R, A>
): ReaderMiddleware<R, I, I, never, A>
/**
 * @category natural transformations
 * @since 0.6.3
 */
export declare function fromReaderTaskEither<R, I = H.StatusOpen, E = never, A = never>(
  fa: ReaderTaskEither<R, E, A>
): ReaderMiddleware<R, I, I, E, A>
/**
 * @category natural transformations
 * @since 0.6.3
 */
export declare const fromMiddleware: <R, I = H.StatusOpen, O = I, E = never, A = never>(
  fa: M.Middleware<I, O, E, A>
) => ReaderMiddleware<R, I, O, E, A>
/**
 * @category constructors
 * @since 0.7.0
 */
export declare function gets<R, I = H.StatusOpen, E = never, A = never>(
  f: (c: H.Connection<I>) => A
): ReaderMiddleware<R, I, I, E, A>
/**
 * @category constructors
 * @since 0.7.0
 */
export declare function fromConnection<R, I = H.StatusOpen, E = never, A = never>(
  f: (c: H.Connection<I>) => E.Either<E, A>
): ReaderMiddleware<R, I, I, E, A>
/**
 * @category constructors
 * @since 0.7.0
 */
export declare function modifyConnection<R, I, O, E>(
  f: (c: H.Connection<I>) => H.Connection<O>
): ReaderMiddleware<R, I, O, E, void>
/**
 * @category constructors
 * @since 0.6.3
 */
export declare function right<R, I = H.StatusOpen, E = never, A = never>(a: A): ReaderMiddleware<R, I, I, E, A>
/**
 * @category constructors
 * @since 0.6.3
 */
export declare function left<R, I = H.StatusOpen, E = never, A = never>(e: E): ReaderMiddleware<R, I, I, E, A>
/**
 * @category constructors
 * @since 0.6.3
 */
export declare function rightTask<R, I = H.StatusOpen, E = never, A = never>(
  fa: Task<A>
): ReaderMiddleware<R, I, I, E, A>
/**
 * @category constructors
 * @since 0.6.3
 */
export declare function leftTask<R, I = H.StatusOpen, E = never, A = never>(
  te: Task<E>
): ReaderMiddleware<R, I, I, E, A>
/**
 * @category constructors
 * @since 0.6.3
 */
export declare function rightIO<R, I = H.StatusOpen, E = never, A = never>(fa: IO<A>): ReaderMiddleware<R, I, I, E, A>
/**
 * @category constructors
 * @since 0.6.3
 */
export declare function leftIO<R, I = H.StatusOpen, E = never, A = never>(fe: IO<E>): ReaderMiddleware<R, I, I, E, A>
/**
 * @category natural transformations
 * @since 0.7.0
 */
export declare const fromEither: <R, I = H.StatusOpen, E = never, A = never>(
  e: E.Either<E, A>
) => ReaderMiddleware<R, I, I, E, A>
/**
 * @category natural transformations
 * @since 0.6.3
 */
export declare function fromIOEither<R, I = H.StatusOpen, E = never, A = never>(
  fa: IOEither<E, A>
): ReaderMiddleware<R, I, I, E, A>
/**
 * @category constructors
 * @since 0.6.3
 */
export declare const rightReader: <R, I = H.StatusOpen, E = never, A = never>(
  ma: Reader<R, A>
) => ReaderMiddleware<R, I, I, E, A>
/**
 * @category constructors
 * @since 0.6.3
 */
export declare function leftReader<R, I = H.StatusOpen, E = never, A = never>(
  me: Reader<R, E>
): ReaderMiddleware<R, I, I, E, A>
/**
 * @category constructors
 * @since 0.7.9
 */
export declare const rightReaderIO: <R, I = H.StatusOpen, E = never, A = never>(
  ma: ReaderIO<R, A>
) => ReaderMiddleware<R, I, I, E, A>
/**
 * @category constructors
 * @since 0.7.9
 */
export declare const leftReaderIO: <R, I = H.StatusOpen, E = never, A = never>(
  me: ReaderIO<R, E>
) => ReaderMiddleware<R, I, I, E, A>
/**
 * @category constructors
 * @since 0.7.7
 */
export declare const rightReaderTask: <R, I = H.StatusOpen, E = never, A = never>(
  ma: ReaderTask<R, A>
) => ReaderMiddleware<R, I, I, E, A>
/**
 * @category constructors
 * @since 0.7.7
 */
export declare const leftReaderTask: <R, I = H.StatusOpen, E = never, A = never>(
  me: ReaderTask<R, E>
) => ReaderMiddleware<R, I, I, E, A>
/**
 * @category constructors
 * @since 0.6.3
 */
export declare const ask: <R, I = H.StatusOpen, E = never>() => ReaderMiddleware<R, I, I, E, R>
/**
 * @category constructors
 * @since 0.6.3
 */
export declare const asks: <R, E = never, A = never>(
  f: (r: R) => A
) => ReaderMiddleware<R, H.StatusOpen, H.StatusOpen, E, A>
/**
 * Less strict version of [`asksReaderMiddleware`](#asksreadermiddleware).
 *
 * @category combinators
 * @since 0.7.9
 */
export declare const asksReaderMiddlewareW: <R1, R2, E = never, A = never>(
  f: (r: R1) => ReaderMiddleware<R2, H.StatusOpen, H.StatusOpen, E, A>
) => ReaderMiddleware<R1 & R2, H.StatusOpen, H.StatusOpen, E, A>
/**
 * Effectfully accesses the environment.
 *
 * @category combinators
 * @since 0.7.9
 */
export declare const asksReaderMiddleware: <R, E = never, A = never>(
  f: (r: R) => ReaderMiddleware<R, H.StatusOpen, H.StatusOpen, E, A>
) => ReaderMiddleware<R, H.StatusOpen, H.StatusOpen, E, A>
/**
 * @category combinators
 * @since 0.7.9
 */
export declare const fromReaderK: <R, A extends readonly unknown[], B, I = H.StatusOpen, E = never>(
  f: (...a: A) => Reader<R, B>
) => (...a: A) => ReaderMiddleware<R, I, I, E, B>
/**
 * @category combinators
 * @since 0.7.9
 */
export declare const fromReaderIOK: <R, A extends readonly unknown[], B, I = H.StatusOpen, E = never>(
  f: (...a: A) => ReaderIO<R, B>
) => (...a: A) => ReaderMiddleware<R, I, I, E, B>
/**
 * @category combinators
 * @since 0.7.8
 */
export declare const fromReaderTaskK: <R, A extends readonly unknown[], B, I = H.StatusOpen, E = never>(
  f: (...a: A) => ReaderTask<R, B>
) => (...a: A) => ReaderMiddleware<R, I, I, E, B>
/**
 * @category combinators
 * @since 0.7.9
 */
export declare const fromReaderEitherK: <R, A extends readonly unknown[], B, I = H.StatusOpen, E = never>(
  f: (...a: A) => ReaderEither<R, E, B>
) => (...a: A) => ReaderMiddleware<R, I, I, E, B>
/**
 * @category combinators
 * @since 0.7.8
 */
export declare const fromReaderTaskEitherK: <R, A extends readonly unknown[], B, I = H.StatusOpen, E = never>(
  f: (...a: A) => ReaderTaskEither<R, E, B>
) => (...a: A) => ReaderMiddleware<R, I, I, E, B>
/**
 * Less strict version of [`orElse`](#orelse).
 *
 * @category combinators
 * @since 0.6.4
 */
export declare const orElseW: <R2, E, I, O, M, B>(
  f: (e: E) => ReaderMiddleware<R2, I, O, M, B>
) => <R1, A>(ma: ReaderMiddleware<R1, I, O, E, A>) => ReaderMiddleware<R2 & R1, I, O, M, B | A>
/**
 * @category combinators
 * @since 0.6.3
 */
export declare const orElse: <R, E, I, O, M, A>(
  f: (e: E) => ReaderMiddleware<R, I, O, M, A>
) => (ma: ReaderMiddleware<R, I, O, E, A>) => ReaderMiddleware<R, I, O, M, A>
/**
 * Less strict version of [`orElseMiddlewareK`](#orelsemiddlewarek).
 *
 * @category combinators
 * @since 0.7.7
 */
export declare const orElseMiddlewareKW: <E, I, O, M, B>(
  f: (e: E) => M.Middleware<I, O, M, B>
) => <R, A>(ma: ReaderMiddleware<R, I, O, E, A>) => ReaderMiddleware<R, I, O, M, B | A>
/**
 * @category combinators
 * @since 0.7.7
 */
export declare const orElseMiddlewareK: <E, I, O, M, A>(
  f: (e: E) => M.Middleware<I, O, M, A>
) => <R>(ma: ReaderMiddleware<R, I, O, E, A>) => ReaderMiddleware<R, I, O, M, A>
/**
 * @category constructors
 * @since 0.6.3
 */
export declare function status<R, E = never>(
  status: H.Status
): ReaderMiddleware<R, H.StatusOpen, H.HeadersOpen, E, void>
/**
 * @category constructors
 * @since 0.6.3
 */
export declare function header<R, E = never>(
  name: string,
  value: string
): ReaderMiddleware<R, H.HeadersOpen, H.HeadersOpen, E, void>
/**
 * @category constructors
 * @since 0.6.3
 */
export declare function contentType<R, E = never>(
  mediaType: H.MediaType
): ReaderMiddleware<R, H.HeadersOpen, H.HeadersOpen, E, void>
/**
 * @category constructors
 * @since 0.6.3
 */
export declare function cookie<R, E = never>(
  name: string,
  value: string,
  options: H.CookieOptions
): ReaderMiddleware<R, H.HeadersOpen, H.HeadersOpen, E, void>
/**
 * @category constructors
 * @since 0.6.3
 */
export declare function clearCookie<R, E = never>(
  name: string,
  options: H.CookieOptions
): ReaderMiddleware<R, H.HeadersOpen, H.HeadersOpen, E, void>
/**
 * @category constructors
 * @since 0.6.3
 */
export declare function closeHeaders<R, E = never>(): ReaderMiddleware<R, H.HeadersOpen, H.BodyOpen, E, void>
/**
 * @category constructors
 * @since 0.6.3
 */
export declare function send<R, E = never>(
  body: string | Buffer
): ReaderMiddleware<R, H.BodyOpen, H.ResponseEnded, E, void>
/**
 * @category constructors
 * @since 0.6.3
 */
export declare function end<R, E = never>(): ReaderMiddleware<R, H.BodyOpen, H.ResponseEnded, E, void>
/**
 * @category constructors
 * @since 0.6.3
 */
export declare function json<R, E>(
  body: unknown,
  onError: (reason: unknown) => E
): ReaderMiddleware<R, H.HeadersOpen, H.ResponseEnded, E, void>
/**
 * @category constructors
 * @since 0.6.3
 */
export declare function redirect<R, E = never>(
  uri:
    | string
    | {
        href: string
      }
): ReaderMiddleware<R, H.StatusOpen, H.HeadersOpen, E, void>
/**
 * Returns a `ReaderMiddleware` that pipes a stream to the response object.
 *
 * @category constructors
 * @since 0.7.3
 */
export declare function pipeStream<R, E>(
  stream: NodeJS.ReadableStream,
  onError: (reason: unknown) => ReaderIO<R, void>
): ReaderMiddleware<R, H.BodyOpen, H.ResponseEnded, E, void>
/**
 * @category constructors
 * @since 0.6.3
 */
export declare function decodeParam<R, I = H.StatusOpen, E = never, A = never>(
  name: string,
  f: (input: unknown) => E.Either<E, A>
): ReaderMiddleware<R, I, I, E, A>
/**
 * @category constructors
 * @since 0.6.3
 */
export declare function decodeParams<R, I = H.StatusOpen, E = never, A = never>(
  f: (input: unknown) => E.Either<E, A>
): ReaderMiddleware<R, I, I, E, A>
/**
 * @category constructors
 * @since 0.6.3
 */
export declare function decodeQuery<R, I = H.StatusOpen, E = never, A = never>(
  f: (input: unknown) => E.Either<E, A>
): ReaderMiddleware<R, I, I, E, A>
/**
 * @category constructors
 * @since 0.6.3
 */
export declare function decodeBody<R, I = H.StatusOpen, E = never, A = never>(
  f: (input: unknown) => E.Either<E, A>
): ReaderMiddleware<R, I, I, E, A>
/**
 * @category constructors
 * @since 0.6.3
 */
export declare function decodeMethod<R, I = H.StatusOpen, E = never, A = never>(
  f: (method: string) => E.Either<E, A>
): ReaderMiddleware<R, I, I, E, A>
/**
 * @category constructors
 * @since 0.6.3
 */
export declare function decodeHeader<R, I = H.StatusOpen, E = never, A = never>(
  name: string,
  f: (input: unknown) => E.Either<E, A>
): ReaderMiddleware<R, I, I, E, A>
/**
 * `map` can be used to turn functions `(a: A) => B` into functions `(fa: F<A>) => F<B>` whose argument and return types
 * use the type constructor `F` to represent some computational context.
 *
 * @category Functor
 * @since 0.6.3
 */
export declare const map: <A, B>(
  f: (a: A) => B
) => <R, I, E>(fa: ReaderMiddleware<R, I, I, E, A>) => ReaderMiddleware<R, I, I, E, B>
/**
 * Indexed version of [`map`](#map).
 *
 * @category IxFunctor
 * @since 0.7.0
 */
export declare const imap: <A, B>(
  f: (a: A) => B
) => <R, I, O, E>(fa: ReaderMiddleware<R, I, O, E, A>) => ReaderMiddleware<R, I, O, E, B>
/**
 * Map a pair of functions over the two last type arguments of the bifunctor.
 *
 * @category Bifunctor
 * @since 0.6.3
 */
export declare const bimap: <E, G, A, B>(
  f: (e: E) => G,
  g: (a: A) => B
) => <R, I>(fa: ReaderMiddleware<R, I, I, E, A>) => ReaderMiddleware<R, I, I, G, B>
/**
 * Map a function over the second type argument of a bifunctor.
 *
 * @category Bifunctor
 * @since 0.6.3
 */
export declare const mapLeft: <E, G>(
  f: (e: E) => G
) => <R, I, A>(fa: ReaderMiddleware<R, I, I, E, A>) => ReaderMiddleware<R, I, I, G, A>
/**
 * Apply a function to an argument under a type constructor.
 *
 * @category Apply
 * @since 0.6.3
 */
export declare const ap: <R, I, E, A>(
  fa: ReaderMiddleware<R, I, I, E, A>
) => <B>(fab: ReaderMiddleware<R, I, I, E, (a: A) => B>) => ReaderMiddleware<R, I, I, E, B>
/**
 * Less strict version of [`ap`](#ap).
 *
 * @category Apply
 * @since 0.6.3
 */
export declare const apW: <R2, I, E2, A>(
  fa: ReaderMiddleware<R2, I, I, E2, A>
) => <R1, E1, B>(fab: ReaderMiddleware<R1, I, I, E1, (a: A) => B>) => ReaderMiddleware<R1 & R2, I, I, E1 | E2, B>
/**
 * Indexed version of [`ap`](#ap).
 *
 * @category Apply
 * @since 0.7.9
 */
export declare const iap: <R, O, Z, E, A>(
  fa: ReaderMiddleware<R, O, Z, E, A>
) => <I, B>(fab: ReaderMiddleware<R, I, O, E, (a: A) => B>) => ReaderMiddleware<R, I, Z, E, B>
/**
 * Less strict version of [`iap`](#iap).
 *
 * @category Apply
 * @since 0.6.3
 */
export declare const iapW: <R2, O, Z, E2, A>(
  fa: ReaderMiddleware<R2, O, Z, E2, A>
) => <R1, I, E1, B>(fab: ReaderMiddleware<R1, I, O, E1, (a: A) => B>) => ReaderMiddleware<R1 & R2, I, Z, E1 | E2, B>
/**
 * @category Pointed
 * @since 0.6.3
 */
export declare const of: <R, I = H.StatusOpen, E = never, A = never>(a: A) => ReaderMiddleware<R, I, I, E, A>
/**
 * @category IxPointed
 * @since 0.6.3
 */
export declare function iof<R, I = H.StatusOpen, O = H.StatusOpen, E = never, A = never>(
  a: A
): ReaderMiddleware<R, I, O, E, A>
/**
 * Composes computations in sequence, using the return value of one computation to determine the next computation.
 *
 * @category Monad
 * @since 0.6.3
 */
export declare const chain: <R, I, E, A, B>(
  f: (a: A) => ReaderMiddleware<R, I, I, E, B>
) => (ma: ReaderMiddleware<R, I, I, E, A>) => ReaderMiddleware<R, I, I, E, B>
/**
 * Less strict version of [`chain`](#chain).
 *
 * @category Monad
 * @since 0.6.3
 */
export declare const chainW: <R2, I, E2, A, B>(
  f: (a: A) => ReaderMiddleware<R2, I, I, E2, B>
) => <R1, E1>(ma: ReaderMiddleware<R1, I, I, E1, A>) => ReaderMiddleware<R1 & R2, I, I, E1 | E2, B>
/**
 * Less strict version of [`flatten`](#flatten).
 *
 * @category combinators
 * @since 0.7.2
 */
export declare const flattenW: <R1, I, E1, R2, E2, A>(
  mma: ReaderMiddleware<R1, I, I, E1, ReaderMiddleware<R2, I, I, E2, A>>
) => ReaderMiddleware<R1 & R2, I, I, E1 | E2, A>
/**
 * Derivable from `Chain`.
 *
 * @category combinators
 * @since 0.7.2
 */
export declare const flatten: <R, I, E, A>(
  mma: ReaderMiddleware<R, I, I, E, ReaderMiddleware<R, I, I, E, A>>
) => ReaderMiddleware<R, I, I, E, A>
/**
 * Indexed version of [`chain`](#chain).
 *
 * @category IxMonad
 * @since 0.6.3
 */
export declare const ichain: <R, A, O, Z, E, B>(
  f: (a: A) => ReaderMiddleware<R, O, Z, E, B>
) => <I>(ma: ReaderMiddleware<R, I, O, E, A>) => ReaderMiddleware<R, I, Z, E, B>
/**
 * Less strict version of [`ichain`](#ichain).
 *
 * @category IxMonad
 * @since 0.6.3
 */
export declare function ichainW<R2, A, O, Z, E2, B>(
  f: (a: A) => ReaderMiddleware<R2, O, Z, E2, B>
): <R1, I, E1>(ma: ReaderMiddleware<R1, I, O, E1, A>) => ReaderMiddleware<R1 & R2, I, Z, E1 | E2, B>
/**
 * Indexed version of [`chainFirst`](#chainfirst).
 *
 * @category IxMonad
 * @since 0.7.6
 */
export declare const ichainFirst: <R, A, O, Z, E, B>(
  f: (a: A) => ReaderMiddleware<R, O, Z, E, B>
) => <I>(ma: ReaderMiddleware<R, I, O, E, A>) => ReaderMiddleware<R, I, Z, E, A>
/**
 * Less strict version of [`ichainFirst`](#ichainfirst).
 *
 * @category IxMonad
 * @since 0.7.6
 */
export declare function ichainFirstW<R2, A, O, Z, E2, B>(
  f: (a: A) => ReaderMiddleware<R2, O, Z, E2, B>
): <R1, I, E1>(ma: ReaderMiddleware<R1, I, O, E1, A>) => ReaderMiddleware<R1 & R2, I, Z, E1 | E2, A>
/**
 * Less strict version of [`iflatten`](#iflatten).
 *
 * @category combinators
 * @since 0.7.2
 */
export declare const iflattenW: <R1, I, O, Z, E1, R2, E2, A>(
  mma: ReaderMiddleware<R1, I, O, E1, ReaderMiddleware<R2, O, Z, E2, A>>
) => ReaderMiddleware<R1 & R2, I, Z, E1 | E2, A>
/**
 * Derivable from indexed version of `Chain`.
 *
 * @category combinators
 * @since 0.7.2
 */
export declare const iflatten: <R, I, O, Z, E, A>(
  mma: ReaderMiddleware<R, I, O, E, ReaderMiddleware<R, O, Z, E, A>>
) => ReaderMiddleware<R, I, Z, E, A>
/**
 * @category Alt
 * @since 0.7.5
 */
export declare const alt: <R, I, E, A>(
  that: Lazy<ReaderMiddleware<R, I, I, E, A>>
) => (fa: ReaderMiddleware<R, I, I, E, A>) => ReaderMiddleware<R, I, I, E, A>
/**
 * Less strict version of [`alt`](#alt).
 *
 * @category Alt
 * @since 0.7.5
 */
export declare const altW: <R2, I, E2, A>(
  that: Lazy<ReaderMiddleware<R2, I, I, E2, A>>
) => <R1, E1>(fa: ReaderMiddleware<R1, I, I, E1, A>) => ReaderMiddleware<R1 & R2, I, I, E1 | E2, A>
/**
 * Less strict version of [`chainMiddlewareK`](#chainmiddlewarek).
 *
 * @category combinators
 * @since 0.7.9
 */
export declare const chainMiddlewareKW: <I, E2, A, B>(
  f: (a: A) => M.Middleware<I, I, E2, B>
) => <R, E1>(ma: ReaderMiddleware<R, I, I, E1, A>) => ReaderMiddleware<R, I, I, E2 | E1, B>
/**
 * @category combinators
 * @since 0.7.9
 */
export declare const fromMiddlewareK: <R, A extends readonly unknown[], B, I, O, E>(
  f: (...a: A) => M.Middleware<I, O, E, B>
) => (...a: A) => ReaderMiddleware<R, I, O, E, B>
/**
 * @category combinators
 * @since 0.6.5
 */
export declare const ichainMiddlewareKW: <R, A, O, Z, E, B>(
  f: (a: A) => M.Middleware<O, Z, E, B>
) => <I, D>(ma: ReaderMiddleware<R, I, O, D, A>) => ReaderMiddleware<R, I, Z, E | D, B>
/**
 * @category combinators
 * @since 0.6.3
 */
export declare const ichainMiddlewareK: <R, A, O, Z, E, B>(
  f: (a: A) => M.Middleware<O, Z, E, B>
) => <I>(ma: ReaderMiddleware<R, I, O, E, A>) => ReaderMiddleware<R, I, Z, E, B>
/**
 * @category combinators
 * @since 0.6.3
 */
export declare const chainMiddlewareK: <I, E, A, B>(
  f: (a: A) => M.Middleware<I, I, E, B>
) => <R>(ma: ReaderMiddleware<R, I, I, E, A>) => ReaderMiddleware<R, I, I, E, B>
/**
 * @category combinators
 * @since 0.6.3
 */
export declare const chainTaskEitherK: <E, A, B>(
  f: (a: A) => TE.TaskEither<E, B>
) => <R, I>(ma: ReaderMiddleware<R, I, I, E, A>) => ReaderMiddleware<R, I, I, E, B>
/**
 * @category combinators
 * @since 0.6.3
 */
export declare const chainTaskEitherKW: <E2, A, B>(
  f: (a: A) => TE.TaskEither<E2, B>
) => <R, I, E1>(ma: ReaderMiddleware<R, I, I, E1, A>) => ReaderMiddleware<R, I, I, E1 | E2, B>
/**
 * Less strict version of [`chainTaskOptionK`](#chaintaskoptionk).
 *
 * @category combinators
 * @since 0.7.9
 */
export declare const chainTaskOptionKW: <E2>(
  onNone: Lazy<E2>
) => <A, B>(
  f: (a: A) => TO.TaskOption<B>
) => <R, I, E1>(ma: ReaderMiddleware<R, I, I, E1, A>) => ReaderMiddleware<R, I, I, E1 | E2, B>
/**
 * @category combinators
 * @since 0.7.9
 */
export declare const chainTaskOptionK: <E>(
  onNone: Lazy<E>
) => <A, B>(
  f: (a: A) => TO.TaskOption<B>
) => <R, I>(ma: ReaderMiddleware<R, I, I, E, A>) => ReaderMiddleware<R, I, I, E, B>
/**
 * Less strict version of [`chainReaderK`](#chainreaderk).
 *
 * @category combinators
 * @since 0.7.9
 */
export declare const chainReaderKW: <R2, A, B>(
  f: (a: A) => Reader<R2, B>
) => <R1, I, E>(ma: ReaderMiddleware<R1, I, I, E, A>) => ReaderMiddleware<R1 & R2, I, I, E, B>
/**
 * @category combinators
 * @since 0.7.9
 */
export declare const chainReaderK: <R, A, B>(
  f: (a: A) => Reader<R, B>
) => <I, E>(ma: ReaderMiddleware<R, I, I, E, A>) => ReaderMiddleware<R, I, I, E, B>
/**
 * Less strict version of [`chainReaderTaskK`](#chainreadertaskk).
 *
 * @category combinators
 * @since 0.7.8
 */
export declare const chainReaderTaskKW: <R2, A, B>(
  f: (a: A) => ReaderTask<R2, B>
) => <R1, I, E>(ma: ReaderMiddleware<R1, I, I, E, A>) => ReaderMiddleware<R1 & R2, I, I, E, B>
/**
 * @category combinators
 * @since 0.7.8
 */
export declare const chainReaderTaskK: <R, A, B>(
  f: (a: A) => ReaderTask<R, B>
) => <I, E>(ma: ReaderMiddleware<R, I, I, E, A>) => ReaderMiddleware<R, I, I, E, B>
/**
 * @category combinators
 * @since 0.6.3
 */
export declare const chainReaderTaskEitherKW: <R2, E2, A, B>(
  f: (a: A) => ReaderTaskEither<R2, E2, B>
) => <R1, I, E1>(ma: ReaderMiddleware<R1, I, I, E1, A>) => ReaderMiddleware<R1 & R2, I, I, E1 | E2, B>
/**
 * @category combinators
 * @since 0.6.3
 */
export declare const chainReaderTaskEitherK: <R, E, A, B>(
  f: (a: A) => ReaderTaskEither<R, E, B>
) => <I>(ma: ReaderMiddleware<R, I, I, E, A>) => ReaderMiddleware<R, I, I, E, B>
/**
 * Less strict version of [`chainFirstReaderTaskK`](#chainfirstreadertaskk).
 *
 * @category combinators
 * @since 0.7.8
 */
export declare const chainFirstReaderTaskKW: <R2, E, A, B>(
  f: (a: A) => ReaderTask<R2, B>
) => <R1, I>(ma: ReaderMiddleware<R1, I, I, E, A>) => ReaderMiddleware<R1 & R2, I, I, E, A>
/**
 * @category combinators
 * @since 0.7.8
 */
export declare const chainFirstReaderTaskK: <R, E, A, B>(
  f: (a: A) => ReaderTask<R, B>
) => <I>(ma: ReaderMiddleware<R, I, I, E, A>) => ReaderMiddleware<R, I, I, E, A>
/**
 * Less strict version of [`chainFirstReaderTaskEitherK`](#chainfirstreadertaskeitherk).
 *
 * @category combinators
 * @since 0.7.0
 */
export declare const chainFirstReaderTaskEitherKW: <R2, E2, A, B>(
  f: (a: A) => ReaderTaskEither<R2, E2, B>
) => <R1, I, E1>(ma: ReaderMiddleware<R1, I, I, E1, A>) => ReaderMiddleware<R1 & R2, I, I, E1 | E2, A>
/**
 * @category combinators
 * @since 0.7.0
 */
export declare const chainFirstReaderTaskEitherK: <R, E, A, B>(
  f: (a: A) => ReaderTaskEither<R, E, B>
) => <I>(ma: ReaderMiddleware<R, I, I, E, A>) => ReaderMiddleware<R, I, I, E, A>
/**
 * @category instances
 * @since 0.6.3
 */
export declare const Functor: Functor4<URI>
/**
 * @category instances
 * @since 0.7.0
 */
export declare const ApplyPar: Apply4<URI>
/**
 * @category instances
 * @since 0.7.0
 */
export declare const ApplySeq: Apply4<URI>
/**
 * Use [`ApplySeq`](./ReaderMiddleware.ts.html#ApplySeq) instead.
 *
 * @category instances
 * @since 0.6.3
 * @deprecated
 */
export declare const Apply: Apply4<URI>
/**
 * @category instances
 * @since 0.7.0
 */
export declare const ApplicativePar: Applicative4<URI>
/**
 * @category instances
 * @since 0.7.0
 */
export declare const ApplicativeSeq: Applicative4<URI>
/**
 * Use [`ApplicativeSeq`](./ReaderMiddleware.ts.html#ApplicativeSeq) instead.
 *
 * @category instances
 * @since 0.6.3
 * @deprecated
 */
export declare const Applicative: Applicative4<URI>
/**
 * @category instances
 * @since 0.7.0
 */
export declare const Chain: Chain4<URI>
/**
 * @category instances
 * @since 0.6.3
 */
export declare const Monad: Monad4<URI>
/**
 * @category instances
 * @since 0.6.3
 */
export declare const MonadThrow: MonadThrow4<URI>
/**
 * @category instances
 * @since 0.6.3
 */
export declare const Alt: Alt4<URI>
/**
 * @category instances
 * @since 0.6.3
 */
export declare const Bifunctor: Bifunctor4<URI>
/**
 * @category instances
 * @since 0.7.0
 */
export declare const FromEither: FromEither4<URI>
/**
 * @category combinators
 * @since 0.7.0
 */
export declare const apFirst: <S, R, E, B>(
  second: ReaderMiddleware<S, R, R, E, B>
) => <A>(first: ReaderMiddleware<S, R, R, E, A>) => ReaderMiddleware<S, R, R, E, A>
/**
 * Less strict version of [`apFirst`](#apfirst).
 *
 * @category combinators
 * @since 0.7.1
 */
export declare const apFirstW: <R2, I, E2, B>(
  second: ReaderMiddleware<R2, I, I, E2, B>
) => <R1, E1, A>(first: ReaderMiddleware<R1, I, I, E1, A>) => ReaderMiddleware<R1 & R2, I, I, E1 | E2, A>
/**
 * Indexed version of [`apFirst`](#apfirst).
 *
 * @category combinators
 * @since 0.7.9
 */
export declare const iapFirst: <R, O, Z, E, B>(
  second: ReaderMiddleware<R, O, Z, E, B>
) => <I, A>(first: ReaderMiddleware<R, I, O, E, A>) => ReaderMiddleware<R, I, Z, E, A>
/**
 * Less strict version of [`iapFirst`](#iapfirst).
 *
 * @category combinators
 * @since 0.7.9
 */
export declare const iapFirstW: <R2, O, Z, E2, B>(
  second: ReaderMiddleware<R2, O, Z, E2, B>
) => <R1, I, E1, A>(first: ReaderMiddleware<R1, I, O, E1, A>) => ReaderMiddleware<R1 & R2, I, Z, E1 | E2, A>
/**
 * @category combinators
 * @since 0.7.0
 */
export declare const apSecond: <S, R, E, B>(
  second: ReaderMiddleware<S, R, R, E, B>
) => <A>(first: ReaderMiddleware<S, R, R, E, A>) => ReaderMiddleware<S, R, R, E, B>
/**
 * Less strict version of [`apSecond`](#apsecond).
 *
 * @category combinators
 * @since 0.7.1
 */
export declare const apSecondW: <R2, I, E2, B>(
  second: ReaderMiddleware<R2, I, I, E2, B>
) => <R1, E1, A>(first: ReaderMiddleware<R1, I, I, E1, A>) => ReaderMiddleware<R1 & R2, I, I, E1 | E2, B>
/**
 * Indexed version of [`apSecond`](#apsecond).
 *
 * @category combinators
 * @since 0.7.9
 */
export declare const iapSecond: <R, O, Z, E, B>(
  second: ReaderMiddleware<R, O, Z, E, B>
) => <I, A>(first: ReaderMiddleware<R, I, O, E, A>) => ReaderMiddleware<R, I, Z, E, B>
/**
 * Less strict version of [`iapSecond`](#iapsecond).
 *
 * @category combinators
 * @since 0.7.9
 */
export declare const iapSecondW: <R2, O, Z, E2, B>(
  second: ReaderMiddleware<R2, O, Z, E2, B>
) => <R1, I, E1, A>(first: ReaderMiddleware<R1, I, O, E1, A>) => ReaderMiddleware<R1 & R2, I, Z, E1 | E2, B>
/**
 * Composes computations in sequence, using the return value of one computation to determine
 * the next computation and keeping only the result of the first.
 *
 * Derivable from `Chain`.
 *
 * @category combinators
 * @since 0.7.0
 */
export declare const chainFirst: <R, I, E, A, B>(
  f: (a: A) => ReaderMiddleware<R, I, I, E, B>
) => (ma: ReaderMiddleware<R, I, I, E, A>) => ReaderMiddleware<R, I, I, E, A>
/**
 * Less strict version of [`chainFirst`](#chainfirst).
 *
 * Derivable from `Chain`.
 *
 * @category combinators
 * @since 0.7.0
 */
export declare const chainFirstW: <R2, I, E2, A, B>(
  f: (a: A) => ReaderMiddleware<R2, I, I, E2, B>
) => <R1, E1>(ma: ReaderMiddleware<R1, I, I, E1, A>) => ReaderMiddleware<R1 & R2, I, I, E1 | E2, A>
/**
 * @category constructors
 * @since 0.7.0
 */
export declare const fromPredicate: {
  <E, A, B extends A>(refinement: Refinement<A, B>, onFalse: (a: A) => E): <R, I>(
    a: A
  ) => ReaderMiddleware<R, I, I, E, B>
  <E, A>(predicate: Predicate<A>, onFalse: (a: A) => E): <R, I>(a: A) => ReaderMiddleware<R, I, I, E, A>
}
/**
 * @category combinators
 * @since 0.7.0
 */
export declare const filterOrElse: {
  <E, A, B extends A>(refinement: Refinement<A, B>, onFalse: (a: A) => E): <R, I>(
    ma: ReaderMiddleware<R, I, I, E, A>
  ) => ReaderMiddleware<R, I, I, E, B>
  <E, A>(predicate: Predicate<A>, onFalse: (a: A) => E): <R, I>(
    ma: ReaderMiddleware<R, I, I, E, A>
  ) => ReaderMiddleware<R, I, I, E, A>
}
/**
 * Less strict version of [`filterOrElse`](#filterorelse).
 *
 * @category combinators
 * @since 0.7.0
 */
export declare const filterOrElseW: {
  <A, B extends A, E2>(refinement: Refinement<A, B>, onFalse: (a: A) => E2): <R, I, E1>(
    ma: ReaderMiddleware<R, I, I, E1, A>
  ) => ReaderMiddleware<R, I, I, E1 | E2, B>
  <A, E2>(predicate: Predicate<A>, onFalse: (a: A) => E2): <R, I, E1>(
    ma: ReaderMiddleware<R, I, I, E1, A>
  ) => ReaderMiddleware<R, I, I, E1 | E2, A>
}
/**
 * @category natural transformations
 * @since 0.7.9
 */
export declare const fromOption: <E>(onNone: Lazy<E>) => <R, I, A>(ma: O.Option<A>) => ReaderMiddleware<R, I, I, E, A>
/**
 * @category combinators
 * @since 0.7.9
 */
export declare const fromEitherK: <E, A extends ReadonlyArray<unknown>, B>(
  f: (...a: A) => E.Either<E, B>
) => <R, I>(...a: A) => ReaderMiddleware<R, I, I, E, B>
/**
 * @category combinators
 * @since 0.7.9
 */
export declare const fromOptionK: <E>(
  onNone: Lazy<E>
) => <A extends ReadonlyArray<unknown>, B>(
  f: (...a: A) => O.Option<B>
) => <R, I>(...a: A) => ReaderMiddleware<R, I, I, E, B>
/**
 * @category combinators
 * @since 0.7.0
 */
export declare const chainEitherK: <E, A, B>(
  f: (a: A) => E.Either<E, B>
) => <R, I>(ma: ReaderMiddleware<R, I, I, E, A>) => ReaderMiddleware<R, I, I, E, B>
/**
 * Less strict version of [`chainEitherK`](#chaineitherk).
 *
 * @category combinators
 * @since 0.7.0
 */
export declare const chainEitherKW: <E2, A, B>(
  f: (a: A) => E.Either<E2, B>
) => <R, I, E1>(ma: ReaderMiddleware<R, I, I, E1, A>) => ReaderMiddleware<R, I, I, E1 | E2, B>
/**
 * @category combinators
 * @since 0.7.9
 */
export declare const chainOptionK: <E>(
  onNone: Lazy<E>
) => <A, B>(f: (a: A) => O.Option<B>) => <R, I>(ma: ReaderMiddleware<R, I, I, E, A>) => ReaderMiddleware<R, I, I, E, B>
/**
 * Less strict version of [`chainOptionK`](#chainoptionk).
 *
 * @category combinators
 * @since 0.7.9
 */
export declare const chainOptionKW: <E2>(
  onNone: Lazy<E2>
) => <A, B>(
  f: (a: A) => O.Option<B>
) => <R, I, E1>(ma: ReaderMiddleware<R, I, I, E1, A>) => ReaderMiddleware<R, I, I, E1 | E2, B>
/**
 * @category natural transformations
 * @since 0.7.0
 */
export declare const fromIO: FromIO4<URI>['fromIO']
/**
 * @category instances
 * @since 0.7.0
 */
export declare const FromIO: FromIO4<URI>
/**
 * @category combinators
 * @since 0.7.0
 */
export declare const fromIOK: <A extends readonly unknown[], B>(
  f: (...a: A) => IO<B>
) => <S, R, E>(...a: A) => ReaderMiddleware<S, R, R, E, B>
/**
 * @category combinators
 * @since 0.7.0
 */
export declare const chainIOK: <A, B>(
  f: (a: A) => IO<B>
) => <S, R, E>(first: ReaderMiddleware<S, R, R, E, A>) => ReaderMiddleware<S, R, R, E, B>
/**
 * @category combinators
 * @since 0.7.0
 */
export declare const chainFirstIOK: <A, B>(
  f: (a: A) => IO<B>
) => <S, R, E>(first: ReaderMiddleware<S, R, R, E, A>) => ReaderMiddleware<S, R, R, E, A>
/**
 * @category natural transformations
 * @since 0.7.0
 */
export declare const fromTask: FromTask4<URI>['fromTask']
/**
 * @category instances
 * @since 0.7.0
 */
export declare const FromTask: FromTask4<URI>
/**
 * @category combinators
 * @since 0.7.0
 */
export declare const fromTaskK: <A extends readonly unknown[], B>(
  f: (...a: A) => Task<B>
) => <S, R, E>(...a: A) => ReaderMiddleware<S, R, R, E, B>
/**
 * @category combinators
 * @since 0.7.0
 */
export declare const chainTaskK: <A, B>(
  f: (a: A) => Task<B>
) => <S, R, E>(first: ReaderMiddleware<S, R, R, E, A>) => ReaderMiddleware<S, R, R, E, B>
/**
 * @category combinators
 * @since 0.7.0
 */
export declare const chainFirstTaskK: <A, B>(
  f: (a: A) => Task<B>
) => <S, R, E>(first: ReaderMiddleware<S, R, R, E, A>) => ReaderMiddleware<S, R, R, E, A>
/**
 * Less strict version of [`chainFirstTaskEitherK`](#chainfirsttaskeitherk).
 *
 * @category combinators
 * @since 0.7.0
 */
export declare const chainFirstTaskEitherKW: <E2, A, B>(
  f: (a: A) => TE.TaskEither<E2, B>
) => <R, I, E1>(ma: ReaderMiddleware<R, I, I, E1, A>) => ReaderMiddleware<R, I, I, E1 | E2, A>
/**
 * @category combinators
 * @since 0.7.0
 */
export declare const chainFirstTaskEitherK: <E, A, B>(
  f: (a: A) => TE.TaskEither<E, B>
) => <R, I>(ma: ReaderMiddleware<R, I, I, E, A>) => ReaderMiddleware<R, I, I, E, A>
/**
 * Less strict version of [`chainFirstTaskOptionK`](#chainfirsttaskoptionk).
 *
 * @category combinators
 * @since 0.7.9
 */
export declare const chainFirstTaskOptionKW: <E2>(
  onNone: Lazy<E2>
) => <A, B>(
  f: (a: A) => TO.TaskOption<B>
) => <R, I, E1>(ma: ReaderMiddleware<R, I, I, E1, A>) => ReaderMiddleware<R, I, I, E1 | E2, A>
/**
 * @category combinators
 * @since 0.7.9
 */
export declare const chainFirstTaskOptionK: <E>(
  onNone: Lazy<E>
) => <A, B>(
  f: (a: A) => TO.TaskOption<B>
) => <R, I>(ma: ReaderMiddleware<R, I, I, E, A>) => ReaderMiddleware<R, I, I, E, A>
/**
 * Phantom type can't be infered properly, use [`bindTo`](#bindto) instead.
 *
 * @since 0.6.3
 * @deprecated
 */
export declare const Do: ReaderMiddleware<unknown, unknown, unknown, never, {}>
/**
 * @since 0.6.3
 */
export declare const bindTo: <N extends string>(
  name: N
) => <S, R, E, A>(fa: ReaderMiddleware<S, R, R, E, A>) => ReaderMiddleware<S, R, R, E, { readonly [K in N]: A }>
/**
 * Indexed version of [`bindTo`](#bindto).
 *
 * @since 0.7.0
 */
export declare const ibindTo: <N extends string>(
  name: N
) => <R, I, O, E, A>(
  fa: ReaderMiddleware<R, I, O, E, A>
) => ReaderMiddleware<
  R,
  I,
  O,
  E,
  {
    readonly [K in N]: A
  }
>
/**
 * @since 0.6.3
 */
export declare const bind: <N extends string, A, S, R, E, B>(
  name: Exclude<N, keyof A>,
  f: (a: A) => ReaderMiddleware<S, R, R, E, B>
) => (
  ma: ReaderMiddleware<S, R, R, E, A>
) => ReaderMiddleware<S, R, R, E, { readonly [K in N | keyof A]: K extends keyof A ? A[K] : B }>
/**
 * @since 0.6.3
 */
export declare const bindW: <N extends string, R2, I, A, E2, B>(
  name: Exclude<N, keyof A>,
  f: (a: A) => ReaderMiddleware<R2, I, I, E2, B>
) => <R1, E1>(
  fa: ReaderMiddleware<R1, I, I, E1, A>
) => ReaderMiddleware<
  R1 & R2,
  I,
  I,
  E1 | E2,
  {
    [K in keyof A | N]: K extends keyof A ? A[K] : B
  }
>
/**
 * Less strict version of [`ibind`](#ibind).
 *
 * @since 0.7.0
 */
export declare const ibindW: <N extends string, A, R2, O, Z, E2, B>(
  name: Exclude<N, keyof A>,
  f: (a: A) => ReaderMiddleware<R2, O, Z, E2, B>
) => <R1, I, E1>(
  ma: ReaderMiddleware<R1, I, O, E1, A>
) => ReaderMiddleware<
  R1 & R2,
  I,
  Z,
  E1 | E2,
  {
    readonly [K in N | keyof A]: K extends keyof A ? A[K] : B
  }
>
/**
 * @since 0.7.0
 */
export declare const ibind: <N extends string, A, R, O, Z, E, B>(
  name: Exclude<N, keyof A>,
  f: (a: A) => ReaderMiddleware<R, O, Z, E, B>
) => <I>(ma: ReaderMiddleware<R, I, O, E, A>) => ReaderMiddleware<
  R,
  I,
  Z,
  E,
  {
    readonly [K in N | keyof A]: K extends keyof A ? A[K] : B
  }
>
/**
 * @since 0.7.0
 */
export declare const apS: <N extends string, A, S, R, E, B>(
  name: Exclude<N, keyof A>,
  fb: ReaderMiddleware<S, R, R, E, B>
) => (
  fa: ReaderMiddleware<S, R, R, E, A>
) => ReaderMiddleware<S, R, R, E, { readonly [K in N | keyof A]: K extends keyof A ? A[K] : B }>
/**
 * Less strict version of [`apS`](#aps).
 *
 * @since 0.7.0
 */
export declare const apSW: <N extends string, A, I, R2, E2, B>(
  name: Exclude<N, keyof A>,
  fb: ReaderMiddleware<R2, I, I, E2, B>
) => <R1, E1>(
  fa: ReaderMiddleware<R1, I, I, E1, A>
) => ReaderMiddleware<
  R1 & R2,
  I,
  I,
  E1 | E2,
  {
    readonly [K in keyof A | N]: K extends keyof A ? A[K] : B
  }
>
/**
 * Less strict version of [`iapS`](#iaps).
 *
 * @since 0.7.0
 */
export declare const iapSW: <N extends string, A, R2, I, O, E2, B>(
  name: Exclude<N, keyof A>,
  fb: ReaderMiddleware<R2, I, O, E2, B>
) => <R1, E1>(
  fa: ReaderMiddleware<R1, I, O, E1, A>
) => ReaderMiddleware<
  R1 & R2,
  I,
  O,
  E1 | E2,
  {
    readonly [K in keyof A | N]: K extends keyof A ? A[K] : B
  }
>
/**
 * @since 0.7.0
 */
export declare const iapS: <N extends string, A, R, I, O, E, B>(
  name: Exclude<N, keyof A>,
  fb: ReaderMiddleware<R, I, O, E, B>
) => (fa: ReaderMiddleware<R, I, O, E, A>) => ReaderMiddleware<
  R,
  I,
  O,
  E,
  {
    readonly [K in N | keyof A]: K extends keyof A ? A[K] : B
  }
>
