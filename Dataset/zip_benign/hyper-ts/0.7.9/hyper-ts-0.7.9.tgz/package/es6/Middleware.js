/**
 * A middleware is an indexed monadic action transforming one `Connection` to another `Connection`.
 * It operates in the `TaskEither` monad, and is indexed by `I` and `O`, the input and output
 * `Connection` types of the middleware action.
 *
 * @since 0.7.0
 */
import * as TE from 'fp-ts/TaskEither';
import { apFirst as apFirst_, apSecond as apSecond_, apS as apS_ } from 'fp-ts/Apply';
import { bind as bind_, chainFirst as chainFirst_ } from 'fp-ts/Chain';
import { identity, pipe } from 'fp-ts/function';
import { bindTo as bindTo_ } from 'fp-ts/Functor';
import { MediaType, Status } from '.';
import * as T from 'fp-ts/Task';
import * as E from 'fp-ts/Either';
import { fromPredicate as fromPredicate_, fromOption as fromOption_, filterOrElse as filterOrElse_, chainEitherK as chainEitherK_, chainOptionK as chainOptionK_, fromEitherK as fromEitherK_, fromOptionK as fromOptionK_, } from 'fp-ts/FromEither';
import * as J from 'fp-ts/Json';
import { fromIOK as fromIOK_, chainIOK as chainIOK_, chainFirstIOK as chainFirstIOK_ } from 'fp-ts/FromIO';
import { fromTaskK as fromTaskK_, chainTaskK as chainTaskK_, chainFirstTaskK as chainFirstTaskK_, } from 'fp-ts/FromTask';
/**
 * @category instances
 * @since 0.7.0
 */
export const URI = 'Middleware';
/**
 * @category constructors
 * @since 0.7.0
 */
export function gets(f) {
    return (c) => TE.right([f(c), c]);
}
/**
 * @category constructors
 * @since 0.7.0
 */
export function fromConnection(f) {
    return (c) => TE.fromEither(pipe(f(c), E.map((a) => [a, c])));
}
/**
 * @category constructors
 * @since 0.7.0
 */
export function modifyConnection(f) {
    return (c) => TE.right([undefined, f(c)]);
}
const _map = (fa, f) => (ci) => pipe(fa(ci), TE.map(([a, co]) => [f(a), co]));
const _apPar = (fab, fa) => pipe(fab, ap(fa));
const _apSeq = (fab, fa) => _chain(fab, (f) => _map(fa, (a) => f(a)));
const _chain = (ma, f) => (c) => pipe(ma(c), TE.chain(([a, c]) => f(a)(c)));
const _alt = (fx, f) => (c) => pipe(fx(c), TE.alt(() => f()(c)));
const _bimap = (fea, f, g) => (c) => pipe(fea(c), TE.bimap(f, ([a, c]) => [g(a), c]));
const _mapLeft = (fea, f) => (c) => pipe(fea(c), TE.mapLeft(f));
/**
 * `map` can be used to turn functions `(a: A) => B` into functions `(fa: F<A>) => F<B>` whose argument and return types
 * use the type constructor `F` to represent some computational context.
 *
 * @category Functor
 * @since 0.7.0
 */
export const map = (f) => (fa) => _map(fa, f);
/**
 * Indexed version of [`map`](#map).
 *
 * @category IxFunctor
 * @since 0.7.0
 */
export const imap = (f) => (fa) => (ci) => pipe(fa(ci), TE.map(([a, co]) => [f(a), co]));
/**
 * Map a pair of functions over the two last type arguments of the bifunctor.
 *
 * @category Bifunctor
 * @since 0.7.0
 */
export const bimap = (f, g) => (fa) => _bimap(fa, f, g);
/**
 * Map a function over the second type argument of a bifunctor.
 *
 * @category Bifunctor
 * @since 0.7.0
 */
export const mapLeft = (f) => (fa) => _mapLeft(fa, f);
/**
 * Apply a function to an argument under a type constructor.
 *
 * @category Apply
 * @since 0.7.0
 */
export const ap = (fa) => (fab) => _apSeq(fab, fa);
/**
 * Less strict version of [`ap`](#ap).
 *
 * @category Apply
 * @since 0.7.0
 */
export const apW = ap;
/**
 * Indexed version of [`ap`](#ap).
 *
 * @category Apply
 * @since 0.7.9
 */
export const iap = ap;
/**
 * Less strict version of [`iap`](#iap).
 *
 * @category Apply
 * @since 0.7.9
 */
export const iapW = iap;
/**
 * @category Pointed
 * @since 0.7.0
 */
export const of = right;
/**
 * @category IxPointed
 * @since 0.7.0
 */
export function iof(a) {
    return (c) => TE.right([a, c]);
}
/**
 * Composes computations in sequence, using the return value of one computation to determine the next computation.
 *
 * @category Monad
 * @since 0.7.0
 */
export const chain = (f) => (ma) => _chain(ma, f);
/**
 * Less strict version of [`chain`](#chain).
 *
 * @category Monad
 * @since 0.7.0
 */
export const chainW = chain;
/**
 * Less strict version of [`flatten`](#flatten).
 *
 * @category combinators
 * @since 0.7.2
 */
export const flattenW = chainW(identity);
/**
 * Derivable from `Chain`.
 *
 * @category combinators
 * @since 0.7.0
 */
export const flatten = flattenW;
/**
 * Less strict version of [`ichain`](#ichain).
 *
 * @category IxMonad
 * @since 0.7.0
 */
export function ichainW(f) {
    return (ma) => (ci) => pipe(ma(ci), TE.chainW(([a, co]) => f(a)(co)));
}
/**
 * Indexed version of [`chain`](#chain).
 *
 * @category IxMonad
 * @since 0.7.0
 */
export const ichain = ichainW;
/**
 * Less strict version of [`ichainFirst`](#ichainfirst).
 *
 * @category combinators
 * @since 0.7.6
 */
export function ichainFirstW(f) {
    return (ma) => (ci) => pipe(ma(ci), TE.chainW(([a, co]) => pipe(f(a)(co), TE.map(([_, co]) => [a, co]))));
}
/**
 * Indexed version of [`chainFirst`](#chainfirst).
 *
 * @category combinators
 * @since 0.7.6
 */
export const ichainFirst = ichainFirstW;
/**
 * Less strict version of [`iflatten`](#iflatten).
 *
 * @category combinators
 * @since 0.7.2
 */
export const iflattenW = ichainW(identity);
/**
 * Derivable from indexed version of `Chain`.
 *
 * @category combinators
 * @since 0.7.2
 */
export const iflatten = iflattenW;
/**
 * @category Alt
 * @since 0.7.0
 */
export const alt = (that) => (fa) => _alt(fa, that);
/**
 * Less strict version of [`alt`](#alt).
 *
 * @category Alt
 * @since 0.7.5
 */
export const altW = alt;
/**
 * @since 0.7.0
 */
export function evalMiddleware(ma, c) {
    return pipe(ma(c), TE.map(([a]) => a));
}
/**
 * @since 0.7.0
 */
export function execMiddleware(ma, c) {
    return pipe(ma(c), TE.map(([, c]) => c));
}
/**
 * Less strict version of [`orElse`](#orelse).
 *
 * @category combinators
 * @since 0.7.5
 */
export const orElseW = (f) => (ma) => (c) => pipe(ma(c), TE.orElseW((e) => f(e)(c)));
/**
 * @category combinators
 * @since 0.7.0
 */
export const orElse = orElseW;
/**
 * @category interop
 * @since 0.7.0
 */
export function tryCatch(f, onRejected) {
    return fromTaskEither(TE.tryCatch(f, onRejected));
}
/**
 * @category natural transformations
 * @since 0.7.0
 */
export function fromTaskEither(fa) {
    return (c) => pipe(fa, TE.map((a) => [a, c]));
}
/**
 * @category natural transformations
 * @since 0.7.9
 */
// TODO use TE.fromTaskOption when fp-ts version >= 2.11.0
export const fromTaskOption = (onNone) => (fa) => (c) => pipe(fa, T.map(E.fromOption(onNone)), TE.map((a) => [a, c]));
/**
 * @category constructors
 * @since 0.7.0
 */
export function right(a) {
    return iof(a);
}
/**
 * @category constructors
 * @since 0.7.0
 */
export function left(e) {
    return fromTaskEither(TE.left(e));
}
/**
 * @category constructors
 * @since 0.7.0
 */
export function rightTask(fa) {
    return fromTaskEither(TE.rightTask(fa));
}
/**
 * @category constructors
 * @since 0.7.0
 */
export function leftTask(te) {
    return fromTaskEither(TE.leftTask(te));
}
/**
 * @category constructors
 * @since 0.7.0
 */
export function rightIO(fa) {
    return fromTaskEither(TE.rightIO(fa));
}
/**
 * @category constructors
 * @since 0.7.0
 */
export function leftIO(fe) {
    return fromTaskEither(TE.leftIO(fe));
}
/**
 * @category natural transformations
 * @since 0.7.0
 */
export const fromEither = (fa) => fromTaskEither(TE.fromEither(fa));
/**
 * @category natural transformations
 * @since 0.7.0
 */
export function fromIOEither(fa) {
    return fromTaskEither(TE.fromIOEither(fa));
}
/**
 * Returns a middleware that writes the response status
 *
 * @category constructors
 * @since 0.7.0
 */
export function status(status) {
    return modifyConnection((c) => c.setStatus(status));
}
/**
 * Returns a middleware that writes the given header
 *
 * @category constructors
 * @since 0.7.0
 */
export function header(name, value) {
    return modifyConnection((c) => c.setHeader(name, value));
}
/**
 * Returns a middleware that sets the given `mediaType`
 *
 * @category constructors
 * @since 0.7.0
 */
export function contentType(mediaType) {
    return header('Content-Type', mediaType);
}
/**
 * Returns a middleware that sets the cookie `name` to `value`, with the given `options`
 *
 * @category constructors
 * @since 0.7.0
 */
export function cookie(name, value, options) {
    return modifyConnection((c) => c.setCookie(name, value, options));
}
/**
 * Returns a middleware that clears the cookie `name`
 *
 * @category constructors
 * @since 0.7.0
 */
export function clearCookie(name, options) {
    return modifyConnection((c) => c.clearCookie(name, options));
}
const closedHeaders = iof(undefined);
/**
 * Returns a middleware that changes the connection status to `BodyOpen`
 *
 * @category constructors
 * @since 0.7.0
 */
export function closeHeaders() {
    return closedHeaders;
}
/**
 * Returns a middleware that sends `body` as response body
 *
 * @category constructors
 * @since 0.7.0
 */
export function send(body) {
    return modifyConnection((c) => c.setBody(body));
}
const ended = modifyConnection((c) => c.endResponse());
/**
 * Returns a middleware that ends the response without sending any response body
 *
 * @category constructors
 * @since 0.7.0
 */
export function end() {
    return ended;
}
/**
 * Returns a middleware that sends `body` as JSON
 *
 * @category constructors
 * @since 0.7.0
 */
export function json(body, onError) {
    return pipe(fromEither(J.stringify(body)), mapLeft(onError), ichain((json) => pipe(contentType(MediaType.applicationJSON), ichain(() => closeHeaders()), ichain(() => send(json)))));
}
/**
 * Returns a middleware that sends a redirect to `uri`
 *
 * @category constructors
 * @since 0.7.0
 */
export function redirect(uri) {
    return pipe(status(Status.Found), ichain(() => header('Location', typeof uri === 'string' ? uri : uri.href)));
}
/**
 * Returns a middleware that pipes a stream to the response object.
 *
 * @category constructors
 * @since 0.7.0
 */
export function pipeStream(stream, onError) {
    return modifyConnection((c) => c.pipeStream(stream, onError));
}
const isUnknownRecord = (u) => u !== null && typeof u === 'object';
/**
 * Returns a middleware that tries to decode `connection.getParams()[name]`
 *
 * @category constructors
 * @since 0.7.0
 */
export function decodeParam(name, f) {
    return fromConnection((c) => {
        const params = c.getParams();
        return f(isUnknownRecord(params) ? params[name] : undefined);
    });
}
/**
 * Returns a middleware that tries to decode `connection.getParams()`
 *
 * @category constructors
 * @since 0.7.0
 */
export function decodeParams(f) {
    return fromConnection((c) => f(c.getParams()));
}
/**
 * Returns a middleware that tries to decode `connection.getQuery()`
 *
 * @category constructors
 * @since 0.7.0
 */
export function decodeQuery(f) {
    return fromConnection((c) => f(c.getQuery()));
}
/**
 * Returns a middleware that tries to decode `connection.getBody()`
 *
 * @category constructors
 * @since 0.7.0
 */
export function decodeBody(f) {
    return fromConnection((c) => f(c.getBody()));
}
/**
 * Returns a middleware that tries to decode `connection.getMethod()`
 *
 * @category constructors
 * @since 0.7.0
 */
export function decodeMethod(f) {
    return fromConnection((c) => f(c.getMethod()));
}
/**
 * Returns a middleware that tries to decode `connection.getHeader(name)`
 *
 * @category constructors
 * @since 0.7.0
 */
export function decodeHeader(name, f) {
    return fromConnection((c) => f(c.getHeader(name)));
}
/**
 * @category instances
 * @since 0.7.0
 */
export const Functor = {
    URI,
    map: _map,
};
/**
 * @category instances
 * @since 0.7.0
 */
export const Pointed = {
    URI,
    of,
};
/**
 * @category instances
 * @since 0.7.0
 */
export const ApplyPar = Object.assign(Object.assign({}, Functor), { ap: _apPar });
/**
 * @category instances
 * @since 0.7.0
 */
export const ApplySeq = Object.assign(Object.assign({}, Functor), { ap: _apSeq });
/**
 * @category instances
 * @since 0.7.0
 */
export const ApplicativePar = Object.assign(Object.assign({}, ApplyPar), { of });
/**
 * @category instances
 * @since 0.7.0
 */
export const ApplicativeSeq = Object.assign(Object.assign({}, ApplySeq), { of });
/**
 * @category instances
 * @since 0.7.0
 */
export const Chain = Object.assign(Object.assign({}, Functor), { ap: _apPar, chain: _chain });
/**
 * @category instances
 * @since 0.7.0
 */
export const Monad = Object.assign(Object.assign({}, ApplicativePar), { chain: _chain });
/**
 * @category instances
 * @since 0.7.0
 */
export const MonadThrow = Object.assign(Object.assign({}, Monad), { throwError: left });
/**
 * @category instances
 * @since 0.7.0
 */
export const Alt = Object.assign(Object.assign({}, Functor), { alt: _alt });
/**
 * @category instances
 * @since 0.7.0
 */
export const FromEither = {
    URI,
    fromEither,
};
/**
 * @category instances
 * @since 0.7.0
 */
export const Bifunctor = {
    URI,
    bimap: _bimap,
    mapLeft: _mapLeft,
};
/**
 * @category instances
 * @since 0.7.0
 */
export const MonadTask = Object.assign(Object.assign({}, Monad), { fromIO: rightIO, fromTask: rightTask });
/**
 * @category combinators
 * @since 0.7.0
 */
export const apFirst = apFirst_(ApplyPar);
/**
 * Less strict version of [`apFirst`](#apfirst).
 *
 * @category combinators
 * @since 0.7.1
 */
export const apFirstW = apFirst;
/**
 * Indexed version of [`apFirst`](#apfirst).
 *
 * @category combinators
 * @since 0.7.9
 */
export const iapFirst = apFirst;
/**
 * Less strict version of [`iapFirst`](#iapfirst).
 *
 * @category combinators
 * @since 0.7.1
 */
export const iapFirstW = iapFirst;
/**
 * @category combinators
 * @since 0.7.0
 */
export const apSecond = apSecond_(ApplyPar);
/**
 * Less strict version of [`apSecond`](#apsecond).
 *
 * @category combinators
 * @since 0.7.1
 */
export const apSecondW = apSecond;
/**
 * Indexed version of [`apSecond`](#apsecond).
 *
 * @category combinators
 * @since 0.7.9
 */
export const iapSecond = apSecond;
/**
 * Less strict version of [`iapSecond`](#iapsecond).
 *
 * @category combinators
 * @since 0.7.9
 */
export const iapSecondW = iapSecond;
/**
 * Composes computations in sequence, using the return value of one computation to determine the next computation and
 * keeping only the result of the first.
 *
 * Derivable from `Chain`.
 *
 * @category combinators
 * @since 0.7.0
 */
export const chainFirst = chainFirst_(Chain);
/**
 * Less strict version of [`chainFirst`](#chainfirst).
 *
 * Derivable from `Chain`.
 *
 * @category combinators
 * @since 0.7.0
 */
export const chainFirstW = chainFirst;
/**
 * @category constructors
 * @since 0.7.0
 */
export const fromPredicate = fromPredicate_(FromEither);
/**
 * @category combinators
 * @since 0.7.0
 */
export const filterOrElse = filterOrElse_(FromEither, Chain);
/**
 * Less strict version of [`filterOrElse`](#filterorelse).
 *
 * @category combinators
 * @since 0.7.0
 */
export const filterOrElseW = filterOrElse;
/**
 * @category natural transformations
 * @since 0.7.0
 */
export const fromOption = fromOption_(FromEither);
/**
 * @category combinators
 * @since 0.7.9
 */
export const fromEitherK = fromEitherK_(FromEither);
/**
 * @category combinators
 * @since 0.7.9
 */
export const fromOptionK = fromOptionK_(FromEither);
/**
 * @category combinators
 * @since 0.7.0
 */
export const chainEitherK = chainEitherK_(FromEither, Chain);
/**
 * Less strict version of [`chainEitherK`](#chaineitherk).
 *
 * @category combinators
 * @since 0.7.0
 */
export const chainEitherKW = chainEitherK;
/**
 * @category combinators
 * @since 0.7.9
 */
export const chainOptionK = chainOptionK_(FromEither, Chain);
/**
 * Less strict version of [`chainOptionK`](#chainoptionk).
 *
 * @category combinators
 * @since 0.7.9
 */
export const chainOptionKW = chainOptionK;
/**
 * @category natural transformations
 * @since 0.7.0
 */
export const fromIO = rightIO;
/**
 * @category instances
 * @since 0.7.0
 */
export const FromIO = {
    URI,
    fromIO,
};
/**
 * @category combinators
 * @since 0.7.0
 */
export const fromIOK = fromIOK_(FromIO);
/**
 * @category combinators
 * @since 0.7.0
 */
export const chainIOK = chainIOK_(FromIO, Chain);
/**
 * @category combinators
 * @since 0.7.0
 */
export const chainFirstIOK = chainFirstIOK_(FromIO, Chain);
/**
 * @category natural transformations
 * @since 0.7.0
 */
export const fromTask = rightTask;
/**
 * @category instances
 * @since 0.7.0
 */
export const FromTask = Object.assign(Object.assign({}, FromIO), { fromTask });
/**
 * @category combinators
 * @since 0.7.0
 */
export const fromTaskK = fromTaskK_(FromTask);
/**
 * @category combinators
 * @since 0.7.0
 */
export const chainTaskK = chainTaskK_(FromTask, Chain);
/**
 * @category combinators
 * @since 0.7.0
 */
export const chainFirstTaskK = chainFirstTaskK_(FromTask, Chain);
/**
 * Less strict version of [`chainTaskEitherK`](#chaintaskeitherk).
 *
 * @category combinators
 * @since 0.7.0
 */
export const chainTaskEitherKW = (f) => chainW((a) => fromTaskEither(f(a)));
/**
 * @category combinators
 * @since 0.7.0
 */
export const chainTaskEitherK = chainTaskEitherKW;
/**
 * Less strict version of [`chainFirstTaskEitherK`](#chainfirsttaskeitherk).
 *
 * @category combinators
 * @since 0.7.0
 */
export const chainFirstTaskEitherKW = (f) => chainFirstW((a) => fromTaskEither(f(a)));
/**
 * @category combinators
 * @since 0.7.0
 */
export const chainFirstTaskEitherK = chainFirstTaskEitherKW;
/**
 * Less strict version of [`chainTaskOptionK`](#chaintaskoptionk).
 *
 * @category combinators
 * @since 0.7.9
 */
export const chainTaskOptionKW = (onNone) => (f) => chainW((a) => fromTaskOption(onNone)(f(a)));
/**
 * @category combinators
 * @since 0.7.9
 */
export const chainTaskOptionK = chainTaskOptionKW;
/**
 * Less strict version of [`chainFirstTaskOptionK`](#chainfirsttaskoptionk).
 *
 * @category combinators
 * @since 0.7.9
 */
export const chainFirstTaskOptionKW = (onNone) => (f) => chainFirstW((a) => fromTaskOption(onNone)(f(a)));
/**
 * @category combinators
 * @since 0.7.9
 */
export const chainFirstTaskOptionK = chainFirstTaskOptionKW;
/**
 * Phantom type can't be infered properly, use [`bindTo`](#bindto) instead.
 *
 * @since 0.7.0
 * @deprecated
 */
export const Do = iof({});
/**
 * @since 0.7.0
 */
export const bindTo = bindTo_(Functor);
/**
 * Indexed version of [`bindTo`](#bindto).
 *
 * @since 0.7.0
 */
export const ibindTo = bindTo;
/**
 * @since 0.7.0
 */
export const bind = bind_(Chain);
/**
 * @since 0.7.0
 */
export const bindW = bind;
/**
 * Less strict version of [`ibind`](#ibind).
 *
 * @since 0.7.0
 */
export const ibindW = bindW;
/**
 * @since 0.7.0
 */
export const ibind = ibindW;
/**
 * @since 0.7.0
 */
export const apS = apS_(ApplyPar);
/**
 * Less strict version of [`apS`](#aps).
 *
 * @since 0.7.0
 */
export const apSW = apS;
/**
 * Less strict version of [`iapS`](#iaps).
 *
 * @since 0.7.0
 */
export const iapSW = apS;
/**
 * @since 0.7.0
 */
export const iapS = iapSW;
