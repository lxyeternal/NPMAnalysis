/// <reference types="node" />
/**
 * @since 0.5.0
 */
import { Bifunctor3 } from 'fp-ts/Bifunctor'
import { Alt3 } from 'fp-ts/Alt'
import { Monad3 } from 'fp-ts/Monad'
import { MonadTask3 } from 'fp-ts/MonadTask'
import { MonadThrow3 } from 'fp-ts/MonadThrow'
import { IncomingMessage } from 'http'
import * as M from './Middleware'
import { IO } from 'fp-ts/IO'
/**
 * Adapted from https://github.com/purescript-contrib/purescript-media-types
 *
 * @since 0.5.0
 */
export declare const MediaType: {
  readonly applicationFormURLEncoded: 'application/x-www-form-urlencoded'
  readonly applicationJSON: 'application/json'
  readonly applicationJavascript: 'application/javascript'
  readonly applicationOctetStream: 'application/octet-stream'
  readonly applicationXML: 'application/xml'
  readonly imageGIF: 'image/gif'
  readonly imageJPEG: 'image/jpeg'
  readonly imagePNG: 'image/png'
  readonly multipartFormData: 'multipart/form-data'
  readonly textCSV: 'text/csv'
  readonly textHTML: 'text/html'
  readonly textPlain: 'text/plain'
  readonly textXML: 'text/xml'
}
/**
 * @since 0.5.0
 */
export declare type MediaType = typeof MediaType[keyof typeof MediaType]
/**
 * @since 0.5.0
 */
export declare const Status: {
  readonly Continue: 100
  readonly SwitchingProtocols: 101
  readonly Processing: 102
  readonly EarlyHints: 103
  readonly OK: 200
  readonly Created: 201
  readonly Accepted: 202
  readonly NonAuthoritativeInformation: 203
  readonly NoContent: 204
  readonly ResetContent: 205
  readonly PartialContent: 206
  readonly MultiStatus: 207
  readonly AlreadyReported: 208
  readonly IMUsed: 226
  readonly MultipleChoices: 300
  readonly MovedPermanently: 301
  readonly Found: 302
  readonly SeeOther: 303
  readonly NotModified: 304
  readonly UseProxy: 305
  readonly SwitchProxy: 306
  readonly TemporaryRedirect: 307
  readonly PermanentRedirect: 308
  readonly BadRequest: 400
  readonly Unauthorized: 401
  readonly PaymentRequired: 402
  readonly Forbidden: 403
  readonly NotFound: 404
  readonly MethodNotAllowed: 405
  readonly NotAcceptable: 406
  readonly ProxyAuthenticationRequired: 407
  readonly RequestTimeout: 408
  readonly Conflict: 409
  readonly Gone: 410
  readonly LengthRequired: 411
  readonly PreconditionFailed: 412
  readonly PayloadTooLarge: 413
  readonly URITooLong: 414
  readonly UnsupportedMediaType: 415
  readonly RangeNotSatisfiable: 416
  readonly ExpectationFailed: 417
  readonly Teapot: 418
  readonly MisdirectedRequest: 421
  readonly UnprocessableEntity: 422
  readonly Locked: 423
  readonly FailedDependency: 424
  readonly TooEarly: 425
  readonly UpgradeRequired: 426
  readonly PreconditionRequired: 428
  readonly TooManyRequests: 429
  readonly RequestHeaderFieldsTooLarge: 431
  readonly UnavailableForLegalReasons: 451
  readonly InternalServerError: 500
  readonly NotImplemented: 501
  readonly BadGateway: 502
  readonly ServiceUnavailable: 503
  readonly GatewayTimeout: 504
  readonly HTTPVersionNotSupported: 505
  readonly VariantAlsoNegotiates: 506
  readonly InsufficientStorage: 507
  readonly LoopDetected: 508
  readonly NotExtended: 510
  readonly NetworkAuthenticationRequired: 511
}
/**
 * @since 0.5.0
 */
export declare type Status = typeof Status[keyof typeof Status]
/**
 * @since 0.5.0
 */
export interface CookieOptions {
  readonly expires?: Date
  readonly domain?: string
  readonly httpOnly?: boolean
  readonly maxAge?: number
  readonly path?: string
  readonly sameSite?: boolean | 'strict' | 'lax'
  readonly secure?: boolean
  readonly signed?: boolean
}
/**
 * Type indicating that the status-line is ready to be sent
 *
 * @since 0.5.0
 */
export interface StatusOpen {
  readonly StatusOpen: unique symbol
}
/**
 * Type indicating that headers are ready to be sent, i.e. the body streaming has not been started
 *
 * @since 0.5.0
 */
export interface HeadersOpen {
  readonly HeadersOpen: unique symbol
}
/**
 * Type indicating that headers have already been sent, and that the body is currently streaming
 *
 * @since 0.5.0
 */
export interface BodyOpen {
  readonly BodyOpen: unique symbol
}
/**
 * Type indicating that headers have already been sent, and that the body stream, and thus the response, is finished
 *
 * @since 0.5.0
 */
export interface ResponseEnded {
  readonly ResponseEnded: unique symbol
}
/**
 * A `Connection`, models the entirety of a connection between the HTTP server and the user agent,
 * both request and response.
 * State changes are tracked by the phantom type `S`
 *
 * @category model
 * @since 0.5.0
 */
export interface Connection<S> {
  /**
   * @since 0.5.0
   */
  readonly _S: S
  readonly getRequest: () => IncomingMessage
  readonly getBody: () => unknown
  readonly getHeader: (name: string) => unknown
  readonly getParams: () => unknown
  readonly getQuery: () => unknown
  readonly getOriginalUrl: () => string
  readonly getMethod: () => string
  readonly setCookie: (
    this: Connection<HeadersOpen>,
    name: string,
    value: string,
    options: CookieOptions
  ) => Connection<HeadersOpen>
  readonly clearCookie: (this: Connection<HeadersOpen>, name: string, options: CookieOptions) => Connection<HeadersOpen>
  readonly setHeader: (this: Connection<HeadersOpen>, name: string, value: string) => Connection<HeadersOpen>
  readonly setStatus: (this: Connection<StatusOpen>, status: Status) => Connection<HeadersOpen>
  readonly setBody: (this: Connection<BodyOpen>, body: string | Buffer) => Connection<ResponseEnded>
  readonly pipeStream: (
    this: Connection<BodyOpen>,
    stream: NodeJS.ReadableStream,
    onError: (e: unknown) => IO<void>
  ) => Connection<ResponseEnded>
  readonly endResponse: (this: Connection<BodyOpen>) => Connection<ResponseEnded>
}
/**
 * Use [`gets`](./Middleware.ts.html#gets) instead.
 *
 * @category constructor
 * @since 0.5.0
 * @deprecated
 */
export declare const gets: typeof M.gets
/**
 * Use [`fromConnection`](./Middleware.ts.html#fromConnection) instead.
 *
 * @category constructor
 * @since 0.5.0
 * @deprecated
 */
export declare const fromConnection: typeof M.fromConnection
/**
 * Use [`modifyConnection`](./Middleware.ts.html#modifyConnection) instead.
 *
 * @category constructor
 * @since 0.5.0
 * @deprecated
 */
export declare const modifyConnection: typeof M.modifyConnection
/**
 * Use [`URI`](./Middleware.ts.html#uri) instead.
 *
 * @category instances
 * @since 0.5.0
 * @deprecated
 */
export declare const URI = 'Middleware'
/**
 * Use [`URI`](./Middleware.ts.html#uri) instead.
 *
 * @category instances
 * @since 0.5.0
 * @deprecated
 */
export declare type URI = typeof M.URI
/**
 * Use [`Middleware`](./Middleware.ts.html#middleware) instead.
 *
 * @category model
 * @since 0.5.0
 * @deprecated
 */
export declare type Middleware<I, O, E, A> = M.Middleware<I, O, E, A>
/**
 * Use [`map`](./Middleware.ts.html#map) instead.
 *
 * @category Functor
 * @since 0.5.0
 * @deprecated
 */
export declare const map: <A, B>(f: (a: A) => B) => <I, E>(fa: M.Middleware<I, I, E, A>) => M.Middleware<I, I, E, B>
/**
 * Use [`bimap`](./Middleware.ts.html#bimap) instead.
 *
 * @category Bifunctor
 * @since 0.6.3
 * @deprecated
 */
export declare const bimap: <E, G, A, B>(
  f: (e: E) => G,
  g: (a: A) => B
) => <I>(fa: M.Middleware<I, I, E, A>) => M.Middleware<I, I, G, B>
/**
 * Use [`mapLeft`](./Middleware.ts.html#mapLeft) instead.
 *
 * @category Bifunctor
 * @since 0.6.3
 * @deprecated
 */
export declare const mapLeft: <E, G>(f: (e: E) => G) => <I, A>(fa: M.Middleware<I, I, E, A>) => M.Middleware<I, I, G, A>
/**
 * Use [`ap`](./Middleware.ts.html#ap) instead.
 *
 * @category Apply
 * @since 0.6.3
 * @deprecated
 */
export declare const ap: <I, E, A>(
  fa: M.Middleware<I, I, E, A>
) => <B>(fab: M.Middleware<I, I, E, (a: A) => B>) => M.Middleware<I, I, E, B>
/**
 * Use [`apW`](./Middleware.ts.html#apw) instead.
 *
 * @category Apply
 * @since 0.6.3
 * @deprecated
 */
export declare const apW: <I, E2, A>(
  fa: M.Middleware<I, I, E2, A>
) => <E1, B>(fab: M.Middleware<I, I, E1, (a: A) => B>) => M.Middleware<I, I, E2 | E1, B>
/**
 * Use [`of`](./Middleware.ts.html#of) instead.
 *
 * @category Pointed
 * @since 0.6.3
 * @deprecated
 */
export declare const of: <I = StatusOpen, E = never, A = never>(a: A) => M.Middleware<I, I, E, A>
/**
 * Use [`iof`](./Middleware.ts.html#iof) instead.
 *
 * @category Pointed
 * @since 0.5.0
 * @deprecated
 */
export declare const iof: typeof M.iof
/**
 * Use [`chain`](./Middleware.ts.html#chain) instead.
 *
 * @category Monad
 * @since 0.6.3
 * @deprecated
 */
export declare const chain: <I, E, A, B>(
  f: (a: A) => M.Middleware<I, I, E, B>
) => (ma: M.Middleware<I, I, E, A>) => M.Middleware<I, I, E, B>
/**
 * Use [`chainW`](./Middleware.ts.html#chainW) instead.
 *
 * @category Monad
 * @since 0.6.3
 * @deprecated
 */
export declare const chainW: <I, E2, A, B>(
  f: (a: A) => M.Middleware<I, I, E2, B>
) => <E1>(ma: M.Middleware<I, I, E1, A>) => M.Middleware<I, I, E2 | E1, B>
/**
 * Use [`ichain`](./Middleware.ts.html#ichain) instead.
 *
 * @category Monad
 * @since 0.5.0
 * @deprecated
 */
export declare const ichain: <A, O, Z, E, B>(
  f: (a: A) => M.Middleware<O, Z, E, B>
) => <I>(ma: M.Middleware<I, O, E, A>) => M.Middleware<I, Z, E, B>
/**
 * Use [`ichainW`](./Middleware.ts.html#ichainW) instead.
 *
 * @category Monad
 * @since 0.6.1
 * @deprecated
 */
export declare const ichainW: typeof M.ichainW
/**
 * Use [`evalMiddleware`](./Middleware.ts.html#evalMiddleware) instead.
 *
 * @since 0.5.0
 * @deprecated
 */
export declare const evalMiddleware: typeof M.evalMiddleware
/**
 * Use [`execMiddleware`](./Middleware.ts.html#execMiddleware) instead.
 *
 * @since 0.5.0
 * @deprecated
 */
export declare const execMiddleware: typeof M.execMiddleware
/**
 * Use [`orElse`](./Middleware.ts.html#orelse) instead.
 *
 * @category combinators
 * @since 0.5.0
 * @deprecated
 */
export declare const orElse: <E, I, O, M, A>(
  f: (e: E) => M.Middleware<I, O, M, A>
) => (ma: M.Middleware<I, O, E, A>) => M.Middleware<I, O, M, A>
/**
 * Use [`tryCatch`](./Middleware.ts.html#tryCatch) instead.
 *
 * @category interop
 * @since 0.5.0
 * @deprecated
 */
export declare const tryCatch: typeof M.tryCatch
/**
 * Use [`fromTaskEither`](./Middleware.ts.html#fromTaskEither) instead.
 *
 * @category constructor
 * @since 0.5.0
 * @deprecated
 */
export declare const fromTaskEither: typeof M.fromTaskEither
/**
 * Use [`right`](./Middleware.ts.html#right) instead.
 *
 * @category constructor
 * @since 0.5.0
 * @deprecated
 */
export declare const right: typeof M.right
/**
 * Use [`left`](./Middleware.ts.html#left) instead.
 *
 * @category constructor
 * @since 0.5.0
 * @deprecated
 */
export declare const left: typeof M.left
/**
 * Use [`rightTask`](./Middleware.ts.html#rightTask) instead.
 *
 * @category constructor
 * @since 0.5.0
 * @deprecated
 */
export declare const rightTask: typeof M.rightTask
/**
 * Use [`leftTask`](./Middleware.ts.html#leftTask) instead.
 *
 * @category constructor
 * @since 0.5.0
 * @deprecated
 */
export declare const leftTask: typeof M.leftTask
/**
 * Use [`rightIO`](./Middleware.ts.html#rightIO) instead.
 *
 * @category constructor
 * @since 0.5.0
 * @deprecated
 */
export declare const rightIO: typeof M.rightIO
/**
 * Use [`leftIO`](./Middleware.ts.html#leftIO) instead.
 *
 * @category constructor
 * @since 0.5.0
 * @deprecated
 */
export declare const leftIO: typeof M.leftIO
/**
 * Use [`fromIOEither`](./Middleware.ts.html#fromIOEither) instead.
 *
 * @category constructor
 * @since 0.5.0
 * @deprecated
 */
export declare const fromIOEither: typeof M.fromIOEither
/**
 * Use [`status`](./Middleware.ts.html#status) instead.
 *
 * @category constructor
 * @since 0.5.0
 * @deprecated
 */
export declare const status: typeof M.status
/**
 * Use [`header`](./Middleware.ts.html#header) instead.
 *
 * @category constructor
 * @since 0.5.0
 * @deprecated
 */
export declare const header: typeof M.header
/**
 * Use [`contentType`](./Middleware.ts.html#contentType) instead.
 *
 * @category constructor
 * @since 0.5.0
 * @deprecated
 */
export declare const contentType: typeof M.contentType
/**
 * Use [`cookie`](./Middleware.ts.html#cookie) instead.
 *
 * @category constructor
 * @since 0.5.0
 * @deprecated
 */
export declare const cookie: typeof M.cookie
/**
 * Use [`clearCookie`](./Middleware.ts.html#clearCookie) instead.
 *
 * @category constructor
 * @since 0.5.0
 * @deprecated
 */
export declare const clearCookie: typeof M.clearCookie
/**
 * Use [`closeHeaders`](./Middleware.ts.html#closeHeaders) instead.
 *
 * @category constructor
 * @since 0.5.0
 * @deprecated
 */
export declare const closeHeaders: typeof M.closeHeaders
/**
 * Use [`send`](./Middleware.ts.html#send) instead.
 *
 * @category constructor
 * @since 0.5.0
 * @deprecated
 */
export declare const send: typeof M.send
/**
 * Use [`end`](./Middleware.ts.html#end) instead.
 *
 * @category constructor
 * @since 0.5.0
 * @deprecated
 */
export declare const end: typeof M.end
/**
 * Use [`json`](./Middleware.ts.html#json) instead.
 *
 * @category constructor
 * @since 0.5.0
 * @deprecated
 */
export declare const json: typeof M.json
/**
 * Use [`redirect`](./Middleware.ts.html#redirect) instead.
 *
 * @category constructor
 * @since 0.5.0
 * @deprecated
 */
export declare const redirect: typeof M.redirect
/**
 * Use [`pipeStream`](./Middleware.ts.html#pipeStream) instead.
 *
 * @category constructor
 * @since 0.6.2
 * @deprecated
 */
export declare const pipeStream: typeof M.pipeStream
/**
 * Use [`decodeParam`](./Middleware.ts.html#decodeParam) instead.
 *
 * @category constructor
 * @since 0.5.0
 * @deprecated
 */
export declare const decodeParam: typeof M.decodeParam
/**
 * Use [`decodeParams`](./Middleware.ts.html#decodeParams) instead.
 *
 * @category constructor
 * @since 0.5.0
 * @deprecated
 */
export declare const decodeParams: typeof M.decodeParams
/**
 * Use [`decodeQuery`](./Middleware.ts.html#decodeQuery) instead.
 *
 * @category constructor
 * @since 0.5.0
 * @deprecated
 */
export declare const decodeQuery: typeof M.decodeQuery
/**
 * Use [`decodeBody`](./Middleware.ts.html#decodeBody) instead.
 *
 * @category constructor
 * @since 0.5.0
 * @deprecated
 */
export declare const decodeBody: typeof M.decodeBody
/**
 * Use [`decodeMethod`](./Middleware.ts.html#decodeMethod) instead.
 *
 * @category constructor
 * @since 0.5.0
 * @deprecated
 */
export declare const decodeMethod: typeof M.decodeMethod
/**
 * Use [`decodeHeader`](./Middleware.ts.html#decodeHeader) instead.
 *
 * @category constructor
 * @since 0.5.0
 * @deprecated
 */
export declare const decodeHeader: typeof M.decodeHeader
/**
 * Use [`Do`](./Middleware.ts.html#do) instead.
 *
 * @since 0.6.1
 * @deprecated
 */
export declare const Do: M.Middleware<unknown, unknown, never, {}>
/**
 * Use [`bindTo`](./Middleware.ts.html#bindTo) instead.
 *
 * @since 0.6.1
 * @deprecated
 */
export declare const bindTo: <N extends string>(
  name: N
) => <R, E, A>(fa: M.Middleware<R, R, E, A>) => M.Middleware<R, R, E, { readonly [K in N]: A }>
/**
 * Use [`bindW`](./Middleware.ts.html#bindW) instead.
 *
 * @since 0.6.1
 * @deprecated
 */
export declare const bindW: <N extends string, I, A, E2, B>(
  name: Exclude<N, keyof A>,
  f: (a: A) => M.Middleware<I, I, E2, B>
) => <E1>(
  fa: M.Middleware<I, I, E1, A>
) => M.Middleware<I, I, E2 | E1, { [K in N | keyof A]: K extends keyof A ? A[K] : B }>
/**
 * Use [`bind`](./Middleware.ts.html#bind) instead.
 *
 * @since 0.6.1
 * @deprecated
 */
export declare const bind: <N extends string, A, R, E, B>(
  name: Exclude<N, keyof A>,
  f: (a: A) => M.Middleware<R, R, E, B>
) => (
  ma: M.Middleware<R, R, E, A>
) => M.Middleware<R, R, E, { readonly [K in N | keyof A]: K extends keyof A ? A[K] : B }>
/**
 * Use smaller instances from [`Middleware`](./Middleware.ts.html) module instead.
 *
 * @category instances
 * @since 0.5.0
 * @deprecated
 */
export declare const middleware: Monad3<M.URI> &
  Alt3<M.URI> &
  Bifunctor3<M.URI> &
  MonadThrow3<M.URI> &
  MonadTask3<M.URI>
