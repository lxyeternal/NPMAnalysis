require('./lib/type.css');
