![blank.css](http://imgh.us/blank-logo.svg)

# [blank.css](http://github.com/blank-css) ‣ type

blank.css composable type components for consistent and flexible typography

## configure
Like all of blank.css, the type component is completely configurable using
custom properties and custom media queries, like so:

```css
:root {
	--Type-size--xxs: 1rem;
	--Type-size--xs: 1.25rem;
	--Type-size--sm: 1.5rem;
	--Type-size--md: 2rem;
	--Type-size--lg: 3rem;
	--Type-size--xl: 4rem;
	--Type-size--xxl: 6rem;

	--Type-height--xs: 1;
	--Type-height--sm: 1.25;
	--Type-height--md: 1.5;
	--Type-height--lg: 2;
	--Type-height--xl: 3;

	--Type-space--sm: 0.2em;
	--Type-space--md: normal;
	--Type-space--lg: 0.5em;

	--Type-weight--extralight: 200;
	--Type-weight--light: 300;
	--Type-weight--normal: 400;
	--Type-weight--bold: 600;
	--Type-weight--heavy: 700;
}
```

## install
`npm i -S blank-css-type`

## use
now you have these classes at your disposal, where

```css
.blank-Type-{prop}--{modifier}

.blank-Type-size--xxs
.blank-Type-size--xs
.blank-Type-size--sm
.blank-Type-size--md
.blank-Type-size--lg
.blank-Type-size--xl
.blank-Type-size--xxl

.blank-Type-weight--extralight
.blank-Type-weight--light
.blank-Type-weight--medium
.blank-Type-weight--bold
.blank-Type-weight--heavy

.blank-Type-height--xs
.blank-Type-height--sm
.blank-Type-height--md
.blank-Type-height--lg
.blank-Type-height--xl

.blank-Type-space--sm
.blank-Type-space--md
.blank-Type-space--lg
```

Mix and match in whichever way you choose.
