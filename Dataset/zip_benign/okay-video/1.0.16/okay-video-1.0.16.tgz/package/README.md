# okay-video

## 总体配置
修改原有一行展示所有控件布局改为两行
第一行为progress
剩余内容放第二行
```js
{
    conainer: '', //容器
    url: "", //传入的url
    poster: '', //封面
    volumePercent: 0.5, //默认音量
    playPercent: 0, // 默认从0开始播放
    autoFit: false, //是否需要根据父容器缩放video大小  默认false
    videoControls: { // video控制台配置
        definition: false, // 切换清晰度  根据传入参数列表   默认展示第一条
        playbackRate: false, // 切换倍速
        volumeBtn: true, // 音量调整按钮
        playBtn: true, // 播放按钮
        fullScreenBtn: true, // 全屏播放按钮
        moreBtn: false, // 是否显示折叠按钮
    },
    onCanPlay:function(){}, // 初始化完成回调
    onPlayCb:function(){}, //播放回调
    onEndedCb:function(){}, // 播放结束回调
    onPausedCb:function(){}, // 暂停回调
    onErrorCb:function(){}, // 播放失败回调
    onSpeedCb:function(){}, // 进度调整回调
    onVolumeCb:function(){}, // 音量调整回调
    getPlayStatus: function(){}, // 获取当前播放状态
    getVolume: function(){}, // 获取当前音量
}
```
## 移动端

#### 组件内部处理移动端兼容 

去除音量调节 使用手机提供的音量控制  

根据宽度计算是否能布置所有控制按钮  不能的话清晰度 倍速 合并折叠  







