'use strict';
const 
    events  = require(`${basedir}/src/events`),
    methods = require(`${basedir}/src/methods`);
    
let start = () => {
    broker.createService({
        name    : global.environment.app.name,
        actions : global.actions,
        events  : events,
        methods : methods,
        async created() {
            global.service = this;
        }
    });
    
    broker.start()
}


module.exports = () => {
    return new Promise((resolve, reject) => {
        start();
        resolve()
    })
}