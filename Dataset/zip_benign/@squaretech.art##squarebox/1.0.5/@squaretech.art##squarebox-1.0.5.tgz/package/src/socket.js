'use strict';

const { request } = require('http');

const
    express   = require(`express`),
    fs        = require('fs');

module.exports = () => {
    const 
        app             = express(),
        http            = require('http').Server(app);
        global.io       = require('socket.io')(http);
        global.ioconn   = {};
        http.listen(global.environment.app.port, function(){
            console.info(`HTTP server started on port ${global.environment.app.port}`);
        }); 

        io.on('connection', (socket) => {
            fs.readdirSync(`${basedir}/src/routers`).forEach((file) => {
            const
                function_   = file.replace(/.js|.ts/g, ``).toLowerCase(),
                source      = require(`${basedir}/src/routers/${file}`);
                if(file === `main.js`) {
                    for (let i in source) {
                        let name = source[i].name
                        socket.on(`${name}`, (data) => {
                            source[name](socket, data);
                        });
                    }
                } else {
                    for (let i in source) {
                        let name = source[i].name;
                        socket.on(`${function_}${name}`, (data) => {
                            source[name](socket, data);
                        });
                    }
                }
            });
        });

    return app;
}
