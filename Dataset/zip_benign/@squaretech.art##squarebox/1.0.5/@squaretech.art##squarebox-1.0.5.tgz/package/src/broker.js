'use strict';

const 
    router            = require('./router'),
    socket            = require('./socket'),
    databases         = require('./databases'),
    { ServiceBroker } = require("moleculer");

const broker = new ServiceBroker({
    //* Broker Started */
    nodeID          : global.environment.app.id,
    logger          : global.environment.logger         || null,
    logLevel        : global.environment.logLevel       || null,
    transporter     : global.environment.transporter    || null,
    metrics         : global.environment.metrics        || null,
    tracing         : global.environment.tracing        || null,
    circuitBreaker  : global.environment.circuitbreaker || null,
    async created(broker) {
        if (global.environment.app.type == 'server') {
            await router();
        }
        if (global.environment.app.type == 'socket') {
            await socket();
        }
        await databases();
    },

    started(broker) {

    },

    stopped(broker) {

    },
});

module.exports = () => {
    return new Promise((resolve, reject) => {
        global.broker = broker;
        resolve(broker)
    })
}