'use strict';

const 
    fs  = require(`fs`),
    obj = {};
fs.readdirSync(__dirname).forEach((file) => {
    
const 
    patern = new RegExp('.js');
    if (patern.test(file) && file != 'index.js') {
        const src = require(`${__dirname}/${file}`);
        obj[file.replace(/.js|.ts/g, ``)] = src;
    }
    
});

 module.exports = { ... obj };