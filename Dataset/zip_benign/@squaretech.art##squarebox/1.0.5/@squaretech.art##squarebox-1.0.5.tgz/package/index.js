
'use strict';

global.basedir = process.env.PWD;

try {
    global.environment = require(`${basedir}/config/env.js`);
} catch(error) {
    throw new Error(`${basedir}/config/env.js is not found.`)
}

const 
    broker   = require('./src/broker'),
    services = require('./src/service'),
    modules  = require('./src/modules'),
    redis    = require('./src/redis'),
    database = require('./src/databases');

module.exports =  {
    start: async(callback) => {
        await broker()
        await services()
        await modules()
        await redis()
        await database()
        if (global.environment.node.mode == 'repl') {
            global.broker.repl()
        } 
        if(callback.constructor === Function) {
            callback();
        }

    }
}