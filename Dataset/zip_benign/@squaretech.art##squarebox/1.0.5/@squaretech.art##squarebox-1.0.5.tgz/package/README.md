# SQUAREBOX

squarebox is a module for quaretech.art framework  based on moleculerJS.

# Features

  - Routing
  - MVC Concept
  - Multiple Transporter
  - Logging
  - Road Balancing
  - Metrcics
  - Tracing
  - Fault Tolerance
  - Fastest Validator
  - Multi Database Connection
  - Redis Engine

### Installation

Squarebox requires [Node.js](https://nodejs.org/) v12+ to run.

```sh
$ cd root_folder
$ npm i @squaretech.art/squarebox
```

### Plugins

Squarebox is currently extended with the following delault plugins. 

-   amqplib
-   bunyan
-   expressjs
-   moleculer
-   pg
-   redis
-   sequelize

### config

- env.js
```
module.exports = {
    node: {
        env: 'development',
        debug: true,
        mode : 'repl'     // normal || repl
    },
    app: {
        id: "869259ced4e8ae68eabca702e23e56c9",
        type: "server",
        name: "master",
        host: "0.0.0.0",
        port: 9912
    },
    logger: {
		type: "Console",
        options: {
            formatter: "simple"
        }
    },
    transporter: {
        type: "AMQP",
        options: {
            url: "amqp://localhost"
        }
    },
    metrics: {
		enabled: true,
		reporter: {
			type: "Prometheus",
			options: {
				port: 9913,
				path: "/metrics",
				defaultLabels: registry => ({
					namespace: 'master',
					nodeID: '869259ced4e8ae68eabca702e23e56c9'
				})
			}
		}
    },
    tracing: {
        enabled: true,
        exporter: {
            type: "Console",
            options: {
                logger: null,
                colors: true,
                width: 100,
                gaugeWidth: 40
            }
        }
    },
    circuitbreaker: {
        enabled: true,
        threshold: 0.5,
        minRequestCount: 20,
        windowTime: 60, 
        halfOpenTime: 5 * 1000, 
        check: err => err && err.code >= 500
    },
    db: {
        host: "",
        name: "",
        user: "",
        pass: "",
        engine: "postgres",
        schema: "public",
        debug: false
    },
    cache: {
        host: "",
        port: ,
        db: 0
    }
}
```

- services.js
```
module.exports = {
    service : 'service'
}
```

