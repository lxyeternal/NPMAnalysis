import React from 'react';

declare function useResponsive(elRef: React.RefObject<HTMLDivElement>, initSize: {
    width: number;
    height: number;
}): {
    width: number;
    height: number;
};

export { useResponsive };
