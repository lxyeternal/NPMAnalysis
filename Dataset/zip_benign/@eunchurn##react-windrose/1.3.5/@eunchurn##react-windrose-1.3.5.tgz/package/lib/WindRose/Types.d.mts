type DirectionCount = {
    "0-1": number;
    "1-2": number;
    "2-3": number;
    "3-4": number;
    "4-5": number;
    "5-6": number;
    "6-7": number;
    "7+": number;
};
type CountClassify = "angle" | "0-1" | "1-2" | "2-3" | "3-4" | "4-5" | "5-6" | "6-7" | "7+";
declare enum Direction {
    N = "N",
    NNE = "NNE",
    NE = "NE",
    ENE = "ENE",
    E = "E",
    ESE = "ESE",
    SE = "SE",
    SSE = "SSE",
    S = "S",
    SSW = "SSW",
    SW = "SW",
    WSW = "WSW",
    W = "W",
    WNW = "WNW",
    NW = "NW",
    NNW = "NNW"
}
type Count = {
    N: DirectionCount;
    NNE: DirectionCount;
    NE: DirectionCount;
    ENE: DirectionCount;
    E: DirectionCount;
    ESE: DirectionCount;
    SE: DirectionCount;
    SSE: DirectionCount;
    S: DirectionCount;
    SSW: DirectionCount;
    SW: DirectionCount;
    WSW: DirectionCount;
    W: DirectionCount;
    WNW: DirectionCount;
    NW: DirectionCount;
    NNW: DirectionCount;
};
type DataTypes = {
    [key: string]: number;
}[];
type Angle = "N" | "NNE" | "NE" | "ENE" | "E" | "ESE" | "SE" | "SSE" | "S" | "SSW" | "SW" | "WSW" | "W" | "WNW" | "NW" | "NNW";
type ChartData = {
    angle: Angle;
    "0-1": number;
    "1-2": number;
    "2-3": number;
    "3-4": number;
    "4-5": number;
    "5-6": number;
    "6-7": number;
    "7+": number;
    total: number;
};
type Column = keyof ChartData;
type ChartPropsOnly = {
    chartData?: ChartData[];
    columns?: string[];
    width?: number;
    height?: number;
    responsive?: boolean;
    legendGap?: number;
};
type ChartPropTypes = ChartPropsOnly & React.HTMLProps<HTMLDivElement>;
declare const ChartDefaultProps: ChartPropTypes;
interface DataType {
    [key: string]: number;
}

export { type ChartData, ChartDefaultProps, type ChartPropTypes, type ChartPropsOnly, type Column, type Count, type CountClassify, type DataType, type DataTypes, Direction, type DirectionCount };
