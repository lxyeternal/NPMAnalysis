import * as react_jsx_runtime from 'react/jsx-runtime';
import { ChartPropTypes } from './Types.js';

declare function Chart(props: ChartPropTypes): react_jsx_runtime.JSX.Element;

export { Chart };
