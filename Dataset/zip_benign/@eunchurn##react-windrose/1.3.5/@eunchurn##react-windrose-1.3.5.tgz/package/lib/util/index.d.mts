import { Count, Direction, ChartData } from '../WindRose/Types.mjs';

declare const countPush: (count: Count, dir: Direction, speed: number) => Count;
declare const classifyDir: (direction: number) => Direction;
type Data = {
    direction: number[];
    speed: number[];
};
declare function calculateWindRose(data: Data): ChartData[];

export { type Data, calculateWindRose, classifyDir, countPush };
