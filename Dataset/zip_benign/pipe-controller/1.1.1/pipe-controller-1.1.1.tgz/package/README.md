# pipe-controller
a tool for pipe and flow control

# installation
```
npm install pipe-controller
```
# Usage
```
const pipeController = require('pipe-controller')

function onePlusOne() {
    return 1 + 1
}

function double(value) {
    return 2 * value
}

const config = {
    chunkSize: 10,    //pipe size
    maxMinutes: 0.5,
    maxRetryTimes: 1
}
const pc = new pipeController(config)
pc.add([onePlusOne, double])
const response = await pc.exec(100) //100 任务总数
```
# Lincese
MIT
