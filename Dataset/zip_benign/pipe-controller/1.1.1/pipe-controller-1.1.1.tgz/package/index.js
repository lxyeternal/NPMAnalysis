const logger = require('simple-json-logger')
const execPipe = require('./lib/exec-pipe')

class PipeController {
  constructor (config) {
    this.tasks = null
    this.config = Object.assign(PipeController.defaultConfig(), config)
  }
}

PipeController.defaultConfig = function () {
  return {
    chunkSize: 100,
    maxMinutes: 1,
    maxRetryTimes: 0
  }
}

PipeController.prototype['add'] = function (funcArr) {
  if (this.tasks) { throw new Error('failed to add another task') }
  if (Object.prototype.toString.call(funcArr) !== '[object Array]') { throw new Error('failed to add a none object') }
  this.tasks = funcArr
}

PipeController.prototype['exec'] = async function (numbers) { // numbers 任务总数
  const {
    chunkSize,
    maxMinutes,
    maxRetryTimes
  } = this.config
  const { tasks } = this
  let remains = numbers
  let success = false
  let retryTimes = 0
  const startTimestamp = new Date().getTime()
  while (remains > 0) {
    const now = new Date().getTime()
    if ((now - startTimestamp >= maxMinutes * 60 * 1000)) {
      logger.warn('Timed out')
      break
    }
    if (retryTimes >= maxRetryTimes) {
      logger.warn('Retry times exceed')
      break
    }

    const successCount = await execPipe(chunkSize, tasks)
    remains -= successCount
    success = remains <= 0
    if (successCount === 0) retryTimes += 1
  }
  return {
    success,
    remains
  }
}

module.exports = PipeController
