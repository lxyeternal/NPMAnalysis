const pipeController = require('./index')

describe('pipeController', () => {
  it('should run functions with pipeController', async () => {
    function onePlusOne() {
      return 1 + 1
    }

    function double(value) {
      return 2 * value
    }

    const config = {
      chunkSize: 10,    //pipe size
      maxMinutes: 0.5,
      maxRetryTimes: 1
    }
    const pc = new pipeController(config)
    pc.add([onePlusOne, double])
    const response = await pc.exec(100) //100 任务总数
    expect(response).toEqual({success: true, remains: 0})
  })
})
