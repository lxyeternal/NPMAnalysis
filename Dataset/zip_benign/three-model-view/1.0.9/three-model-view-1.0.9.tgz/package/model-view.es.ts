var Jn = Object.defineProperty;
var $n = (h, e, n) => e in h ? Jn(h, e, { enumerable: !0, configurable: !0, writable: !0, value: n }) : h[e] = n;
var L = (h, e, n) => ($n(h, typeof e != "symbol" ? e + "" : e, n), n);
import { defineComponent as es, computed as ts, ref as ns, reactive as Yt, onMounted as ss, openBlock as is, createElementBlock as rs, normalizeStyle as os } from "vue";
import { Vector3 as R, PerspectiveCamera as Pt, Scene as as, WebGLRenderer as cs, SRGBColorSpace as $, LinearToneMapping as ls, Group as fe, AmbientLight as pn, Color as D, DirectionalLight as st, CubeTextureLoader as Wt, TrianglesDrawMode as us, TriangleFanDrawMode as wt, TriangleStripDrawMode as dn, Loader as Me, LoaderUtils as ye, FileLoader as ze, LinearSRGBColorSpace as re, SpotLight as mn, PointLight as xt, MeshBasicMaterial as ke, MeshPhysicalMaterial as oe, Vector2 as G, Matrix4 as _, Quaternion as W, InstancedMesh as hs, InstancedBufferAttribute as fs, Object3D as Ee, TextureLoader as Ft, ImageBitmapLoader as ps, BufferAttribute as lt, InterleavedBuffer as ds, InterleavedBufferAttribute as ms, LinearFilter as gn, LinearMipmapLinearFilter as yn, RepeatWrapping as Re, PointsMaterial as Ne, Material as Be, LineBasicMaterial as je, MeshStandardMaterial as Tn, DoubleSide as gs, PropertyBinding as Ve, BufferGeometry as ve, SkinnedMesh as An, Mesh as it, LineSegments as bt, Line as wn, LineLoop as ys, Points as nt, MathUtils as j, OrthographicCamera as xn, Skeleton as bn, AnimationClip as _t, Bone as Et, InterpolateLinear as En, ColorManagement as qt, NearestFilter as Ts, NearestMipmapNearestFilter as As, LinearMipmapNearestFilter as ws, NearestMipmapLinearFilter as xs, ClampToEdgeWrapping as vt, MirroredRepeatWrapping as bs, InterpolateDiscrete as Es, FrontSide as vn, Texture as Ge, VectorKeyframeTrack as Lt, NumberKeyframeTrack as Mt, QuaternionKeyframeTrack as rt, Box3 as vs, Sphere as Ls, Interpolant as Ms, Float32BufferAttribute as q, MeshPhongMaterial as Ue, DefaultLoadingManager as Rs, Vector4 as ot, Curve as Ss, MeshLambertMaterial as Is, EquirectangularReflectionMapping as Cs, Uint16BufferAttribute as Ps, Matrix3 as Fs, ShapeUtils as _s, Euler as ne, AnimationMixer as Os, LoopRepeat as Ds, LoopOnce as ks, Clock as Ns, Ray as Bs, Plane as js, EventDispatcher as Gs, MOUSE as we, TOUCH as xe, Spherical as Zt, AxesHelper as Us, GridHelper as Hs } from "three";
import Vs, { Tween as Ln } from "@tweenjs/tween.js";
class zs {
  constructor(e, n) {
    L(this, "container");
    L(this, "camera");
    L(this, "scene");
    L(this, "renderer");
    L(this, "loopSwitch", !0);
    this.container = e;
    const t = e.offsetWidth, s = e.offsetHeight, i = {
      fov: n.fov || 70,
      near: 5,
      far: 1e6,
      aspect: t / s,
      position: new R(300, 300, 300)
    };
    n.cameraPosition && n.cameraPosition.length == 3 && (i.position = new R(n.cameraPosition[0], n.cameraPosition[1], n.cameraPosition[2]));
    const { fov: r, aspect: a, near: o, far: c, position: u } = i;
    this.camera = new Pt(r, a, o, c), this.camera.position.set(u.x, u.y, u.z), this.scene = new as(), this.camera.lookAt(this.scene.position);
    const l = {
      clearColor: n.clearColor || 15658734,
      shadowEnabled: n.shadowEnabled || !1,
      alpha: n.alpha || !1,
      opacity: n.opacity || 1,
      antialias: !0
    }, { clearColor: f, shadowEnabled: p, alpha: m, opacity: y, antialias: g } = l, T = new cs({ alpha: m, antialias: g, logarithmicDepthBuffer: !1 });
    T.outputColorSpace = $, T.toneMapping = ls, T.toneMappingExposure = 0.5, T.setPixelRatio(window.devicePixelRatio), T.setSize(t, s), f && T.setClearColor(f, y), T.shadowMap.enabled = p, e.appendChild(T.domElement), T.render(this.scene, this.camera), this.renderer = T, this.listenResize(), this.render();
  }
  listenResize() {
    const e = () => {
      const n = this.container.offsetWidth, t = this.container.offsetHeight;
      this.camera.aspect = n / t, this.camera.updateProjectionMatrix(), this.renderer.setSize(n, t);
    };
    window.addEventListener("resize", e, !1);
  }
  render() {
    requestAnimationFrame(() => {
      this.loopSwitch && (this.render(), Vs.update());
    }), this.renderer.clear(), this.renderer.render(this.scene, this.camera);
  }
  setLoop(e) {
    this.loopSwitch = e;
  }
}
class Ks {
  constructor(e, n) {
    L(this, "scene");
    L(this, "amientLight");
    L(this, "lightType");
    L(this, "directionalLights", []);
    L(this, "elementGroup", new fe());
    L(this, "skyboxImgs", []);
    this.scene = n.scene, this.scene.add(this.elementGroup);
    const { lightType: t = "single" } = e;
    this.lightType = t, this.addAmbientLight(), this.addDirectionalLight();
  }
  addAmbientLight() {
    this.amientLight = new pn(16777215, 0.3), this.scene.add(this.amientLight);
  }
  removeAmbientLight() {
    this.amientLight && this.scene.remove(this.amientLight);
  }
  getLightColor() {
    return this.amientLight.color.getHexString();
  }
  setLightColor(e) {
    (typeof e == "string" || typeof e == "number") && (e = new D(e)), this.amientLight.color = e;
  }
  getLightness() {
    return this.amientLight.intensity;
  }
  setLightness(e) {
    this.amientLight.intensity = e;
  }
  addDirectionalLight() {
    if (this.lightType === "single") {
      const e = new st(16777215, 1);
      e.position.set(1e3, 500, 1e3), this.directionalLights.push(e), this.scene.add(e);
    } else
      this.lightType === "all" && [
        { x: 1e3, y: 500, z: 0 },
        { x: -1e3, y: 500, z: 0 },
        { x: 0, y: 500, z: 1e3 },
        { x: 0, y: 500, z: -1e3 }
      ].forEach((n) => {
        const t = new st(16777215, 1);
        t.position.set(n.x, n.y, n.z), this.directionalLights.push(t), this.scene.add(t);
      });
  }
  getDirectLightColor() {
    return this.directionalLights[0].color.getHexString();
  }
  setDirectLightColor(e) {
    (typeof e == "string" || typeof e == "number") && (e = new D(e)), this.directionalLights.forEach((n) => {
      n.color = e;
    });
  }
  getDirectLightness() {
    return this.directionalLights[0].intensity;
  }
  setDirectLightness(e) {
    this.directionalLights.forEach((n) => {
      n.intensity = e;
    });
  }
  getDirectLightPosition() {
    return this.directionalLights.map((n) => n.position);
  }
  setDirectLightPosition(e) {
    this.directionalLights.forEach((n, t) => {
      const s = e[t];
      n.position.set(s.x, s.y, s.z);
    });
  }
  setSkyBox(e) {
    this.skyboxImgs = e, this.scene.background = new Wt().load(e);
  }
  clearSkyBox() {
    this.scene.background = null;
  }
  setEnvironment(e) {
    this.skyboxImgs && e && (this.scene.environment = new Wt().load(this.skyboxImgs)), e || (this.scene.environment = null);
  }
  getSkyBoxImgs() {
    return this.skyboxImgs;
  }
  loadSceneData(e) {
    const { lightColor: n, lightness: t, directLightColor: s, directLightness: i, skyboxImgs: r } = e;
    this.setLightColor(n), this.setLightness(t), this.setDirectLightColor(s), this.setDirectLightness(i), this.setSkyBox(r);
  }
  saveSceneData() {
    return {
      lightColor: this.getLightColor(),
      lightness: this.getLightness(),
      directLightColor: this.getDirectLightColor(),
      directLightness: this.getDirectLightness(),
      skyboxImgs: this.getSkyBoxImgs()
    };
  }
}
function Qt(h, e) {
  if (e === us)
    return console.warn("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Geometry already defined as triangles."), h;
  if (e === wt || e === dn) {
    let n = h.getIndex();
    if (n === null) {
      const r = [], a = h.getAttribute("position");
      if (a !== void 0) {
        for (let o = 0; o < a.count; o++)
          r.push(o);
        h.setIndex(r), n = h.getIndex();
      } else
        return console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Undefined position attribute. Processing not possible."), h;
    }
    const t = n.count - 2, s = [];
    if (e === wt)
      for (let r = 1; r <= t; r++)
        s.push(n.getX(0)), s.push(n.getX(r)), s.push(n.getX(r + 1));
    else
      for (let r = 0; r < t; r++)
        r % 2 === 0 ? (s.push(n.getX(r)), s.push(n.getX(r + 1)), s.push(n.getX(r + 2))) : (s.push(n.getX(r + 2)), s.push(n.getX(r + 1)), s.push(n.getX(r)));
    s.length / 3 !== t && console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Unable to generate correct amount of triangles.");
    const i = h.clone();
    return i.setIndex(s), i.clearGroups(), i;
  } else
    return console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Unknown draw mode:", e), h;
}
class Xs extends Me {
  constructor(e) {
    super(e), this.dracoLoader = null, this.ktx2Loader = null, this.meshoptDecoder = null, this.pluginCallbacks = [], this.register(function(n) {
      return new Qs(n);
    }), this.register(function(n) {
      return new oi(n);
    }), this.register(function(n) {
      return new ai(n);
    }), this.register(function(n) {
      return new ci(n);
    }), this.register(function(n) {
      return new $s(n);
    }), this.register(function(n) {
      return new ei(n);
    }), this.register(function(n) {
      return new ti(n);
    }), this.register(function(n) {
      return new ni(n);
    }), this.register(function(n) {
      return new Zs(n);
    }), this.register(function(n) {
      return new si(n);
    }), this.register(function(n) {
      return new Js(n);
    }), this.register(function(n) {
      return new ri(n);
    }), this.register(function(n) {
      return new ii(n);
    }), this.register(function(n) {
      return new Ws(n);
    }), this.register(function(n) {
      return new li(n);
    }), this.register(function(n) {
      return new ui(n);
    });
  }
  load(e, n, t, s) {
    const i = this;
    let r;
    if (this.resourcePath !== "")
      r = this.resourcePath;
    else if (this.path !== "") {
      const c = ye.extractUrlBase(e);
      r = ye.resolveURL(c, this.path);
    } else
      r = ye.extractUrlBase(e);
    this.manager.itemStart(e);
    const a = function(c) {
      s ? s(c) : console.error(c), i.manager.itemError(e), i.manager.itemEnd(e);
    }, o = new ze(this.manager);
    o.setPath(this.path), o.setResponseType("arraybuffer"), o.setRequestHeader(this.requestHeader), o.setWithCredentials(this.withCredentials), o.load(e, function(c) {
      try {
        i.parse(c, r, function(u) {
          n(u), i.manager.itemEnd(e);
        }, a);
      } catch (u) {
        a(u);
      }
    }, t, a);
  }
  setDRACOLoader(e) {
    return this.dracoLoader = e, this;
  }
  setDDSLoader() {
    throw new Error(
      'THREE.GLTFLoader: "MSFT_texture_dds" no longer supported. Please update to "KHR_texture_basisu".'
    );
  }
  setKTX2Loader(e) {
    return this.ktx2Loader = e, this;
  }
  setMeshoptDecoder(e) {
    return this.meshoptDecoder = e, this;
  }
  register(e) {
    return this.pluginCallbacks.indexOf(e) === -1 && this.pluginCallbacks.push(e), this;
  }
  unregister(e) {
    return this.pluginCallbacks.indexOf(e) !== -1 && this.pluginCallbacks.splice(this.pluginCallbacks.indexOf(e), 1), this;
  }
  parse(e, n, t, s) {
    let i;
    const r = {}, a = {}, o = new TextDecoder();
    if (typeof e == "string")
      i = JSON.parse(e);
    else if (e instanceof ArrayBuffer)
      if (o.decode(new Uint8Array(e, 0, 4)) === Mn) {
        try {
          r[C.KHR_BINARY_GLTF] = new hi(e);
        } catch (l) {
          s && s(l);
          return;
        }
        i = JSON.parse(r[C.KHR_BINARY_GLTF].content);
      } else
        i = JSON.parse(o.decode(e));
    else
      i = e;
    if (i.asset === void 0 || i.asset.version[0] < 2) {
      s && s(new Error("THREE.GLTFLoader: Unsupported asset. glTF versions >=2.0 are supported."));
      return;
    }
    const c = new vi(i, {
      path: n || this.resourcePath || "",
      crossOrigin: this.crossOrigin,
      requestHeader: this.requestHeader,
      manager: this.manager,
      ktx2Loader: this.ktx2Loader,
      meshoptDecoder: this.meshoptDecoder
    });
    c.fileLoader.setRequestHeader(this.requestHeader);
    for (let u = 0; u < this.pluginCallbacks.length; u++) {
      const l = this.pluginCallbacks[u](c);
      l.name || console.error("THREE.GLTFLoader: Invalid plugin found: missing name"), a[l.name] = l, r[l.name] = !0;
    }
    if (i.extensionsUsed)
      for (let u = 0; u < i.extensionsUsed.length; ++u) {
        const l = i.extensionsUsed[u], f = i.extensionsRequired || [];
        switch (l) {
          case C.KHR_MATERIALS_UNLIT:
            r[l] = new qs();
            break;
          case C.KHR_DRACO_MESH_COMPRESSION:
            r[l] = new fi(i, this.dracoLoader);
            break;
          case C.KHR_TEXTURE_TRANSFORM:
            r[l] = new pi();
            break;
          case C.KHR_MESH_QUANTIZATION:
            r[l] = new di();
            break;
          default:
            f.indexOf(l) >= 0 && a[l] === void 0 && console.warn('THREE.GLTFLoader: Unknown extension "' + l + '".');
        }
      }
    c.setExtensions(r), c.setPlugins(a), c.parse(t, s);
  }
  parseAsync(e, n) {
    const t = this;
    return new Promise(function(s, i) {
      t.parse(e, n, s, i);
    });
  }
}
function Ys() {
  let h = {};
  return {
    get: function(e) {
      return h[e];
    },
    add: function(e, n) {
      h[e] = n;
    },
    remove: function(e) {
      delete h[e];
    },
    removeAll: function() {
      h = {};
    }
  };
}
const C = {
  KHR_BINARY_GLTF: "KHR_binary_glTF",
  KHR_DRACO_MESH_COMPRESSION: "KHR_draco_mesh_compression",
  KHR_LIGHTS_PUNCTUAL: "KHR_lights_punctual",
  KHR_MATERIALS_CLEARCOAT: "KHR_materials_clearcoat",
  KHR_MATERIALS_IOR: "KHR_materials_ior",
  KHR_MATERIALS_SHEEN: "KHR_materials_sheen",
  KHR_MATERIALS_SPECULAR: "KHR_materials_specular",
  KHR_MATERIALS_TRANSMISSION: "KHR_materials_transmission",
  KHR_MATERIALS_IRIDESCENCE: "KHR_materials_iridescence",
  KHR_MATERIALS_ANISOTROPY: "KHR_materials_anisotropy",
  KHR_MATERIALS_UNLIT: "KHR_materials_unlit",
  KHR_MATERIALS_VOLUME: "KHR_materials_volume",
  KHR_TEXTURE_BASISU: "KHR_texture_basisu",
  KHR_TEXTURE_TRANSFORM: "KHR_texture_transform",
  KHR_MESH_QUANTIZATION: "KHR_mesh_quantization",
  KHR_MATERIALS_EMISSIVE_STRENGTH: "KHR_materials_emissive_strength",
  EXT_MATERIALS_BUMP: "EXT_materials_bump",
  EXT_TEXTURE_WEBP: "EXT_texture_webp",
  EXT_TEXTURE_AVIF: "EXT_texture_avif",
  EXT_MESHOPT_COMPRESSION: "EXT_meshopt_compression",
  EXT_MESH_GPU_INSTANCING: "EXT_mesh_gpu_instancing"
};
class Ws {
  constructor(e) {
    this.parser = e, this.name = C.KHR_LIGHTS_PUNCTUAL, this.cache = { refs: {}, uses: {} };
  }
  _markDefs() {
    const e = this.parser, n = this.parser.json.nodes || [];
    for (let t = 0, s = n.length; t < s; t++) {
      const i = n[t];
      i.extensions && i.extensions[this.name] && i.extensions[this.name].light !== void 0 && e._addNodeRef(this.cache, i.extensions[this.name].light);
    }
  }
  _loadLight(e) {
    const n = this.parser, t = "light:" + e;
    let s = n.cache.get(t);
    if (s)
      return s;
    const i = n.json, o = ((i.extensions && i.extensions[this.name] || {}).lights || [])[e];
    let c;
    const u = new D(16777215);
    o.color !== void 0 && u.setRGB(o.color[0], o.color[1], o.color[2], re);
    const l = o.range !== void 0 ? o.range : 0;
    switch (o.type) {
      case "directional":
        c = new st(u), c.target.position.set(0, 0, -1), c.add(c.target);
        break;
      case "point":
        c = new xt(u), c.distance = l;
        break;
      case "spot":
        c = new mn(u), c.distance = l, o.spot = o.spot || {}, o.spot.innerConeAngle = o.spot.innerConeAngle !== void 0 ? o.spot.innerConeAngle : 0, o.spot.outerConeAngle = o.spot.outerConeAngle !== void 0 ? o.spot.outerConeAngle : Math.PI / 4, c.angle = o.spot.outerConeAngle, c.penumbra = 1 - o.spot.innerConeAngle / o.spot.outerConeAngle, c.target.position.set(0, 0, -1), c.add(c.target);
        break;
      default:
        throw new Error("THREE.GLTFLoader: Unexpected light type: " + o.type);
    }
    return c.position.set(0, 0, 0), c.decay = 2, ue(c, o), o.intensity !== void 0 && (c.intensity = o.intensity), c.name = n.createUniqueName(o.name || "light_" + e), s = Promise.resolve(c), n.cache.add(t, s), s;
  }
  getDependency(e, n) {
    if (e === "light")
      return this._loadLight(n);
  }
  createNodeAttachment(e) {
    const n = this, t = this.parser, i = t.json.nodes[e], a = (i.extensions && i.extensions[this.name] || {}).light;
    return a === void 0 ? null : this._loadLight(a).then(function(o) {
      return t._getNodeRef(n.cache, a, o);
    });
  }
}
class qs {
  constructor() {
    this.name = C.KHR_MATERIALS_UNLIT;
  }
  getMaterialType() {
    return ke;
  }
  extendParams(e, n, t) {
    const s = [];
    e.color = new D(1, 1, 1), e.opacity = 1;
    const i = n.pbrMetallicRoughness;
    if (i) {
      if (Array.isArray(i.baseColorFactor)) {
        const r = i.baseColorFactor;
        e.color.setRGB(r[0], r[1], r[2], re), e.opacity = r[3];
      }
      i.baseColorTexture !== void 0 && s.push(t.assignTexture(e, "map", i.baseColorTexture, $));
    }
    return Promise.all(s);
  }
}
class Zs {
  constructor(e) {
    this.parser = e, this.name = C.KHR_MATERIALS_EMISSIVE_STRENGTH;
  }
  extendMaterialParams(e, n) {
    const s = this.parser.json.materials[e];
    if (!s.extensions || !s.extensions[this.name])
      return Promise.resolve();
    const i = s.extensions[this.name].emissiveStrength;
    return i !== void 0 && (n.emissiveIntensity = i), Promise.resolve();
  }
}
class Qs {
  constructor(e) {
    this.parser = e, this.name = C.KHR_MATERIALS_CLEARCOAT;
  }
  getMaterialType(e) {
    const t = this.parser.json.materials[e];
    return !t.extensions || !t.extensions[this.name] ? null : oe;
  }
  extendMaterialParams(e, n) {
    const t = this.parser, s = t.json.materials[e];
    if (!s.extensions || !s.extensions[this.name])
      return Promise.resolve();
    const i = [], r = s.extensions[this.name];
    if (r.clearcoatFactor !== void 0 && (n.clearcoat = r.clearcoatFactor), r.clearcoatTexture !== void 0 && i.push(t.assignTexture(n, "clearcoatMap", r.clearcoatTexture)), r.clearcoatRoughnessFactor !== void 0 && (n.clearcoatRoughness = r.clearcoatRoughnessFactor), r.clearcoatRoughnessTexture !== void 0 && i.push(t.assignTexture(n, "clearcoatRoughnessMap", r.clearcoatRoughnessTexture)), r.clearcoatNormalTexture !== void 0 && (i.push(t.assignTexture(n, "clearcoatNormalMap", r.clearcoatNormalTexture)), r.clearcoatNormalTexture.scale !== void 0)) {
      const a = r.clearcoatNormalTexture.scale;
      n.clearcoatNormalScale = new G(a, a);
    }
    return Promise.all(i);
  }
}
class Js {
  constructor(e) {
    this.parser = e, this.name = C.KHR_MATERIALS_IRIDESCENCE;
  }
  getMaterialType(e) {
    const t = this.parser.json.materials[e];
    return !t.extensions || !t.extensions[this.name] ? null : oe;
  }
  extendMaterialParams(e, n) {
    const t = this.parser, s = t.json.materials[e];
    if (!s.extensions || !s.extensions[this.name])
      return Promise.resolve();
    const i = [], r = s.extensions[this.name];
    return r.iridescenceFactor !== void 0 && (n.iridescence = r.iridescenceFactor), r.iridescenceTexture !== void 0 && i.push(t.assignTexture(n, "iridescenceMap", r.iridescenceTexture)), r.iridescenceIor !== void 0 && (n.iridescenceIOR = r.iridescenceIor), n.iridescenceThicknessRange === void 0 && (n.iridescenceThicknessRange = [100, 400]), r.iridescenceThicknessMinimum !== void 0 && (n.iridescenceThicknessRange[0] = r.iridescenceThicknessMinimum), r.iridescenceThicknessMaximum !== void 0 && (n.iridescenceThicknessRange[1] = r.iridescenceThicknessMaximum), r.iridescenceThicknessTexture !== void 0 && i.push(t.assignTexture(n, "iridescenceThicknessMap", r.iridescenceThicknessTexture)), Promise.all(i);
  }
}
class $s {
  constructor(e) {
    this.parser = e, this.name = C.KHR_MATERIALS_SHEEN;
  }
  getMaterialType(e) {
    const t = this.parser.json.materials[e];
    return !t.extensions || !t.extensions[this.name] ? null : oe;
  }
  extendMaterialParams(e, n) {
    const t = this.parser, s = t.json.materials[e];
    if (!s.extensions || !s.extensions[this.name])
      return Promise.resolve();
    const i = [];
    n.sheenColor = new D(0, 0, 0), n.sheenRoughness = 0, n.sheen = 1;
    const r = s.extensions[this.name];
    if (r.sheenColorFactor !== void 0) {
      const a = r.sheenColorFactor;
      n.sheenColor.setRGB(a[0], a[1], a[2], re);
    }
    return r.sheenRoughnessFactor !== void 0 && (n.sheenRoughness = r.sheenRoughnessFactor), r.sheenColorTexture !== void 0 && i.push(t.assignTexture(n, "sheenColorMap", r.sheenColorTexture, $)), r.sheenRoughnessTexture !== void 0 && i.push(t.assignTexture(n, "sheenRoughnessMap", r.sheenRoughnessTexture)), Promise.all(i);
  }
}
class ei {
  constructor(e) {
    this.parser = e, this.name = C.KHR_MATERIALS_TRANSMISSION;
  }
  getMaterialType(e) {
    const t = this.parser.json.materials[e];
    return !t.extensions || !t.extensions[this.name] ? null : oe;
  }
  extendMaterialParams(e, n) {
    const t = this.parser, s = t.json.materials[e];
    if (!s.extensions || !s.extensions[this.name])
      return Promise.resolve();
    const i = [], r = s.extensions[this.name];
    return r.transmissionFactor !== void 0 && (n.transmission = r.transmissionFactor), r.transmissionTexture !== void 0 && i.push(t.assignTexture(n, "transmissionMap", r.transmissionTexture)), Promise.all(i);
  }
}
class ti {
  constructor(e) {
    this.parser = e, this.name = C.KHR_MATERIALS_VOLUME;
  }
  getMaterialType(e) {
    const t = this.parser.json.materials[e];
    return !t.extensions || !t.extensions[this.name] ? null : oe;
  }
  extendMaterialParams(e, n) {
    const t = this.parser, s = t.json.materials[e];
    if (!s.extensions || !s.extensions[this.name])
      return Promise.resolve();
    const i = [], r = s.extensions[this.name];
    n.thickness = r.thicknessFactor !== void 0 ? r.thicknessFactor : 0, r.thicknessTexture !== void 0 && i.push(t.assignTexture(n, "thicknessMap", r.thicknessTexture)), n.attenuationDistance = r.attenuationDistance || 1 / 0;
    const a = r.attenuationColor || [1, 1, 1];
    return n.attenuationColor = new D().setRGB(a[0], a[1], a[2], re), Promise.all(i);
  }
}
class ni {
  constructor(e) {
    this.parser = e, this.name = C.KHR_MATERIALS_IOR;
  }
  getMaterialType(e) {
    const t = this.parser.json.materials[e];
    return !t.extensions || !t.extensions[this.name] ? null : oe;
  }
  extendMaterialParams(e, n) {
    const s = this.parser.json.materials[e];
    if (!s.extensions || !s.extensions[this.name])
      return Promise.resolve();
    const i = s.extensions[this.name];
    return n.ior = i.ior !== void 0 ? i.ior : 1.5, Promise.resolve();
  }
}
class si {
  constructor(e) {
    this.parser = e, this.name = C.KHR_MATERIALS_SPECULAR;
  }
  getMaterialType(e) {
    const t = this.parser.json.materials[e];
    return !t.extensions || !t.extensions[this.name] ? null : oe;
  }
  extendMaterialParams(e, n) {
    const t = this.parser, s = t.json.materials[e];
    if (!s.extensions || !s.extensions[this.name])
      return Promise.resolve();
    const i = [], r = s.extensions[this.name];
    n.specularIntensity = r.specularFactor !== void 0 ? r.specularFactor : 1, r.specularTexture !== void 0 && i.push(t.assignTexture(n, "specularIntensityMap", r.specularTexture));
    const a = r.specularColorFactor || [1, 1, 1];
    return n.specularColor = new D().setRGB(a[0], a[1], a[2], re), r.specularColorTexture !== void 0 && i.push(t.assignTexture(n, "specularColorMap", r.specularColorTexture, $)), Promise.all(i);
  }
}
class ii {
  constructor(e) {
    this.parser = e, this.name = C.EXT_MATERIALS_BUMP;
  }
  getMaterialType(e) {
    const t = this.parser.json.materials[e];
    return !t.extensions || !t.extensions[this.name] ? null : oe;
  }
  extendMaterialParams(e, n) {
    const t = this.parser, s = t.json.materials[e];
    if (!s.extensions || !s.extensions[this.name])
      return Promise.resolve();
    const i = [], r = s.extensions[this.name];
    return n.bumpScale = r.bumpFactor !== void 0 ? r.bumpFactor : 1, r.bumpTexture !== void 0 && i.push(t.assignTexture(n, "bumpMap", r.bumpTexture)), Promise.all(i);
  }
}
class ri {
  constructor(e) {
    this.parser = e, this.name = C.KHR_MATERIALS_ANISOTROPY;
  }
  getMaterialType(e) {
    const t = this.parser.json.materials[e];
    return !t.extensions || !t.extensions[this.name] ? null : oe;
  }
  extendMaterialParams(e, n) {
    const t = this.parser, s = t.json.materials[e];
    if (!s.extensions || !s.extensions[this.name])
      return Promise.resolve();
    const i = [], r = s.extensions[this.name];
    return r.anisotropyStrength !== void 0 && (n.anisotropy = r.anisotropyStrength), r.anisotropyRotation !== void 0 && (n.anisotropyRotation = r.anisotropyRotation), r.anisotropyTexture !== void 0 && i.push(t.assignTexture(n, "anisotropyMap", r.anisotropyTexture)), Promise.all(i);
  }
}
class oi {
  constructor(e) {
    this.parser = e, this.name = C.KHR_TEXTURE_BASISU;
  }
  loadTexture(e) {
    const n = this.parser, t = n.json, s = t.textures[e];
    if (!s.extensions || !s.extensions[this.name])
      return null;
    const i = s.extensions[this.name], r = n.options.ktx2Loader;
    if (!r) {
      if (t.extensionsRequired && t.extensionsRequired.indexOf(this.name) >= 0)
        throw new Error("THREE.GLTFLoader: setKTX2Loader must be called before loading KTX2 textures");
      return null;
    }
    return n.loadTextureImage(e, i.source, r);
  }
}
class ai {
  constructor(e) {
    this.parser = e, this.name = C.EXT_TEXTURE_WEBP, this.isSupported = null;
  }
  loadTexture(e) {
    const n = this.name, t = this.parser, s = t.json, i = s.textures[e];
    if (!i.extensions || !i.extensions[n])
      return null;
    const r = i.extensions[n], a = s.images[r.source];
    let o = t.textureLoader;
    if (a.uri) {
      const c = t.options.manager.getHandler(a.uri);
      c !== null && (o = c);
    }
    return this.detectSupport().then(function(c) {
      if (c)
        return t.loadTextureImage(e, r.source, o);
      if (s.extensionsRequired && s.extensionsRequired.indexOf(n) >= 0)
        throw new Error("THREE.GLTFLoader: WebP required by asset but unsupported.");
      return t.loadTexture(e);
    });
  }
  detectSupport() {
    return this.isSupported || (this.isSupported = new Promise(function(e) {
      const n = new Image();
      n.src = "data:image/webp;base64,UklGRiIAAABXRUJQVlA4IBYAAAAwAQCdASoBAAEADsD+JaQAA3AAAAAA", n.onload = n.onerror = function() {
        e(n.height === 1);
      };
    })), this.isSupported;
  }
}
class ci {
  constructor(e) {
    this.parser = e, this.name = C.EXT_TEXTURE_AVIF, this.isSupported = null;
  }
  loadTexture(e) {
    const n = this.name, t = this.parser, s = t.json, i = s.textures[e];
    if (!i.extensions || !i.extensions[n])
      return null;
    const r = i.extensions[n], a = s.images[r.source];
    let o = t.textureLoader;
    if (a.uri) {
      const c = t.options.manager.getHandler(a.uri);
      c !== null && (o = c);
    }
    return this.detectSupport().then(function(c) {
      if (c)
        return t.loadTextureImage(e, r.source, o);
      if (s.extensionsRequired && s.extensionsRequired.indexOf(n) >= 0)
        throw new Error("THREE.GLTFLoader: AVIF required by asset but unsupported.");
      return t.loadTexture(e);
    });
  }
  detectSupport() {
    return this.isSupported || (this.isSupported = new Promise(function(e) {
      const n = new Image();
      n.src = "data:image/avif;base64,AAAAIGZ0eXBhdmlmAAAAAGF2aWZtaWYxbWlhZk1BMUIAAADybWV0YQAAAAAAAAAoaGRscgAAAAAAAAAAcGljdAAAAAAAAAAAAAAAAGxpYmF2aWYAAAAADnBpdG0AAAAAAAEAAAAeaWxvYwAAAABEAAABAAEAAAABAAABGgAAABcAAAAoaWluZgAAAAAAAQAAABppbmZlAgAAAAABAABhdjAxQ29sb3IAAAAAamlwcnAAAABLaXBjbwAAABRpc3BlAAAAAAAAAAEAAAABAAAAEHBpeGkAAAAAAwgICAAAAAxhdjFDgQAMAAAAABNjb2xybmNseAACAAIABoAAAAAXaXBtYQAAAAAAAAABAAEEAQKDBAAAAB9tZGF0EgAKCBgABogQEDQgMgkQAAAAB8dSLfI=", n.onload = n.onerror = function() {
        e(n.height === 1);
      };
    })), this.isSupported;
  }
}
class li {
  constructor(e) {
    this.name = C.EXT_MESHOPT_COMPRESSION, this.parser = e;
  }
  loadBufferView(e) {
    const n = this.parser.json, t = n.bufferViews[e];
    if (t.extensions && t.extensions[this.name]) {
      const s = t.extensions[this.name], i = this.parser.getDependency("buffer", s.buffer), r = this.parser.options.meshoptDecoder;
      if (!r || !r.supported) {
        if (n.extensionsRequired && n.extensionsRequired.indexOf(this.name) >= 0)
          throw new Error("THREE.GLTFLoader: setMeshoptDecoder must be called before loading compressed files");
        return null;
      }
      return i.then(function(a) {
        const o = s.byteOffset || 0, c = s.byteLength || 0, u = s.count, l = s.byteStride, f = new Uint8Array(a, o, c);
        return r.decodeGltfBufferAsync ? r.decodeGltfBufferAsync(u, l, f, s.mode, s.filter).then(function(p) {
          return p.buffer;
        }) : r.ready.then(function() {
          const p = new ArrayBuffer(u * l);
          return r.decodeGltfBuffer(new Uint8Array(p), u, l, f, s.mode, s.filter), p;
        });
      });
    } else
      return null;
  }
}
class ui {
  constructor(e) {
    this.name = C.EXT_MESH_GPU_INSTANCING, this.parser = e;
  }
  createNodeMesh(e) {
    const n = this.parser.json, t = n.nodes[e];
    if (!t.extensions || !t.extensions[this.name] || t.mesh === void 0)
      return null;
    const s = n.meshes[t.mesh];
    for (const c of s.primitives)
      if (c.mode !== Y.TRIANGLES && c.mode !== Y.TRIANGLE_STRIP && c.mode !== Y.TRIANGLE_FAN && c.mode !== void 0)
        return null;
    const r = t.extensions[this.name].attributes, a = [], o = {};
    for (const c in r)
      a.push(this.parser.getDependency("accessor", r[c]).then((u) => (o[c] = u, o[c])));
    return a.length < 1 ? null : (a.push(this.parser.createNodeMesh(e)), Promise.all(a).then((c) => {
      const u = c.pop(), l = u.isGroup ? u.children : [u], f = c[0].count, p = [];
      for (const m of l) {
        const y = new _(), g = new R(), T = new W(), w = new R(1, 1, 1), A = new hs(m.geometry, m.material, f);
        for (let x = 0; x < f; x++)
          o.TRANSLATION && g.fromBufferAttribute(o.TRANSLATION, x), o.ROTATION && T.fromBufferAttribute(o.ROTATION, x), o.SCALE && w.fromBufferAttribute(o.SCALE, x), A.setMatrixAt(x, y.compose(g, T, w));
        for (const x in o)
          if (x === "_COLOR_0") {
            const S = o[x];
            A.instanceColor = new fs(S.array, S.itemSize, S.normalized);
          } else
            x !== "TRANSLATION" && x !== "ROTATION" && x !== "SCALE" && m.geometry.setAttribute(x, o[x]);
        Ee.prototype.copy.call(A, m), this.parser.assignFinalMaterial(A), p.push(A);
      }
      return u.isGroup ? (u.clear(), u.add(...p), u) : p[0];
    }));
  }
}
const Mn = "glTF", De = 12, Jt = { JSON: 1313821514, BIN: 5130562 };
class hi {
  constructor(e) {
    this.name = C.KHR_BINARY_GLTF, this.content = null, this.body = null;
    const n = new DataView(e, 0, De), t = new TextDecoder();
    if (this.header = {
      magic: t.decode(new Uint8Array(e.slice(0, 4))),
      version: n.getUint32(4, !0),
      length: n.getUint32(8, !0)
    }, this.header.magic !== Mn)
      throw new Error("THREE.GLTFLoader: Unsupported glTF-Binary header.");
    if (this.header.version < 2)
      throw new Error("THREE.GLTFLoader: Legacy binary file detected.");
    const s = this.header.length - De, i = new DataView(e, De);
    let r = 0;
    for (; r < s; ) {
      const a = i.getUint32(r, !0);
      r += 4;
      const o = i.getUint32(r, !0);
      if (r += 4, o === Jt.JSON) {
        const c = new Uint8Array(e, De + r, a);
        this.content = t.decode(c);
      } else if (o === Jt.BIN) {
        const c = De + r;
        this.body = e.slice(c, c + a);
      }
      r += a;
    }
    if (this.content === null)
      throw new Error("THREE.GLTFLoader: JSON content not found.");
  }
}
class fi {
  constructor(e, n) {
    if (!n)
      throw new Error("THREE.GLTFLoader: No DRACOLoader instance provided.");
    this.name = C.KHR_DRACO_MESH_COMPRESSION, this.json = e, this.dracoLoader = n, this.dracoLoader.preload();
  }
  decodePrimitive(e, n) {
    const t = this.json, s = this.dracoLoader, i = e.extensions[this.name].bufferView, r = e.extensions[this.name].attributes, a = {}, o = {}, c = {};
    for (const u in r) {
      const l = Rt[u] || u.toLowerCase();
      a[l] = r[u];
    }
    for (const u in e.attributes) {
      const l = Rt[u] || u.toLowerCase();
      if (r[u] !== void 0) {
        const f = t.accessors[e.attributes[u]], p = Le[f.componentType];
        c[l] = p.name, o[l] = f.normalized === !0;
      }
    }
    return n.getDependency("bufferView", i).then(function(u) {
      return new Promise(function(l, f) {
        s.decodeDracoFile(u, function(p) {
          for (const m in p.attributes) {
            const y = p.attributes[m], g = o[m];
            g !== void 0 && (y.normalized = g);
          }
          l(p);
        }, a, c, re, f);
      });
    });
  }
}
class pi {
  constructor() {
    this.name = C.KHR_TEXTURE_TRANSFORM;
  }
  extendTexture(e, n) {
    return (n.texCoord === void 0 || n.texCoord === e.channel) && n.offset === void 0 && n.rotation === void 0 && n.scale === void 0 || (e = e.clone(), n.texCoord !== void 0 && (e.channel = n.texCoord), n.offset !== void 0 && e.offset.fromArray(n.offset), n.rotation !== void 0 && (e.rotation = n.rotation), n.scale !== void 0 && e.repeat.fromArray(n.scale), e.needsUpdate = !0), e;
  }
}
class di {
  constructor() {
    this.name = C.KHR_MESH_QUANTIZATION;
  }
}
class Rn extends Ms {
  constructor(e, n, t, s) {
    super(e, n, t, s);
  }
  copySampleValue_(e) {
    const n = this.resultBuffer, t = this.sampleValues, s = this.valueSize, i = e * s * 3 + s;
    for (let r = 0; r !== s; r++)
      n[r] = t[i + r];
    return n;
  }
  interpolate_(e, n, t, s) {
    const i = this.resultBuffer, r = this.sampleValues, a = this.valueSize, o = a * 2, c = a * 3, u = s - n, l = (t - n) / u, f = l * l, p = f * l, m = e * c, y = m - c, g = -2 * p + 3 * f, T = p - f, w = 1 - g, A = T - f + l;
    for (let x = 0; x !== a; x++) {
      const S = r[y + x + a], E = r[y + x + o] * u, v = r[m + x + a], P = r[m + x] * u;
      i[x] = w * S + A * E + g * v + T * P;
    }
    return i;
  }
}
const mi = new W();
class gi extends Rn {
  interpolate_(e, n, t, s) {
    const i = super.interpolate_(e, n, t, s);
    return mi.fromArray(i).normalize().toArray(i), i;
  }
}
const Y = {
  FLOAT: 5126,
  //FLOAT_MAT2: 35674,
  FLOAT_MAT3: 35675,
  FLOAT_MAT4: 35676,
  FLOAT_VEC2: 35664,
  FLOAT_VEC3: 35665,
  FLOAT_VEC4: 35666,
  LINEAR: 9729,
  REPEAT: 10497,
  SAMPLER_2D: 35678,
  POINTS: 0,
  LINES: 1,
  LINE_LOOP: 2,
  LINE_STRIP: 3,
  TRIANGLES: 4,
  TRIANGLE_STRIP: 5,
  TRIANGLE_FAN: 6,
  UNSIGNED_BYTE: 5121,
  UNSIGNED_SHORT: 5123
}, Le = {
  5120: Int8Array,
  5121: Uint8Array,
  5122: Int16Array,
  5123: Uint16Array,
  5125: Uint32Array,
  5126: Float32Array
}, $t = {
  9728: Ts,
  9729: gn,
  9984: As,
  9985: ws,
  9986: xs,
  9987: yn
}, en = {
  33071: vt,
  33648: bs,
  10497: Re
}, ut = {
  SCALAR: 1,
  VEC2: 2,
  VEC3: 3,
  VEC4: 4,
  MAT2: 4,
  MAT3: 9,
  MAT4: 16
}, Rt = {
  POSITION: "position",
  NORMAL: "normal",
  TANGENT: "tangent",
  TEXCOORD_0: "uv",
  TEXCOORD_1: "uv1",
  TEXCOORD_2: "uv2",
  TEXCOORD_3: "uv3",
  COLOR_0: "color",
  WEIGHTS_0: "skinWeight",
  JOINTS_0: "skinIndex"
}, ce = {
  scale: "scale",
  translation: "position",
  rotation: "quaternion",
  weights: "morphTargetInfluences"
}, yi = {
  CUBICSPLINE: void 0,
  // We use a custom interpolant (GLTFCubicSplineInterpolation) for CUBICSPLINE tracks. Each
  // keyframe track will be initialized with a default interpolation type, then modified.
  LINEAR: En,
  STEP: Es
}, ht = {
  OPAQUE: "OPAQUE",
  MASK: "MASK",
  BLEND: "BLEND"
};
function Ti(h) {
  return h.DefaultMaterial === void 0 && (h.DefaultMaterial = new Tn({
    color: 16777215,
    emissive: 0,
    metalness: 1,
    roughness: 1,
    transparent: !1,
    depthTest: !0,
    side: vn
  })), h.DefaultMaterial;
}
function ge(h, e, n) {
  for (const t in n.extensions)
    h[t] === void 0 && (e.userData.gltfExtensions = e.userData.gltfExtensions || {}, e.userData.gltfExtensions[t] = n.extensions[t]);
}
function ue(h, e) {
  e.extras !== void 0 && (typeof e.extras == "object" ? Object.assign(h.userData, e.extras) : console.warn("THREE.GLTFLoader: Ignoring primitive type .extras, " + e.extras));
}
function Ai(h, e, n) {
  let t = !1, s = !1, i = !1;
  for (let c = 0, u = e.length; c < u; c++) {
    const l = e[c];
    if (l.POSITION !== void 0 && (t = !0), l.NORMAL !== void 0 && (s = !0), l.COLOR_0 !== void 0 && (i = !0), t && s && i)
      break;
  }
  if (!t && !s && !i)
    return Promise.resolve(h);
  const r = [], a = [], o = [];
  for (let c = 0, u = e.length; c < u; c++) {
    const l = e[c];
    if (t) {
      const f = l.POSITION !== void 0 ? n.getDependency("accessor", l.POSITION) : h.attributes.position;
      r.push(f);
    }
    if (s) {
      const f = l.NORMAL !== void 0 ? n.getDependency("accessor", l.NORMAL) : h.attributes.normal;
      a.push(f);
    }
    if (i) {
      const f = l.COLOR_0 !== void 0 ? n.getDependency("accessor", l.COLOR_0) : h.attributes.color;
      o.push(f);
    }
  }
  return Promise.all([
    Promise.all(r),
    Promise.all(a),
    Promise.all(o)
  ]).then(function(c) {
    const u = c[0], l = c[1], f = c[2];
    return t && (h.morphAttributes.position = u), s && (h.morphAttributes.normal = l), i && (h.morphAttributes.color = f), h.morphTargetsRelative = !0, h;
  });
}
function wi(h, e) {
  if (h.updateMorphTargets(), e.weights !== void 0)
    for (let n = 0, t = e.weights.length; n < t; n++)
      h.morphTargetInfluences[n] = e.weights[n];
  if (e.extras && Array.isArray(e.extras.targetNames)) {
    const n = e.extras.targetNames;
    if (h.morphTargetInfluences.length === n.length) {
      h.morphTargetDictionary = {};
      for (let t = 0, s = n.length; t < s; t++)
        h.morphTargetDictionary[n[t]] = t;
    } else
      console.warn("THREE.GLTFLoader: Invalid extras.targetNames length. Ignoring names.");
  }
}
function xi(h) {
  let e;
  const n = h.extensions && h.extensions[C.KHR_DRACO_MESH_COMPRESSION];
  if (n ? e = "draco:" + n.bufferView + ":" + n.indices + ":" + ft(n.attributes) : e = h.indices + ":" + ft(h.attributes) + ":" + h.mode, h.targets !== void 0)
    for (let t = 0, s = h.targets.length; t < s; t++)
      e += ":" + ft(h.targets[t]);
  return e;
}
function ft(h) {
  let e = "";
  const n = Object.keys(h).sort();
  for (let t = 0, s = n.length; t < s; t++)
    e += n[t] + ":" + h[n[t]] + ";";
  return e;
}
function St(h) {
  switch (h) {
    case Int8Array:
      return 1 / 127;
    case Uint8Array:
      return 1 / 255;
    case Int16Array:
      return 1 / 32767;
    case Uint16Array:
      return 1 / 65535;
    default:
      throw new Error("THREE.GLTFLoader: Unsupported normalized accessor component type.");
  }
}
function bi(h) {
  return h.search(/\.jpe?g($|\?)/i) > 0 || h.search(/^data\:image\/jpeg/) === 0 ? "image/jpeg" : h.search(/\.webp($|\?)/i) > 0 || h.search(/^data\:image\/webp/) === 0 ? "image/webp" : "image/png";
}
const Ei = new _();
class vi {
  constructor(e = {}, n = {}) {
    this.json = e, this.extensions = {}, this.plugins = {}, this.options = n, this.cache = new Ys(), this.associations = /* @__PURE__ */ new Map(), this.primitiveCache = {}, this.nodeCache = {}, this.meshCache = { refs: {}, uses: {} }, this.cameraCache = { refs: {}, uses: {} }, this.lightCache = { refs: {}, uses: {} }, this.sourceCache = {}, this.textureCache = {}, this.nodeNamesUsed = {};
    let t = !1, s = !1, i = -1;
    typeof navigator < "u" && (t = /^((?!chrome|android).)*safari/i.test(navigator.userAgent) === !0, s = navigator.userAgent.indexOf("Firefox") > -1, i = s ? navigator.userAgent.match(/Firefox\/([0-9]+)\./)[1] : -1), typeof createImageBitmap > "u" || t || s && i < 98 ? this.textureLoader = new Ft(this.options.manager) : this.textureLoader = new ps(this.options.manager), this.textureLoader.setCrossOrigin(this.options.crossOrigin), this.textureLoader.setRequestHeader(this.options.requestHeader), this.fileLoader = new ze(this.options.manager), this.fileLoader.setResponseType("arraybuffer"), this.options.crossOrigin === "use-credentials" && this.fileLoader.setWithCredentials(!0);
  }
  setExtensions(e) {
    this.extensions = e;
  }
  setPlugins(e) {
    this.plugins = e;
  }
  parse(e, n) {
    const t = this, s = this.json, i = this.extensions;
    this.cache.removeAll(), this.nodeCache = {}, this._invokeAll(function(r) {
      return r._markDefs && r._markDefs();
    }), Promise.all(this._invokeAll(function(r) {
      return r.beforeRoot && r.beforeRoot();
    })).then(function() {
      return Promise.all([
        t.getDependencies("scene"),
        t.getDependencies("animation"),
        t.getDependencies("camera")
      ]);
    }).then(function(r) {
      const a = {
        scene: r[0][s.scene || 0],
        scenes: r[0],
        animations: r[1],
        cameras: r[2],
        asset: s.asset,
        parser: t,
        userData: {}
      };
      return ge(i, a, s), ue(a, s), Promise.all(t._invokeAll(function(o) {
        return o.afterRoot && o.afterRoot(a);
      })).then(function() {
        e(a);
      });
    }).catch(n);
  }
  /**
   * Marks the special nodes/meshes in json for efficient parse.
   */
  _markDefs() {
    const e = this.json.nodes || [], n = this.json.skins || [], t = this.json.meshes || [];
    for (let s = 0, i = n.length; s < i; s++) {
      const r = n[s].joints;
      for (let a = 0, o = r.length; a < o; a++)
        e[r[a]].isBone = !0;
    }
    for (let s = 0, i = e.length; s < i; s++) {
      const r = e[s];
      r.mesh !== void 0 && (this._addNodeRef(this.meshCache, r.mesh), r.skin !== void 0 && (t[r.mesh].isSkinnedMesh = !0)), r.camera !== void 0 && this._addNodeRef(this.cameraCache, r.camera);
    }
  }
  /**
   * Counts references to shared node / Object3D resources. These resources
   * can be reused, or "instantiated", at multiple nodes in the scene
   * hierarchy. Mesh, Camera, and Light instances are instantiated and must
   * be marked. Non-scenegraph resources (like Materials, Geometries, and
   * Textures) can be reused directly and are not marked here.
   *
   * Example: CesiumMilkTruck sample model reuses "Wheel" meshes.
   */
  _addNodeRef(e, n) {
    n !== void 0 && (e.refs[n] === void 0 && (e.refs[n] = e.uses[n] = 0), e.refs[n]++);
  }
  /** Returns a reference to a shared resource, cloning it if necessary. */
  _getNodeRef(e, n, t) {
    if (e.refs[n] <= 1)
      return t;
    const s = t.clone(), i = (r, a) => {
      const o = this.associations.get(r);
      o != null && this.associations.set(a, o);
      for (const [c, u] of r.children.entries())
        i(u, a.children[c]);
    };
    return i(t, s), s.name += "_instance_" + e.uses[n]++, s;
  }
  _invokeOne(e) {
    const n = Object.values(this.plugins);
    n.push(this);
    for (let t = 0; t < n.length; t++) {
      const s = e(n[t]);
      if (s)
        return s;
    }
    return null;
  }
  _invokeAll(e) {
    const n = Object.values(this.plugins);
    n.unshift(this);
    const t = [];
    for (let s = 0; s < n.length; s++) {
      const i = e(n[s]);
      i && t.push(i);
    }
    return t;
  }
  /**
   * Requests the specified dependency asynchronously, with caching.
   * @param {string} type
   * @param {number} index
   * @return {Promise<Object3D|Material|THREE.Texture|AnimationClip|ArrayBuffer|Object>}
   */
  getDependency(e, n) {
    const t = e + ":" + n;
    let s = this.cache.get(t);
    if (!s) {
      switch (e) {
        case "scene":
          s = this.loadScene(n);
          break;
        case "node":
          s = this._invokeOne(function(i) {
            return i.loadNode && i.loadNode(n);
          });
          break;
        case "mesh":
          s = this._invokeOne(function(i) {
            return i.loadMesh && i.loadMesh(n);
          });
          break;
        case "accessor":
          s = this.loadAccessor(n);
          break;
        case "bufferView":
          s = this._invokeOne(function(i) {
            return i.loadBufferView && i.loadBufferView(n);
          });
          break;
        case "buffer":
          s = this.loadBuffer(n);
          break;
        case "material":
          s = this._invokeOne(function(i) {
            return i.loadMaterial && i.loadMaterial(n);
          });
          break;
        case "texture":
          s = this._invokeOne(function(i) {
            return i.loadTexture && i.loadTexture(n);
          });
          break;
        case "skin":
          s = this.loadSkin(n);
          break;
        case "animation":
          s = this._invokeOne(function(i) {
            return i.loadAnimation && i.loadAnimation(n);
          });
          break;
        case "camera":
          s = this.loadCamera(n);
          break;
        default:
          if (s = this._invokeOne(function(i) {
            return i != this && i.getDependency && i.getDependency(e, n);
          }), !s)
            throw new Error("Unknown type: " + e);
          break;
      }
      this.cache.add(t, s);
    }
    return s;
  }
  /**
   * Requests all dependencies of the specified type asynchronously, with caching.
   * @param {string} type
   * @return {Promise<Array<Object>>}
   */
  getDependencies(e) {
    let n = this.cache.get(e);
    if (!n) {
      const t = this, s = this.json[e + (e === "mesh" ? "es" : "s")] || [];
      n = Promise.all(s.map(function(i, r) {
        return t.getDependency(e, r);
      })), this.cache.add(e, n);
    }
    return n;
  }
  /**
   * Specification: https://github.com/KhronosGroup/glTF/blob/master/specification/2.0/README.md#buffers-and-buffer-views
   * @param {number} bufferIndex
   * @return {Promise<ArrayBuffer>}
   */
  loadBuffer(e) {
    const n = this.json.buffers[e], t = this.fileLoader;
    if (n.type && n.type !== "arraybuffer")
      throw new Error("THREE.GLTFLoader: " + n.type + " buffer type is not supported.");
    if (n.uri === void 0 && e === 0)
      return Promise.resolve(this.extensions[C.KHR_BINARY_GLTF].body);
    const s = this.options;
    return new Promise(function(i, r) {
      t.load(ye.resolveURL(n.uri, s.path), i, void 0, function() {
        r(new Error('THREE.GLTFLoader: Failed to load buffer "' + n.uri + '".'));
      });
    });
  }
  /**
   * Specification: https://github.com/KhronosGroup/glTF/blob/master/specification/2.0/README.md#buffers-and-buffer-views
   * @param {number} bufferViewIndex
   * @return {Promise<ArrayBuffer>}
   */
  loadBufferView(e) {
    const n = this.json.bufferViews[e];
    return this.getDependency("buffer", n.buffer).then(function(t) {
      const s = n.byteLength || 0, i = n.byteOffset || 0;
      return t.slice(i, i + s);
    });
  }
  /**
   * Specification: https://github.com/KhronosGroup/glTF/blob/master/specification/2.0/README.md#accessors
   * @param {number} accessorIndex
   * @return {Promise<BufferAttribute|InterleavedBufferAttribute>}
   */
  loadAccessor(e) {
    const n = this, t = this.json, s = this.json.accessors[e];
    if (s.bufferView === void 0 && s.sparse === void 0) {
      const r = ut[s.type], a = Le[s.componentType], o = s.normalized === !0, c = new a(s.count * r);
      return Promise.resolve(new lt(c, r, o));
    }
    const i = [];
    return s.bufferView !== void 0 ? i.push(this.getDependency("bufferView", s.bufferView)) : i.push(null), s.sparse !== void 0 && (i.push(this.getDependency("bufferView", s.sparse.indices.bufferView)), i.push(this.getDependency("bufferView", s.sparse.values.bufferView))), Promise.all(i).then(function(r) {
      const a = r[0], o = ut[s.type], c = Le[s.componentType], u = c.BYTES_PER_ELEMENT, l = u * o, f = s.byteOffset || 0, p = s.bufferView !== void 0 ? t.bufferViews[s.bufferView].byteStride : void 0, m = s.normalized === !0;
      let y, g;
      if (p && p !== l) {
        const T = Math.floor(f / p), w = "InterleavedBuffer:" + s.bufferView + ":" + s.componentType + ":" + T + ":" + s.count;
        let A = n.cache.get(w);
        A || (y = new c(a, T * p, s.count * p / u), A = new ds(y, p / u), n.cache.add(w, A)), g = new ms(A, o, f % p / u, m);
      } else
        a === null ? y = new c(s.count * o) : y = new c(a, f, s.count * o), g = new lt(y, o, m);
      if (s.sparse !== void 0) {
        const T = ut.SCALAR, w = Le[s.sparse.indices.componentType], A = s.sparse.indices.byteOffset || 0, x = s.sparse.values.byteOffset || 0, S = new w(r[1], A, s.sparse.count * T), E = new c(r[2], x, s.sparse.count * o);
        a !== null && (g = new lt(g.array.slice(), g.itemSize, g.normalized));
        for (let v = 0, P = S.length; v < P; v++) {
          const B = S[v];
          if (g.setX(B, E[v * o]), o >= 2 && g.setY(B, E[v * o + 1]), o >= 3 && g.setZ(B, E[v * o + 2]), o >= 4 && g.setW(B, E[v * o + 3]), o >= 5)
            throw new Error("THREE.GLTFLoader: Unsupported itemSize in sparse BufferAttribute.");
        }
      }
      return g;
    });
  }
  /**
   * Specification: https://github.com/KhronosGroup/glTF/tree/master/specification/2.0#textures
   * @param {number} textureIndex
   * @return {Promise<THREE.Texture|null>}
   */
  loadTexture(e) {
    const n = this.json, t = this.options, i = n.textures[e].source, r = n.images[i];
    let a = this.textureLoader;
    if (r.uri) {
      const o = t.manager.getHandler(r.uri);
      o !== null && (a = o);
    }
    return this.loadTextureImage(e, i, a);
  }
  loadTextureImage(e, n, t) {
    const s = this, i = this.json, r = i.textures[e], a = i.images[n], o = (a.uri || a.bufferView) + ":" + r.sampler;
    if (this.textureCache[o])
      return this.textureCache[o];
    const c = this.loadImageSource(n, t).then(function(u) {
      u.flipY = !1, u.name = r.name || a.name || "", u.name === "" && typeof a.uri == "string" && a.uri.startsWith("data:image/") === !1 && (u.name = a.uri);
      const f = (i.samplers || {})[r.sampler] || {};
      return u.magFilter = $t[f.magFilter] || gn, u.minFilter = $t[f.minFilter] || yn, u.wrapS = en[f.wrapS] || Re, u.wrapT = en[f.wrapT] || Re, s.associations.set(u, { textures: e }), u;
    }).catch(function() {
      return null;
    });
    return this.textureCache[o] = c, c;
  }
  loadImageSource(e, n) {
    const t = this, s = this.json, i = this.options;
    if (this.sourceCache[e] !== void 0)
      return this.sourceCache[e].then((l) => l.clone());
    const r = s.images[e], a = self.URL || self.webkitURL;
    let o = r.uri || "", c = !1;
    if (r.bufferView !== void 0)
      o = t.getDependency("bufferView", r.bufferView).then(function(l) {
        c = !0;
        const f = new Blob([l], { type: r.mimeType });
        return o = a.createObjectURL(f), o;
      });
    else if (r.uri === void 0)
      throw new Error("THREE.GLTFLoader: Image " + e + " is missing URI and bufferView");
    const u = Promise.resolve(o).then(function(l) {
      return new Promise(function(f, p) {
        let m = f;
        n.isImageBitmapLoader === !0 && (m = function(y) {
          const g = new Ge(y);
          g.needsUpdate = !0, f(g);
        }), n.load(ye.resolveURL(l, i.path), m, void 0, p);
      });
    }).then(function(l) {
      return c === !0 && a.revokeObjectURL(o), l.userData.mimeType = r.mimeType || bi(r.uri), l;
    }).catch(function(l) {
      throw console.error("THREE.GLTFLoader: Couldn't load texture", o), l;
    });
    return this.sourceCache[e] = u, u;
  }
  /**
   * Asynchronously assigns a texture to the given material parameters.
   * @param {Object} materialParams
   * @param {string} mapName
   * @param {Object} mapDef
   * @return {Promise<Texture>}
   */
  assignTexture(e, n, t, s) {
    const i = this;
    return this.getDependency("texture", t.index).then(function(r) {
      if (!r)
        return null;
      if (t.texCoord !== void 0 && t.texCoord > 0 && (r = r.clone(), r.channel = t.texCoord), i.extensions[C.KHR_TEXTURE_TRANSFORM]) {
        const a = t.extensions !== void 0 ? t.extensions[C.KHR_TEXTURE_TRANSFORM] : void 0;
        if (a) {
          const o = i.associations.get(r);
          r = i.extensions[C.KHR_TEXTURE_TRANSFORM].extendTexture(r, a), i.associations.set(r, o);
        }
      }
      return s !== void 0 && (r.colorSpace = s), e[n] = r, r;
    });
  }
  /**
   * Assigns final material to a Mesh, Line, or Points instance. The instance
   * already has a material (generated from the glTF material options alone)
   * but reuse of the same glTF material may require multiple threejs materials
   * to accommodate different primitive types, defines, etc. New materials will
   * be created if necessary, and reused from a cache.
   * @param  {Object3D} mesh Mesh, Line, or Points instance.
   */
  assignFinalMaterial(e) {
    const n = e.geometry;
    let t = e.material;
    const s = n.attributes.tangent === void 0, i = n.attributes.color !== void 0, r = n.attributes.normal === void 0;
    if (e.isPoints) {
      const a = "PointsMaterial:" + t.uuid;
      let o = this.cache.get(a);
      o || (o = new Ne(), Be.prototype.copy.call(o, t), o.color.copy(t.color), o.map = t.map, o.sizeAttenuation = !1, this.cache.add(a, o)), t = o;
    } else if (e.isLine) {
      const a = "LineBasicMaterial:" + t.uuid;
      let o = this.cache.get(a);
      o || (o = new je(), Be.prototype.copy.call(o, t), o.color.copy(t.color), o.map = t.map, this.cache.add(a, o)), t = o;
    }
    if (s || i || r) {
      let a = "ClonedMaterial:" + t.uuid + ":";
      s && (a += "derivative-tangents:"), i && (a += "vertex-colors:"), r && (a += "flat-shading:");
      let o = this.cache.get(a);
      o || (o = t.clone(), i && (o.vertexColors = !0), r && (o.flatShading = !0), s && (o.normalScale && (o.normalScale.y *= -1), o.clearcoatNormalScale && (o.clearcoatNormalScale.y *= -1)), this.cache.add(a, o), this.associations.set(o, this.associations.get(t))), t = o;
    }
    e.material = t;
  }
  getMaterialType() {
    return Tn;
  }
  /**
   * Specification: https://github.com/KhronosGroup/glTF/blob/master/specification/2.0/README.md#materials
   * @param {number} materialIndex
   * @return {Promise<Material>}
   */
  loadMaterial(e) {
    const n = this, t = this.json, s = this.extensions, i = t.materials[e];
    let r;
    const a = {}, o = i.extensions || {}, c = [];
    if (o[C.KHR_MATERIALS_UNLIT]) {
      const l = s[C.KHR_MATERIALS_UNLIT];
      r = l.getMaterialType(), c.push(l.extendParams(a, i, n));
    } else {
      const l = i.pbrMetallicRoughness || {};
      if (a.color = new D(1, 1, 1), a.opacity = 1, Array.isArray(l.baseColorFactor)) {
        const f = l.baseColorFactor;
        a.color.setRGB(f[0], f[1], f[2], re), a.opacity = f[3];
      }
      l.baseColorTexture !== void 0 && c.push(n.assignTexture(a, "map", l.baseColorTexture, $)), a.metalness = l.metallicFactor !== void 0 ? l.metallicFactor : 1, a.roughness = l.roughnessFactor !== void 0 ? l.roughnessFactor : 1, l.metallicRoughnessTexture !== void 0 && (c.push(n.assignTexture(a, "metalnessMap", l.metallicRoughnessTexture)), c.push(n.assignTexture(a, "roughnessMap", l.metallicRoughnessTexture))), r = this._invokeOne(function(f) {
        return f.getMaterialType && f.getMaterialType(e);
      }), c.push(Promise.all(this._invokeAll(function(f) {
        return f.extendMaterialParams && f.extendMaterialParams(e, a);
      })));
    }
    i.doubleSided === !0 && (a.side = gs);
    const u = i.alphaMode || ht.OPAQUE;
    if (u === ht.BLEND ? (a.transparent = !0, a.depthWrite = !1) : (a.transparent = !1, u === ht.MASK && (a.alphaTest = i.alphaCutoff !== void 0 ? i.alphaCutoff : 0.5)), i.normalTexture !== void 0 && r !== ke && (c.push(n.assignTexture(a, "normalMap", i.normalTexture)), a.normalScale = new G(1, 1), i.normalTexture.scale !== void 0)) {
      const l = i.normalTexture.scale;
      a.normalScale.set(l, l);
    }
    if (i.occlusionTexture !== void 0 && r !== ke && (c.push(n.assignTexture(a, "aoMap", i.occlusionTexture)), i.occlusionTexture.strength !== void 0 && (a.aoMapIntensity = i.occlusionTexture.strength)), i.emissiveFactor !== void 0 && r !== ke) {
      const l = i.emissiveFactor;
      a.emissive = new D().setRGB(l[0], l[1], l[2], re);
    }
    return i.emissiveTexture !== void 0 && r !== ke && c.push(n.assignTexture(a, "emissiveMap", i.emissiveTexture, $)), Promise.all(c).then(function() {
      const l = new r(a);
      return i.name && (l.name = i.name), ue(l, i), n.associations.set(l, { materials: e }), i.extensions && ge(s, l, i), l;
    });
  }
  /** When Object3D instances are targeted by animation, they need unique names. */
  createUniqueName(e) {
    const n = Ve.sanitizeNodeName(e || "");
    return n in this.nodeNamesUsed ? n + "_" + ++this.nodeNamesUsed[n] : (this.nodeNamesUsed[n] = 0, n);
  }
  /**
   * Specification: https://github.com/KhronosGroup/glTF/blob/master/specification/2.0/README.md#geometry
   *
   * Creates BufferGeometries from primitives.
   *
   * @param {Array<GLTF.Primitive>} primitives
   * @return {Promise<Array<BufferGeometry>>}
   */
  loadGeometries(e) {
    const n = this, t = this.extensions, s = this.primitiveCache;
    function i(a) {
      return t[C.KHR_DRACO_MESH_COMPRESSION].decodePrimitive(a, n).then(function(o) {
        return tn(o, a, n);
      });
    }
    const r = [];
    for (let a = 0, o = e.length; a < o; a++) {
      const c = e[a], u = xi(c), l = s[u];
      if (l)
        r.push(l.promise);
      else {
        let f;
        c.extensions && c.extensions[C.KHR_DRACO_MESH_COMPRESSION] ? f = i(c) : f = tn(new ve(), c, n), s[u] = { primitive: c, promise: f }, r.push(f);
      }
    }
    return Promise.all(r);
  }
  /**
   * Specification: https://github.com/KhronosGroup/glTF/blob/master/specification/2.0/README.md#meshes
   * @param {number} meshIndex
   * @return {Promise<Group|Mesh|SkinnedMesh>}
   */
  loadMesh(e) {
    const n = this, t = this.json, s = this.extensions, i = t.meshes[e], r = i.primitives, a = [];
    for (let o = 0, c = r.length; o < c; o++) {
      const u = r[o].material === void 0 ? Ti(this.cache) : this.getDependency("material", r[o].material);
      a.push(u);
    }
    return a.push(n.loadGeometries(r)), Promise.all(a).then(function(o) {
      const c = o.slice(0, o.length - 1), u = o[o.length - 1], l = [];
      for (let p = 0, m = u.length; p < m; p++) {
        const y = u[p], g = r[p];
        let T;
        const w = c[p];
        if (g.mode === Y.TRIANGLES || g.mode === Y.TRIANGLE_STRIP || g.mode === Y.TRIANGLE_FAN || g.mode === void 0)
          T = i.isSkinnedMesh === !0 ? new An(y, w) : new it(y, w), T.isSkinnedMesh === !0 && T.normalizeSkinWeights(), g.mode === Y.TRIANGLE_STRIP ? T.geometry = Qt(T.geometry, dn) : g.mode === Y.TRIANGLE_FAN && (T.geometry = Qt(T.geometry, wt));
        else if (g.mode === Y.LINES)
          T = new bt(y, w);
        else if (g.mode === Y.LINE_STRIP)
          T = new wn(y, w);
        else if (g.mode === Y.LINE_LOOP)
          T = new ys(y, w);
        else if (g.mode === Y.POINTS)
          T = new nt(y, w);
        else
          throw new Error("THREE.GLTFLoader: Primitive mode unsupported: " + g.mode);
        Object.keys(T.geometry.morphAttributes).length > 0 && wi(T, i), T.name = n.createUniqueName(i.name || "mesh_" + e), ue(T, i), g.extensions && ge(s, T, g), n.assignFinalMaterial(T), l.push(T);
      }
      for (let p = 0, m = l.length; p < m; p++)
        n.associations.set(l[p], {
          meshes: e,
          primitives: p
        });
      if (l.length === 1)
        return i.extensions && ge(s, l[0], i), l[0];
      const f = new fe();
      i.extensions && ge(s, f, i), n.associations.set(f, { meshes: e });
      for (let p = 0, m = l.length; p < m; p++)
        f.add(l[p]);
      return f;
    });
  }
  /**
   * Specification: https://github.com/KhronosGroup/glTF/tree/master/specification/2.0#cameras
   * @param {number} cameraIndex
   * @return {Promise<THREE.Camera>}
   */
  loadCamera(e) {
    let n;
    const t = this.json.cameras[e], s = t[t.type];
    if (!s) {
      console.warn("THREE.GLTFLoader: Missing camera parameters.");
      return;
    }
    return t.type === "perspective" ? n = new Pt(j.radToDeg(s.yfov), s.aspectRatio || 1, s.znear || 1, s.zfar || 2e6) : t.type === "orthographic" && (n = new xn(-s.xmag, s.xmag, s.ymag, -s.ymag, s.znear, s.zfar)), t.name && (n.name = this.createUniqueName(t.name)), ue(n, t), Promise.resolve(n);
  }
  /**
   * Specification: https://github.com/KhronosGroup/glTF/tree/master/specification/2.0#skins
   * @param {number} skinIndex
   * @return {Promise<Skeleton>}
   */
  loadSkin(e) {
    const n = this.json.skins[e], t = [];
    for (let s = 0, i = n.joints.length; s < i; s++)
      t.push(this._loadNodeShallow(n.joints[s]));
    return n.inverseBindMatrices !== void 0 ? t.push(this.getDependency("accessor", n.inverseBindMatrices)) : t.push(null), Promise.all(t).then(function(s) {
      const i = s.pop(), r = s, a = [], o = [];
      for (let c = 0, u = r.length; c < u; c++) {
        const l = r[c];
        if (l) {
          a.push(l);
          const f = new _();
          i !== null && f.fromArray(i.array, c * 16), o.push(f);
        } else
          console.warn('THREE.GLTFLoader: Joint "%s" could not be found.', n.joints[c]);
      }
      return new bn(a, o);
    });
  }
  /**
   * Specification: https://github.com/KhronosGroup/glTF/tree/master/specification/2.0#animations
   * @param {number} animationIndex
   * @return {Promise<AnimationClip>}
   */
  loadAnimation(e) {
    const n = this.json, t = this, s = n.animations[e], i = s.name ? s.name : "animation_" + e, r = [], a = [], o = [], c = [], u = [];
    for (let l = 0, f = s.channels.length; l < f; l++) {
      const p = s.channels[l], m = s.samplers[p.sampler], y = p.target, g = y.node, T = s.parameters !== void 0 ? s.parameters[m.input] : m.input, w = s.parameters !== void 0 ? s.parameters[m.output] : m.output;
      y.node !== void 0 && (r.push(this.getDependency("node", g)), a.push(this.getDependency("accessor", T)), o.push(this.getDependency("accessor", w)), c.push(m), u.push(y));
    }
    return Promise.all([
      Promise.all(r),
      Promise.all(a),
      Promise.all(o),
      Promise.all(c),
      Promise.all(u)
    ]).then(function(l) {
      const f = l[0], p = l[1], m = l[2], y = l[3], g = l[4], T = [];
      for (let w = 0, A = f.length; w < A; w++) {
        const x = f[w], S = p[w], E = m[w], v = y[w], P = g[w];
        if (x === void 0)
          continue;
        x.updateMatrix && x.updateMatrix();
        const B = t._createAnimationTracks(x, S, E, v, P);
        if (B)
          for (let k = 0; k < B.length; k++)
            T.push(B[k]);
      }
      return new _t(i, void 0, T);
    });
  }
  createNodeMesh(e) {
    const n = this.json, t = this, s = n.nodes[e];
    return s.mesh === void 0 ? null : t.getDependency("mesh", s.mesh).then(function(i) {
      const r = t._getNodeRef(t.meshCache, s.mesh, i);
      return s.weights !== void 0 && r.traverse(function(a) {
        if (a.isMesh)
          for (let o = 0, c = s.weights.length; o < c; o++)
            a.morphTargetInfluences[o] = s.weights[o];
      }), r;
    });
  }
  /**
   * Specification: https://github.com/KhronosGroup/glTF/tree/master/specification/2.0#nodes-and-hierarchy
   * @param {number} nodeIndex
   * @return {Promise<Object3D>}
   */
  loadNode(e) {
    const n = this.json, t = this, s = n.nodes[e], i = t._loadNodeShallow(e), r = [], a = s.children || [];
    for (let c = 0, u = a.length; c < u; c++)
      r.push(t.getDependency("node", a[c]));
    const o = s.skin === void 0 ? Promise.resolve(null) : t.getDependency("skin", s.skin);
    return Promise.all([
      i,
      Promise.all(r),
      o
    ]).then(function(c) {
      const u = c[0], l = c[1], f = c[2];
      f !== null && u.traverse(function(p) {
        p.isSkinnedMesh && p.bind(f, Ei);
      });
      for (let p = 0, m = l.length; p < m; p++)
        u.add(l[p]);
      return u;
    });
  }
  // ._loadNodeShallow() parses a single node.
  // skin and child nodes are created and added in .loadNode() (no '_' prefix).
  _loadNodeShallow(e) {
    const n = this.json, t = this.extensions, s = this;
    if (this.nodeCache[e] !== void 0)
      return this.nodeCache[e];
    const i = n.nodes[e], r = i.name ? s.createUniqueName(i.name) : "", a = [], o = s._invokeOne(function(c) {
      return c.createNodeMesh && c.createNodeMesh(e);
    });
    return o && a.push(o), i.camera !== void 0 && a.push(s.getDependency("camera", i.camera).then(function(c) {
      return s._getNodeRef(s.cameraCache, i.camera, c);
    })), s._invokeAll(function(c) {
      return c.createNodeAttachment && c.createNodeAttachment(e);
    }).forEach(function(c) {
      a.push(c);
    }), this.nodeCache[e] = Promise.all(a).then(function(c) {
      let u;
      if (i.isBone === !0 ? u = new Et() : c.length > 1 ? u = new fe() : c.length === 1 ? u = c[0] : u = new Ee(), u !== c[0])
        for (let l = 0, f = c.length; l < f; l++)
          u.add(c[l]);
      if (i.name && (u.userData.name = i.name, u.name = r), ue(u, i), i.extensions && ge(t, u, i), i.matrix !== void 0) {
        const l = new _();
        l.fromArray(i.matrix), u.applyMatrix4(l);
      } else
        i.translation !== void 0 && u.position.fromArray(i.translation), i.rotation !== void 0 && u.quaternion.fromArray(i.rotation), i.scale !== void 0 && u.scale.fromArray(i.scale);
      return s.associations.has(u) || s.associations.set(u, {}), s.associations.get(u).nodes = e, u;
    }), this.nodeCache[e];
  }
  /**
   * Specification: https://github.com/KhronosGroup/glTF/tree/master/specification/2.0#scenes
   * @param {number} sceneIndex
   * @return {Promise<Group>}
   */
  loadScene(e) {
    const n = this.extensions, t = this.json.scenes[e], s = this, i = new fe();
    t.name && (i.name = s.createUniqueName(t.name)), ue(i, t), t.extensions && ge(n, i, t);
    const r = t.nodes || [], a = [];
    for (let o = 0, c = r.length; o < c; o++)
      a.push(s.getDependency("node", r[o]));
    return Promise.all(a).then(function(o) {
      for (let u = 0, l = o.length; u < l; u++)
        i.add(o[u]);
      const c = (u) => {
        const l = /* @__PURE__ */ new Map();
        for (const [f, p] of s.associations)
          (f instanceof Be || f instanceof Ge) && l.set(f, p);
        return u.traverse((f) => {
          const p = s.associations.get(f);
          p != null && l.set(f, p);
        }), l;
      };
      return s.associations = c(i), i;
    });
  }
  _createAnimationTracks(e, n, t, s, i) {
    const r = [], a = e.name ? e.name : e.uuid, o = [];
    ce[i.path] === ce.weights ? e.traverse(function(f) {
      f.morphTargetInfluences && o.push(f.name ? f.name : f.uuid);
    }) : o.push(a);
    let c;
    switch (ce[i.path]) {
      case ce.weights:
        c = Mt;
        break;
      case ce.rotation:
        c = rt;
        break;
      case ce.position:
      case ce.scale:
        c = Lt;
        break;
      default:
        switch (t.itemSize) {
          case 1:
            c = Mt;
            break;
          case 2:
          case 3:
          default:
            c = Lt;
            break;
        }
        break;
    }
    const u = s.interpolation !== void 0 ? yi[s.interpolation] : En, l = this._getArrayFromAccessor(t);
    for (let f = 0, p = o.length; f < p; f++) {
      const m = new c(
        o[f] + "." + ce[i.path],
        n.array,
        l,
        u
      );
      s.interpolation === "CUBICSPLINE" && this._createCubicSplineTrackInterpolant(m), r.push(m);
    }
    return r;
  }
  _getArrayFromAccessor(e) {
    let n = e.array;
    if (e.normalized) {
      const t = St(n.constructor), s = new Float32Array(n.length);
      for (let i = 0, r = n.length; i < r; i++)
        s[i] = n[i] * t;
      n = s;
    }
    return n;
  }
  _createCubicSplineTrackInterpolant(e) {
    e.createInterpolant = function(t) {
      const s = this instanceof rt ? gi : Rn;
      return new s(this.times, this.values, this.getValueSize() / 3, t);
    }, e.createInterpolant.isInterpolantFactoryMethodGLTFCubicSpline = !0;
  }
}
function Li(h, e, n) {
  const t = e.attributes, s = new vs();
  if (t.POSITION !== void 0) {
    const a = n.json.accessors[t.POSITION], o = a.min, c = a.max;
    if (o !== void 0 && c !== void 0) {
      if (s.set(
        new R(o[0], o[1], o[2]),
        new R(c[0], c[1], c[2])
      ), a.normalized) {
        const u = St(Le[a.componentType]);
        s.min.multiplyScalar(u), s.max.multiplyScalar(u);
      }
    } else {
      console.warn("THREE.GLTFLoader: Missing min/max properties for accessor POSITION.");
      return;
    }
  } else
    return;
  const i = e.targets;
  if (i !== void 0) {
    const a = new R(), o = new R();
    for (let c = 0, u = i.length; c < u; c++) {
      const l = i[c];
      if (l.POSITION !== void 0) {
        const f = n.json.accessors[l.POSITION], p = f.min, m = f.max;
        if (p !== void 0 && m !== void 0) {
          if (o.setX(Math.max(Math.abs(p[0]), Math.abs(m[0]))), o.setY(Math.max(Math.abs(p[1]), Math.abs(m[1]))), o.setZ(Math.max(Math.abs(p[2]), Math.abs(m[2]))), f.normalized) {
            const y = St(Le[f.componentType]);
            o.multiplyScalar(y);
          }
          a.max(o);
        } else
          console.warn("THREE.GLTFLoader: Missing min/max properties for accessor POSITION.");
      }
    }
    s.expandByVector(a);
  }
  h.boundingBox = s;
  const r = new Ls();
  s.getCenter(r.center), r.radius = s.min.distanceTo(s.max) / 2, h.boundingSphere = r;
}
function tn(h, e, n) {
  const t = e.attributes, s = [];
  function i(r, a) {
    return n.getDependency("accessor", r).then(function(o) {
      h.setAttribute(a, o);
    });
  }
  for (const r in t) {
    const a = Rt[r] || r.toLowerCase();
    a in h.attributes || s.push(i(t[r], a));
  }
  if (e.indices !== void 0 && !h.index) {
    const r = n.getDependency("accessor", e.indices).then(function(a) {
      h.setIndex(a);
    });
    s.push(r);
  }
  return qt.workingColorSpace !== re && "COLOR_0" in t && console.warn(`THREE.GLTFLoader: Converting vertex colors from "srgb-linear" to "${qt.workingColorSpace}" not supported.`), ue(h, e), Li(h, e, n), Promise.all(s).then(function() {
    return e.targets !== void 0 ? Ai(h, e.targets, n) : h;
  });
}
const Mi = /^[og]\s*(.+)?/, Ri = /^mtllib /, Si = /^usemtl /, Ii = /^usemap /, nn = /\s+/, sn = new R(), pt = new R(), rn = new R(), on = new R(), X = new R(), $e = new D();
function Ci() {
  const h = {
    objects: [],
    object: {},
    vertices: [],
    normals: [],
    colors: [],
    uvs: [],
    materials: {},
    materialLibraries: [],
    startObject: function(e, n) {
      if (this.object && this.object.fromDeclaration === !1) {
        this.object.name = e, this.object.fromDeclaration = n !== !1;
        return;
      }
      const t = this.object && typeof this.object.currentMaterial == "function" ? this.object.currentMaterial() : void 0;
      if (this.object && typeof this.object._finalize == "function" && this.object._finalize(!0), this.object = {
        name: e || "",
        fromDeclaration: n !== !1,
        geometry: {
          vertices: [],
          normals: [],
          colors: [],
          uvs: [],
          hasUVIndices: !1
        },
        materials: [],
        smooth: !0,
        startMaterial: function(s, i) {
          const r = this._finalize(!1);
          r && (r.inherited || r.groupCount <= 0) && this.materials.splice(r.index, 1);
          const a = {
            index: this.materials.length,
            name: s || "",
            mtllib: Array.isArray(i) && i.length > 0 ? i[i.length - 1] : "",
            smooth: r !== void 0 ? r.smooth : this.smooth,
            groupStart: r !== void 0 ? r.groupEnd : 0,
            groupEnd: -1,
            groupCount: -1,
            inherited: !1,
            clone: function(o) {
              const c = {
                index: typeof o == "number" ? o : this.index,
                name: this.name,
                mtllib: this.mtllib,
                smooth: this.smooth,
                groupStart: 0,
                groupEnd: -1,
                groupCount: -1,
                inherited: !1
              };
              return c.clone = this.clone.bind(c), c;
            }
          };
          return this.materials.push(a), a;
        },
        currentMaterial: function() {
          if (this.materials.length > 0)
            return this.materials[this.materials.length - 1];
        },
        _finalize: function(s) {
          const i = this.currentMaterial();
          if (i && i.groupEnd === -1 && (i.groupEnd = this.geometry.vertices.length / 3, i.groupCount = i.groupEnd - i.groupStart, i.inherited = !1), s && this.materials.length > 1)
            for (let r = this.materials.length - 1; r >= 0; r--)
              this.materials[r].groupCount <= 0 && this.materials.splice(r, 1);
          return s && this.materials.length === 0 && this.materials.push({
            name: "",
            smooth: this.smooth
          }), i;
        }
      }, t && t.name && typeof t.clone == "function") {
        const s = t.clone(0);
        s.inherited = !0, this.object.materials.push(s);
      }
      this.objects.push(this.object);
    },
    finalize: function() {
      this.object && typeof this.object._finalize == "function" && this.object._finalize(!0);
    },
    parseVertexIndex: function(e, n) {
      const t = parseInt(e, 10);
      return (t >= 0 ? t - 1 : t + n / 3) * 3;
    },
    parseNormalIndex: function(e, n) {
      const t = parseInt(e, 10);
      return (t >= 0 ? t - 1 : t + n / 3) * 3;
    },
    parseUVIndex: function(e, n) {
      const t = parseInt(e, 10);
      return (t >= 0 ? t - 1 : t + n / 2) * 2;
    },
    addVertex: function(e, n, t) {
      const s = this.vertices, i = this.object.geometry.vertices;
      i.push(s[e + 0], s[e + 1], s[e + 2]), i.push(s[n + 0], s[n + 1], s[n + 2]), i.push(s[t + 0], s[t + 1], s[t + 2]);
    },
    addVertexPoint: function(e) {
      const n = this.vertices;
      this.object.geometry.vertices.push(n[e + 0], n[e + 1], n[e + 2]);
    },
    addVertexLine: function(e) {
      const n = this.vertices;
      this.object.geometry.vertices.push(n[e + 0], n[e + 1], n[e + 2]);
    },
    addNormal: function(e, n, t) {
      const s = this.normals, i = this.object.geometry.normals;
      i.push(s[e + 0], s[e + 1], s[e + 2]), i.push(s[n + 0], s[n + 1], s[n + 2]), i.push(s[t + 0], s[t + 1], s[t + 2]);
    },
    addFaceNormal: function(e, n, t) {
      const s = this.vertices, i = this.object.geometry.normals;
      sn.fromArray(s, e), pt.fromArray(s, n), rn.fromArray(s, t), X.subVectors(rn, pt), on.subVectors(sn, pt), X.cross(on), X.normalize(), i.push(X.x, X.y, X.z), i.push(X.x, X.y, X.z), i.push(X.x, X.y, X.z);
    },
    addColor: function(e, n, t) {
      const s = this.colors, i = this.object.geometry.colors;
      s[e] !== void 0 && i.push(s[e + 0], s[e + 1], s[e + 2]), s[n] !== void 0 && i.push(s[n + 0], s[n + 1], s[n + 2]), s[t] !== void 0 && i.push(s[t + 0], s[t + 1], s[t + 2]);
    },
    addUV: function(e, n, t) {
      const s = this.uvs, i = this.object.geometry.uvs;
      i.push(s[e + 0], s[e + 1]), i.push(s[n + 0], s[n + 1]), i.push(s[t + 0], s[t + 1]);
    },
    addDefaultUV: function() {
      const e = this.object.geometry.uvs;
      e.push(0, 0), e.push(0, 0), e.push(0, 0);
    },
    addUVLine: function(e) {
      const n = this.uvs;
      this.object.geometry.uvs.push(n[e + 0], n[e + 1]);
    },
    addFace: function(e, n, t, s, i, r, a, o, c) {
      const u = this.vertices.length;
      let l = this.parseVertexIndex(e, u), f = this.parseVertexIndex(n, u), p = this.parseVertexIndex(t, u);
      if (this.addVertex(l, f, p), this.addColor(l, f, p), a !== void 0 && a !== "") {
        const m = this.normals.length;
        l = this.parseNormalIndex(a, m), f = this.parseNormalIndex(o, m), p = this.parseNormalIndex(c, m), this.addNormal(l, f, p);
      } else
        this.addFaceNormal(l, f, p);
      if (s !== void 0 && s !== "") {
        const m = this.uvs.length;
        l = this.parseUVIndex(s, m), f = this.parseUVIndex(i, m), p = this.parseUVIndex(r, m), this.addUV(l, f, p), this.object.geometry.hasUVIndices = !0;
      } else
        this.addDefaultUV();
    },
    addPointGeometry: function(e) {
      this.object.geometry.type = "Points";
      const n = this.vertices.length;
      for (let t = 0, s = e.length; t < s; t++) {
        const i = this.parseVertexIndex(e[t], n);
        this.addVertexPoint(i), this.addColor(i);
      }
    },
    addLineGeometry: function(e, n) {
      this.object.geometry.type = "Line";
      const t = this.vertices.length, s = this.uvs.length;
      for (let i = 0, r = e.length; i < r; i++)
        this.addVertexLine(this.parseVertexIndex(e[i], t));
      for (let i = 0, r = n.length; i < r; i++)
        this.addUVLine(this.parseUVIndex(n[i], s));
    }
  };
  return h.startObject("", !1), h;
}
class Pi extends Me {
  constructor(e) {
    super(e), this.materials = null;
  }
  load(e, n, t, s) {
    const i = this, r = new ze(this.manager);
    r.setPath(this.path), r.setRequestHeader(this.requestHeader), r.setWithCredentials(this.withCredentials), r.load(e, function(a) {
      try {
        n(i.parse(a));
      } catch (o) {
        s ? s(o) : console.error(o), i.manager.itemError(e);
      }
    }, t, s);
  }
  setMaterials(e) {
    return this.materials = e, this;
  }
  parse(e) {
    const n = new Ci();
    e.indexOf(`\r
`) !== -1 && (e = e.replace(/\r\n/g, `
`)), e.indexOf(`\\
`) !== -1 && (e = e.replace(/\\\n/g, ""));
    const t = e.split(`
`);
    let s = [];
    for (let a = 0, o = t.length; a < o; a++) {
      const c = t[a].trimStart();
      if (c.length === 0)
        continue;
      const u = c.charAt(0);
      if (u !== "#")
        if (u === "v") {
          const l = c.split(nn);
          switch (l[0]) {
            case "v":
              n.vertices.push(
                parseFloat(l[1]),
                parseFloat(l[2]),
                parseFloat(l[3])
              ), l.length >= 7 ? ($e.setRGB(
                parseFloat(l[4]),
                parseFloat(l[5]),
                parseFloat(l[6])
              ).convertSRGBToLinear(), n.colors.push($e.r, $e.g, $e.b)) : n.colors.push(void 0, void 0, void 0);
              break;
            case "vn":
              n.normals.push(
                parseFloat(l[1]),
                parseFloat(l[2]),
                parseFloat(l[3])
              );
              break;
            case "vt":
              n.uvs.push(
                parseFloat(l[1]),
                parseFloat(l[2])
              );
              break;
          }
        } else if (u === "f") {
          const f = c.slice(1).trim().split(nn), p = [];
          for (let y = 0, g = f.length; y < g; y++) {
            const T = f[y];
            if (T.length > 0) {
              const w = T.split("/");
              p.push(w);
            }
          }
          const m = p[0];
          for (let y = 1, g = p.length - 1; y < g; y++) {
            const T = p[y], w = p[y + 1];
            n.addFace(
              m[0],
              T[0],
              w[0],
              m[1],
              T[1],
              w[1],
              m[2],
              T[2],
              w[2]
            );
          }
        } else if (u === "l") {
          const l = c.substring(1).trim().split(" ");
          let f = [];
          const p = [];
          if (c.indexOf("/") === -1)
            f = l;
          else
            for (let m = 0, y = l.length; m < y; m++) {
              const g = l[m].split("/");
              g[0] !== "" && f.push(g[0]), g[1] !== "" && p.push(g[1]);
            }
          n.addLineGeometry(f, p);
        } else if (u === "p") {
          const f = c.slice(1).trim().split(" ");
          n.addPointGeometry(f);
        } else if ((s = Mi.exec(c)) !== null) {
          const l = (" " + s[0].slice(1).trim()).slice(1);
          n.startObject(l);
        } else if (Si.test(c))
          n.object.startMaterial(c.substring(7).trim(), n.materialLibraries);
        else if (Ri.test(c))
          n.materialLibraries.push(c.substring(7).trim());
        else if (Ii.test(c))
          console.warn('THREE.OBJLoader: Rendering identifier "usemap" not supported. Textures must be defined in MTL files.');
        else if (u === "s") {
          if (s = c.split(" "), s.length > 1) {
            const f = s[1].trim().toLowerCase();
            n.object.smooth = f !== "0" && f !== "off";
          } else
            n.object.smooth = !0;
          const l = n.object.currentMaterial();
          l && (l.smooth = n.object.smooth);
        } else {
          if (c === "\0")
            continue;
          console.warn('THREE.OBJLoader: Unexpected line: "' + c + '"');
        }
    }
    n.finalize();
    const i = new fe();
    if (i.materialLibraries = [].concat(n.materialLibraries), !(n.objects.length === 1 && n.objects[0].geometry.vertices.length === 0) === !0)
      for (let a = 0, o = n.objects.length; a < o; a++) {
        const c = n.objects[a], u = c.geometry, l = c.materials, f = u.type === "Line", p = u.type === "Points";
        let m = !1;
        if (u.vertices.length === 0)
          continue;
        const y = new ve();
        y.setAttribute("position", new q(u.vertices, 3)), u.normals.length > 0 && y.setAttribute("normal", new q(u.normals, 3)), u.colors.length > 0 && (m = !0, y.setAttribute("color", new q(u.colors, 3))), u.hasUVIndices === !0 && y.setAttribute("uv", new q(u.uvs, 2));
        const g = [];
        for (let w = 0, A = l.length; w < A; w++) {
          const x = l[w], S = x.name + "_" + x.smooth + "_" + m;
          let E = n.materials[S];
          if (this.materials !== null) {
            if (E = this.materials.create(x.name), f && E && !(E instanceof je)) {
              const v = new je();
              Be.prototype.copy.call(v, E), v.color.copy(E.color), E = v;
            } else if (p && E && !(E instanceof Ne)) {
              const v = new Ne({ size: 10, sizeAttenuation: !1 });
              Be.prototype.copy.call(v, E), v.color.copy(E.color), v.map = E.map, E = v;
            }
          }
          E === void 0 && (f ? E = new je() : p ? E = new Ne({ size: 1, sizeAttenuation: !1 }) : E = new Ue(), E.name = x.name, E.flatShading = !x.smooth, E.vertexColors = m, n.materials[S] = E), g.push(E);
        }
        let T;
        if (g.length > 1) {
          for (let w = 0, A = l.length; w < A; w++) {
            const x = l[w];
            y.addGroup(x.groupStart, x.groupCount, w);
          }
          f ? T = new bt(y, g) : p ? T = new nt(y, g) : T = new it(y, g);
        } else
          f ? T = new bt(y, g[0]) : p ? T = new nt(y, g[0]) : T = new it(y, g[0]);
        T.name = c.name, i.add(T);
      }
    else if (n.vertices.length > 0) {
      const a = new Ne({ size: 1, sizeAttenuation: !1 }), o = new ve();
      o.setAttribute("position", new q(n.vertices, 3)), n.colors.length > 0 && n.colors[0] !== void 0 && (o.setAttribute("color", new q(n.colors, 3)), a.vertexColors = !0);
      const c = new nt(o, a);
      i.add(c);
    }
    return i;
  }
}
class Fi extends Me {
  constructor(e) {
    super(e);
  }
  /**
   * Loads and parses a MTL asset from a URL.
   *
   * @param {String} url - URL to the MTL file.
   * @param {Function} [onLoad] - Callback invoked with the loaded object.
   * @param {Function} [onProgress] - Callback for download progress.
   * @param {Function} [onError] - Callback for download errors.
   *
   * @see setPath setResourcePath
   *
   * @note In order for relative texture references to resolve correctly
   * you must call setResourcePath() explicitly prior to load.
   */
  load(e, n, t, s) {
    const i = this, r = this.path === "" ? ye.extractUrlBase(e) : this.path, a = new ze(this.manager);
    a.setPath(this.path), a.setRequestHeader(this.requestHeader), a.setWithCredentials(this.withCredentials), a.load(e, function(o) {
      try {
        n(i.parse(o, r));
      } catch (c) {
        s ? s(c) : console.error(c), i.manager.itemError(e);
      }
    }, t, s);
  }
  setMaterialOptions(e) {
    return this.materialOptions = e, this;
  }
  /**
   * Parses a MTL file.
   *
   * @param {String} text - Content of MTL file
   * @return {MaterialCreator}
   *
   * @see setPath setResourcePath
   *
   * @note In order for relative texture references to resolve correctly
   * you must call setResourcePath() explicitly prior to parse.
   */
  parse(e, n) {
    const t = e.split(`
`);
    let s = {};
    const i = /\s+/, r = {};
    for (let o = 0; o < t.length; o++) {
      let c = t[o];
      if (c = c.trim(), c.length === 0 || c.charAt(0) === "#")
        continue;
      const u = c.indexOf(" ");
      let l = u >= 0 ? c.substring(0, u) : c;
      l = l.toLowerCase();
      let f = u >= 0 ? c.substring(u + 1) : "";
      if (f = f.trim(), l === "newmtl")
        s = { name: f }, r[f] = s;
      else if (l === "ka" || l === "kd" || l === "ks" || l === "ke") {
        const p = f.split(i, 3);
        s[l] = [parseFloat(p[0]), parseFloat(p[1]), parseFloat(p[2])];
      } else
        s[l] = f;
    }
    const a = new _i(this.resourcePath || n, this.materialOptions);
    return a.setCrossOrigin(this.crossOrigin), a.setManager(this.manager), a.setMaterials(r), a;
  }
}
class _i {
  constructor(e = "", n = {}) {
    this.baseUrl = e, this.options = n, this.materialsInfo = {}, this.materials = {}, this.materialsArray = [], this.nameLookup = {}, this.crossOrigin = "anonymous", this.side = this.options.side !== void 0 ? this.options.side : vn, this.wrap = this.options.wrap !== void 0 ? this.options.wrap : Re;
  }
  setCrossOrigin(e) {
    return this.crossOrigin = e, this;
  }
  setManager(e) {
    this.manager = e;
  }
  setMaterials(e) {
    this.materialsInfo = this.convert(e), this.materials = {}, this.materialsArray = [], this.nameLookup = {};
  }
  convert(e) {
    if (!this.options)
      return e;
    const n = {};
    for (const t in e) {
      const s = e[t], i = {};
      n[t] = i;
      for (const r in s) {
        let a = !0, o = s[r];
        const c = r.toLowerCase();
        switch (c) {
          case "kd":
          case "ka":
          case "ks":
            this.options && this.options.normalizeRGB && (o = [o[0] / 255, o[1] / 255, o[2] / 255]), this.options && this.options.ignoreZeroRGBs && o[0] === 0 && o[1] === 0 && o[2] === 0 && (a = !1);
            break;
        }
        a && (i[c] = o);
      }
    }
    return n;
  }
  preload() {
    for (const e in this.materialsInfo)
      this.create(e);
  }
  getIndex(e) {
    return this.nameLookup[e];
  }
  getAsArray() {
    let e = 0;
    for (const n in this.materialsInfo)
      this.materialsArray[e] = this.create(n), this.nameLookup[n] = e, e++;
    return this.materialsArray;
  }
  create(e) {
    return this.materials[e] === void 0 && this.createMaterial_(e), this.materials[e];
  }
  createMaterial_(e) {
    const n = this, t = this.materialsInfo[e], s = {
      name: e,
      side: this.side
    };
    function i(a, o) {
      return typeof o != "string" || o === "" ? "" : /^https?:\/\//i.test(o) ? o : a + o;
    }
    function r(a, o) {
      if (s[a])
        return;
      const c = n.getTextureParams(o, s), u = n.loadTexture(i(n.baseUrl, c.url));
      u.repeat.copy(c.scale), u.offset.copy(c.offset), u.wrapS = n.wrap, u.wrapT = n.wrap, (a === "map" || a === "emissiveMap") && (u.colorSpace = $), s[a] = u;
    }
    for (const a in t) {
      const o = t[a];
      let c;
      if (o !== "")
        switch (a.toLowerCase()) {
          case "kd":
            s.color = new D().fromArray(o).convertSRGBToLinear();
            break;
          case "ks":
            s.specular = new D().fromArray(o).convertSRGBToLinear();
            break;
          case "ke":
            s.emissive = new D().fromArray(o).convertSRGBToLinear();
            break;
          case "map_kd":
            r("map", o);
            break;
          case "map_ks":
            r("specularMap", o);
            break;
          case "map_ke":
            r("emissiveMap", o);
            break;
          case "norm":
            r("normalMap", o);
            break;
          case "map_bump":
          case "bump":
            r("bumpMap", o);
            break;
          case "map_d":
            r("alphaMap", o), s.transparent = !0;
            break;
          case "ns":
            s.shininess = parseFloat(o);
            break;
          case "d":
            c = parseFloat(o), c < 1 && (s.opacity = c, s.transparent = !0);
            break;
          case "tr":
            c = parseFloat(o), this.options && this.options.invertTrProperty && (c = 1 - c), c > 0 && (s.opacity = 1 - c, s.transparent = !0);
            break;
        }
    }
    return this.materials[e] = new Ue(s), this.materials[e];
  }
  getTextureParams(e, n) {
    const t = {
      scale: new G(1, 1),
      offset: new G(0, 0)
    }, s = e.split(/\s+/);
    let i;
    return i = s.indexOf("-bm"), i >= 0 && (n.bumpScale = parseFloat(s[i + 1]), s.splice(i, 2)), i = s.indexOf("-s"), i >= 0 && (t.scale.set(parseFloat(s[i + 1]), parseFloat(s[i + 2])), s.splice(i, 4)), i = s.indexOf("-o"), i >= 0 && (t.offset.set(parseFloat(s[i + 1]), parseFloat(s[i + 2])), s.splice(i, 4)), t.url = s.join(" ").trim(), t;
  }
  loadTexture(e, n, t, s, i) {
    const r = this.manager !== void 0 ? this.manager : Rs;
    let a = r.getHandler(e);
    a === null && (a = new Ft(r)), a.setCrossOrigin && a.setCrossOrigin(this.crossOrigin);
    const o = a.load(e, t, s, i);
    return n !== void 0 && (o.mapping = n), o;
  }
}
/*!
fflate - fast JavaScript compression/decompression
<https://101arrowz.github.io/fflate>
Licensed under MIT. https://github.com/101arrowz/fflate/blob/master/LICENSE
version 0.6.9
*/
var an = function(h) {
  return URL.createObjectURL(new Blob([h], { type: "text/javascript" }));
};
try {
  URL.revokeObjectURL(an(""));
} catch {
  an = function(e) {
    return "data:application/javascript;charset=UTF-8," + encodeURI(e);
  };
}
var Z = Uint8Array, he = Uint16Array, It = Uint32Array, Sn = new Z([
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  1,
  1,
  1,
  1,
  2,
  2,
  2,
  2,
  3,
  3,
  3,
  3,
  4,
  4,
  4,
  4,
  5,
  5,
  5,
  5,
  0,
  /* unused */
  0,
  0,
  /* impossible */
  0
]), In = new Z([
  0,
  0,
  0,
  0,
  1,
  1,
  2,
  2,
  3,
  3,
  4,
  4,
  5,
  5,
  6,
  6,
  7,
  7,
  8,
  8,
  9,
  9,
  10,
  10,
  11,
  11,
  12,
  12,
  13,
  13,
  /* unused */
  0,
  0
]), Oi = new Z([16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15]), Cn = function(h, e) {
  for (var n = new he(31), t = 0; t < 31; ++t)
    n[t] = e += 1 << h[t - 1];
  for (var s = new It(n[30]), t = 1; t < 30; ++t)
    for (var i = n[t]; i < n[t + 1]; ++i)
      s[i] = i - n[t] << 5 | t;
  return [n, s];
}, Pn = Cn(Sn, 2), Fn = Pn[0], Di = Pn[1];
Fn[28] = 258, Di[258] = 28;
var ki = Cn(In, 0), Ni = ki[0], Ct = new he(32768);
for (var O = 0; O < 32768; ++O) {
  var le = (O & 43690) >>> 1 | (O & 21845) << 1;
  le = (le & 52428) >>> 2 | (le & 13107) << 2, le = (le & 61680) >>> 4 | (le & 3855) << 4, Ct[O] = ((le & 65280) >>> 8 | (le & 255) << 8) >>> 1;
}
var He = function(h, e, n) {
  for (var t = h.length, s = 0, i = new he(e); s < t; ++s)
    ++i[h[s] - 1];
  var r = new he(e);
  for (s = 0; s < e; ++s)
    r[s] = r[s - 1] + i[s - 1] << 1;
  var a;
  if (n) {
    a = new he(1 << e);
    var o = 15 - e;
    for (s = 0; s < t; ++s)
      if (h[s])
        for (var c = s << 4 | h[s], u = e - h[s], l = r[h[s] - 1]++ << u, f = l | (1 << u) - 1; l <= f; ++l)
          a[Ct[l] >>> o] = c;
  } else
    for (a = new he(t), s = 0; s < t; ++s)
      h[s] && (a[s] = Ct[r[h[s] - 1]++] >>> 15 - h[s]);
  return a;
}, Ke = new Z(288);
for (var O = 0; O < 144; ++O)
  Ke[O] = 8;
for (var O = 144; O < 256; ++O)
  Ke[O] = 9;
for (var O = 256; O < 280; ++O)
  Ke[O] = 7;
for (var O = 280; O < 288; ++O)
  Ke[O] = 8;
var _n = new Z(32);
for (var O = 0; O < 32; ++O)
  _n[O] = 5;
var Bi = /* @__PURE__ */ He(Ke, 9, 1), ji = /* @__PURE__ */ He(_n, 5, 1), dt = function(h) {
  for (var e = h[0], n = 1; n < h.length; ++n)
    h[n] > e && (e = h[n]);
  return e;
}, J = function(h, e, n) {
  var t = e / 8 | 0;
  return (h[t] | h[t + 1] << 8) >> (e & 7) & n;
}, mt = function(h, e) {
  var n = e / 8 | 0;
  return (h[n] | h[n + 1] << 8 | h[n + 2] << 16) >> (e & 7);
}, Gi = function(h) {
  return (h / 8 | 0) + (h & 7 && 1);
}, Ui = function(h, e, n) {
  (e == null || e < 0) && (e = 0), (n == null || n > h.length) && (n = h.length);
  var t = new (h instanceof he ? he : h instanceof It ? It : Z)(n - e);
  return t.set(h.subarray(e, n)), t;
}, Hi = function(h, e, n) {
  var t = h.length;
  if (!t || n && !n.l && t < 5)
    return e || new Z(0);
  var s = !e || n, i = !n || n.i;
  n || (n = {}), e || (e = new Z(t * 3));
  var r = function(We) {
    var qe = e.length;
    if (We > qe) {
      var Ze = new Z(Math.max(qe * 2, We));
      Ze.set(e), e = Ze;
    }
  }, a = n.f || 0, o = n.p || 0, c = n.b || 0, u = n.l, l = n.d, f = n.m, p = n.n, m = t * 8;
  do {
    if (!u) {
      n.f = a = J(h, o, 1);
      var y = J(h, o + 1, 3);
      if (o += 3, y)
        if (y == 1)
          u = Bi, l = ji, f = 9, p = 5;
        else if (y == 2) {
          var A = J(h, o, 31) + 257, x = J(h, o + 10, 15) + 4, S = A + J(h, o + 5, 31) + 1;
          o += 14;
          for (var E = new Z(S), v = new Z(19), P = 0; P < x; ++P)
            v[Oi[P]] = J(h, o + P * 3, 7);
          o += x * 3;
          for (var B = dt(v), k = (1 << B) - 1, ee = He(v, B, 1), P = 0; P < S; ) {
            var z = ee[J(h, o, k)];
            o += z & 15;
            var g = z >>> 4;
            if (g < 16)
              E[P++] = g;
            else {
              var Q = 0, pe = 0;
              for (g == 16 ? (pe = 3 + J(h, o, 3), o += 2, Q = E[P - 1]) : g == 17 ? (pe = 3 + J(h, o, 7), o += 3) : g == 18 && (pe = 11 + J(h, o, 127), o += 7); pe--; )
                E[P++] = Q;
            }
          }
          var Se = E.subarray(0, A), U = E.subarray(A);
          f = dt(Se), p = dt(U), u = He(Se, f, 1), l = He(U, p, 1);
        } else
          throw "invalid block type";
      else {
        var g = Gi(o) + 4, T = h[g - 4] | h[g - 3] << 8, w = g + T;
        if (w > t) {
          if (i)
            throw "unexpected EOF";
          break;
        }
        s && r(c + T), e.set(h.subarray(g, w), c), n.b = c += T, n.p = o = w * 8;
        continue;
      }
      if (o > m) {
        if (i)
          throw "unexpected EOF";
        break;
      }
    }
    s && r(c + 131072);
    for (var Ie = (1 << f) - 1, Xe = (1 << p) - 1, de = o; ; de = o) {
      var Q = u[mt(h, o) & Ie], te = Q >>> 4;
      if (o += Q & 15, o > m) {
        if (i)
          throw "unexpected EOF";
        break;
      }
      if (!Q)
        throw "invalid length/literal";
      if (te < 256)
        e[c++] = te;
      else if (te == 256) {
        de = o, u = null;
        break;
      } else {
        var Ce = te - 254;
        if (te > 264) {
          var P = te - 257, me = Sn[P];
          Ce = J(h, o, (1 << me) - 1) + Fn[P], o += me;
        }
        var Te = l[mt(h, o) & Xe], Pe = Te >>> 4;
        if (!Te)
          throw "invalid distance";
        o += Te & 15;
        var U = Ni[Pe];
        if (Pe > 3) {
          var me = In[Pe];
          U += mt(h, o) & (1 << me) - 1, o += me;
        }
        if (o > m) {
          if (i)
            throw "unexpected EOF";
          break;
        }
        s && r(c + 131072);
        for (var Ye = c + Ce; c < Ye; c += 4)
          e[c] = e[c - U], e[c + 1] = e[c + 1 - U], e[c + 2] = e[c + 2 - U], e[c + 3] = e[c + 3 - U];
        c = Ye;
      }
    }
    n.l = u, n.p = de, n.b = c, u && (a = 1, n.m = f, n.d = l, n.n = p);
  } while (!a);
  return c == e.length ? e : Ui(e, 0, c);
}, Vi = /* @__PURE__ */ new Z(0), zi = function(h) {
  if ((h[0] & 15) != 8 || h[0] >>> 4 > 7 || (h[0] << 8 | h[1]) % 31)
    throw "invalid zlib data";
  if (h[1] & 32)
    throw "invalid zlib data: preset dictionaries not supported";
};
function Ki(h, e) {
  return Hi((zi(h), h.subarray(2, -4)), e);
}
var Xi = typeof TextDecoder < "u" && /* @__PURE__ */ new TextDecoder(), Yi = 0;
try {
  Xi.decode(Vi, { stream: !0 }), Yi = 1;
} catch {
}
function On(h, e, n) {
  const t = n.length - h - 1;
  if (e >= n[t])
    return t - 1;
  if (e <= n[h])
    return h;
  let s = h, i = t, r = Math.floor((s + i) / 2);
  for (; e < n[r] || e >= n[r + 1]; )
    e < n[r] ? i = r : s = r, r = Math.floor((s + i) / 2);
  return r;
}
function Wi(h, e, n, t) {
  const s = [], i = [], r = [];
  s[0] = 1;
  for (let a = 1; a <= n; ++a) {
    i[a] = e - t[h + 1 - a], r[a] = t[h + a] - e;
    let o = 0;
    for (let c = 0; c < a; ++c) {
      const u = r[c + 1], l = i[a - c], f = s[c] / (u + l);
      s[c] = o + u * f, o = l * f;
    }
    s[a] = o;
  }
  return s;
}
function qi(h, e, n, t) {
  const s = On(h, t, e), i = Wi(s, t, h, e), r = new ot(0, 0, 0, 0);
  for (let a = 0; a <= h; ++a) {
    const o = n[s - h + a], c = i[a], u = o.w * c;
    r.x += o.x * u, r.y += o.y * u, r.z += o.z * u, r.w += o.w * c;
  }
  return r;
}
function Zi(h, e, n, t, s) {
  const i = [];
  for (let l = 0; l <= n; ++l)
    i[l] = 0;
  const r = [];
  for (let l = 0; l <= t; ++l)
    r[l] = i.slice(0);
  const a = [];
  for (let l = 0; l <= n; ++l)
    a[l] = i.slice(0);
  a[0][0] = 1;
  const o = i.slice(0), c = i.slice(0);
  for (let l = 1; l <= n; ++l) {
    o[l] = e - s[h + 1 - l], c[l] = s[h + l] - e;
    let f = 0;
    for (let p = 0; p < l; ++p) {
      const m = c[p + 1], y = o[l - p];
      a[l][p] = m + y;
      const g = a[p][l - 1] / a[l][p];
      a[p][l] = f + m * g, f = y * g;
    }
    a[l][l] = f;
  }
  for (let l = 0; l <= n; ++l)
    r[0][l] = a[l][n];
  for (let l = 0; l <= n; ++l) {
    let f = 0, p = 1;
    const m = [];
    for (let y = 0; y <= n; ++y)
      m[y] = i.slice(0);
    m[0][0] = 1;
    for (let y = 1; y <= t; ++y) {
      let g = 0;
      const T = l - y, w = n - y;
      l >= y && (m[p][0] = m[f][0] / a[w + 1][T], g = m[p][0] * a[T][w]);
      const A = T >= -1 ? 1 : -T, x = l - 1 <= w ? y - 1 : n - l;
      for (let E = A; E <= x; ++E)
        m[p][E] = (m[f][E] - m[f][E - 1]) / a[w + 1][T + E], g += m[p][E] * a[T + E][w];
      l <= w && (m[p][y] = -m[f][y - 1] / a[w + 1][l], g += m[p][y] * a[l][w]), r[y][l] = g;
      const S = f;
      f = p, p = S;
    }
  }
  let u = n;
  for (let l = 1; l <= t; ++l) {
    for (let f = 0; f <= n; ++f)
      r[l][f] *= u;
    u *= n - l;
  }
  return r;
}
function Qi(h, e, n, t, s) {
  const i = s < h ? s : h, r = [], a = On(h, t, e), o = Zi(a, t, h, i, e), c = [];
  for (let u = 0; u < n.length; ++u) {
    const l = n[u].clone(), f = l.w;
    l.x *= f, l.y *= f, l.z *= f, c[u] = l;
  }
  for (let u = 0; u <= i; ++u) {
    const l = c[a - h].clone().multiplyScalar(o[u][0]);
    for (let f = 1; f <= h; ++f)
      l.add(c[a - h + f].clone().multiplyScalar(o[u][f]));
    r[u] = l;
  }
  for (let u = i + 1; u <= s + 1; ++u)
    r[u] = new ot(0, 0, 0);
  return r;
}
function Ji(h, e) {
  let n = 1;
  for (let s = 2; s <= h; ++s)
    n *= s;
  let t = 1;
  for (let s = 2; s <= e; ++s)
    t *= s;
  for (let s = 2; s <= h - e; ++s)
    t *= s;
  return n / t;
}
function $i(h) {
  const e = h.length, n = [], t = [];
  for (let i = 0; i < e; ++i) {
    const r = h[i];
    n[i] = new R(r.x, r.y, r.z), t[i] = r.w;
  }
  const s = [];
  for (let i = 0; i < e; ++i) {
    const r = n[i].clone();
    for (let a = 1; a <= i; ++a)
      r.sub(s[i - a].clone().multiplyScalar(Ji(i, a) * t[a]));
    s[i] = r.divideScalar(t[0]);
  }
  return s;
}
function er(h, e, n, t, s) {
  const i = Qi(h, e, n, t, s);
  return $i(i);
}
class tr extends Ss {
  constructor(e, n, t, s, i) {
    super(), this.degree = e, this.knots = n, this.controlPoints = [], this.startKnot = s || 0, this.endKnot = i || this.knots.length - 1;
    for (let r = 0; r < t.length; ++r) {
      const a = t[r];
      this.controlPoints[r] = new ot(a.x, a.y, a.z, a.w);
    }
  }
  getPoint(e, n = new R()) {
    const t = n, s = this.knots[this.startKnot] + e * (this.knots[this.endKnot] - this.knots[this.startKnot]), i = qi(this.degree, this.knots, this.controlPoints, s);
    return i.w !== 1 && i.divideScalar(i.w), t.set(i.x, i.y, i.z);
  }
  getTangent(e, n = new R()) {
    const t = n, s = this.knots[0] + e * (this.knots[this.knots.length - 1] - this.knots[0]), i = er(this.degree, this.knots, this.controlPoints, s, 1);
    return t.copy(i[1]).normalize(), t;
  }
}
let M, N, V;
class nr extends Me {
  constructor(e) {
    super(e);
  }
  load(e, n, t, s) {
    const i = this, r = i.path === "" ? ye.extractUrlBase(e) : i.path, a = new ze(this.manager);
    a.setPath(i.path), a.setResponseType("arraybuffer"), a.setRequestHeader(i.requestHeader), a.setWithCredentials(i.withCredentials), a.load(e, function(o) {
      try {
        n(i.parse(o, r));
      } catch (c) {
        s ? s(c) : console.error(c), i.manager.itemError(e);
      }
    }, t, s);
  }
  parse(e, n) {
    if (cr(e))
      M = new ar().parse(e);
    else {
      const s = Bn(e);
      if (!lr(s))
        throw new Error("THREE.FBXLoader: Unknown format.");
      if (ln(s) < 7e3)
        throw new Error("THREE.FBXLoader: FBX version not supported, FileVersion: " + ln(s));
      M = new or().parse(s);
    }
    const t = new Ft(this.manager).setPath(this.resourcePath || n).setCrossOrigin(this.crossOrigin);
    return new sr(t, this.manager).parse(M);
  }
}
class sr {
  constructor(e, n) {
    this.textureLoader = e, this.manager = n;
  }
  parse() {
    N = this.parseConnections();
    const e = this.parseImages(), n = this.parseTextures(e), t = this.parseMaterials(n), s = this.parseDeformers(), i = new ir().parse(s);
    return this.parseScene(s, i, t), V;
  }
  // Parses FBXTree.Connections which holds parent-child connections between objects (e.g. material -> texture, model->geometry )
  // and details the connection type
  parseConnections() {
    const e = /* @__PURE__ */ new Map();
    return "Connections" in M && M.Connections.connections.forEach(function(t) {
      const s = t[0], i = t[1], r = t[2];
      e.has(s) || e.set(s, {
        parents: [],
        children: []
      });
      const a = { ID: i, relationship: r };
      e.get(s).parents.push(a), e.has(i) || e.set(i, {
        parents: [],
        children: []
      });
      const o = { ID: s, relationship: r };
      e.get(i).children.push(o);
    }), e;
  }
  // Parse FBXTree.Objects.Video for embedded image data
  // These images are connected to textures in FBXTree.Objects.Textures
  // via FBXTree.Connections.
  parseImages() {
    const e = {}, n = {};
    if ("Video" in M.Objects) {
      const t = M.Objects.Video;
      for (const s in t) {
        const i = t[s], r = parseInt(s);
        if (e[r] = i.RelativeFilename || i.Filename, "Content" in i) {
          const a = i.Content instanceof ArrayBuffer && i.Content.byteLength > 0, o = typeof i.Content == "string" && i.Content !== "";
          if (a || o) {
            const c = this.parseImage(t[s]);
            n[i.RelativeFilename || i.Filename] = c;
          }
        }
      }
    }
    for (const t in e) {
      const s = e[t];
      n[s] !== void 0 ? e[t] = n[s] : e[t] = e[t].split("\\").pop();
    }
    return e;
  }
  // Parse embedded image data in FBXTree.Video.Content
  parseImage(e) {
    const n = e.Content, t = e.RelativeFilename || e.Filename, s = t.slice(t.lastIndexOf(".") + 1).toLowerCase();
    let i;
    switch (s) {
      case "bmp":
        i = "image/bmp";
        break;
      case "jpg":
      case "jpeg":
        i = "image/jpeg";
        break;
      case "png":
        i = "image/png";
        break;
      case "tif":
        i = "image/tiff";
        break;
      case "tga":
        this.manager.getHandler(".tga") === null && console.warn("FBXLoader: TGA loader not found, skipping ", t), i = "image/tga";
        break;
      default:
        console.warn('FBXLoader: Image type "' + s + '" is not supported.');
        return;
    }
    if (typeof n == "string")
      return "data:" + i + ";base64," + n;
    {
      const r = new Uint8Array(n);
      return window.URL.createObjectURL(new Blob([r], { type: i }));
    }
  }
  // Parse nodes in FBXTree.Objects.Texture
  // These contain details such as UV scaling, cropping, rotation etc and are connected
  // to images in FBXTree.Objects.Video
  parseTextures(e) {
    const n = /* @__PURE__ */ new Map();
    if ("Texture" in M.Objects) {
      const t = M.Objects.Texture;
      for (const s in t) {
        const i = this.parseTexture(t[s], e);
        n.set(parseInt(s), i);
      }
    }
    return n;
  }
  // Parse individual node in FBXTree.Objects.Texture
  parseTexture(e, n) {
    const t = this.loadTexture(e, n);
    t.ID = e.id, t.name = e.attrName;
    const s = e.WrapModeU, i = e.WrapModeV, r = s !== void 0 ? s.value : 0, a = i !== void 0 ? i.value : 0;
    if (t.wrapS = r === 0 ? Re : vt, t.wrapT = a === 0 ? Re : vt, "Scaling" in e) {
      const o = e.Scaling.value;
      t.repeat.x = o[0], t.repeat.y = o[1];
    }
    if ("Translation" in e) {
      const o = e.Translation.value;
      t.offset.x = o[0], t.offset.y = o[1];
    }
    return t;
  }
  // load a texture specified as a blob or data URI, or via an external URL using TextureLoader
  loadTexture(e, n) {
    let t;
    const s = this.textureLoader.path, i = N.get(e.id).children;
    i !== void 0 && i.length > 0 && n[i[0].ID] !== void 0 && (t = n[i[0].ID], (t.indexOf("blob:") === 0 || t.indexOf("data:") === 0) && this.textureLoader.setPath(void 0));
    let r;
    const a = e.FileName.slice(-3).toLowerCase();
    if (a === "tga") {
      const o = this.manager.getHandler(".tga");
      o === null ? (console.warn("FBXLoader: TGA loader not found, creating placeholder texture for", e.RelativeFilename), r = new Ge()) : (o.setPath(this.textureLoader.path), r = o.load(t));
    } else if (a === "dds") {
      const o = this.manager.getHandler(".dds");
      o === null ? (console.warn("FBXLoader: DDS loader not found, creating placeholder texture for", e.RelativeFilename), r = new Ge()) : (o.setPath(this.textureLoader.path), r = o.load(t));
    } else
      a === "psd" ? (console.warn("FBXLoader: PSD textures are not supported, creating placeholder texture for", e.RelativeFilename), r = new Ge()) : r = this.textureLoader.load(t);
    return this.textureLoader.setPath(s), r;
  }
  // Parse nodes in FBXTree.Objects.Material
  parseMaterials(e) {
    const n = /* @__PURE__ */ new Map();
    if ("Material" in M.Objects) {
      const t = M.Objects.Material;
      for (const s in t) {
        const i = this.parseMaterial(t[s], e);
        i !== null && n.set(parseInt(s), i);
      }
    }
    return n;
  }
  // Parse single node in FBXTree.Objects.Material
  // Materials are connected to texture maps in FBXTree.Objects.Textures
  // FBX format currently only supports Lambert and Phong shading models
  parseMaterial(e, n) {
    const t = e.id, s = e.attrName;
    let i = e.ShadingModel;
    if (typeof i == "object" && (i = i.value), !N.has(t))
      return null;
    const r = this.parseParameters(e, n, t);
    let a;
    switch (i.toLowerCase()) {
      case "phong":
        a = new Ue();
        break;
      case "lambert":
        a = new Is();
        break;
      default:
        console.warn('THREE.FBXLoader: unknown material type "%s". Defaulting to MeshPhongMaterial.', i), a = new Ue();
        break;
    }
    return a.setValues(r), a.name = s, a;
  }
  // Parse FBX material and return parameters suitable for a three.js material
  // Also parse the texture map and return any textures associated with the material
  parseParameters(e, n, t) {
    const s = {};
    e.BumpFactor && (s.bumpScale = e.BumpFactor.value), e.Diffuse ? s.color = new D().fromArray(e.Diffuse.value).convertSRGBToLinear() : e.DiffuseColor && (e.DiffuseColor.type === "Color" || e.DiffuseColor.type === "ColorRGB") && (s.color = new D().fromArray(e.DiffuseColor.value).convertSRGBToLinear()), e.DisplacementFactor && (s.displacementScale = e.DisplacementFactor.value), e.Emissive ? s.emissive = new D().fromArray(e.Emissive.value).convertSRGBToLinear() : e.EmissiveColor && (e.EmissiveColor.type === "Color" || e.EmissiveColor.type === "ColorRGB") && (s.emissive = new D().fromArray(e.EmissiveColor.value).convertSRGBToLinear()), e.EmissiveFactor && (s.emissiveIntensity = parseFloat(e.EmissiveFactor.value)), e.Opacity && (s.opacity = parseFloat(e.Opacity.value)), s.opacity < 1 && (s.transparent = !0), e.ReflectionFactor && (s.reflectivity = e.ReflectionFactor.value), e.Shininess && (s.shininess = e.Shininess.value), e.Specular ? s.specular = new D().fromArray(e.Specular.value).convertSRGBToLinear() : e.SpecularColor && e.SpecularColor.type === "Color" && (s.specular = new D().fromArray(e.SpecularColor.value).convertSRGBToLinear());
    const i = this;
    return N.get(t).children.forEach(function(r) {
      const a = r.relationship;
      switch (a) {
        case "Bump":
          s.bumpMap = i.getTexture(n, r.ID);
          break;
        case "Maya|TEX_ao_map":
          s.aoMap = i.getTexture(n, r.ID);
          break;
        case "DiffuseColor":
        case "Maya|TEX_color_map":
          s.map = i.getTexture(n, r.ID), s.map !== void 0 && (s.map.colorSpace = $);
          break;
        case "DisplacementColor":
          s.displacementMap = i.getTexture(n, r.ID);
          break;
        case "EmissiveColor":
          s.emissiveMap = i.getTexture(n, r.ID), s.emissiveMap !== void 0 && (s.emissiveMap.colorSpace = $);
          break;
        case "NormalMap":
        case "Maya|TEX_normal_map":
          s.normalMap = i.getTexture(n, r.ID);
          break;
        case "ReflectionColor":
          s.envMap = i.getTexture(n, r.ID), s.envMap !== void 0 && (s.envMap.mapping = Cs, s.envMap.colorSpace = $);
          break;
        case "SpecularColor":
          s.specularMap = i.getTexture(n, r.ID), s.specularMap !== void 0 && (s.specularMap.colorSpace = $);
          break;
        case "TransparentColor":
        case "TransparencyFactor":
          s.alphaMap = i.getTexture(n, r.ID), s.transparent = !0;
          break;
        case "AmbientColor":
        case "ShininessExponent":
        case "SpecularFactor":
        case "VectorDisplacementColor":
        default:
          console.warn("THREE.FBXLoader: %s map is not supported in three.js, skipping texture.", a);
          break;
      }
    }), s;
  }
  // get a texture from the textureMap for use by a material.
  getTexture(e, n) {
    return "LayeredTexture" in M.Objects && n in M.Objects.LayeredTexture && (console.warn("THREE.FBXLoader: layered textures are not supported in three.js. Discarding all but first layer."), n = N.get(n).children[0].ID), e.get(n);
  }
  // Parse nodes in FBXTree.Objects.Deformer
  // Deformer node can contain skinning or Vertex Cache animation data, however only skinning is supported here
  // Generates map of Skeleton-like objects for use later when generating and binding skeletons.
  parseDeformers() {
    const e = {}, n = {};
    if ("Deformer" in M.Objects) {
      const t = M.Objects.Deformer;
      for (const s in t) {
        const i = t[s], r = N.get(parseInt(s));
        if (i.attrType === "Skin") {
          const a = this.parseSkeleton(r, t);
          a.ID = s, r.parents.length > 1 && console.warn("THREE.FBXLoader: skeleton attached to more than one geometry is not supported."), a.geometryID = r.parents[0].ID, e[s] = a;
        } else if (i.attrType === "BlendShape") {
          const a = {
            id: s
          };
          a.rawTargets = this.parseMorphTargets(r, t), a.id = s, r.parents.length > 1 && console.warn("THREE.FBXLoader: morph target attached to more than one geometry is not supported."), n[s] = a;
        }
      }
    }
    return {
      skeletons: e,
      morphTargets: n
    };
  }
  // Parse single nodes in FBXTree.Objects.Deformer
  // The top level skeleton node has type 'Skin' and sub nodes have type 'Cluster'
  // Each skin node represents a skeleton and each cluster node represents a bone
  parseSkeleton(e, n) {
    const t = [];
    return e.children.forEach(function(s) {
      const i = n[s.ID];
      if (i.attrType !== "Cluster")
        return;
      const r = {
        ID: s.ID,
        indices: [],
        weights: [],
        transformLink: new _().fromArray(i.TransformLink.a)
        // transform: new Matrix4().fromArray( boneNode.Transform.a ),
        // linkMode: boneNode.Mode,
      };
      "Indexes" in i && (r.indices = i.Indexes.a, r.weights = i.Weights.a), t.push(r);
    }), {
      rawBones: t,
      bones: []
    };
  }
  // The top level morph deformer node has type "BlendShape" and sub nodes have type "BlendShapeChannel"
  parseMorphTargets(e, n) {
    const t = [];
    for (let s = 0; s < e.children.length; s++) {
      const i = e.children[s], r = n[i.ID], a = {
        name: r.attrName,
        initialWeight: r.DeformPercent,
        id: r.id,
        fullWeights: r.FullWeights.a
      };
      if (r.attrType !== "BlendShapeChannel")
        return;
      a.geoID = N.get(parseInt(i.ID)).children.filter(function(o) {
        return o.relationship === void 0;
      })[0].ID, t.push(a);
    }
    return t;
  }
  // create the main Group() to be returned by the loader
  parseScene(e, n, t) {
    V = new fe();
    const s = this.parseModels(e.skeletons, n, t), i = M.Objects.Model, r = this;
    s.forEach(function(o) {
      const c = i[o.ID];
      r.setLookAtProperties(o, c), N.get(o.ID).parents.forEach(function(l) {
        const f = s.get(l.ID);
        f !== void 0 && f.add(o);
      }), o.parent === null && V.add(o);
    }), this.bindSkeleton(e.skeletons, n, s), this.addGlobalSceneSettings(), V.traverse(function(o) {
      if (o.userData.transformData) {
        o.parent && (o.userData.transformData.parentMatrix = o.parent.matrix, o.userData.transformData.parentMatrixWorld = o.parent.matrixWorld);
        const c = kn(o.userData.transformData);
        o.applyMatrix4(c), o.updateWorldMatrix();
      }
    });
    const a = new rr().parse();
    V.children.length === 1 && V.children[0].isGroup && (V.children[0].animations = a, V = V.children[0]), V.animations = a;
  }
  // parse nodes in FBXTree.Objects.Model
  parseModels(e, n, t) {
    const s = /* @__PURE__ */ new Map(), i = M.Objects.Model;
    for (const r in i) {
      const a = parseInt(r), o = i[r], c = N.get(a);
      let u = this.buildSkeleton(c, e, a, o.attrName);
      if (!u) {
        switch (o.attrType) {
          case "Camera":
            u = this.createCamera(c);
            break;
          case "Light":
            u = this.createLight(c);
            break;
          case "Mesh":
            u = this.createMesh(c, n, t);
            break;
          case "NurbsCurve":
            u = this.createCurve(c, n);
            break;
          case "LimbNode":
          case "Root":
            u = new Et();
            break;
          case "Null":
          default:
            u = new fe();
            break;
        }
        u.name = o.attrName ? Ve.sanitizeNodeName(o.attrName) : "", u.userData.originalName = o.attrName, u.ID = a;
      }
      this.getTransformData(u, o), s.set(a, u);
    }
    return s;
  }
  buildSkeleton(e, n, t, s) {
    let i = null;
    return e.parents.forEach(function(r) {
      for (const a in n) {
        const o = n[a];
        o.rawBones.forEach(function(c, u) {
          if (c.ID === r.ID) {
            const l = i;
            i = new Et(), i.matrixWorld.copy(c.transformLink), i.name = s ? Ve.sanitizeNodeName(s) : "", i.userData.originalName = s, i.ID = t, o.bones[u] = i, l !== null && i.add(l);
          }
        });
      }
    }), i;
  }
  // create a PerspectiveCamera or OrthographicCamera
  createCamera(e) {
    let n, t;
    if (e.children.forEach(function(s) {
      const i = M.Objects.NodeAttribute[s.ID];
      i !== void 0 && (t = i);
    }), t === void 0)
      n = new Ee();
    else {
      let s = 0;
      t.CameraProjectionType !== void 0 && t.CameraProjectionType.value === 1 && (s = 1);
      let i = 1;
      t.NearPlane !== void 0 && (i = t.NearPlane.value / 1e3);
      let r = 1e3;
      t.FarPlane !== void 0 && (r = t.FarPlane.value / 1e3);
      let a = window.innerWidth, o = window.innerHeight;
      t.AspectWidth !== void 0 && t.AspectHeight !== void 0 && (a = t.AspectWidth.value, o = t.AspectHeight.value);
      const c = a / o;
      let u = 45;
      t.FieldOfView !== void 0 && (u = t.FieldOfView.value);
      const l = t.FocalLength ? t.FocalLength.value : null;
      switch (s) {
        case 0:
          n = new Pt(u, c, i, r), l !== null && n.setFocalLength(l);
          break;
        case 1:
          n = new xn(-a / 2, a / 2, o / 2, -o / 2, i, r);
          break;
        default:
          console.warn("THREE.FBXLoader: Unknown camera type " + s + "."), n = new Ee();
          break;
      }
    }
    return n;
  }
  // Create a DirectionalLight, PointLight or SpotLight
  createLight(e) {
    let n, t;
    if (e.children.forEach(function(s) {
      const i = M.Objects.NodeAttribute[s.ID];
      i !== void 0 && (t = i);
    }), t === void 0)
      n = new Ee();
    else {
      let s;
      t.LightType === void 0 ? s = 0 : s = t.LightType.value;
      let i = 16777215;
      t.Color !== void 0 && (i = new D().fromArray(t.Color.value).convertSRGBToLinear());
      let r = t.Intensity === void 0 ? 1 : t.Intensity.value / 100;
      t.CastLightOnObject !== void 0 && t.CastLightOnObject.value === 0 && (r = 0);
      let a = 0;
      t.FarAttenuationEnd !== void 0 && (t.EnableFarAttenuation !== void 0 && t.EnableFarAttenuation.value === 0 ? a = 0 : a = t.FarAttenuationEnd.value);
      const o = 1;
      switch (s) {
        case 0:
          n = new xt(i, r, a, o);
          break;
        case 1:
          n = new st(i, r);
          break;
        case 2:
          let c = Math.PI / 3;
          t.InnerAngle !== void 0 && (c = j.degToRad(t.InnerAngle.value));
          let u = 0;
          t.OuterAngle !== void 0 && (u = j.degToRad(t.OuterAngle.value), u = Math.max(u, 1)), n = new mn(i, r, a, c, u, o);
          break;
        default:
          console.warn("THREE.FBXLoader: Unknown light type " + t.LightType.value + ", defaulting to a PointLight."), n = new xt(i, r);
          break;
      }
      t.CastShadows !== void 0 && t.CastShadows.value === 1 && (n.castShadow = !0);
    }
    return n;
  }
  createMesh(e, n, t) {
    let s, i = null, r = null;
    const a = [];
    return e.children.forEach(function(o) {
      n.has(o.ID) && (i = n.get(o.ID)), t.has(o.ID) && a.push(t.get(o.ID));
    }), a.length > 1 ? r = a : a.length > 0 ? r = a[0] : (r = new Ue({
      name: Me.DEFAULT_MATERIAL_NAME,
      color: 13421772
    }), a.push(r)), "color" in i.attributes && a.forEach(function(o) {
      o.vertexColors = !0;
    }), i.FBX_Deformer ? (s = new An(i, r), s.normalizeSkinWeights()) : s = new it(i, r), s;
  }
  createCurve(e, n) {
    const t = e.children.reduce(function(i, r) {
      return n.has(r.ID) && (i = n.get(r.ID)), i;
    }, null), s = new je({
      name: Me.DEFAULT_MATERIAL_NAME,
      color: 3342591,
      linewidth: 1
    });
    return new wn(t, s);
  }
  // parse the model node for transform data
  getTransformData(e, n) {
    const t = {};
    "InheritType" in n && (t.inheritType = parseInt(n.InheritType.value)), "RotationOrder" in n ? t.eulerOrder = Nn(n.RotationOrder.value) : t.eulerOrder = "ZYX", "Lcl_Translation" in n && (t.translation = n.Lcl_Translation.value), "PreRotation" in n && (t.preRotation = n.PreRotation.value), "Lcl_Rotation" in n && (t.rotation = n.Lcl_Rotation.value), "PostRotation" in n && (t.postRotation = n.PostRotation.value), "Lcl_Scaling" in n && (t.scale = n.Lcl_Scaling.value), "ScalingOffset" in n && (t.scalingOffset = n.ScalingOffset.value), "ScalingPivot" in n && (t.scalingPivot = n.ScalingPivot.value), "RotationOffset" in n && (t.rotationOffset = n.RotationOffset.value), "RotationPivot" in n && (t.rotationPivot = n.RotationPivot.value), e.userData.transformData = t;
  }
  setLookAtProperties(e, n) {
    "LookAtProperty" in n && N.get(e.ID).children.forEach(function(s) {
      if (s.relationship === "LookAtProperty") {
        const i = M.Objects.Model[s.ID];
        if ("Lcl_Translation" in i) {
          const r = i.Lcl_Translation.value;
          e.target !== void 0 ? (e.target.position.fromArray(r), V.add(e.target)) : e.lookAt(new R().fromArray(r));
        }
      }
    });
  }
  bindSkeleton(e, n, t) {
    const s = this.parsePoseNodes();
    for (const i in e) {
      const r = e[i];
      N.get(parseInt(r.ID)).parents.forEach(function(o) {
        if (n.has(o.ID)) {
          const c = o.ID;
          N.get(c).parents.forEach(function(l) {
            t.has(l.ID) && t.get(l.ID).bind(new bn(r.bones), s[l.ID]);
          });
        }
      });
    }
  }
  parsePoseNodes() {
    const e = {};
    if ("Pose" in M.Objects) {
      const n = M.Objects.Pose;
      for (const t in n)
        if (n[t].attrType === "BindPose" && n[t].NbPoseNodes > 0) {
          const s = n[t].PoseNode;
          Array.isArray(s) ? s.forEach(function(i) {
            e[i.Node] = new _().fromArray(i.Matrix.a);
          }) : e[s.Node] = new _().fromArray(s.Matrix.a);
        }
    }
    return e;
  }
  addGlobalSceneSettings() {
    if ("GlobalSettings" in M) {
      if ("AmbientColor" in M.GlobalSettings) {
        const e = M.GlobalSettings.AmbientColor.value, n = e[0], t = e[1], s = e[2];
        if (n !== 0 || t !== 0 || s !== 0) {
          const i = new D(n, t, s).convertSRGBToLinear();
          V.add(new pn(i, 1));
        }
      }
      "UnitScaleFactor" in M.GlobalSettings && (V.userData.unitScaleFactor = M.GlobalSettings.UnitScaleFactor.value);
    }
  }
}
class ir {
  constructor() {
    this.negativeMaterialIndices = !1;
  }
  // Parse nodes in FBXTree.Objects.Geometry
  parse(e) {
    const n = /* @__PURE__ */ new Map();
    if ("Geometry" in M.Objects) {
      const t = M.Objects.Geometry;
      for (const s in t) {
        const i = N.get(parseInt(s)), r = this.parseGeometry(i, t[s], e);
        n.set(parseInt(s), r);
      }
    }
    return this.negativeMaterialIndices === !0 && console.warn("THREE.FBXLoader: The FBX file contains invalid (negative) material indices. The asset might not render as expected."), n;
  }
  // Parse single node in FBXTree.Objects.Geometry
  parseGeometry(e, n, t) {
    switch (n.attrType) {
      case "Mesh":
        return this.parseMeshGeometry(e, n, t);
      case "NurbsCurve":
        return this.parseNurbsGeometry(n);
    }
  }
  // Parse single node mesh geometry in FBXTree.Objects.Geometry
  parseMeshGeometry(e, n, t) {
    const s = t.skeletons, i = [], r = e.parents.map(function(l) {
      return M.Objects.Model[l.ID];
    });
    if (r.length === 0)
      return;
    const a = e.children.reduce(function(l, f) {
      return s[f.ID] !== void 0 && (l = s[f.ID]), l;
    }, null);
    e.children.forEach(function(l) {
      t.morphTargets[l.ID] !== void 0 && i.push(t.morphTargets[l.ID]);
    });
    const o = r[0], c = {};
    "RotationOrder" in o && (c.eulerOrder = Nn(o.RotationOrder.value)), "InheritType" in o && (c.inheritType = parseInt(o.InheritType.value)), "GeometricTranslation" in o && (c.translation = o.GeometricTranslation.value), "GeometricRotation" in o && (c.rotation = o.GeometricRotation.value), "GeometricScaling" in o && (c.scale = o.GeometricScaling.value);
    const u = kn(c);
    return this.genGeometry(n, a, i, u);
  }
  // Generate a BufferGeometry from a node in FBXTree.Objects.Geometry
  genGeometry(e, n, t, s) {
    const i = new ve();
    e.attrName && (i.name = e.attrName);
    const r = this.parseGeoNode(e, n), a = this.genBuffers(r), o = new q(a.vertex, 3);
    if (o.applyMatrix4(s), i.setAttribute("position", o), a.colors.length > 0 && i.setAttribute("color", new q(a.colors, 3)), n && (i.setAttribute("skinIndex", new Ps(a.weightsIndices, 4)), i.setAttribute("skinWeight", new q(a.vertexWeights, 4)), i.FBX_Deformer = n), a.normal.length > 0) {
      const c = new Fs().getNormalMatrix(s), u = new q(a.normal, 3);
      u.applyNormalMatrix(c), i.setAttribute("normal", u);
    }
    if (a.uvs.forEach(function(c, u) {
      const l = u === 0 ? "uv" : `uv${u}`;
      i.setAttribute(l, new q(a.uvs[u], 2));
    }), r.material && r.material.mappingType !== "AllSame") {
      let c = a.materialIndex[0], u = 0;
      if (a.materialIndex.forEach(function(l, f) {
        l !== c && (i.addGroup(u, f - u, c), c = l, u = f);
      }), i.groups.length > 0) {
        const l = i.groups[i.groups.length - 1], f = l.start + l.count;
        f !== a.materialIndex.length && i.addGroup(f, a.materialIndex.length - f, c);
      }
      i.groups.length === 0 && i.addGroup(0, a.materialIndex.length, a.materialIndex[0]);
    }
    return this.addMorphTargets(i, e, t, s), i;
  }
  parseGeoNode(e, n) {
    const t = {};
    if (t.vertexPositions = e.Vertices !== void 0 ? e.Vertices.a : [], t.vertexIndices = e.PolygonVertexIndex !== void 0 ? e.PolygonVertexIndex.a : [], e.LayerElementColor && (t.color = this.parseVertexColors(e.LayerElementColor[0])), e.LayerElementMaterial && (t.material = this.parseMaterialIndices(e.LayerElementMaterial[0])), e.LayerElementNormal && (t.normal = this.parseNormals(e.LayerElementNormal[0])), e.LayerElementUV) {
      t.uv = [];
      let s = 0;
      for (; e.LayerElementUV[s]; )
        e.LayerElementUV[s].UV && t.uv.push(this.parseUVs(e.LayerElementUV[s])), s++;
    }
    return t.weightTable = {}, n !== null && (t.skeleton = n, n.rawBones.forEach(function(s, i) {
      s.indices.forEach(function(r, a) {
        t.weightTable[r] === void 0 && (t.weightTable[r] = []), t.weightTable[r].push({
          id: i,
          weight: s.weights[a]
        });
      });
    })), t;
  }
  genBuffers(e) {
    const n = {
      vertex: [],
      normal: [],
      colors: [],
      uvs: [],
      materialIndex: [],
      vertexWeights: [],
      weightsIndices: []
    };
    let t = 0, s = 0, i = !1, r = [], a = [], o = [], c = [], u = [], l = [];
    const f = this;
    return e.vertexIndices.forEach(function(p, m) {
      let y, g = !1;
      p < 0 && (p = p ^ -1, g = !0);
      let T = [], w = [];
      if (r.push(p * 3, p * 3 + 1, p * 3 + 2), e.color) {
        const A = et(m, t, p, e.color);
        o.push(A[0], A[1], A[2]);
      }
      if (e.skeleton) {
        if (e.weightTable[p] !== void 0 && e.weightTable[p].forEach(function(A) {
          w.push(A.weight), T.push(A.id);
        }), w.length > 4) {
          i || (console.warn("THREE.FBXLoader: Vertex has more than 4 skinning weights assigned to vertex. Deleting additional weights."), i = !0);
          const A = [0, 0, 0, 0], x = [0, 0, 0, 0];
          w.forEach(function(S, E) {
            let v = S, P = T[E];
            x.forEach(function(B, k, ee) {
              if (v > B) {
                ee[k] = v, v = B;
                const z = A[k];
                A[k] = P, P = z;
              }
            });
          }), T = A, w = x;
        }
        for (; w.length < 4; )
          w.push(0), T.push(0);
        for (let A = 0; A < 4; ++A)
          u.push(w[A]), l.push(T[A]);
      }
      if (e.normal) {
        const A = et(m, t, p, e.normal);
        a.push(A[0], A[1], A[2]);
      }
      e.material && e.material.mappingType !== "AllSame" && (y = et(m, t, p, e.material)[0], y < 0 && (f.negativeMaterialIndices = !0, y = 0)), e.uv && e.uv.forEach(function(A, x) {
        const S = et(m, t, p, A);
        c[x] === void 0 && (c[x] = []), c[x].push(S[0]), c[x].push(S[1]);
      }), s++, g && (f.genFace(n, e, r, y, a, o, c, u, l, s), t++, s = 0, r = [], a = [], o = [], c = [], u = [], l = []);
    }), n;
  }
  // See https://www.khronos.org/opengl/wiki/Calculating_a_Surface_Normal
  getNormalNewell(e) {
    const n = new R(0, 0, 0);
    for (let t = 0; t < e.length; t++) {
      const s = e[t], i = e[(t + 1) % e.length];
      n.x += (s.y - i.y) * (s.z + i.z), n.y += (s.z - i.z) * (s.x + i.x), n.z += (s.x - i.x) * (s.y + i.y);
    }
    return n.normalize(), n;
  }
  getNormalTangentAndBitangent(e) {
    const n = this.getNormalNewell(e), s = (Math.abs(n.z) > 0.5 ? new R(0, 1, 0) : new R(0, 0, 1)).cross(n).normalize(), i = n.clone().cross(s).normalize();
    return {
      normal: n,
      tangent: s,
      bitangent: i
    };
  }
  flattenVertex(e, n, t) {
    return new G(
      e.dot(n),
      e.dot(t)
    );
  }
  // Generate data for a single face in a geometry. If the face is a quad then split it into 2 tris
  genFace(e, n, t, s, i, r, a, o, c, u) {
    let l;
    if (u > 3) {
      const f = [];
      for (let g = 0; g < t.length; g += 3)
        f.push(new R(
          n.vertexPositions[t[g]],
          n.vertexPositions[t[g + 1]],
          n.vertexPositions[t[g + 2]]
        ));
      const { tangent: p, bitangent: m } = this.getNormalTangentAndBitangent(f), y = [];
      for (const g of f)
        y.push(this.flattenVertex(g, p, m));
      l = _s.triangulateShape(y, []);
    } else
      l = [[0, 1, 2]];
    for (const [f, p, m] of l)
      e.vertex.push(n.vertexPositions[t[f * 3]]), e.vertex.push(n.vertexPositions[t[f * 3 + 1]]), e.vertex.push(n.vertexPositions[t[f * 3 + 2]]), e.vertex.push(n.vertexPositions[t[p * 3]]), e.vertex.push(n.vertexPositions[t[p * 3 + 1]]), e.vertex.push(n.vertexPositions[t[p * 3 + 2]]), e.vertex.push(n.vertexPositions[t[m * 3]]), e.vertex.push(n.vertexPositions[t[m * 3 + 1]]), e.vertex.push(n.vertexPositions[t[m * 3 + 2]]), n.skeleton && (e.vertexWeights.push(o[f * 4]), e.vertexWeights.push(o[f * 4 + 1]), e.vertexWeights.push(o[f * 4 + 2]), e.vertexWeights.push(o[f * 4 + 3]), e.vertexWeights.push(o[p * 4]), e.vertexWeights.push(o[p * 4 + 1]), e.vertexWeights.push(o[p * 4 + 2]), e.vertexWeights.push(o[p * 4 + 3]), e.vertexWeights.push(o[m * 4]), e.vertexWeights.push(o[m * 4 + 1]), e.vertexWeights.push(o[m * 4 + 2]), e.vertexWeights.push(o[m * 4 + 3]), e.weightsIndices.push(c[f * 4]), e.weightsIndices.push(c[f * 4 + 1]), e.weightsIndices.push(c[f * 4 + 2]), e.weightsIndices.push(c[f * 4 + 3]), e.weightsIndices.push(c[p * 4]), e.weightsIndices.push(c[p * 4 + 1]), e.weightsIndices.push(c[p * 4 + 2]), e.weightsIndices.push(c[p * 4 + 3]), e.weightsIndices.push(c[m * 4]), e.weightsIndices.push(c[m * 4 + 1]), e.weightsIndices.push(c[m * 4 + 2]), e.weightsIndices.push(c[m * 4 + 3])), n.color && (e.colors.push(r[f * 3]), e.colors.push(r[f * 3 + 1]), e.colors.push(r[f * 3 + 2]), e.colors.push(r[p * 3]), e.colors.push(r[p * 3 + 1]), e.colors.push(r[p * 3 + 2]), e.colors.push(r[m * 3]), e.colors.push(r[m * 3 + 1]), e.colors.push(r[m * 3 + 2])), n.material && n.material.mappingType !== "AllSame" && (e.materialIndex.push(s), e.materialIndex.push(s), e.materialIndex.push(s)), n.normal && (e.normal.push(i[f * 3]), e.normal.push(i[f * 3 + 1]), e.normal.push(i[f * 3 + 2]), e.normal.push(i[p * 3]), e.normal.push(i[p * 3 + 1]), e.normal.push(i[p * 3 + 2]), e.normal.push(i[m * 3]), e.normal.push(i[m * 3 + 1]), e.normal.push(i[m * 3 + 2])), n.uv && n.uv.forEach(function(y, g) {
        e.uvs[g] === void 0 && (e.uvs[g] = []), e.uvs[g].push(a[g][f * 2]), e.uvs[g].push(a[g][f * 2 + 1]), e.uvs[g].push(a[g][p * 2]), e.uvs[g].push(a[g][p * 2 + 1]), e.uvs[g].push(a[g][m * 2]), e.uvs[g].push(a[g][m * 2 + 1]);
      });
  }
  addMorphTargets(e, n, t, s) {
    if (t.length === 0)
      return;
    e.morphTargetsRelative = !0, e.morphAttributes.position = [];
    const i = this;
    t.forEach(function(r) {
      r.rawTargets.forEach(function(a) {
        const o = M.Objects.Geometry[a.geoID];
        o !== void 0 && i.genMorphGeometry(e, n, o, s, a.name);
      });
    });
  }
  // a morph geometry node is similar to a standard  node, and the node is also contained
  // in FBXTree.Objects.Geometry, however it can only have attributes for position, normal
  // and a special attribute Index defining which vertices of the original geometry are affected
  // Normal and position attributes only have data for the vertices that are affected by the morph
  genMorphGeometry(e, n, t, s, i) {
    const r = n.PolygonVertexIndex !== void 0 ? n.PolygonVertexIndex.a : [], a = t.Vertices !== void 0 ? t.Vertices.a : [], o = t.Indexes !== void 0 ? t.Indexes.a : [], c = e.attributes.position.count * 3, u = new Float32Array(c);
    for (let m = 0; m < o.length; m++) {
      const y = o[m] * 3;
      u[y] = a[m * 3], u[y + 1] = a[m * 3 + 1], u[y + 2] = a[m * 3 + 2];
    }
    const l = {
      vertexIndices: r,
      vertexPositions: u
    }, f = this.genBuffers(l), p = new q(f.vertex, 3);
    p.name = i || t.attrName, p.applyMatrix4(s), e.morphAttributes.position.push(p);
  }
  // Parse normal from FBXTree.Objects.Geometry.LayerElementNormal if it exists
  parseNormals(e) {
    const n = e.MappingInformationType, t = e.ReferenceInformationType, s = e.Normals.a;
    let i = [];
    return t === "IndexToDirect" && ("NormalIndex" in e ? i = e.NormalIndex.a : "NormalsIndex" in e && (i = e.NormalsIndex.a)), {
      dataSize: 3,
      buffer: s,
      indices: i,
      mappingType: n,
      referenceType: t
    };
  }
  // Parse UVs from FBXTree.Objects.Geometry.LayerElementUV if it exists
  parseUVs(e) {
    const n = e.MappingInformationType, t = e.ReferenceInformationType, s = e.UV.a;
    let i = [];
    return t === "IndexToDirect" && (i = e.UVIndex.a), {
      dataSize: 2,
      buffer: s,
      indices: i,
      mappingType: n,
      referenceType: t
    };
  }
  // Parse Vertex Colors from FBXTree.Objects.Geometry.LayerElementColor if it exists
  parseVertexColors(e) {
    const n = e.MappingInformationType, t = e.ReferenceInformationType, s = e.Colors.a;
    let i = [];
    t === "IndexToDirect" && (i = e.ColorIndex.a);
    for (let r = 0, a = new D(); r < s.length; r += 4)
      a.fromArray(s, r).convertSRGBToLinear().toArray(s, r);
    return {
      dataSize: 4,
      buffer: s,
      indices: i,
      mappingType: n,
      referenceType: t
    };
  }
  // Parse mapping and material data in FBXTree.Objects.Geometry.LayerElementMaterial if it exists
  parseMaterialIndices(e) {
    const n = e.MappingInformationType, t = e.ReferenceInformationType;
    if (n === "NoMappingInformation")
      return {
        dataSize: 1,
        buffer: [0],
        indices: [0],
        mappingType: "AllSame",
        referenceType: t
      };
    const s = e.Materials.a, i = [];
    for (let r = 0; r < s.length; ++r)
      i.push(r);
    return {
      dataSize: 1,
      buffer: s,
      indices: i,
      mappingType: n,
      referenceType: t
    };
  }
  // Generate a NurbGeometry from a node in FBXTree.Objects.Geometry
  parseNurbsGeometry(e) {
    const n = parseInt(e.Order);
    if (isNaN(n))
      return console.error("THREE.FBXLoader: Invalid Order %s given for geometry ID: %s", e.Order, e.id), new ve();
    const t = n - 1, s = e.KnotVector.a, i = [], r = e.Points.a;
    for (let l = 0, f = r.length; l < f; l += 4)
      i.push(new ot().fromArray(r, l));
    let a, o;
    if (e.Form === "Closed")
      i.push(i[0]);
    else if (e.Form === "Periodic") {
      a = t, o = s.length - 1 - a;
      for (let l = 0; l < t; ++l)
        i.push(i[l]);
    }
    const u = new tr(t, s, i, a, o).getPoints(i.length * 12);
    return new ve().setFromPoints(u);
  }
}
class rr {
  // take raw animation clips and turn them into three.js animation clips
  parse() {
    const e = [], n = this.parseClips();
    if (n !== void 0)
      for (const t in n) {
        const s = n[t], i = this.addClip(s);
        e.push(i);
      }
    return e;
  }
  parseClips() {
    if (M.Objects.AnimationCurve === void 0)
      return;
    const e = this.parseAnimationCurveNodes();
    this.parseAnimationCurves(e);
    const n = this.parseAnimationLayers(e);
    return this.parseAnimStacks(n);
  }
  // parse nodes in FBXTree.Objects.AnimationCurveNode
  // each AnimationCurveNode holds data for an animation transform for a model (e.g. left arm rotation )
  // and is referenced by an AnimationLayer
  parseAnimationCurveNodes() {
    const e = M.Objects.AnimationCurveNode, n = /* @__PURE__ */ new Map();
    for (const t in e) {
      const s = e[t];
      if (s.attrName.match(/S|R|T|DeformPercent/) !== null) {
        const i = {
          id: s.id,
          attr: s.attrName,
          curves: {}
        };
        n.set(i.id, i);
      }
    }
    return n;
  }
  // parse nodes in FBXTree.Objects.AnimationCurve and connect them up to
  // previously parsed AnimationCurveNodes. Each AnimationCurve holds data for a single animated
  // axis ( e.g. times and values of x rotation)
  parseAnimationCurves(e) {
    const n = M.Objects.AnimationCurve;
    for (const t in n) {
      const s = {
        id: n[t].id,
        times: n[t].KeyTime.a.map(ur),
        values: n[t].KeyValueFloat.a
      }, i = N.get(s.id);
      if (i !== void 0) {
        const r = i.parents[0].ID, a = i.parents[0].relationship;
        a.match(/X/) ? e.get(r).curves.x = s : a.match(/Y/) ? e.get(r).curves.y = s : a.match(/Z/) ? e.get(r).curves.z = s : a.match(/DeformPercent/) && e.has(r) && (e.get(r).curves.morph = s);
      }
    }
  }
  // parse nodes in FBXTree.Objects.AnimationLayer. Each layers holds references
  // to various AnimationCurveNodes and is referenced by an AnimationStack node
  // note: theoretically a stack can have multiple layers, however in practice there always seems to be one per stack
  parseAnimationLayers(e) {
    const n = M.Objects.AnimationLayer, t = /* @__PURE__ */ new Map();
    for (const s in n) {
      const i = [], r = N.get(parseInt(s));
      r !== void 0 && (r.children.forEach(function(o, c) {
        if (e.has(o.ID)) {
          const u = e.get(o.ID);
          if (u.curves.x !== void 0 || u.curves.y !== void 0 || u.curves.z !== void 0) {
            if (i[c] === void 0) {
              const l = N.get(o.ID).parents.filter(function(f) {
                return f.relationship !== void 0;
              })[0].ID;
              if (l !== void 0) {
                const f = M.Objects.Model[l.toString()];
                if (f === void 0) {
                  console.warn("THREE.FBXLoader: Encountered a unused curve.", o);
                  return;
                }
                const p = {
                  modelName: f.attrName ? Ve.sanitizeNodeName(f.attrName) : "",
                  ID: f.id,
                  initialPosition: [0, 0, 0],
                  initialRotation: [0, 0, 0],
                  initialScale: [1, 1, 1]
                };
                V.traverse(function(m) {
                  m.ID === f.id && (p.transform = m.matrix, m.userData.transformData && (p.eulerOrder = m.userData.transformData.eulerOrder));
                }), p.transform || (p.transform = new _()), "PreRotation" in f && (p.preRotation = f.PreRotation.value), "PostRotation" in f && (p.postRotation = f.PostRotation.value), i[c] = p;
              }
            }
            i[c] && (i[c][u.attr] = u);
          } else if (u.curves.morph !== void 0) {
            if (i[c] === void 0) {
              const l = N.get(o.ID).parents.filter(function(T) {
                return T.relationship !== void 0;
              })[0].ID, f = N.get(l).parents[0].ID, p = N.get(f).parents[0].ID, m = N.get(p).parents[0].ID, y = M.Objects.Model[m], g = {
                modelName: y.attrName ? Ve.sanitizeNodeName(y.attrName) : "",
                morphName: M.Objects.Deformer[l].attrName
              };
              i[c] = g;
            }
            i[c][u.attr] = u;
          }
        }
      }), t.set(parseInt(s), i));
    }
    return t;
  }
  // parse nodes in FBXTree.Objects.AnimationStack. These are the top level node in the animation
  // hierarchy. Each Stack node will be used to create a AnimationClip
  parseAnimStacks(e) {
    const n = M.Objects.AnimationStack, t = {};
    for (const s in n) {
      const i = N.get(parseInt(s)).children;
      i.length > 1 && console.warn("THREE.FBXLoader: Encountered an animation stack with multiple layers, this is currently not supported. Ignoring subsequent layers.");
      const r = e.get(i[0].ID);
      t[s] = {
        name: n[s].attrName,
        layer: r
      };
    }
    return t;
  }
  addClip(e) {
    let n = [];
    const t = this;
    return e.layer.forEach(function(s) {
      n = n.concat(t.generateTracks(s));
    }), new _t(e.name, -1, n);
  }
  generateTracks(e) {
    const n = [];
    let t = new R(), s = new R();
    if (e.transform && e.transform.decompose(t, new W(), s), t = t.toArray(), s = s.toArray(), e.T !== void 0 && Object.keys(e.T.curves).length > 0) {
      const i = this.generateVectorTrack(e.modelName, e.T.curves, t, "position");
      i !== void 0 && n.push(i);
    }
    if (e.R !== void 0 && Object.keys(e.R.curves).length > 0) {
      const i = this.generateRotationTrack(e.modelName, e.R.curves, e.preRotation, e.postRotation, e.eulerOrder);
      i !== void 0 && n.push(i);
    }
    if (e.S !== void 0 && Object.keys(e.S.curves).length > 0) {
      const i = this.generateVectorTrack(e.modelName, e.S.curves, s, "scale");
      i !== void 0 && n.push(i);
    }
    if (e.DeformPercent !== void 0) {
      const i = this.generateMorphTrack(e);
      i !== void 0 && n.push(i);
    }
    return n;
  }
  generateVectorTrack(e, n, t, s) {
    const i = this.getTimesForAllAxes(n), r = this.getKeyframeTrackValues(i, n, t);
    return new Lt(e + "." + s, i, r);
  }
  generateRotationTrack(e, n, t, s, i) {
    let r, a;
    if (n.x !== void 0 && n.y !== void 0 && n.z !== void 0) {
      const l = this.interpolateRotations(n.x, n.y, n.z, i);
      r = l[0], a = l[1];
    }
    t !== void 0 && (t = t.map(j.degToRad), t.push(i), t = new ne().fromArray(t), t = new W().setFromEuler(t)), s !== void 0 && (s = s.map(j.degToRad), s.push(i), s = new ne().fromArray(s), s = new W().setFromEuler(s).invert());
    const o = new W(), c = new ne(), u = [];
    if (!a || !r)
      return new rt(e + ".quaternion", [], []);
    for (let l = 0; l < a.length; l += 3)
      c.set(a[l], a[l + 1], a[l + 2], i), o.setFromEuler(c), t !== void 0 && o.premultiply(t), s !== void 0 && o.multiply(s), l > 2 && new W().fromArray(
        u,
        (l - 3) / 3 * 4
      ).dot(o) < 0 && o.set(-o.x, -o.y, -o.z, -o.w), o.toArray(u, l / 3 * 4);
    return new rt(e + ".quaternion", r, u);
  }
  generateMorphTrack(e) {
    const n = e.DeformPercent.curves.morph, t = n.values.map(function(i) {
      return i / 100;
    }), s = V.getObjectByName(e.modelName).morphTargetDictionary[e.morphName];
    return new Mt(e.modelName + ".morphTargetInfluences[" + s + "]", n.times, t);
  }
  // For all animated objects, times are defined separately for each axis
  // Here we'll combine the times into one sorted array without duplicates
  getTimesForAllAxes(e) {
    let n = [];
    if (e.x !== void 0 && (n = n.concat(e.x.times)), e.y !== void 0 && (n = n.concat(e.y.times)), e.z !== void 0 && (n = n.concat(e.z.times)), n = n.sort(function(t, s) {
      return t - s;
    }), n.length > 1) {
      let t = 1, s = n[0];
      for (let i = 1; i < n.length; i++) {
        const r = n[i];
        r !== s && (n[t] = r, s = r, t++);
      }
      n = n.slice(0, t);
    }
    return n;
  }
  getKeyframeTrackValues(e, n, t) {
    const s = t, i = [];
    let r = -1, a = -1, o = -1;
    return e.forEach(function(c) {
      if (n.x && (r = n.x.times.indexOf(c)), n.y && (a = n.y.times.indexOf(c)), n.z && (o = n.z.times.indexOf(c)), r !== -1) {
        const u = n.x.values[r];
        i.push(u), s[0] = u;
      } else
        i.push(s[0]);
      if (a !== -1) {
        const u = n.y.values[a];
        i.push(u), s[1] = u;
      } else
        i.push(s[1]);
      if (o !== -1) {
        const u = n.z.values[o];
        i.push(u), s[2] = u;
      } else
        i.push(s[2]);
    }), i;
  }
  // Rotations are defined as Euler angles which can have values  of any size
  // These will be converted to quaternions which don't support values greater than
  // PI, so we'll interpolate large rotations
  interpolateRotations(e, n, t, s) {
    const i = [], r = [];
    i.push(e.times[0]), r.push(j.degToRad(e.values[0])), r.push(j.degToRad(n.values[0])), r.push(j.degToRad(t.values[0]));
    for (let a = 1; a < e.values.length; a++) {
      const o = [
        e.values[a - 1],
        n.values[a - 1],
        t.values[a - 1]
      ];
      if (isNaN(o[0]) || isNaN(o[1]) || isNaN(o[2]))
        continue;
      const c = o.map(j.degToRad), u = [
        e.values[a],
        n.values[a],
        t.values[a]
      ];
      if (isNaN(u[0]) || isNaN(u[1]) || isNaN(u[2]))
        continue;
      const l = u.map(j.degToRad), f = [
        u[0] - o[0],
        u[1] - o[1],
        u[2] - o[2]
      ], p = [
        Math.abs(f[0]),
        Math.abs(f[1]),
        Math.abs(f[2])
      ];
      if (p[0] >= 180 || p[1] >= 180 || p[2] >= 180) {
        const y = Math.max(...p) / 180, g = new ne(...c, s), T = new ne(...l, s), w = new W().setFromEuler(g), A = new W().setFromEuler(T);
        w.dot(A) && A.set(-A.x, -A.y, -A.z, -A.w);
        const x = e.times[a - 1], S = e.times[a] - x, E = new W(), v = new ne();
        for (let P = 0; P < 1; P += 1 / y)
          E.copy(w.clone().slerp(A.clone(), P)), i.push(x + P * S), v.setFromQuaternion(E, s), r.push(v.x), r.push(v.y), r.push(v.z);
      } else
        i.push(e.times[a]), r.push(j.degToRad(e.values[a])), r.push(j.degToRad(n.values[a])), r.push(j.degToRad(t.values[a]));
    }
    return [i, r];
  }
}
class or {
  getPrevNode() {
    return this.nodeStack[this.currentIndent - 2];
  }
  getCurrentNode() {
    return this.nodeStack[this.currentIndent - 1];
  }
  getCurrentProp() {
    return this.currentProp;
  }
  pushStack(e) {
    this.nodeStack.push(e), this.currentIndent += 1;
  }
  popStack() {
    this.nodeStack.pop(), this.currentIndent -= 1;
  }
  setCurrentProp(e, n) {
    this.currentProp = e, this.currentPropName = n;
  }
  parse(e) {
    this.currentIndent = 0, this.allNodes = new Dn(), this.nodeStack = [], this.currentProp = [], this.currentPropName = "";
    const n = this, t = e.split(/[\r\n]+/);
    return t.forEach(function(s, i) {
      const r = s.match(/^[\s\t]*;/), a = s.match(/^[\s\t]*$/);
      if (r || a)
        return;
      const o = s.match("^\\t{" + n.currentIndent + "}(\\w+):(.*){", ""), c = s.match("^\\t{" + n.currentIndent + "}(\\w+):[\\s\\t\\r\\n](.*)"), u = s.match("^\\t{" + (n.currentIndent - 1) + "}}");
      o ? n.parseNodeBegin(s, o) : c ? n.parseNodeProperty(s, c, t[++i]) : u ? n.popStack() : s.match(/^[^\s\t}]/) && n.parseNodePropertyContinued(s);
    }), this.allNodes;
  }
  parseNodeBegin(e, n) {
    const t = n[1].trim().replace(/^"/, "").replace(/"$/, ""), s = n[2].split(",").map(function(o) {
      return o.trim().replace(/^"/, "").replace(/"$/, "");
    }), i = { name: t }, r = this.parseNodeAttr(s), a = this.getCurrentNode();
    this.currentIndent === 0 ? this.allNodes.add(t, i) : t in a ? (t === "PoseNode" ? a.PoseNode.push(i) : a[t].id !== void 0 && (a[t] = {}, a[t][a[t].id] = a[t]), r.id !== "" && (a[t][r.id] = i)) : typeof r.id == "number" ? (a[t] = {}, a[t][r.id] = i) : t !== "Properties70" && (t === "PoseNode" ? a[t] = [i] : a[t] = i), typeof r.id == "number" && (i.id = r.id), r.name !== "" && (i.attrName = r.name), r.type !== "" && (i.attrType = r.type), this.pushStack(i);
  }
  parseNodeAttr(e) {
    let n = e[0];
    e[0] !== "" && (n = parseInt(e[0]), isNaN(n) && (n = e[0]));
    let t = "", s = "";
    return e.length > 1 && (t = e[1].replace(/^(\w+)::/, ""), s = e[2]), { id: n, name: t, type: s };
  }
  parseNodeProperty(e, n, t) {
    let s = n[1].replace(/^"/, "").replace(/"$/, "").trim(), i = n[2].replace(/^"/, "").replace(/"$/, "").trim();
    s === "Content" && i === "," && (i = t.replace(/"/g, "").replace(/,$/, "").trim());
    const r = this.getCurrentNode();
    if (r.name === "Properties70") {
      this.parseNodeSpecialProperty(e, s, i);
      return;
    }
    if (s === "C") {
      const o = i.split(",").slice(1), c = parseInt(o[0]), u = parseInt(o[1]);
      let l = i.split(",").slice(3);
      l = l.map(function(f) {
        return f.trim().replace(/^"/, "");
      }), s = "connections", i = [c, u], fr(i, l), r[s] === void 0 && (r[s] = []);
    }
    s === "Node" && (r.id = i), s in r && Array.isArray(r[s]) ? r[s].push(i) : s !== "a" ? r[s] = i : r.a = i, this.setCurrentProp(r, s), s === "a" && i.slice(-1) !== "," && (r.a = yt(i));
  }
  parseNodePropertyContinued(e) {
    const n = this.getCurrentNode();
    n.a += e, e.slice(-1) !== "," && (n.a = yt(n.a));
  }
  // parse "Property70"
  parseNodeSpecialProperty(e, n, t) {
    const s = t.split('",').map(function(u) {
      return u.trim().replace(/^\"/, "").replace(/\s/, "_");
    }), i = s[0], r = s[1], a = s[2], o = s[3];
    let c = s[4];
    switch (r) {
      case "int":
      case "enum":
      case "bool":
      case "ULongLong":
      case "double":
      case "Number":
      case "FieldOfView":
        c = parseFloat(c);
        break;
      case "Color":
      case "ColorRGB":
      case "Vector3D":
      case "Lcl_Translation":
      case "Lcl_Rotation":
      case "Lcl_Scaling":
        c = yt(c);
        break;
    }
    this.getPrevNode()[i] = {
      type: r,
      type2: a,
      flag: o,
      value: c
    }, this.setCurrentProp(this.getPrevNode(), i);
  }
}
class ar {
  parse(e) {
    const n = new cn(e);
    n.skip(23);
    const t = n.getUint32();
    if (t < 6400)
      throw new Error("THREE.FBXLoader: FBX version not supported, FileVersion: " + t);
    const s = new Dn();
    for (; !this.endOfContent(n); ) {
      const i = this.parseNode(n, t);
      i !== null && s.add(i.name, i);
    }
    return s;
  }
  // Check if reader has reached the end of content.
  endOfContent(e) {
    return e.size() % 16 === 0 ? (e.getOffset() + 160 + 16 & -16) >= e.size() : e.getOffset() + 160 + 16 >= e.size();
  }
  // recursively parse nodes until the end of the file is reached
  parseNode(e, n) {
    const t = {}, s = n >= 7500 ? e.getUint64() : e.getUint32(), i = n >= 7500 ? e.getUint64() : e.getUint32();
    n >= 7500 ? e.getUint64() : e.getUint32();
    const r = e.getUint8(), a = e.getString(r);
    if (s === 0)
      return null;
    const o = [];
    for (let f = 0; f < i; f++)
      o.push(this.parseProperty(e));
    const c = o.length > 0 ? o[0] : "", u = o.length > 1 ? o[1] : "", l = o.length > 2 ? o[2] : "";
    for (t.singleProperty = i === 1 && e.getOffset() === s; s > e.getOffset(); ) {
      const f = this.parseNode(e, n);
      f !== null && this.parseSubNode(a, t, f);
    }
    return t.propertyList = o, typeof c == "number" && (t.id = c), u !== "" && (t.attrName = u), l !== "" && (t.attrType = l), a !== "" && (t.name = a), t;
  }
  parseSubNode(e, n, t) {
    if (t.singleProperty === !0) {
      const s = t.propertyList[0];
      Array.isArray(s) ? (n[t.name] = t, t.a = s) : n[t.name] = s;
    } else if (e === "Connections" && t.name === "C") {
      const s = [];
      t.propertyList.forEach(function(i, r) {
        r !== 0 && s.push(i);
      }), n.connections === void 0 && (n.connections = []), n.connections.push(s);
    } else if (t.name === "Properties70")
      Object.keys(t).forEach(function(i) {
        n[i] = t[i];
      });
    else if (e === "Properties70" && t.name === "P") {
      let s = t.propertyList[0], i = t.propertyList[1];
      const r = t.propertyList[2], a = t.propertyList[3];
      let o;
      s.indexOf("Lcl ") === 0 && (s = s.replace("Lcl ", "Lcl_")), i.indexOf("Lcl ") === 0 && (i = i.replace("Lcl ", "Lcl_")), i === "Color" || i === "ColorRGB" || i === "Vector" || i === "Vector3D" || i.indexOf("Lcl_") === 0 ? o = [
        t.propertyList[4],
        t.propertyList[5],
        t.propertyList[6]
      ] : o = t.propertyList[4], n[s] = {
        type: i,
        type2: r,
        flag: a,
        value: o
      };
    } else
      n[t.name] === void 0 ? typeof t.id == "number" ? (n[t.name] = {}, n[t.name][t.id] = t) : n[t.name] = t : t.name === "PoseNode" ? (Array.isArray(n[t.name]) || (n[t.name] = [n[t.name]]), n[t.name].push(t)) : n[t.name][t.id] === void 0 && (n[t.name][t.id] = t);
  }
  parseProperty(e) {
    const n = e.getString(1);
    let t;
    switch (n) {
      case "C":
        return e.getBoolean();
      case "D":
        return e.getFloat64();
      case "F":
        return e.getFloat32();
      case "I":
        return e.getInt32();
      case "L":
        return e.getInt64();
      case "R":
        return t = e.getUint32(), e.getArrayBuffer(t);
      case "S":
        return t = e.getUint32(), e.getString(t);
      case "Y":
        return e.getInt16();
      case "b":
      case "c":
      case "d":
      case "f":
      case "i":
      case "l":
        const s = e.getUint32(), i = e.getUint32(), r = e.getUint32();
        if (i === 0)
          switch (n) {
            case "b":
            case "c":
              return e.getBooleanArray(s);
            case "d":
              return e.getFloat64Array(s);
            case "f":
              return e.getFloat32Array(s);
            case "i":
              return e.getInt32Array(s);
            case "l":
              return e.getInt64Array(s);
          }
        const a = Ki(new Uint8Array(e.getArrayBuffer(r))), o = new cn(a.buffer);
        switch (n) {
          case "b":
          case "c":
            return o.getBooleanArray(s);
          case "d":
            return o.getFloat64Array(s);
          case "f":
            return o.getFloat32Array(s);
          case "i":
            return o.getInt32Array(s);
          case "l":
            return o.getInt64Array(s);
        }
        break;
      default:
        throw new Error("THREE.FBXLoader: Unknown property type " + n);
    }
  }
}
class cn {
  constructor(e, n) {
    this.dv = new DataView(e), this.offset = 0, this.littleEndian = n !== void 0 ? n : !0, this._textDecoder = new TextDecoder();
  }
  getOffset() {
    return this.offset;
  }
  size() {
    return this.dv.buffer.byteLength;
  }
  skip(e) {
    this.offset += e;
  }
  // seems like true/false representation depends on exporter.
  // true: 1 or 'Y'(=0x59), false: 0 or 'T'(=0x54)
  // then sees LSB.
  getBoolean() {
    return (this.getUint8() & 1) === 1;
  }
  getBooleanArray(e) {
    const n = [];
    for (let t = 0; t < e; t++)
      n.push(this.getBoolean());
    return n;
  }
  getUint8() {
    const e = this.dv.getUint8(this.offset);
    return this.offset += 1, e;
  }
  getInt16() {
    const e = this.dv.getInt16(this.offset, this.littleEndian);
    return this.offset += 2, e;
  }
  getInt32() {
    const e = this.dv.getInt32(this.offset, this.littleEndian);
    return this.offset += 4, e;
  }
  getInt32Array(e) {
    const n = [];
    for (let t = 0; t < e; t++)
      n.push(this.getInt32());
    return n;
  }
  getUint32() {
    const e = this.dv.getUint32(this.offset, this.littleEndian);
    return this.offset += 4, e;
  }
  // JavaScript doesn't support 64-bit integer so calculate this here
  // 1 << 32 will return 1 so using multiply operation instead here.
  // There's a possibility that this method returns wrong value if the value
  // is out of the range between Number.MAX_SAFE_INTEGER and Number.MIN_SAFE_INTEGER.
  // TODO: safely handle 64-bit integer
  getInt64() {
    let e, n;
    return this.littleEndian ? (e = this.getUint32(), n = this.getUint32()) : (n = this.getUint32(), e = this.getUint32()), n & 2147483648 ? (n = ~n & 4294967295, e = ~e & 4294967295, e === 4294967295 && (n = n + 1 & 4294967295), e = e + 1 & 4294967295, -(n * 4294967296 + e)) : n * 4294967296 + e;
  }
  getInt64Array(e) {
    const n = [];
    for (let t = 0; t < e; t++)
      n.push(this.getInt64());
    return n;
  }
  // Note: see getInt64() comment
  getUint64() {
    let e, n;
    return this.littleEndian ? (e = this.getUint32(), n = this.getUint32()) : (n = this.getUint32(), e = this.getUint32()), n * 4294967296 + e;
  }
  getFloat32() {
    const e = this.dv.getFloat32(this.offset, this.littleEndian);
    return this.offset += 4, e;
  }
  getFloat32Array(e) {
    const n = [];
    for (let t = 0; t < e; t++)
      n.push(this.getFloat32());
    return n;
  }
  getFloat64() {
    const e = this.dv.getFloat64(this.offset, this.littleEndian);
    return this.offset += 8, e;
  }
  getFloat64Array(e) {
    const n = [];
    for (let t = 0; t < e; t++)
      n.push(this.getFloat64());
    return n;
  }
  getArrayBuffer(e) {
    const n = this.dv.buffer.slice(this.offset, this.offset + e);
    return this.offset += e, n;
  }
  getString(e) {
    const n = this.offset;
    let t = new Uint8Array(this.dv.buffer, n, e);
    this.skip(e);
    const s = t.indexOf(0);
    return s >= 0 && (t = new Uint8Array(this.dv.buffer, n, s)), this._textDecoder.decode(t);
  }
}
class Dn {
  add(e, n) {
    this[e] = n;
  }
}
function cr(h) {
  const e = "Kaydara FBX Binary  \0";
  return h.byteLength >= e.length && e === Bn(h, 0, e.length);
}
function lr(h) {
  const e = ["K", "a", "y", "d", "a", "r", "a", "\\", "F", "B", "X", "\\", "B", "i", "n", "a", "r", "y", "\\", "\\"];
  let n = 0;
  function t(s) {
    const i = h[s - 1];
    return h = h.slice(n + s), n++, i;
  }
  for (let s = 0; s < e.length; ++s)
    if (t(1) === e[s])
      return !1;
  return !0;
}
function ln(h) {
  const e = /FBXVersion: (\d+)/, n = h.match(e);
  if (n)
    return parseInt(n[1]);
  throw new Error("THREE.FBXLoader: Cannot find the version number for the file given.");
}
function ur(h) {
  return h / 46186158e3;
}
const hr = [];
function et(h, e, n, t) {
  let s;
  switch (t.mappingType) {
    case "ByPolygonVertex":
      s = h;
      break;
    case "ByPolygon":
      s = e;
      break;
    case "ByVertice":
      s = n;
      break;
    case "AllSame":
      s = t.indices[0];
      break;
    default:
      console.warn("THREE.FBXLoader: unknown attribute mapping type " + t.mappingType);
  }
  t.referenceType === "IndexToDirect" && (s = t.indices[s]);
  const i = s * t.dataSize, r = i + t.dataSize;
  return pr(hr, t.buffer, i, r);
}
const gt = new ne(), be = new R();
function kn(h) {
  const e = new _(), n = new _(), t = new _(), s = new _(), i = new _(), r = new _(), a = new _(), o = new _(), c = new _(), u = new _(), l = new _(), f = new _(), p = h.inheritType ? h.inheritType : 0;
  if (h.translation && e.setPosition(be.fromArray(h.translation)), h.preRotation) {
    const k = h.preRotation.map(j.degToRad);
    k.push(h.eulerOrder || ne.DEFAULT_ORDER), n.makeRotationFromEuler(gt.fromArray(k));
  }
  if (h.rotation) {
    const k = h.rotation.map(j.degToRad);
    k.push(h.eulerOrder || ne.DEFAULT_ORDER), t.makeRotationFromEuler(gt.fromArray(k));
  }
  if (h.postRotation) {
    const k = h.postRotation.map(j.degToRad);
    k.push(h.eulerOrder || ne.DEFAULT_ORDER), s.makeRotationFromEuler(gt.fromArray(k)), s.invert();
  }
  h.scale && i.scale(be.fromArray(h.scale)), h.scalingOffset && a.setPosition(be.fromArray(h.scalingOffset)), h.scalingPivot && r.setPosition(be.fromArray(h.scalingPivot)), h.rotationOffset && o.setPosition(be.fromArray(h.rotationOffset)), h.rotationPivot && c.setPosition(be.fromArray(h.rotationPivot)), h.parentMatrixWorld && (l.copy(h.parentMatrix), u.copy(h.parentMatrixWorld));
  const m = n.clone().multiply(t).multiply(s), y = new _();
  y.extractRotation(u);
  const g = new _();
  g.copyPosition(u);
  const T = g.clone().invert().multiply(u), w = y.clone().invert().multiply(T), A = i, x = new _();
  if (p === 0)
    x.copy(y).multiply(m).multiply(w).multiply(A);
  else if (p === 1)
    x.copy(y).multiply(w).multiply(m).multiply(A);
  else {
    const ee = new _().scale(new R().setFromMatrixScale(l)).clone().invert(), z = w.clone().multiply(ee);
    x.copy(y).multiply(m).multiply(z).multiply(A);
  }
  const S = c.clone().invert(), E = r.clone().invert();
  let v = e.clone().multiply(o).multiply(c).multiply(n).multiply(t).multiply(s).multiply(S).multiply(a).multiply(r).multiply(i).multiply(E);
  const P = new _().copyPosition(v), B = u.clone().multiply(P);
  return f.copyPosition(B), v = f.clone().multiply(x), v.premultiply(u.invert()), v;
}
function Nn(h) {
  h = h || 0;
  const e = [
    "ZYX",
    // -> XYZ extrinsic
    "YZX",
    // -> XZY extrinsic
    "XZY",
    // -> YZX extrinsic
    "ZXY",
    // -> YXZ extrinsic
    "YXZ",
    // -> ZXY extrinsic
    "XYZ"
    // -> ZYX extrinsic
    //'SphericXYZ', // not possible to support
  ];
  return h === 6 ? (console.warn("THREE.FBXLoader: unsupported Euler Order: Spherical XYZ. Animations and rotations may be incorrect."), e[0]) : e[h];
}
function yt(h) {
  return h.split(",").map(function(n) {
    return parseFloat(n);
  });
}
function Bn(h, e, n) {
  return e === void 0 && (e = 0), n === void 0 && (n = h.byteLength), new TextDecoder().decode(new Uint8Array(h, e, n));
}
function fr(h, e) {
  for (let n = 0, t = h.length, s = e.length; n < s; n++, t++)
    h[t] = e[n];
}
function pr(h, e, n, t) {
  for (let s = n, i = 0; s < t; s++, i++)
    h[i] = e[s];
  return h;
}
class Tt extends Ee {
  // private emit = defineEmits(['playAniFinished'])
  constructor(n) {
    super();
    L(this, "model");
    L(this, "gltf");
    L(this, "gltfAnimations");
    L(this, "mixer");
    L(this, "curAni");
    L(this, "actionClip");
    L(this, "aniIsLoop", !1);
    L(this, "tween", null);
    L(this, "clock");
    L(this, "aniSpeed", 1);
    // public disassembleModels: Mesh[] = [];
    // public moveModelDesPos: Vector3[] = [];
    // private moveModelInitPos: Vector3[] = [];
    L(this, "idleAniName");
    L(this, "rotationSpeed", 0);
    L(this, "aniFinishedCallback");
    L(this, "playAniFinished");
    this.gltf = n, this.model = n.scene, this.add(this.model), this.mixer = new Os(this.model), this.setAnimations(n.animations), this.render(), this.aniFinishedCallback = this.finishAni.bind(this), this.mixer.addEventListener("finished", this.aniFinishedCallback);
  }
  setAnimations(n) {
    this.gltfAnimations = n;
  }
  /* public setDisassembeModel(models: Mesh[], distance = 100) {
      for (let i = 0; i < models.length; i++) {
        this.disassembleModels.push(models[i]);
        const pos: Vector3 = models[i].position;
        this.moveModelDesPos.push({
          x: pos.x + Math.random() * distance - distance / 2,
          y: pos.y + Math.random() * distance - distance / 2,
          z: pos.z + Math.random() * distance - distance / 2
        });
      }
    }
  
    public openDisassembleModel() {
      this.moveModelInitPos.length = 0;
      for (let i = 0; i < this.disassembleModels.length; i++) {
        this.moveModelInitPos.push(this.disassembleModels[i].position);
        setTimeout(() => {
          ToolFuntion.modelMove([this.disassembleModels[i]], [this.moveModelDesPos[i]]);
        }, 500 * (i + 1));
      }
    }
  
    public resetDisassembleModel() {
      ToolFuntion.modelMove(this.disassembleModels, this.moveModelInitPos, 800);
    } */
  playAni(n, t = !0) {
    n === void 0 || n === "" || this.curAni !== n && (this.aniIsLoop = t, this.curAni = n, this.setAnimation(n, 0.01));
  }
  setIdleAni(n) {
    this.idleAniName = n;
  }
  stopAni() {
    this.actionClip && this.actionClip.stop();
  }
  resetPlayAni() {
    this.actionClip && (this.actionClip.reset(), this.actionClip.play());
  }
  pauseAni() {
    this.actionClip && (this.actionClip.paused = !0);
  }
  continueAni() {
    this.actionClip && (this.actionClip.paused = !1);
  }
  setAnimation(n, t) {
    if (this.mixer !== void 0) {
      const s = _t.findByName(this.gltfAnimations, n), i = this.mixer.clipAction(s);
      return i === null ? (console.error(`Animation ${n} not found!`), 0) : (this.mixer.stopAllAction(), i.fadeIn(t), i.loop = this.aniIsLoop ? Ds : ks, i.play(), i.timeScale = this.aniSpeed, this.actionClip = i, i.getClip().duration);
    }
    return 0;
  }
  finishAni(n) {
    this.playAniFinished && this.playAniFinished(), this.idleAniName && this.playAni(this.idleAniName, !0);
  }
  get Model() {
    return this.model;
  }
  get Gltf() {
    return this.gltf;
  }
  destroy() {
    this.remove(), this.parent && this.parent.remove(this), this.model = void 0, this.animations.length = 0, this.mixer.removeEventListener("finished", this.aniFinishedCallback), this.mixer = void 0, this.gltf = void 0, this.tween && (this.tween.stop(), this.tween = void 0, this.clock = void 0);
  }
  hide() {
    this.visible = !1, this.tween && this.tween.pause();
  }
  show() {
    this.visible = !0, this.tween && this.tween.resume();
  }
  setModelRotation(n) {
    this.rotationSpeed = n;
  }
  resetModelRotation() {
    this.rotationSpeed = 0, this.rotation.set(0, 0, 0);
  }
  render() {
    this.clock = new Ns(), this.tween = new Ln({}).to({}, 1).repeat(1 / 0).onRepeat(() => {
      this.update(this.clock.getDelta());
    }).start();
  }
  update(n) {
    this.mixer && this.mixer.update(n), this.rotationSpeed > 0 && this.rotateOnAxis(new R(0, 1, 0), n * this.rotationSpeed);
  }
}
class dr {
  constructor() {
    L(this, "name", "ModelManager");
    L(this, "version", "1.0.0");
    L(this, "viewer");
    L(this, "renderManager");
    L(this, "sceneManager");
    L(this, "modelGroup");
  }
  install(e) {
    this.viewer = e, this.viewer.modelManager = this, this.renderManager = e.renderManager, this.sceneManager = e.sceneManager, this.modelGroup = new fe(), this.sceneManager.elementGroup.add(this.modelGroup);
  }
  uninstall() {
    this.viewer.modelManager = void 0;
  }
  addModel(e, n) {
    const { type: t, position: s, rotation: i, scale: r } = e, a = (o) => {
      const c = new Tt(o);
      this.modelGroup.add(c), s && c.position.set(s.x, s.y, s.z), i && c.rotation.set(i.x, i.y, i.z), r && c.scale.set(r, r, r), n && n(c);
    };
    switch (t) {
      case "OBJ":
        this.loadOBJModel(e.objUrl, e.mtlUrl, a);
        break;
      case "FBX":
        this.loadFBXModel(e.url, a);
        break;
      case "GLTF":
      default:
        this.loadGLTFModel(e.url, a);
        break;
    }
  }
  loadGLTFModel(e, n) {
    new Xs().load(
      e,
      /** onComplete */
      (s) => {
        n && n(s);
      },
      /** onProgress */
      () => {
      },
      /** onError */
      () => {
        console.warn("GLTF load error.");
      }
    );
  }
  loadOBJModel(e, n, t) {
    new Fi().load(
      n,
      /** onComplete */
      (i) => {
        i.preload();
        const r = new Pi();
        r.setMaterials(i), r.load(
          e,
          /** onComplete */
          (a) => {
            t && t(a);
          },
          /** onProgress */
          () => {
          },
          /** onError */
          () => {
            console.warn("OBJ load error.");
          }
        );
      },
      /** onProgress */
      () => {
      },
      /** onError */
      () => {
        console.warn("MTL load error.");
      }
    );
  }
  loadFBXModel(e, n) {
    new nr().load(
      e,
      /** onComplete */
      (s) => {
        n && n(s);
      },
      /** onProgress */
      () => {
      },
      /** onError */
      () => {
        console.warn("FBX load error.");
      }
    );
  }
  selectModelById(e) {
    return this.modelGroup.children.find((t) => t.uuid === e);
  }
  removeModelById(e) {
    const n = this.selectModelById(e);
    n && (this.modelGroup.remove(n), n instanceof Tt && n.destroy());
  }
  removeModel(e) {
    e instanceof Tt ? e.destroy() : this.modelGroup.remove(e.scene);
  }
  /* public load3DTiles(path: string) {
      const { scene, camera, renderer } = this.renderManager;
      const tilesRenderer = new TilesRenderer(path);
      tilesRenderer.setCamera(camera);
      tilesRenderer.setResolutionFromRenderer(camera, renderer);
      scene.add(tilesRenderer.group);
  
      this.init3DTilesAnim(tilesRenderer);
    }
  
    private init3DTilesAnim(tilesRenderer: TilesRenderer) {
      const anim = new Tween({})
        .to({})
        .repeat(Infinity)
        .onUpdate(() => {
          tilesRenderer.update();
        });
      anim.start();
    } */
  clear() {
    this.modelGroup.clear();
  }
}
var mr = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {};
function gr(h) {
  return h && h.__esModule && Object.prototype.hasOwnProperty.call(h, "default") ? h.default : h;
}
var jn = { exports: {} };
(function(h, e) {
  (function(n, t) {
    h.exports = t();
  })(mr, function() {
    var n = function() {
      var t = 0, s = document.createElement("div");
      function i(p) {
        return s.appendChild(p.dom), p;
      }
      function r(p) {
        for (var m = 0; m < s.children.length; m++)
          s.children[m].style.display = m === p ? "block" : "none";
        t = p;
      }
      s.style.cssText = "position:fixed;top:0;left:0;cursor:pointer;opacity:0.9;z-index:10000", s.addEventListener("click", function(p) {
        p.preventDefault(), r(++t % s.children.length);
      }, !1);
      var a = (performance || Date).now(), o = a, c = 0, u = i(new n.Panel("FPS", "#0ff", "#002")), l = i(new n.Panel("MS", "#0f0", "#020"));
      if (self.performance && self.performance.memory)
        var f = i(new n.Panel("MB", "#f08", "#201"));
      return r(0), { REVISION: 16, dom: s, addPanel: i, showPanel: r, begin: function() {
        a = (performance || Date).now();
      }, end: function() {
        c++;
        var p = (performance || Date).now();
        if (l.update(p - a, 200), o + 1e3 <= p && (u.update(1e3 * c / (p - o), 100), o = p, c = 0, f)) {
          var m = performance.memory;
          f.update(m.usedJSHeapSize / 1048576, m.jsHeapSizeLimit / 1048576);
        }
        return p;
      }, update: function() {
        a = this.end();
      }, domElement: s, setMode: r };
    };
    return n.Panel = function(t, s, i) {
      var r = 1 / 0, a = 0, o = Math.round, c = o(window.devicePixelRatio || 1), u = 80 * c, l = 48 * c, f = 3 * c, p = 2 * c, m = 3 * c, y = 15 * c, g = 74 * c, T = 30 * c, w = document.createElement("canvas");
      w.width = u, w.height = l, w.style.cssText = "width:80px;height:48px";
      var A = w.getContext("2d");
      return A.font = "bold " + 9 * c + "px Helvetica,Arial,sans-serif", A.textBaseline = "top", A.fillStyle = i, A.fillRect(0, 0, u, l), A.fillStyle = s, A.fillText(t, f, p), A.fillRect(m, y, g, T), A.fillStyle = i, A.globalAlpha = 0.9, A.fillRect(m, y, g, T), { dom: w, update: function(x, S) {
        r = Math.min(r, x), a = Math.max(a, x), A.fillStyle = i, A.globalAlpha = 1, A.fillRect(0, 0, u, y), A.fillStyle = s, A.fillText(o(x) + " " + t + " (" + o(r) + "-" + o(a) + ")", f, p), A.drawImage(w, m + c, y, g - c, T, m, y, g - c, T), A.fillRect(m + g - c, y, c, T), A.fillStyle = i, A.globalAlpha = 0.9, A.fillRect(m + g - c, y, c, o((1 - x / S) * T));
      } };
    }, n;
  });
})(jn);
var yr = jn.exports;
const Tr = /* @__PURE__ */ gr(yr), un = { type: "change" }, At = { type: "start" }, hn = { type: "end" }, tt = new Bs(), fn = new js(), Ar = Math.cos(70 * j.DEG2RAD);
class wr extends Gs {
  constructor(e, n) {
    super(), this.object = e, this.domElement = n, this.domElement.style.touchAction = "none", this.enabled = !0, this.target = new R(), this.cursor = new R(), this.minDistance = 0, this.maxDistance = 1 / 0, this.minZoom = 0, this.maxZoom = 1 / 0, this.minTargetRadius = 0, this.maxTargetRadius = 1 / 0, this.minPolarAngle = 0, this.maxPolarAngle = Math.PI, this.minAzimuthAngle = -1 / 0, this.maxAzimuthAngle = 1 / 0, this.enableDamping = !1, this.dampingFactor = 0.05, this.enableZoom = !0, this.zoomSpeed = 1, this.enableRotate = !0, this.rotateSpeed = 1, this.enablePan = !0, this.panSpeed = 1, this.screenSpacePanning = !0, this.keyPanSpeed = 7, this.zoomToCursor = !1, this.autoRotate = !1, this.autoRotateSpeed = 2, this.keys = { LEFT: "ArrowLeft", UP: "ArrowUp", RIGHT: "ArrowRight", BOTTOM: "ArrowDown" }, this.mouseButtons = { LEFT: we.ROTATE, MIDDLE: we.DOLLY, RIGHT: we.PAN }, this.touches = { ONE: xe.ROTATE, TWO: xe.DOLLY_PAN }, this.target0 = this.target.clone(), this.position0 = this.object.position.clone(), this.zoom0 = this.object.zoom, this._domElementKeyEvents = null, this.getPolarAngle = function() {
      return a.phi;
    }, this.getAzimuthalAngle = function() {
      return a.theta;
    }, this.getDistance = function() {
      return this.object.position.distanceTo(this.target);
    }, this.listenToKeyEvents = function(d) {
      d.addEventListener("keydown", ct), this._domElementKeyEvents = d;
    }, this.stopListenToKeyEvents = function() {
      this._domElementKeyEvents.removeEventListener("keydown", ct), this._domElementKeyEvents = null;
    }, this.saveState = function() {
      t.target0.copy(t.target), t.position0.copy(t.object.position), t.zoom0 = t.object.zoom;
    }, this.reset = function() {
      t.target.copy(t.target0), t.object.position.copy(t.position0), t.object.zoom = t.zoom0, t.object.updateProjectionMatrix(), t.dispatchEvent(un), t.update(), i = s.NONE;
    }, this.update = function() {
      const d = new R(), b = new W().setFromUnitVectors(e.up, new R(0, 1, 0)), I = b.clone().invert(), F = new R(), H = new W(), ae = new R(), K = 2 * Math.PI;
      return function(Qn = null) {
        const Xt = t.object.position;
        d.copy(Xt).sub(t.target), d.applyQuaternion(b), a.setFromVector3(d), t.autoRotate && i === s.NONE && z(k(Qn)), t.enableDamping ? (a.theta += o.theta * t.dampingFactor, a.phi += o.phi * t.dampingFactor) : (a.theta += o.theta, a.phi += o.phi);
        let se = t.minAzimuthAngle, ie = t.maxAzimuthAngle;
        isFinite(se) && isFinite(ie) && (se < -Math.PI ? se += K : se > Math.PI && (se -= K), ie < -Math.PI ? ie += K : ie > Math.PI && (ie -= K), se <= ie ? a.theta = Math.max(se, Math.min(ie, a.theta)) : a.theta = a.theta > (se + ie) / 2 ? Math.max(se, a.theta) : Math.min(ie, a.theta)), a.phi = Math.max(t.minPolarAngle, Math.min(t.maxPolarAngle, a.phi)), a.makeSafe(), t.enableDamping === !0 ? t.target.addScaledVector(u, t.dampingFactor) : t.target.add(u), t.target.sub(t.cursor), t.target.clampLength(t.minTargetRadius, t.maxTargetRadius), t.target.add(t.cursor), t.zoomToCursor && E || t.object.isOrthographicCamera ? a.radius = te(a.radius) : a.radius = te(a.radius * c), d.setFromSpherical(a), d.applyQuaternion(I), Xt.copy(t.target).add(d), t.object.lookAt(t.target), t.enableDamping === !0 ? (o.theta *= 1 - t.dampingFactor, o.phi *= 1 - t.dampingFactor, u.multiplyScalar(1 - t.dampingFactor)) : (o.set(0, 0, 0), u.set(0, 0, 0));
        let Qe = !1;
        if (t.zoomToCursor && E) {
          let _e = null;
          if (t.object.isPerspectiveCamera) {
            const Oe = d.length();
            _e = te(Oe * c);
            const Je = Oe - _e;
            t.object.position.addScaledVector(x, Je), t.object.updateMatrixWorld();
          } else if (t.object.isOrthographicCamera) {
            const Oe = new R(S.x, S.y, 0);
            Oe.unproject(t.object), t.object.zoom = Math.max(t.minZoom, Math.min(t.maxZoom, t.object.zoom / c)), t.object.updateProjectionMatrix(), Qe = !0;
            const Je = new R(S.x, S.y, 0);
            Je.unproject(t.object), t.object.position.sub(Je).add(Oe), t.object.updateMatrixWorld(), _e = d.length();
          } else
            console.warn("WARNING: OrbitControls.js encountered an unknown camera type - zoom to cursor disabled."), t.zoomToCursor = !1;
          _e !== null && (this.screenSpacePanning ? t.target.set(0, 0, -1).transformDirection(t.object.matrix).multiplyScalar(_e).add(t.object.position) : (tt.origin.copy(t.object.position), tt.direction.set(0, 0, -1).transformDirection(t.object.matrix), Math.abs(t.object.up.dot(tt.direction)) < Ar ? e.lookAt(t.target) : (fn.setFromNormalAndCoplanarPoint(t.object.up, t.target), tt.intersectPlane(fn, t.target))));
        } else
          t.object.isOrthographicCamera && (Qe = c !== 1, Qe && (t.object.zoom = Math.max(t.minZoom, Math.min(t.maxZoom, t.object.zoom / c)), t.object.updateProjectionMatrix()));
        return c = 1, E = !1, Qe || F.distanceToSquared(t.object.position) > r || 8 * (1 - H.dot(t.object.quaternion)) > r || ae.distanceToSquared(t.target) > 0 ? (t.dispatchEvent(un), F.copy(t.object.position), H.copy(t.object.quaternion), ae.copy(t.target), !0) : !1;
      };
    }(), this.dispose = function() {
      t.domElement.removeEventListener("contextmenu", zt), t.domElement.removeEventListener("pointerdown", Gt), t.domElement.removeEventListener("pointercancel", Fe), t.domElement.removeEventListener("wheel", Ut), t.domElement.removeEventListener("pointermove", at), t.domElement.removeEventListener("pointerup", Fe), t._domElementKeyEvents !== null && (t._domElementKeyEvents.removeEventListener("keydown", ct), t._domElementKeyEvents = null);
    };
    const t = this, s = {
      NONE: -1,
      ROTATE: 0,
      DOLLY: 1,
      PAN: 2,
      TOUCH_ROTATE: 3,
      TOUCH_PAN: 4,
      TOUCH_DOLLY_PAN: 5,
      TOUCH_DOLLY_ROTATE: 6
    };
    let i = s.NONE;
    const r = 1e-6, a = new Zt(), o = new Zt();
    let c = 1;
    const u = new R(), l = new G(), f = new G(), p = new G(), m = new G(), y = new G(), g = new G(), T = new G(), w = new G(), A = new G(), x = new R(), S = new G();
    let E = !1;
    const v = [], P = {};
    let B = !1;
    function k(d) {
      return d !== null ? 2 * Math.PI / 60 * t.autoRotateSpeed * d : 2 * Math.PI / 60 / 60 * t.autoRotateSpeed;
    }
    function ee(d) {
      const b = Math.abs(d * 0.01);
      return Math.pow(0.95, t.zoomSpeed * b);
    }
    function z(d) {
      o.theta -= d;
    }
    function Q(d) {
      o.phi -= d;
    }
    const pe = function() {
      const d = new R();
      return function(I, F) {
        d.setFromMatrixColumn(F, 0), d.multiplyScalar(-I), u.add(d);
      };
    }(), Se = function() {
      const d = new R();
      return function(I, F) {
        t.screenSpacePanning === !0 ? d.setFromMatrixColumn(F, 1) : (d.setFromMatrixColumn(F, 0), d.crossVectors(t.object.up, d)), d.multiplyScalar(I), u.add(d);
      };
    }(), U = function() {
      const d = new R();
      return function(I, F) {
        const H = t.domElement;
        if (t.object.isPerspectiveCamera) {
          const ae = t.object.position;
          d.copy(ae).sub(t.target);
          let K = d.length();
          K *= Math.tan(t.object.fov / 2 * Math.PI / 180), pe(2 * I * K / H.clientHeight, t.object.matrix), Se(2 * F * K / H.clientHeight, t.object.matrix);
        } else
          t.object.isOrthographicCamera ? (pe(I * (t.object.right - t.object.left) / t.object.zoom / H.clientWidth, t.object.matrix), Se(F * (t.object.top - t.object.bottom) / t.object.zoom / H.clientHeight, t.object.matrix)) : (console.warn("WARNING: OrbitControls.js encountered an unknown camera type - pan disabled."), t.enablePan = !1);
      };
    }();
    function Ie(d) {
      t.object.isPerspectiveCamera || t.object.isOrthographicCamera ? c /= d : (console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."), t.enableZoom = !1);
    }
    function Xe(d) {
      t.object.isPerspectiveCamera || t.object.isOrthographicCamera ? c *= d : (console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."), t.enableZoom = !1);
    }
    function de(d, b) {
      if (!t.zoomToCursor)
        return;
      E = !0;
      const I = t.domElement.getBoundingClientRect(), F = d - I.left, H = b - I.top, ae = I.width, K = I.height;
      S.x = F / ae * 2 - 1, S.y = -(H / K) * 2 + 1, x.set(S.x, S.y, 1).unproject(t.object).sub(t.object.position).normalize();
    }
    function te(d) {
      return Math.max(t.minDistance, Math.min(t.maxDistance, d));
    }
    function Ce(d) {
      l.set(d.clientX, d.clientY);
    }
    function me(d) {
      de(d.clientX, d.clientX), T.set(d.clientX, d.clientY);
    }
    function Te(d) {
      m.set(d.clientX, d.clientY);
    }
    function Pe(d) {
      f.set(d.clientX, d.clientY), p.subVectors(f, l).multiplyScalar(t.rotateSpeed);
      const b = t.domElement;
      z(2 * Math.PI * p.x / b.clientHeight), Q(2 * Math.PI * p.y / b.clientHeight), l.copy(f), t.update();
    }
    function Ye(d) {
      w.set(d.clientX, d.clientY), A.subVectors(w, T), A.y > 0 ? Ie(ee(A.y)) : A.y < 0 && Xe(ee(A.y)), T.copy(w), t.update();
    }
    function We(d) {
      y.set(d.clientX, d.clientY), g.subVectors(y, m).multiplyScalar(t.panSpeed), U(g.x, g.y), m.copy(y), t.update();
    }
    function qe(d) {
      de(d.clientX, d.clientY), d.deltaY < 0 ? Xe(ee(d.deltaY)) : d.deltaY > 0 && Ie(ee(d.deltaY)), t.update();
    }
    function Ze(d) {
      let b = !1;
      switch (d.code) {
        case t.keys.UP:
          d.ctrlKey || d.metaKey || d.shiftKey ? Q(2 * Math.PI * t.rotateSpeed / t.domElement.clientHeight) : U(0, t.keyPanSpeed), b = !0;
          break;
        case t.keys.BOTTOM:
          d.ctrlKey || d.metaKey || d.shiftKey ? Q(-2 * Math.PI * t.rotateSpeed / t.domElement.clientHeight) : U(0, -t.keyPanSpeed), b = !0;
          break;
        case t.keys.LEFT:
          d.ctrlKey || d.metaKey || d.shiftKey ? z(2 * Math.PI * t.rotateSpeed / t.domElement.clientHeight) : U(t.keyPanSpeed, 0), b = !0;
          break;
        case t.keys.RIGHT:
          d.ctrlKey || d.metaKey || d.shiftKey ? z(-2 * Math.PI * t.rotateSpeed / t.domElement.clientHeight) : U(-t.keyPanSpeed, 0), b = !0;
          break;
      }
      b && (d.preventDefault(), t.update());
    }
    function Ot(d) {
      if (v.length === 1)
        l.set(d.pageX, d.pageY);
      else {
        const b = Ae(d), I = 0.5 * (d.pageX + b.x), F = 0.5 * (d.pageY + b.y);
        l.set(I, F);
      }
    }
    function Dt(d) {
      if (v.length === 1)
        m.set(d.pageX, d.pageY);
      else {
        const b = Ae(d), I = 0.5 * (d.pageX + b.x), F = 0.5 * (d.pageY + b.y);
        m.set(I, F);
      }
    }
    function kt(d) {
      const b = Ae(d), I = d.pageX - b.x, F = d.pageY - b.y, H = Math.sqrt(I * I + F * F);
      T.set(0, H);
    }
    function Gn(d) {
      t.enableZoom && kt(d), t.enablePan && Dt(d);
    }
    function Un(d) {
      t.enableZoom && kt(d), t.enableRotate && Ot(d);
    }
    function Nt(d) {
      if (v.length == 1)
        f.set(d.pageX, d.pageY);
      else {
        const I = Ae(d), F = 0.5 * (d.pageX + I.x), H = 0.5 * (d.pageY + I.y);
        f.set(F, H);
      }
      p.subVectors(f, l).multiplyScalar(t.rotateSpeed);
      const b = t.domElement;
      z(2 * Math.PI * p.x / b.clientHeight), Q(2 * Math.PI * p.y / b.clientHeight), l.copy(f);
    }
    function Bt(d) {
      if (v.length === 1)
        y.set(d.pageX, d.pageY);
      else {
        const b = Ae(d), I = 0.5 * (d.pageX + b.x), F = 0.5 * (d.pageY + b.y);
        y.set(I, F);
      }
      g.subVectors(y, m).multiplyScalar(t.panSpeed), U(g.x, g.y), m.copy(y);
    }
    function jt(d) {
      const b = Ae(d), I = d.pageX - b.x, F = d.pageY - b.y, H = Math.sqrt(I * I + F * F);
      w.set(0, H), A.set(0, Math.pow(w.y / T.y, t.zoomSpeed)), Ie(A.y), T.copy(w);
      const ae = (d.pageX + b.x) * 0.5, K = (d.pageY + b.y) * 0.5;
      de(ae, K);
    }
    function Hn(d) {
      t.enableZoom && jt(d), t.enablePan && Bt(d);
    }
    function Vn(d) {
      t.enableZoom && jt(d), t.enableRotate && Nt(d);
    }
    function Gt(d) {
      t.enabled !== !1 && (v.length === 0 && (t.domElement.setPointerCapture(d.pointerId), t.domElement.addEventListener("pointermove", at), t.domElement.addEventListener("pointerup", Fe)), qn(d), d.pointerType === "touch" ? Vt(d) : zn(d));
    }
    function at(d) {
      t.enabled !== !1 && (d.pointerType === "touch" ? Wn(d) : Kn(d));
    }
    function Fe(d) {
      switch (Zn(d), v.length) {
        case 0:
          t.domElement.releasePointerCapture(d.pointerId), t.domElement.removeEventListener("pointermove", at), t.domElement.removeEventListener("pointerup", Fe), t.dispatchEvent(hn), i = s.NONE;
          break;
        case 1:
          const b = v[0], I = P[b];
          Vt({ pointerId: b, pageX: I.x, pageY: I.y });
          break;
      }
    }
    function zn(d) {
      let b;
      switch (d.button) {
        case 0:
          b = t.mouseButtons.LEFT;
          break;
        case 1:
          b = t.mouseButtons.MIDDLE;
          break;
        case 2:
          b = t.mouseButtons.RIGHT;
          break;
        default:
          b = -1;
      }
      switch (b) {
        case we.DOLLY:
          if (t.enableZoom === !1)
            return;
          me(d), i = s.DOLLY;
          break;
        case we.ROTATE:
          if (d.ctrlKey || d.metaKey || d.shiftKey) {
            if (t.enablePan === !1)
              return;
            Te(d), i = s.PAN;
          } else {
            if (t.enableRotate === !1)
              return;
            Ce(d), i = s.ROTATE;
          }
          break;
        case we.PAN:
          if (d.ctrlKey || d.metaKey || d.shiftKey) {
            if (t.enableRotate === !1)
              return;
            Ce(d), i = s.ROTATE;
          } else {
            if (t.enablePan === !1)
              return;
            Te(d), i = s.PAN;
          }
          break;
        default:
          i = s.NONE;
      }
      i !== s.NONE && t.dispatchEvent(At);
    }
    function Kn(d) {
      switch (i) {
        case s.ROTATE:
          if (t.enableRotate === !1)
            return;
          Pe(d);
          break;
        case s.DOLLY:
          if (t.enableZoom === !1)
            return;
          Ye(d);
          break;
        case s.PAN:
          if (t.enablePan === !1)
            return;
          We(d);
          break;
      }
    }
    function Ut(d) {
      t.enabled === !1 || t.enableZoom === !1 || i !== s.NONE || (d.preventDefault(), t.dispatchEvent(At), qe(Xn(d)), t.dispatchEvent(hn));
    }
    function Xn(d) {
      const b = d.deltaMode, I = {
        clientX: d.clientX,
        clientY: d.clientY,
        deltaY: d.deltaY
      };
      switch (b) {
        case 1:
          I.deltaY *= 16;
          break;
        case 2:
          I.deltaY *= 100;
          break;
      }
      return d.ctrlKey && !B && (I.deltaY *= 10), I;
    }
    function Yn(d) {
      d.key === "Control" && (B = !0, t.domElement.getRootNode().addEventListener("keyup", Ht, { passive: !0, capture: !0 }));
    }
    function Ht(d) {
      d.key === "Control" && (B = !1, t.domElement.getRootNode().removeEventListener("keyup", Ht, { passive: !0, capture: !0 }));
    }
    function ct(d) {
      t.enabled === !1 || t.enablePan === !1 || Ze(d);
    }
    function Vt(d) {
      switch (Kt(d), v.length) {
        case 1:
          switch (t.touches.ONE) {
            case xe.ROTATE:
              if (t.enableRotate === !1)
                return;
              Ot(d), i = s.TOUCH_ROTATE;
              break;
            case xe.PAN:
              if (t.enablePan === !1)
                return;
              Dt(d), i = s.TOUCH_PAN;
              break;
            default:
              i = s.NONE;
          }
          break;
        case 2:
          switch (t.touches.TWO) {
            case xe.DOLLY_PAN:
              if (t.enableZoom === !1 && t.enablePan === !1)
                return;
              Gn(d), i = s.TOUCH_DOLLY_PAN;
              break;
            case xe.DOLLY_ROTATE:
              if (t.enableZoom === !1 && t.enableRotate === !1)
                return;
              Un(d), i = s.TOUCH_DOLLY_ROTATE;
              break;
            default:
              i = s.NONE;
          }
          break;
        default:
          i = s.NONE;
      }
      i !== s.NONE && t.dispatchEvent(At);
    }
    function Wn(d) {
      switch (Kt(d), i) {
        case s.TOUCH_ROTATE:
          if (t.enableRotate === !1)
            return;
          Nt(d), t.update();
          break;
        case s.TOUCH_PAN:
          if (t.enablePan === !1)
            return;
          Bt(d), t.update();
          break;
        case s.TOUCH_DOLLY_PAN:
          if (t.enableZoom === !1 && t.enablePan === !1)
            return;
          Hn(d), t.update();
          break;
        case s.TOUCH_DOLLY_ROTATE:
          if (t.enableZoom === !1 && t.enableRotate === !1)
            return;
          Vn(d), t.update();
          break;
        default:
          i = s.NONE;
      }
    }
    function zt(d) {
      t.enabled !== !1 && d.preventDefault();
    }
    function qn(d) {
      v.push(d.pointerId);
    }
    function Zn(d) {
      delete P[d.pointerId];
      for (let b = 0; b < v.length; b++)
        if (v[b] == d.pointerId) {
          v.splice(b, 1);
          return;
        }
    }
    function Kt(d) {
      let b = P[d.pointerId];
      b === void 0 && (b = new G(), P[d.pointerId] = b), b.set(d.pageX, d.pageY);
    }
    function Ae(d) {
      const b = d.pointerId === v[0] ? v[1] : v[0];
      return P[b];
    }
    t.domElement.addEventListener("contextmenu", zt), t.domElement.addEventListener("pointerdown", Gt), t.domElement.addEventListener("pointercancel", Fe), t.domElement.addEventListener("wheel", Ut, { passive: !1 }), t.domElement.getRootNode().addEventListener("keydown", Yn, { passive: !0, capture: !0 }), this.update();
  }
}
class xr {
  constructor() {
    L(this, "name", "DebugTool");
    L(this, "version", "1.0.0");
    L(this, "viewer");
    L(this, "stats");
    L(this, "tween", null);
    L(this, "htmlCon");
    L(this, "renderManager");
    L(this, "grid");
    L(this, "axes");
    L(this, "orbitControls");
  }
  install(e) {
    this.viewer = e;
    const { renderManager: n } = e;
    this.renderManager = n, this.render(), this.htmlCon = n.container, this.viewer.debugTool = this;
  }
  uninstall() {
    this.viewer.debugTool = void 0, this.dispose();
  }
  showAxesHelper(e = 1e4) {
    this.axes || (this.axes = new Us(e), this.viewer.sceneManager.scene.add(this.axes));
  }
  showThreeGrid(e, n) {
    if (e)
      if (this.grid)
        this.renderManager.scene.remove(this.grid), this.grid = null, this.showThreeGrid(e, n);
      else {
        const t = n ? n.size : 10, s = n ? n.divisions : 10, i = n && n.colorCenterLine ? n.colorCenterLine : 4473924, r = n && n.colorGrid ? n.colorGrid : 4473924;
        this.grid = new Hs(t, s, i, r), this.renderManager.scene.add(this.grid);
      }
    else
      this.grid && (this.renderManager.scene.remove(this.grid), this.grid = null);
  }
  addCameraControl() {
    this.orbitControls = new wr(this.renderManager.camera, this.renderManager.container);
  }
  resetCamera() {
    this.orbitControls.reset();
  }
  addStats(e, n) {
    e === void 0 && (e = this.htmlCon);
    const t = new Tr(), s = t.domElement;
    t.setMode(0), s.style.position = "absolute", s.style.left = n ? `${n.x}px` : 0, s.style.top = n ? `${n.y}px` : 0, e.appendChild(s), this.stats = t;
  }
  dispose() {
    this.tween && (this.tween.stop(), this.tween = void 0), this.stats && (this.htmlCon.removeChild(this.stats.domElement), this.stats = void 0, this.htmlCon = void 0), this.showThreeGrid(!1), this.axes && (this.viewer.sceneManager.scene.remove(this.axes), this.axes = null);
  }
  render() {
    this.tween = new Ln({}).to({}, 1).repeat(1 / 0).onRepeat(() => {
      this.stats && this.stats.update(), this.orbitControls && this.orbitControls.update();
    }).start();
  }
}
class br {
  constructor(e, n) {
    L(this, "renderManager");
    L(this, "sceneManager");
    L(this, "modelManager");
    L(this, "debugTool");
    if (!e) {
      console.error("Container is not found.");
      return;
    }
    e.style.position = "relative", e.style.overflow = "hidden", this.renderManager = new zs(e, n), this.sceneManager = new Ks(n, this.renderManager), this.modelManager = new dr(), this.modelManager.install(this);
  }
  addDebugTool() {
    this.debugTool = new xr(), this.debugTool.install(this);
  }
  removeDebugTool() {
    this.debugTool && (this.debugTool.uninstall(), this.debugTool = null);
  }
  resetOrbitControl() {
    this.debugTool && this.debugTool.resetCamera();
  }
  /*  public addTestModel() {
       let cube: BoxGeometry = new BoxGeometry(10, 10, 10);
       let mat: MeshBasicMaterial = new MeshBasicMaterial({ color: 0x00ff00 });
       let mesh: Mesh = new Mesh(cube, mat);
       this.sceneManager.elementGroup.add(mesh);
       mesh.position.set(0, 0, 0);
   } */
  addModel(e, n) {
    this.modelManager.addModel(e, n);
  }
  removeModel(e) {
    this.modelManager.removeModel(e);
  }
  getModel(e) {
  }
}
const Er = "modelView", vr = /* @__PURE__ */ es({
  name: Er,
  __name: "index",
  props: {
    viewData: {},
    modelData: {},
    width: {},
    height: {}
  },
  emits: ["loadModelCom"],
  setup(h, { expose: e, emit: n }) {
    const t = n, s = h, i = ts(() => ({
      width: `${s.width}px`,
      // 确保宽度是像素值
      height: `${s.height}px`
      // 确保高度是像素值
    })), r = ns();
    var a = null, o = null;
    const u = Yt([]), l = Yt({
      threeView: null,
      modelObject: null
    });
    ss(() => {
      const g = r.value;
      a = new br(g, s.viewData), l.threeView = a;
    });
    function f() {
      o == null && (a == null || a.addModel(s.modelData, (g) => {
        o = g, u.length = 0;
        for (let T = 0; T < o.gltfAnimations.length; T++)
          u.push({ key: T, name: o.gltfAnimations[T].name });
        l.modelObject = g, t("loadModelCom", o);
      }));
    }
    function p() {
      o != null && (a == null || a.removeModel(o), o = null, u.length = 0);
    }
    function m(g, T = !1) {
      o && o.playAni(g, T);
    }
    function y() {
      o && o.stopAni();
    }
    return e({
      threeObject: l,
      aniNames: u,
      loadModelHandler: f,
      removeModel: p,
      playAni: m,
      stopAni: y
    }), (g, T) => (is(), rs("div", {
      name: "ddd",
      ref_key: "containerRef",
      ref: r,
      style: os(i.value)
    }, null, 4));
  }
}), Lr = [vr], Fr = (h) => {
  Lr.forEach((e) => {
    h.component(e.name, e);
  });
};
export {
  Tt as ModelObject,
  br as ThreeView,
  Fr as threeModelView
};
