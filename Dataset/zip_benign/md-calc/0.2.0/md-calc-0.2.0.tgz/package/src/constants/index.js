module.exports = {
  errorText: '!REF',
};
