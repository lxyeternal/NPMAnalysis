declare const defer: <T>(factory: () => import("callbag").Callbag<void, T>) => import("callbag").Callbag<void, T>;
export default defer;
