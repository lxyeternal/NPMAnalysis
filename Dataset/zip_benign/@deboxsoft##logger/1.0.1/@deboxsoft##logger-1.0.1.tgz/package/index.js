/* eslint-disable no-param-reassign */
const winston = require('winston');
const logger = require('./logger');

const createLogger = (options = {}) => {
  options.format = options.format || winston.format.combine(winston.format.splat(), winston.format.simple());
  options.transports = options.transports || [new winston.transports.Console()];
  return winston.createLogger(options);
};

const loggerMiddleware = (app, payload = {}) => {
  payload.logger = createLogger();
  app.use(logger(payload));
};

let tmpLogger;
const getLogger = () => tmpLogger || createLogger();

module.exports = {
  logger,
  getLogger,
  createLogger,
  loggerMiddleware,
};
