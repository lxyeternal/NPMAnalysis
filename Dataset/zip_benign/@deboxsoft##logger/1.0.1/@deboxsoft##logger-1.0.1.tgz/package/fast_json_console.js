const winston = require('winston');
const Transport = require('winston-transport')
const isFunction = require('lodash.isfunction')
const os = require('os');

class FastJsonConsoleTransport extends Transport {
  constructor(options = {}) {
    super();

    this.stringify = options.stringify || JSON.stringify;
    this.assign = options.assign || Object.assign;
  }
  log(info = {}, callback) {
    process.stdout.write(this.getLog(info.level, info.message, info.meta));
    isFunction(callback) && callback(null, true);
  }
  
  getLog(level, message, meta) {
    return this.stringify(this.assign({ level, message }, meta)) + os.EOL;
  }
}

module.exports = FastJsonConsoleTransport;
