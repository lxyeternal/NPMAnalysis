# TS Color Service

A utility library for working with colors in typsecript web applications. This library provides various functions to manipulate, convert, and generate colors.

## Installation

You can install the library using npm: 

`npm install color-utility-library`

## Usage

Just import the function that you need like this:

`import { lightenColor } from 'color-utility-library'`


## Available Functions


### lightenColor/darkenColor

Lightens/Darkens a color by a specified percentage.

`const lighterColor = lightenColor('#3498db', 0.2)`

`const darkerColor = darkenColor('#3498db', 0.2);`

### hexToRgb

Converts a hex color code to an RGB color object.

`const rgbColor = hexToRgb('#3498db');`


### rgbToHex

Converts an RGB color object to a hex color code.

`const hexColor = rgbToHex({ r: 52, g: 152, b: 219 });`


### interpolateColor

Interpolates between two colors based on a ratio.

`const interpolatedColor = interpolateColor('#3498db', '#ffffff', 0.5);`

### generateRandomColor

Generates a random hex color.

`const randomColor = generateRandomColor();`

### generateGradientColors

Generates an array of gradient colors based on a start color and count.

`const gradientColors = generateGradientColors('#3498db', 5);`

### calculateContrastColor

Calculates a contrasting color (black or white) for a given color.

`const contrastColor = calculateContrastColor('#3498db');`

### calculateColorDifference

Calculates the color difference between two colors.

`const colorDifference = calculateColorDifference('#3498db', '#ffffff');`

### isValidColor

Checks if a color value is valid (hex or RGB format).`


`const isValid = isValidColor('#3498db');

### calculateColorBrightness

Calculates the brightness of a color and returns "light" or "dark".

`const brightness = calculateColorBrightness('#3498db');`

### rgbToHsl

Converts an RGB color object to an HSL color object.

`const hslColor = rgbToHsl({ r: 52, g: 152, b: 219 });`

### generateContrastingColor

Generates a contrasting color (black or white) based on the brightness of the input color.

`const contrastingColor = generateContrastingColor('#3498db');`

### generateComplementaryColors

Generates an array of complementary colors for a given base color.

`const complementaryColors = generateComplementaryColors('#3498db');`

### generateSplitComplementaryColors

Generates an array of split-complementary colors for a given base color and count.

`const splitComplementaryColors = generateSplitComplementaryColors('#3498db', 3);`

### hslToRgb

Converts an HSL color object to an RGB color object.


`const rgbColor = hslToRgb({ h: 0.57, s: 0.7, l: 0.6 });`

## License

This project is available under the MIT License: [![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

