## 介绍
基于sentry封装的埋点库，支持设备指纹，后续功能待拓展。目前只能基于vue使用。


## 安装
```
// npm
npm install @fosunwealth/report -S

// yarn
yarn add @fosunwealth/report
```


## 初始化
### VUE2初始化
```
import FReport from '@fosunwealth/report';
import Vue from 'vue';
import Router from "vue-router";

const router = new Router({
  // ...
});

// vue2初始化
FReport.init({ 
    // sentry相关配置
    Vue,   
    dsn: 'your dsn',
    release: process.env.VUE_APP_RELEASE, // 版本
    tracesSampleRate: process.env.VUE_APP_ENV !== 'prod' ? 1.0 : 0.3, // 页面性能采样率
    environment: process.env.VUE_APP_ENV,  // 环境 
    
    // FReport特有配置 
    router, // vue-router实例
    autoReportRouter: true // 是否开启自动上报页面
});
```

###  VUE3初始化
```
import FReport from '@fosunwealth/report';
import { createApp } from "vue";
import { createRouter } from "vue-router";

const app = createApp({
  // ...
});
const router = createRouter({
  // ...
});

// vue2初始化
FReport.init({ 
    // sentry相关配置
    app, // vue app实例
    dsn: 'your dsn',
    release: process.env.VUE_APP_RELEASE, // 版本
    tracesSampleRate: process.env.VUE_APP_ENV !== 'prod' ? 1.0 : 0.3, // 页面性能采样率
    environment: process.env.VUE_APP_ENV,  // 环境

    // FReport特有配置 
    router, // vue-router实例
    autoReportRouter: true // 是否开启自动上报页面
});
```

## 使用
初始化完成之后，可通过进行 `window.__FREPORT` 进行访问
```
// 设置用户Id
window.__FREPORT.setId("13712345678");


// 上报消息-字符串
window.__FREPORT.report("this is a msg");


/** 
* 上报消息-对象
* 最后会组装成此字符串格式进行上报：[type]msg
 */ 
window.__FREPORT.report({
    type: "visit page",
    msg: "visit page path"
});


// 设置用户标签
window.__FREPORT.setTag("name", "123");
```

## sourcemap上传
Vue2使用SentryPlugin：https://www.npmjs.com/package/@sentry/webpack-plugin

Vue3使用vite-plugin-sentry：https://www.npmjs.com/package/vite-plugin-sentry
