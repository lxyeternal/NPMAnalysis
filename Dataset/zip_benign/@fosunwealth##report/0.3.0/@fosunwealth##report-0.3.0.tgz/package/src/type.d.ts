declare interface Window {
  __FREPORT: any;
}
