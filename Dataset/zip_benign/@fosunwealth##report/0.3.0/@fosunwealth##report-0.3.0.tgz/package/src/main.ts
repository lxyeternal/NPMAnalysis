import * as Sentry from "@sentry/vue";
import FingerprintJS from "@fingerprintjs/fingerprintjs";
import { BrowserTracing } from "@sentry/tracing";

interface ReportmsgData {
  type: string;
  msg: string;
}

interface InitConfig {
  router: any; // vue-router实例
  autoReportRouter?: boolean; // 是否开启report自动上报
}

interface MethodFactoryFunc<T extends (...args: Parameters<T>) => any> {
  (...args: Parameters<T>): ReturnType<T> | undefined;
}

type SentryInitConfig = Parameters<typeof Sentry.init>[0];

function methodFactory<T extends (...args: Parameters<T>) => any>(
  method: T
): MethodFactoryFunc<T> {
  const _wrapperMethod: MethodFactoryFunc<T> = (...args) => {
    if (window.__FREPORT) {
      return method.apply(null, args);
    } else {
      console.warn("FReport还未初始化");
      return;
    }
  };

  return _wrapperMethod;
}

export class FReport {
  public deviceId = null; // 设备Id
  public msgList: string[] = []; // 待上报的消息队列

  init(config: SentryInitConfig & InitConfig) {
    const { router, autoReportRouter } = config;

    if (!window.__FREPORT) {
      Sentry.init({
        integrations: [
          new BrowserTracing({
            routingInstrumentation: Sentry.vueRouterInstrumentation(router),
            tracingOrigins: [/^\//],
          }),
        ],
        ignoreErrors: ["ResizeObserver loop limit exceeded"],
        ...config,
      });
      initDeviceId().then(() => {
        this.clearMsgList();
      });
      window.__FREPORT = this;

      if (autoReportRouter) {
        router.beforeEach((to: any, from: any, next: any) => {
          const path = to.path.replace(/^\//, "");
          this.report({
            type: "page",
            msg: path,
          });
          next();
        });
      }
    }

    return window.__FREPORT;
  }

  setId = methodFactory((id: any) => {
    Sentry.setUser({ id });
  });

  report = methodFactory((msgData: string | ReportmsgData) => {
    if (msgData && typeof msgData === "object") {
      msgData = `[${msgData.type}]${msgData.msg || ""}`;
    }

    if (this.deviceId) {
      Sentry.captureMessage(msgData);
    } else {
      this.msgList.push(msgData);
    }
  });

  setTag = methodFactory((name: string, value: string) => {
    Sentry.setTag(name, value);
  });

  private clearMsgList() {
    this.msgList.forEach((msg) => {
      Sentry.captureMessage(msg);
    });
    this.msgList = [];
  }
}

async function initDeviceId() {
  const fp = await FingerprintJS.load();
  const result = await fp.get();
  const visitorId = result.visitorId;
  Sentry.setTag("deviceId", visitorId);
  return visitorId;
}
