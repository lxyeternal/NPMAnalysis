import { FReport } from "./src/main";

export default new FReport();
