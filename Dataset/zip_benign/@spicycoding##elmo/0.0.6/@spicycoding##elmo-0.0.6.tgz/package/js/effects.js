import 'gsap/umd/TweenMax';

const engine = {
    /**
     * Properties
     */
    timeout: 0,
    scrollDelay: 0,
    queuedElements: [],
    offset: 0,

    /**
     * All the effects are defined right here
     */
    effects: {
        // Slide
        'slideUp': {direction: 'from', duration: 0.5, y: 75},
        'slideDown': {direction: 'from', duration: 0.5, y: -75},
        'slideLeft': {direction: 'from', duration: 0.5, x: 75},
        'slideRight': {direction: 'from', duration: 0.5, x: -75},

        // Zoom
        'zoomIn': {direction: 'to', duration: 0.5, scale: 1.2},
        'zoomOut': {direction: 'to', duration: 0.5, scale: 0.8},

        // Zoom
        'fadeIn': {direction: 'to', duration: 1, opacity: 1},
        'fadeOut': {direction: 'to', duration: 1, opacity: 0},
    },

    /**
     * Start the engine!
     */
    start(options = {}) {
        engine.offset = options.offset || engine.offset;

        window.addEventListener('scroll', engine.handleQueue);

        document.querySelectorAll(engine.getSelectors()).forEach(element => {
            element.getAttribute('data-effect').split('|').forEach(effect => engine.runEffect(element, effect));
        });
    },

    /**
     * Run the effect
     *
     * @param element
     * @param dataEffect
     * @param queuePosition
     */
    runEffect(element, dataEffect, queuePosition = null) {
        // Split on : in case we need to handle custom durations
        dataEffect = dataEffect.split(':');

        // Determine the duration
        const duration = typeof dataEffect[1] === 'undefined' ? null : dataEffect[1];

        // The first item in the array always is the effect name
        dataEffect = dataEffect[0];

        // Set data
        const effect = engine.effects[dataEffect].css || engine.effects[dataEffect];
        const inViewport = engine.isElementInViewport(element);
        const isQueuedItem = queuePosition !== null;

        // Effect found and a valid direction?
        if (typeof effect === 'undefined' || typeof effect.direction === 'undefined') {
            return;
        }

        // Elements that must fade in, must be invisble on page load
        if (dataEffect === 'fadeIn' && element.style.getPropertyValue('opacity') !== '0') {
            TweenLite.to(element, 0, {opacity: 0});
        }

        // In viewport? Otherwise add to queue
        if (!inViewport && !isQueuedItem) {
            engine.queuedElements.push(element);

            return;
        }

        // Not in viewport but already added to the queue?
        if (!inViewport) {
            return;
        }

        // Is this a queued element? Then remove it from the queue
        if (isQueuedItem) {
            engine.queuedElements.splice(queuePosition, 1);
        }

        // Element is in the viewport, start the effect!
        TweenLite[effect.direction](element, duration ? duration : effect.duration, effect);
    },

    /**
     * Generate a string that includes all the selectors we are searching for in our DOM
     *
     * @returns {string}
     */
    getSelectors() {
        let selectors = '';

        Object.keys(engine.effects).forEach(effect => selectors += `[data-effect*="${effect}"], `);

        return selectors.substring(0, selectors.length - 2);
    },

    /**
     * Handle the queue
     */
    handleQueue() {
        const totalInQueue = engine.queuedElements.length;

        // Nothing in the queue? Then remove the event listener
        if (!totalInQueue) {
            window.removeEventListener('scroll', engine.handleQueue);

            return;
        }

        clearTimeout(engine.timeout);

        engine.timeout = setTimeout(() => {
            engine.queuedElements.forEach((element, queuePosition) => {
                element.getAttribute('data-effect').split('|').forEach(effect => engine.runEffect(element, effect, queuePosition));
            });
        }, engine.scrollDelay);
    },

    /**
     * Determine if any part of the given element is in the viewport
     *
     * @param element
     * @returns {boolean}
     */
    isElementInViewport(element) {
        const rect = element.getBoundingClientRect();
        const isInViewport = (
            (rect.top + engine.offset) >= 0 &&
            rect.left >= 0 &&
            (rect.bottom - engine.offset) <= (window.innerHeight || document. documentElement.clientHeight) &&
            rect.right <= (window.innerWidth || document. documentElement.clientWidth)
        );

        return isInViewport;
    }
};

// Start the engine!
module.exports = engine;