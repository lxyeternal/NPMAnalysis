export declare class TiltModule {
}
