import { OnInit, OnDestroy, ElementRef, EventEmitter } from "@angular/core";
import { TiltOptions, TiltValues } from "vanilla-tilt";
export declare class TiltDirective implements OnInit, OnDestroy {
    private el;
    tiltOptions: TiltOptions | undefined;
    tiltChange: EventEmitter<TiltValues>;
    private vanillaTilt;
    private onTiltChange;
    constructor(el: ElementRef<HTMLElement>);
    ngOnInit(): void;
    ngOnDestroy(): void;
    getValues(): TiltValues;
    reset(): void;
    private handleTiltChange;
}
