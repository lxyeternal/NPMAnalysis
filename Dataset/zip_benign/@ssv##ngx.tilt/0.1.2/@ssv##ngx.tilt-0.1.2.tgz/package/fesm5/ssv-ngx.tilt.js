import VanillaTilt from 'vanilla-tilt';
import { Directive, Input, ElementRef, Output, EventEmitter, NgModule } from '@angular/core';

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var TiltDirective = /** @class */ (function () {
    function TiltDirective(el) {
        this.el = el;
        this.tiltChange = new EventEmitter();
        this.onTiltChange = this.handleTiltChange.bind(this);
    }
    /**
     * @return {?}
     */
    TiltDirective.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
        this.vanillaTilt = new VanillaTilt(this.el.nativeElement, this.tiltOptions);
        this.el.nativeElement.addEventListener("tiltChange", this.onTiltChange);
    };
    /**
     * @return {?}
     */
    TiltDirective.prototype.ngOnDestroy = /**
     * @return {?}
     */
    function () {
        if (this.vanillaTilt) {
            this.vanillaTilt.destroy();
        }
        this.el.nativeElement.removeEventListener("tiltChange", this.onTiltChange);
    };
    /**
     * @return {?}
     */
    TiltDirective.prototype.getValues = /**
     * @return {?}
     */
    function () {
        return this.vanillaTilt.getValues();
    };
    /**
     * @return {?}
     */
    TiltDirective.prototype.reset = /**
     * @return {?}
     */
    function () {
        this.vanillaTilt.reset();
    };
    /**
     * @private
     * @param {?} event
     * @return {?}
     */
    TiltDirective.prototype.handleTiltChange = /**
     * @private
     * @param {?} event
     * @return {?}
     */
    function (event) {
        this.tiltChange.emit(event.detail);
    };
    TiltDirective.decorators = [
        { type: Directive, args: [{
                    selector: "[ssvTilt]",
                    exportAs: "ssvTilt",
                },] }
    ];
    /** @nocollapse */
    TiltDirective.ctorParameters = function () { return [
        { type: ElementRef }
    ]; };
    TiltDirective.propDecorators = {
        tiltOptions: [{ type: Input }],
        tiltChange: [{ type: Output }]
    };
    return TiltDirective;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var TiltModule = /** @class */ (function () {
    function TiltModule() {
    }
    TiltModule.decorators = [
        { type: NgModule, args: [{
                    declarations: [TiltDirective],
                    exports: [TiltDirective]
                },] }
    ];
    return TiltModule;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/** @type {?} */
var VERSION = "0.1.2";

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

export { TiltModule, VERSION, TiltDirective as ɵa };

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3N2LW5neC50aWx0LmpzLm1hcCIsInNvdXJjZXMiOlsibmc6Ly9Ac3N2L25neC50aWx0L3RpbHQuZGlyZWN0aXZlLnRzIiwibmc6Ly9Ac3N2L25neC50aWx0L21vZHVsZS50cyIsIm5nOi8vQHNzdi9uZ3gudGlsdC92ZXJzaW9uLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBWYW5pbGxhVGlsdCBmcm9tIFwidmFuaWxsYS10aWx0XCI7XG5pbXBvcnQgeyBPbkluaXQsIE9uRGVzdHJveSwgRGlyZWN0aXZlLCBJbnB1dCwgRWxlbWVudFJlZiwgT3V0cHV0LCBFdmVudEVtaXR0ZXIgfSBmcm9tIFwiQGFuZ3VsYXIvY29yZVwiO1xuaW1wb3J0IHsgVGlsdE9wdGlvbnMsIFRpbHRWYWx1ZXMgfSBmcm9tIFwidmFuaWxsYS10aWx0XCI7XG5cbkBEaXJlY3RpdmUoe1xuXHRzZWxlY3RvcjogXCJbc3N2VGlsdF1cIixcblx0ZXhwb3J0QXM6IFwic3N2VGlsdFwiLFxufSlcbmV4cG9ydCBjbGFzcyBUaWx0RGlyZWN0aXZlIGltcGxlbWVudHMgT25Jbml0LCBPbkRlc3Ryb3kge1xuXG5cdEBJbnB1dCgpIHRpbHRPcHRpb25zOiBUaWx0T3B0aW9ucyB8IHVuZGVmaW5lZDtcblxuXHRAT3V0cHV0KCkgdGlsdENoYW5nZSA9IG5ldyBFdmVudEVtaXR0ZXI8VGlsdFZhbHVlcz4oKTtcblxuXHRwcml2YXRlIHZhbmlsbGFUaWx0ITogVmFuaWxsYVRpbHQ7XG5cdHByaXZhdGUgb25UaWx0Q2hhbmdlID0gdGhpcy5oYW5kbGVUaWx0Q2hhbmdlLmJpbmQodGhpcyk7XG5cblx0Y29uc3RydWN0b3IoXG5cdFx0cHJpdmF0ZSBlbDogRWxlbWVudFJlZjxIVE1MRWxlbWVudD4sXG5cdCkge1xuXHR9XG5cblx0bmdPbkluaXQoKSB7XG5cdFx0dGhpcy52YW5pbGxhVGlsdCA9IG5ldyBWYW5pbGxhVGlsdCh0aGlzLmVsLm5hdGl2ZUVsZW1lbnQsIHRoaXMudGlsdE9wdGlvbnMpO1xuXHRcdHRoaXMuZWwubmF0aXZlRWxlbWVudC5hZGRFdmVudExpc3RlbmVyKFwidGlsdENoYW5nZVwiLCB0aGlzLm9uVGlsdENoYW5nZSk7XG5cdH1cblxuXHRuZ09uRGVzdHJveSgpIHtcblx0XHRpZiAodGhpcy52YW5pbGxhVGlsdCkge1xuXHRcdFx0dGhpcy52YW5pbGxhVGlsdC5kZXN0cm95KCk7XG5cdFx0fVxuXHRcdHRoaXMuZWwubmF0aXZlRWxlbWVudC5yZW1vdmVFdmVudExpc3RlbmVyKFwidGlsdENoYW5nZVwiLCB0aGlzLm9uVGlsdENoYW5nZSk7XG5cdH1cblxuXHRnZXRWYWx1ZXMoKTogVGlsdFZhbHVlcyB7XG5cdFx0cmV0dXJuIHRoaXMudmFuaWxsYVRpbHQuZ2V0VmFsdWVzKCk7XG5cdH1cblxuXHRyZXNldCgpIHtcblx0XHR0aGlzLnZhbmlsbGFUaWx0LnJlc2V0KCk7XG5cdH1cblxuXHRwcml2YXRlIGhhbmRsZVRpbHRDaGFuZ2UoZXZlbnQ6IEN1c3RvbUV2ZW50PFRpbHRWYWx1ZXM+KSB7XG5cdFx0dGhpcy50aWx0Q2hhbmdlLmVtaXQoZXZlbnQuZGV0YWlsKTtcblx0fVxufSIsImltcG9ydCB7IE5nTW9kdWxlIH0gZnJvbSBcIkBhbmd1bGFyL2NvcmVcIjtcblxuaW1wb3J0IHsgVGlsdERpcmVjdGl2ZSB9IGZyb20gXCIuL3RpbHQuZGlyZWN0aXZlXCI7XG5cbkBOZ01vZHVsZSh7XG5cdGRlY2xhcmF0aW9uczogW1RpbHREaXJlY3RpdmVdLFxuXHRleHBvcnRzOiBbVGlsdERpcmVjdGl2ZV1cbn0pXG5leHBvcnQgY2xhc3MgVGlsdE1vZHVsZSB7XG59IiwiZXhwb3J0IGNvbnN0IFZFUlNJT04gPSBcIjAuMS4yXCI7Il0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFBQTtJQWlCQyx1QkFDUyxFQUEyQjtRQUEzQixPQUFFLEdBQUYsRUFBRSxDQUF5QjtRQU4xQixlQUFVLEdBQUcsSUFBSSxZQUFZLEVBQWMsQ0FBQztRQUc5QyxpQkFBWSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7S0FLdkQ7Ozs7SUFFRCxnQ0FBUTs7O0lBQVI7UUFDQyxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksV0FBVyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsYUFBYSxFQUFFLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUM1RSxJQUFJLENBQUMsRUFBRSxDQUFDLGFBQWEsQ0FBQyxnQkFBZ0IsQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO0tBQ3hFOzs7O0lBRUQsbUNBQVc7OztJQUFYO1FBQ0MsSUFBSSxJQUFJLENBQUMsV0FBVyxFQUFFO1lBQ3JCLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxFQUFFLENBQUM7U0FDM0I7UUFDRCxJQUFJLENBQUMsRUFBRSxDQUFDLGFBQWEsQ0FBQyxtQkFBbUIsQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO0tBQzNFOzs7O0lBRUQsaUNBQVM7OztJQUFUO1FBQ0MsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsRUFBRSxDQUFDO0tBQ3BDOzs7O0lBRUQsNkJBQUs7OztJQUFMO1FBQ0MsSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLEVBQUUsQ0FBQztLQUN6Qjs7Ozs7O0lBRU8sd0NBQWdCOzs7OztJQUF4QixVQUF5QixLQUE4QjtRQUN0RCxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUM7S0FDbkM7O2dCQXhDRCxTQUFTLFNBQUM7b0JBQ1YsUUFBUSxFQUFFLFdBQVc7b0JBQ3JCLFFBQVEsRUFBRSxTQUFTO2lCQUNuQjs7OztnQkFONkMsVUFBVTs7OzhCQVN0RCxLQUFLOzZCQUVMLE1BQU07O0lBaUNSLG9CQUFDO0NBekNEOzs7Ozs7QUNKQTtJQUlBO0tBS0M7O2dCQUxBLFFBQVEsU0FBQztvQkFDVCxZQUFZLEVBQUUsQ0FBQyxhQUFhLENBQUM7b0JBQzdCLE9BQU8sRUFBRSxDQUFDLGFBQWEsQ0FBQztpQkFDeEI7O0lBRUQsaUJBQUM7Q0FMRDs7Ozs7OztBQ0pBLElBQWEsT0FBTyxHQUFHLE9BQU87Ozs7Ozs7Ozs7Ozs7OyJ9