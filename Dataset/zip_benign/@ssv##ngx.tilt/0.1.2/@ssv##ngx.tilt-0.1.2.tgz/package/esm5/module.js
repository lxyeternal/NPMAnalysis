/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
import { NgModule } from "@angular/core";
import { TiltDirective } from "./tilt.directive";
var TiltModule = /** @class */ (function () {
    function TiltModule() {
    }
    TiltModule.decorators = [
        { type: NgModule, args: [{
                    declarations: [TiltDirective],
                    exports: [TiltDirective]
                },] }
    ];
    return TiltModule;
}());
export { TiltModule };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibW9kdWxlLmpzIiwic291cmNlUm9vdCI6Im5nOi8vQHNzdi9uZ3gudGlsdC8iLCJzb3VyY2VzIjpbIm1vZHVsZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7O0FBQUEsT0FBTyxFQUFFLFFBQVEsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUV6QyxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0sa0JBQWtCLENBQUM7QUFFakQ7SUFBQTtJQUtBLENBQUM7O2dCQUxBLFFBQVEsU0FBQztvQkFDVCxZQUFZLEVBQUUsQ0FBQyxhQUFhLENBQUM7b0JBQzdCLE9BQU8sRUFBRSxDQUFDLGFBQWEsQ0FBQztpQkFDeEI7O0lBRUQsaUJBQUM7Q0FBQSxBQUxELElBS0M7U0FEWSxVQUFVIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTmdNb2R1bGUgfSBmcm9tIFwiQGFuZ3VsYXIvY29yZVwiO1xuXG5pbXBvcnQgeyBUaWx0RGlyZWN0aXZlIH0gZnJvbSBcIi4vdGlsdC5kaXJlY3RpdmVcIjtcblxuQE5nTW9kdWxlKHtcblx0ZGVjbGFyYXRpb25zOiBbVGlsdERpcmVjdGl2ZV0sXG5cdGV4cG9ydHM6IFtUaWx0RGlyZWN0aXZlXVxufSlcbmV4cG9ydCBjbGFzcyBUaWx0TW9kdWxlIHtcbn0iXX0=