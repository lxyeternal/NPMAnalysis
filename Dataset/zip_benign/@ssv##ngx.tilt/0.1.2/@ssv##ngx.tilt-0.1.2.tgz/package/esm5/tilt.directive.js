/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
import VanillaTilt from "vanilla-tilt";
import { Directive, Input, ElementRef, Output, EventEmitter } from "@angular/core";
var TiltDirective = /** @class */ (function () {
    function TiltDirective(el) {
        this.el = el;
        this.tiltChange = new EventEmitter();
        this.onTiltChange = this.handleTiltChange.bind(this);
    }
    /**
     * @return {?}
     */
    TiltDirective.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
        this.vanillaTilt = new VanillaTilt(this.el.nativeElement, this.tiltOptions);
        this.el.nativeElement.addEventListener("tiltChange", this.onTiltChange);
    };
    /**
     * @return {?}
     */
    TiltDirective.prototype.ngOnDestroy = /**
     * @return {?}
     */
    function () {
        if (this.vanillaTilt) {
            this.vanillaTilt.destroy();
        }
        this.el.nativeElement.removeEventListener("tiltChange", this.onTiltChange);
    };
    /**
     * @return {?}
     */
    TiltDirective.prototype.getValues = /**
     * @return {?}
     */
    function () {
        return this.vanillaTilt.getValues();
    };
    /**
     * @return {?}
     */
    TiltDirective.prototype.reset = /**
     * @return {?}
     */
    function () {
        this.vanillaTilt.reset();
    };
    /**
     * @private
     * @param {?} event
     * @return {?}
     */
    TiltDirective.prototype.handleTiltChange = /**
     * @private
     * @param {?} event
     * @return {?}
     */
    function (event) {
        this.tiltChange.emit(event.detail);
    };
    TiltDirective.decorators = [
        { type: Directive, args: [{
                    selector: "[ssvTilt]",
                    exportAs: "ssvTilt",
                },] }
    ];
    /** @nocollapse */
    TiltDirective.ctorParameters = function () { return [
        { type: ElementRef }
    ]; };
    TiltDirective.propDecorators = {
        tiltOptions: [{ type: Input }],
        tiltChange: [{ type: Output }]
    };
    return TiltDirective;
}());
export { TiltDirective };
if (false) {
    /** @type {?} */
    TiltDirective.prototype.tiltOptions;
    /** @type {?} */
    TiltDirective.prototype.tiltChange;
    /**
     * @type {?}
     * @private
     */
    TiltDirective.prototype.vanillaTilt;
    /**
     * @type {?}
     * @private
     */
    TiltDirective.prototype.onTiltChange;
    /**
     * @type {?}
     * @private
     */
    TiltDirective.prototype.el;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGlsdC5kaXJlY3RpdmUuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9Ac3N2L25neC50aWx0LyIsInNvdXJjZXMiOlsidGlsdC5kaXJlY3RpdmUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7OztBQUFBLE9BQU8sV0FBVyxNQUFNLGNBQWMsQ0FBQztBQUN2QyxPQUFPLEVBQXFCLFNBQVMsRUFBRSxLQUFLLEVBQUUsVUFBVSxFQUFFLE1BQU0sRUFBRSxZQUFZLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFHdEc7SUFhQyx1QkFDUyxFQUEyQjtRQUEzQixPQUFFLEdBQUYsRUFBRSxDQUF5QjtRQU4xQixlQUFVLEdBQUcsSUFBSSxZQUFZLEVBQWMsQ0FBQztRQUc5QyxpQkFBWSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7SUFLeEQsQ0FBQzs7OztJQUVELGdDQUFROzs7SUFBUjtRQUNDLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxXQUFXLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxhQUFhLEVBQUUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBQzVFLElBQUksQ0FBQyxFQUFFLENBQUMsYUFBYSxDQUFDLGdCQUFnQixDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7SUFDekUsQ0FBQzs7OztJQUVELG1DQUFXOzs7SUFBWDtRQUNDLElBQUksSUFBSSxDQUFDLFdBQVcsRUFBRTtZQUNyQixJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sRUFBRSxDQUFDO1NBQzNCO1FBQ0QsSUFBSSxDQUFDLEVBQUUsQ0FBQyxhQUFhLENBQUMsbUJBQW1CLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQztJQUM1RSxDQUFDOzs7O0lBRUQsaUNBQVM7OztJQUFUO1FBQ0MsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsRUFBRSxDQUFDO0lBQ3JDLENBQUM7Ozs7SUFFRCw2QkFBSzs7O0lBQUw7UUFDQyxJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssRUFBRSxDQUFDO0lBQzFCLENBQUM7Ozs7OztJQUVPLHdDQUFnQjs7Ozs7SUFBeEIsVUFBeUIsS0FBOEI7UUFDdEQsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0lBQ3BDLENBQUM7O2dCQXhDRCxTQUFTLFNBQUM7b0JBQ1YsUUFBUSxFQUFFLFdBQVc7b0JBQ3JCLFFBQVEsRUFBRSxTQUFTO2lCQUNuQjs7OztnQkFONkMsVUFBVTs7OzhCQVN0RCxLQUFLOzZCQUVMLE1BQU07O0lBaUNSLG9CQUFDO0NBQUEsQUF6Q0QsSUF5Q0M7U0FyQ1ksYUFBYTs7O0lBRXpCLG9DQUE4Qzs7SUFFOUMsbUNBQXNEOzs7OztJQUV0RCxvQ0FBa0M7Ozs7O0lBQ2xDLHFDQUF3RDs7Ozs7SUFHdkQsMkJBQW1DIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFZhbmlsbGFUaWx0IGZyb20gXCJ2YW5pbGxhLXRpbHRcIjtcbmltcG9ydCB7IE9uSW5pdCwgT25EZXN0cm95LCBEaXJlY3RpdmUsIElucHV0LCBFbGVtZW50UmVmLCBPdXRwdXQsIEV2ZW50RW1pdHRlciB9IGZyb20gXCJAYW5ndWxhci9jb3JlXCI7XG5pbXBvcnQgeyBUaWx0T3B0aW9ucywgVGlsdFZhbHVlcyB9IGZyb20gXCJ2YW5pbGxhLXRpbHRcIjtcblxuQERpcmVjdGl2ZSh7XG5cdHNlbGVjdG9yOiBcIltzc3ZUaWx0XVwiLFxuXHRleHBvcnRBczogXCJzc3ZUaWx0XCIsXG59KVxuZXhwb3J0IGNsYXNzIFRpbHREaXJlY3RpdmUgaW1wbGVtZW50cyBPbkluaXQsIE9uRGVzdHJveSB7XG5cblx0QElucHV0KCkgdGlsdE9wdGlvbnM6IFRpbHRPcHRpb25zIHwgdW5kZWZpbmVkO1xuXG5cdEBPdXRwdXQoKSB0aWx0Q2hhbmdlID0gbmV3IEV2ZW50RW1pdHRlcjxUaWx0VmFsdWVzPigpO1xuXG5cdHByaXZhdGUgdmFuaWxsYVRpbHQhOiBWYW5pbGxhVGlsdDtcblx0cHJpdmF0ZSBvblRpbHRDaGFuZ2UgPSB0aGlzLmhhbmRsZVRpbHRDaGFuZ2UuYmluZCh0aGlzKTtcblxuXHRjb25zdHJ1Y3Rvcihcblx0XHRwcml2YXRlIGVsOiBFbGVtZW50UmVmPEhUTUxFbGVtZW50Pixcblx0KSB7XG5cdH1cblxuXHRuZ09uSW5pdCgpIHtcblx0XHR0aGlzLnZhbmlsbGFUaWx0ID0gbmV3IFZhbmlsbGFUaWx0KHRoaXMuZWwubmF0aXZlRWxlbWVudCwgdGhpcy50aWx0T3B0aW9ucyk7XG5cdFx0dGhpcy5lbC5uYXRpdmVFbGVtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJ0aWx0Q2hhbmdlXCIsIHRoaXMub25UaWx0Q2hhbmdlKTtcblx0fVxuXG5cdG5nT25EZXN0cm95KCkge1xuXHRcdGlmICh0aGlzLnZhbmlsbGFUaWx0KSB7XG5cdFx0XHR0aGlzLnZhbmlsbGFUaWx0LmRlc3Ryb3koKTtcblx0XHR9XG5cdFx0dGhpcy5lbC5uYXRpdmVFbGVtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJ0aWx0Q2hhbmdlXCIsIHRoaXMub25UaWx0Q2hhbmdlKTtcblx0fVxuXG5cdGdldFZhbHVlcygpOiBUaWx0VmFsdWVzIHtcblx0XHRyZXR1cm4gdGhpcy52YW5pbGxhVGlsdC5nZXRWYWx1ZXMoKTtcblx0fVxuXG5cdHJlc2V0KCkge1xuXHRcdHRoaXMudmFuaWxsYVRpbHQucmVzZXQoKTtcblx0fVxuXG5cdHByaXZhdGUgaGFuZGxlVGlsdENoYW5nZShldmVudDogQ3VzdG9tRXZlbnQ8VGlsdFZhbHVlcz4pIHtcblx0XHR0aGlzLnRpbHRDaGFuZ2UuZW1pdChldmVudC5kZXRhaWwpO1xuXHR9XG59Il19