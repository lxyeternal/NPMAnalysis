(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('vanilla-tilt'), require('@angular/core')) :
    typeof define === 'function' && define.amd ? define('@ssv/ngx.tilt', ['exports', 'vanilla-tilt', '@angular/core'], factory) :
    (factory((global.ssv = global.ssv || {}, global.ssv.ngx = global.ssv.ngx || {}, global.ssv.ngx.tilt = {}),global.vanillaTilt,global.ng.core));
}(this, (function (exports,VanillaTilt,core) { 'use strict';

    VanillaTilt = VanillaTilt && VanillaTilt.hasOwnProperty('default') ? VanillaTilt['default'] : VanillaTilt;

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var TiltDirective = /** @class */ (function () {
        function TiltDirective(el) {
            this.el = el;
            this.tiltChange = new core.EventEmitter();
            this.onTiltChange = this.handleTiltChange.bind(this);
        }
        /**
         * @return {?}
         */
        TiltDirective.prototype.ngOnInit = /**
         * @return {?}
         */
            function () {
                this.vanillaTilt = new VanillaTilt(this.el.nativeElement, this.tiltOptions);
                this.el.nativeElement.addEventListener("tiltChange", this.onTiltChange);
            };
        /**
         * @return {?}
         */
        TiltDirective.prototype.ngOnDestroy = /**
         * @return {?}
         */
            function () {
                if (this.vanillaTilt) {
                    this.vanillaTilt.destroy();
                }
                this.el.nativeElement.removeEventListener("tiltChange", this.onTiltChange);
            };
        /**
         * @return {?}
         */
        TiltDirective.prototype.getValues = /**
         * @return {?}
         */
            function () {
                return this.vanillaTilt.getValues();
            };
        /**
         * @return {?}
         */
        TiltDirective.prototype.reset = /**
         * @return {?}
         */
            function () {
                this.vanillaTilt.reset();
            };
        /**
         * @private
         * @param {?} event
         * @return {?}
         */
        TiltDirective.prototype.handleTiltChange = /**
         * @private
         * @param {?} event
         * @return {?}
         */
            function (event) {
                this.tiltChange.emit(event.detail);
            };
        TiltDirective.decorators = [
            { type: core.Directive, args: [{
                        selector: "[ssvTilt]",
                        exportAs: "ssvTilt",
                    },] }
        ];
        /** @nocollapse */
        TiltDirective.ctorParameters = function () {
            return [
                { type: core.ElementRef }
            ];
        };
        TiltDirective.propDecorators = {
            tiltOptions: [{ type: core.Input }],
            tiltChange: [{ type: core.Output }]
        };
        return TiltDirective;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var TiltModule = /** @class */ (function () {
        function TiltModule() {
        }
        TiltModule.decorators = [
            { type: core.NgModule, args: [{
                        declarations: [TiltDirective],
                        exports: [TiltDirective]
                    },] }
        ];
        return TiltModule;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /** @type {?} */
    var VERSION = "0.1.2";

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    exports.TiltModule = TiltModule;
    exports.VERSION = VERSION;
    exports.ɵa = TiltDirective;

    Object.defineProperty(exports, '__esModule', { value: true });

})));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3N2LW5neC50aWx0LnVtZC5qcy5tYXAiLCJzb3VyY2VzIjpbIm5nOi8vQHNzdi9uZ3gudGlsdC90aWx0LmRpcmVjdGl2ZS50cyIsIm5nOi8vQHNzdi9uZ3gudGlsdC9tb2R1bGUudHMiLCJuZzovL0Bzc3Yvbmd4LnRpbHQvdmVyc2lvbi50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgVmFuaWxsYVRpbHQgZnJvbSBcInZhbmlsbGEtdGlsdFwiO1xuaW1wb3J0IHsgT25Jbml0LCBPbkRlc3Ryb3ksIERpcmVjdGl2ZSwgSW5wdXQsIEVsZW1lbnRSZWYsIE91dHB1dCwgRXZlbnRFbWl0dGVyIH0gZnJvbSBcIkBhbmd1bGFyL2NvcmVcIjtcbmltcG9ydCB7IFRpbHRPcHRpb25zLCBUaWx0VmFsdWVzIH0gZnJvbSBcInZhbmlsbGEtdGlsdFwiO1xuXG5ARGlyZWN0aXZlKHtcblx0c2VsZWN0b3I6IFwiW3NzdlRpbHRdXCIsXG5cdGV4cG9ydEFzOiBcInNzdlRpbHRcIixcbn0pXG5leHBvcnQgY2xhc3MgVGlsdERpcmVjdGl2ZSBpbXBsZW1lbnRzIE9uSW5pdCwgT25EZXN0cm95IHtcblxuXHRASW5wdXQoKSB0aWx0T3B0aW9uczogVGlsdE9wdGlvbnMgfCB1bmRlZmluZWQ7XG5cblx0QE91dHB1dCgpIHRpbHRDaGFuZ2UgPSBuZXcgRXZlbnRFbWl0dGVyPFRpbHRWYWx1ZXM+KCk7XG5cblx0cHJpdmF0ZSB2YW5pbGxhVGlsdCE6IFZhbmlsbGFUaWx0O1xuXHRwcml2YXRlIG9uVGlsdENoYW5nZSA9IHRoaXMuaGFuZGxlVGlsdENoYW5nZS5iaW5kKHRoaXMpO1xuXG5cdGNvbnN0cnVjdG9yKFxuXHRcdHByaXZhdGUgZWw6IEVsZW1lbnRSZWY8SFRNTEVsZW1lbnQ+LFxuXHQpIHtcblx0fVxuXG5cdG5nT25Jbml0KCkge1xuXHRcdHRoaXMudmFuaWxsYVRpbHQgPSBuZXcgVmFuaWxsYVRpbHQodGhpcy5lbC5uYXRpdmVFbGVtZW50LCB0aGlzLnRpbHRPcHRpb25zKTtcblx0XHR0aGlzLmVsLm5hdGl2ZUVsZW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihcInRpbHRDaGFuZ2VcIiwgdGhpcy5vblRpbHRDaGFuZ2UpO1xuXHR9XG5cblx0bmdPbkRlc3Ryb3koKSB7XG5cdFx0aWYgKHRoaXMudmFuaWxsYVRpbHQpIHtcblx0XHRcdHRoaXMudmFuaWxsYVRpbHQuZGVzdHJveSgpO1xuXHRcdH1cblx0XHR0aGlzLmVsLm5hdGl2ZUVsZW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcihcInRpbHRDaGFuZ2VcIiwgdGhpcy5vblRpbHRDaGFuZ2UpO1xuXHR9XG5cblx0Z2V0VmFsdWVzKCk6IFRpbHRWYWx1ZXMge1xuXHRcdHJldHVybiB0aGlzLnZhbmlsbGFUaWx0LmdldFZhbHVlcygpO1xuXHR9XG5cblx0cmVzZXQoKSB7XG5cdFx0dGhpcy52YW5pbGxhVGlsdC5yZXNldCgpO1xuXHR9XG5cblx0cHJpdmF0ZSBoYW5kbGVUaWx0Q2hhbmdlKGV2ZW50OiBDdXN0b21FdmVudDxUaWx0VmFsdWVzPikge1xuXHRcdHRoaXMudGlsdENoYW5nZS5lbWl0KGV2ZW50LmRldGFpbCk7XG5cdH1cbn0iLCJpbXBvcnQgeyBOZ01vZHVsZSB9IGZyb20gXCJAYW5ndWxhci9jb3JlXCI7XG5cbmltcG9ydCB7IFRpbHREaXJlY3RpdmUgfSBmcm9tIFwiLi90aWx0LmRpcmVjdGl2ZVwiO1xuXG5ATmdNb2R1bGUoe1xuXHRkZWNsYXJhdGlvbnM6IFtUaWx0RGlyZWN0aXZlXSxcblx0ZXhwb3J0czogW1RpbHREaXJlY3RpdmVdXG59KVxuZXhwb3J0IGNsYXNzIFRpbHRNb2R1bGUge1xufSIsImV4cG9ydCBjb25zdCBWRVJTSU9OID0gXCIwLjEuMlwiOyJdLCJuYW1lcyI6WyJFdmVudEVtaXR0ZXIiLCJEaXJlY3RpdmUiLCJFbGVtZW50UmVmIiwiSW5wdXQiLCJPdXRwdXQiLCJOZ01vZHVsZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7O0FBQUE7UUFpQkMsdUJBQ1MsRUFBMkI7WUFBM0IsT0FBRSxHQUFGLEVBQUUsQ0FBeUI7WUFOMUIsZUFBVSxHQUFHLElBQUlBLGlCQUFZLEVBQWMsQ0FBQztZQUc5QyxpQkFBWSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7U0FLdkQ7Ozs7UUFFRCxnQ0FBUTs7O1lBQVI7Z0JBQ0MsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLFdBQVcsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLGFBQWEsRUFBRSxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7Z0JBQzVFLElBQUksQ0FBQyxFQUFFLENBQUMsYUFBYSxDQUFDLGdCQUFnQixDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7YUFDeEU7Ozs7UUFFRCxtQ0FBVzs7O1lBQVg7Z0JBQ0MsSUFBSSxJQUFJLENBQUMsV0FBVyxFQUFFO29CQUNyQixJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sRUFBRSxDQUFDO2lCQUMzQjtnQkFDRCxJQUFJLENBQUMsRUFBRSxDQUFDLGFBQWEsQ0FBQyxtQkFBbUIsQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO2FBQzNFOzs7O1FBRUQsaUNBQVM7OztZQUFUO2dCQUNDLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLEVBQUUsQ0FBQzthQUNwQzs7OztRQUVELDZCQUFLOzs7WUFBTDtnQkFDQyxJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssRUFBRSxDQUFDO2FBQ3pCOzs7Ozs7UUFFTyx3Q0FBZ0I7Ozs7O1lBQXhCLFVBQXlCLEtBQThCO2dCQUN0RCxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUM7YUFDbkM7O29CQXhDREMsY0FBUyxTQUFDO3dCQUNWLFFBQVEsRUFBRSxXQUFXO3dCQUNyQixRQUFRLEVBQUUsU0FBUztxQkFDbkI7Ozs7O3dCQU42Q0MsZUFBVTs7OztrQ0FTdERDLFVBQUs7aUNBRUxDLFdBQU07O1FBaUNSLG9CQUFDO0tBekNEOzs7Ozs7QUNKQTtRQUlBO1NBS0M7O29CQUxBQyxhQUFRLFNBQUM7d0JBQ1QsWUFBWSxFQUFFLENBQUMsYUFBYSxDQUFDO3dCQUM3QixPQUFPLEVBQUUsQ0FBQyxhQUFhLENBQUM7cUJBQ3hCOztRQUVELGlCQUFDO0tBTEQ7Ozs7Ozs7QUNKQSxRQUFhLE9BQU8sR0FBRyxPQUFPOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7In0=