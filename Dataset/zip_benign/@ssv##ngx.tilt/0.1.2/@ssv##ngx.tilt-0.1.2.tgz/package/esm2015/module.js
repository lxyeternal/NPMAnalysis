/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
import { NgModule } from "@angular/core";
import { TiltDirective } from "./tilt.directive";
export class TiltModule {
}
TiltModule.decorators = [
    { type: NgModule, args: [{
                declarations: [TiltDirective],
                exports: [TiltDirective]
            },] }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibW9kdWxlLmpzIiwic291cmNlUm9vdCI6Im5nOi8vQHNzdi9uZ3gudGlsdC8iLCJzb3VyY2VzIjpbIm1vZHVsZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7O0FBQUEsT0FBTyxFQUFFLFFBQVEsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUV6QyxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0sa0JBQWtCLENBQUM7QUFNakQsTUFBTSxPQUFPLFVBQVU7OztZQUp0QixRQUFRLFNBQUM7Z0JBQ1QsWUFBWSxFQUFFLENBQUMsYUFBYSxDQUFDO2dCQUM3QixPQUFPLEVBQUUsQ0FBQyxhQUFhLENBQUM7YUFDeEIiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBOZ01vZHVsZSB9IGZyb20gXCJAYW5ndWxhci9jb3JlXCI7XG5cbmltcG9ydCB7IFRpbHREaXJlY3RpdmUgfSBmcm9tIFwiLi90aWx0LmRpcmVjdGl2ZVwiO1xuXG5ATmdNb2R1bGUoe1xuXHRkZWNsYXJhdGlvbnM6IFtUaWx0RGlyZWN0aXZlXSxcblx0ZXhwb3J0czogW1RpbHREaXJlY3RpdmVdXG59KVxuZXhwb3J0IGNsYXNzIFRpbHRNb2R1bGUge1xufSJdfQ==