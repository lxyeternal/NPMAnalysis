/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
import VanillaTilt from "vanilla-tilt";
import { Directive, Input, ElementRef, Output, EventEmitter } from "@angular/core";
export class TiltDirective {
    /**
     * @param {?} el
     */
    constructor(el) {
        this.el = el;
        this.tiltChange = new EventEmitter();
        this.onTiltChange = this.handleTiltChange.bind(this);
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        this.vanillaTilt = new VanillaTilt(this.el.nativeElement, this.tiltOptions);
        this.el.nativeElement.addEventListener("tiltChange", this.onTiltChange);
    }
    /**
     * @return {?}
     */
    ngOnDestroy() {
        if (this.vanillaTilt) {
            this.vanillaTilt.destroy();
        }
        this.el.nativeElement.removeEventListener("tiltChange", this.onTiltChange);
    }
    /**
     * @return {?}
     */
    getValues() {
        return this.vanillaTilt.getValues();
    }
    /**
     * @return {?}
     */
    reset() {
        this.vanillaTilt.reset();
    }
    /**
     * @private
     * @param {?} event
     * @return {?}
     */
    handleTiltChange(event) {
        this.tiltChange.emit(event.detail);
    }
}
TiltDirective.decorators = [
    { type: Directive, args: [{
                selector: "[ssvTilt]",
                exportAs: "ssvTilt",
            },] }
];
/** @nocollapse */
TiltDirective.ctorParameters = () => [
    { type: ElementRef }
];
TiltDirective.propDecorators = {
    tiltOptions: [{ type: Input }],
    tiltChange: [{ type: Output }]
};
if (false) {
    /** @type {?} */
    TiltDirective.prototype.tiltOptions;
    /** @type {?} */
    TiltDirective.prototype.tiltChange;
    /**
     * @type {?}
     * @private
     */
    TiltDirective.prototype.vanillaTilt;
    /**
     * @type {?}
     * @private
     */
    TiltDirective.prototype.onTiltChange;
    /**
     * @type {?}
     * @private
     */
    TiltDirective.prototype.el;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGlsdC5kaXJlY3RpdmUuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9Ac3N2L25neC50aWx0LyIsInNvdXJjZXMiOlsidGlsdC5kaXJlY3RpdmUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7OztBQUFBLE9BQU8sV0FBVyxNQUFNLGNBQWMsQ0FBQztBQUN2QyxPQUFPLEVBQXFCLFNBQVMsRUFBRSxLQUFLLEVBQUUsVUFBVSxFQUFFLE1BQU0sRUFBRSxZQUFZLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFPdEcsTUFBTSxPQUFPLGFBQWE7Ozs7SUFTekIsWUFDUyxFQUEyQjtRQUEzQixPQUFFLEdBQUYsRUFBRSxDQUF5QjtRQU4xQixlQUFVLEdBQUcsSUFBSSxZQUFZLEVBQWMsQ0FBQztRQUc5QyxpQkFBWSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7SUFLeEQsQ0FBQzs7OztJQUVELFFBQVE7UUFDUCxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksV0FBVyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsYUFBYSxFQUFFLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUM1RSxJQUFJLENBQUMsRUFBRSxDQUFDLGFBQWEsQ0FBQyxnQkFBZ0IsQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO0lBQ3pFLENBQUM7Ozs7SUFFRCxXQUFXO1FBQ1YsSUFBSSxJQUFJLENBQUMsV0FBVyxFQUFFO1lBQ3JCLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxFQUFFLENBQUM7U0FDM0I7UUFDRCxJQUFJLENBQUMsRUFBRSxDQUFDLGFBQWEsQ0FBQyxtQkFBbUIsQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO0lBQzVFLENBQUM7Ozs7SUFFRCxTQUFTO1FBQ1IsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsRUFBRSxDQUFDO0lBQ3JDLENBQUM7Ozs7SUFFRCxLQUFLO1FBQ0osSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLEVBQUUsQ0FBQztJQUMxQixDQUFDOzs7Ozs7SUFFTyxnQkFBZ0IsQ0FBQyxLQUE4QjtRQUN0RCxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDcEMsQ0FBQzs7O1lBeENELFNBQVMsU0FBQztnQkFDVixRQUFRLEVBQUUsV0FBVztnQkFDckIsUUFBUSxFQUFFLFNBQVM7YUFDbkI7Ozs7WUFONkMsVUFBVTs7OzBCQVN0RCxLQUFLO3lCQUVMLE1BQU07Ozs7SUFGUCxvQ0FBOEM7O0lBRTlDLG1DQUFzRDs7Ozs7SUFFdEQsb0NBQWtDOzs7OztJQUNsQyxxQ0FBd0Q7Ozs7O0lBR3ZELDJCQUFtQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBWYW5pbGxhVGlsdCBmcm9tIFwidmFuaWxsYS10aWx0XCI7XG5pbXBvcnQgeyBPbkluaXQsIE9uRGVzdHJveSwgRGlyZWN0aXZlLCBJbnB1dCwgRWxlbWVudFJlZiwgT3V0cHV0LCBFdmVudEVtaXR0ZXIgfSBmcm9tIFwiQGFuZ3VsYXIvY29yZVwiO1xuaW1wb3J0IHsgVGlsdE9wdGlvbnMsIFRpbHRWYWx1ZXMgfSBmcm9tIFwidmFuaWxsYS10aWx0XCI7XG5cbkBEaXJlY3RpdmUoe1xuXHRzZWxlY3RvcjogXCJbc3N2VGlsdF1cIixcblx0ZXhwb3J0QXM6IFwic3N2VGlsdFwiLFxufSlcbmV4cG9ydCBjbGFzcyBUaWx0RGlyZWN0aXZlIGltcGxlbWVudHMgT25Jbml0LCBPbkRlc3Ryb3kge1xuXG5cdEBJbnB1dCgpIHRpbHRPcHRpb25zOiBUaWx0T3B0aW9ucyB8IHVuZGVmaW5lZDtcblxuXHRAT3V0cHV0KCkgdGlsdENoYW5nZSA9IG5ldyBFdmVudEVtaXR0ZXI8VGlsdFZhbHVlcz4oKTtcblxuXHRwcml2YXRlIHZhbmlsbGFUaWx0ITogVmFuaWxsYVRpbHQ7XG5cdHByaXZhdGUgb25UaWx0Q2hhbmdlID0gdGhpcy5oYW5kbGVUaWx0Q2hhbmdlLmJpbmQodGhpcyk7XG5cblx0Y29uc3RydWN0b3IoXG5cdFx0cHJpdmF0ZSBlbDogRWxlbWVudFJlZjxIVE1MRWxlbWVudD4sXG5cdCkge1xuXHR9XG5cblx0bmdPbkluaXQoKSB7XG5cdFx0dGhpcy52YW5pbGxhVGlsdCA9IG5ldyBWYW5pbGxhVGlsdCh0aGlzLmVsLm5hdGl2ZUVsZW1lbnQsIHRoaXMudGlsdE9wdGlvbnMpO1xuXHRcdHRoaXMuZWwubmF0aXZlRWxlbWVudC5hZGRFdmVudExpc3RlbmVyKFwidGlsdENoYW5nZVwiLCB0aGlzLm9uVGlsdENoYW5nZSk7XG5cdH1cblxuXHRuZ09uRGVzdHJveSgpIHtcblx0XHRpZiAodGhpcy52YW5pbGxhVGlsdCkge1xuXHRcdFx0dGhpcy52YW5pbGxhVGlsdC5kZXN0cm95KCk7XG5cdFx0fVxuXHRcdHRoaXMuZWwubmF0aXZlRWxlbWVudC5yZW1vdmVFdmVudExpc3RlbmVyKFwidGlsdENoYW5nZVwiLCB0aGlzLm9uVGlsdENoYW5nZSk7XG5cdH1cblxuXHRnZXRWYWx1ZXMoKTogVGlsdFZhbHVlcyB7XG5cdFx0cmV0dXJuIHRoaXMudmFuaWxsYVRpbHQuZ2V0VmFsdWVzKCk7XG5cdH1cblxuXHRyZXNldCgpIHtcblx0XHR0aGlzLnZhbmlsbGFUaWx0LnJlc2V0KCk7XG5cdH1cblxuXHRwcml2YXRlIGhhbmRsZVRpbHRDaGFuZ2UoZXZlbnQ6IEN1c3RvbUV2ZW50PFRpbHRWYWx1ZXM+KSB7XG5cdFx0dGhpcy50aWx0Q2hhbmdlLmVtaXQoZXZlbnQuZGV0YWlsKTtcblx0fVxufSJdfQ==