/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * Generated bundle index. Do not edit.
 */
export { TiltModule, VERSION } from './index';
export { TiltDirective as ɵa } from './tilt.directive';
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3N2LW5neC50aWx0LmpzIiwic291cmNlUm9vdCI6Im5nOi8vQHNzdi9uZ3gudGlsdC8iLCJzb3VyY2VzIjpbInNzdi1uZ3gudGlsdC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7O0FBSUEsb0NBQWMsU0FBUyxDQUFDO0FBRXhCLE9BQU8sRUFBQyxhQUFhLElBQUksRUFBRSxFQUFDLE1BQU0sa0JBQWtCLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEdlbmVyYXRlZCBidW5kbGUgaW5kZXguIERvIG5vdCBlZGl0LlxuICovXG5cbmV4cG9ydCAqIGZyb20gJy4vaW5kZXgnO1xuXG5leHBvcnQge1RpbHREaXJlY3RpdmUgYXMgybVhfSBmcm9tICcuL3RpbHQuZGlyZWN0aXZlJzsiXX0=