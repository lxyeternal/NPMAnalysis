import React from "react";
type NonUndefined<T> = T extends undefined ? never : T;
type MeterColor = {
    stop: number;
    color: NonUndefined<React.CSSProperties["color"]>;
};
export type TAudioSpectrumProps = {
    audioId?: string;
    audioEle?: HTMLAudioElement;
    capColor?: React.CSSProperties["color"];
    capHeight?: number;
    meterWidth: number;
    meterCount: number;
    meterColor: string | MeterColor[];
    gap: number;
    /**
     * @IntRange 0 - 1
     */
    smoothingTimeConstant?: number;
    /**
     * @IntRange 32 - 32768, must be power of 2
     */
    fftSize?: number;
    disableCap?: boolean;
    audioContext?: AudioContext;
} & React.HTMLProps<HTMLCanvasElement>;
declare const AudioSpectrum: (props: TAudioSpectrumProps) => JSX.Element;
export default AudioSpectrum;
