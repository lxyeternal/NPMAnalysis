export { default } from "./AudioSpectrum";
