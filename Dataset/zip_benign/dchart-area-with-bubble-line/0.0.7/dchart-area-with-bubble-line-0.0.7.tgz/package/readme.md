dchart-area-with-bubble-line

符合dchart规范的水平水管图

### 安装

```
npm install dchart-area-with-bubble-line
```

### 用法
```
var Bar = require('dchart-area-with-bubble-line');
var bar = new Bar(container, {
  xaxis: {
    padding: [0.3, 0],      //柱状子间的间距[innerPadding, outerPadding],默认[0.9, 0.4]
    dy: 40,                   //位移
  },
  yaxis: {
    min: null,                 //默认null会自动计算数据中的最小值
    max: null,                 //默认null会自动计算数据中的最大值
    tickFormat: function () {},
    ticks: 4                   //显示4个刻度
  }
});
bar.render([
        {"x": "山东", "y": 100},
        {"x": "山西", "y": 52},
        {"x": "河北", "y": 49}
      ]);
```
