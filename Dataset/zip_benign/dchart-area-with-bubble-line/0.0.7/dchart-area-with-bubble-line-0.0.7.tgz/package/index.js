require('./theme.css');
var Area = require('dchart-area-with-line');
var d3 = require('d3');
var _ = require('dchart-core/util');

function AreaLine(container, options) {
  var opt = {
    interpolate: null
  }
  opt = _.deepMerge(opt, options);
  Area.call(this, container, opt);
}

AreaLine = Area.extend(AreaLine, {
  renderCore: function () {
    var opt = this.options;
    var data = this.data();
    var x = this.getComs('axis', 'xaxis').getX();
    var yAxis = this.getComs('axis', 'yaxis')
    var y = yAxis.getX();
    var xkey = opt.xaxis.key;
    var ykey = opt.yaxis.key;

    var len = _.maxBy(data, function (n) {
      return n[ykey].length
    })[ykey].length
    var svg = this.svg.select('.scatterplot-g')[0][0] ? this.svg.select('.scatterplot-g') : this.svg.append('g')
      .attr('class', 'scatterplot-g')
    var series = svg.selectAll('.series-group').data(data);
    var enter = series.enter()
      .append('g')
      .attr('class', 'series-group');
    var updateSeriesAttr = function (d, i, seriesIndex) {
      var that = d3.select(this);
      (d[ykey][seriesIndex] !== undefined) && that.attr({
        "transform" : "translate(" + (x(opt.xaxis.type === 'time' ? new Date(d[xkey]) : d[xkey]) + (opt.xaxis.type === 'category' ? x.rangeBand()/2 : 0))
        + ", " + y(d[ykey][seriesIndex]) + ")"
      }) || that.attr({
        "transform" : "translate(" + (x(opt.xaxis.type === 'time' ? new Date(d[xkey]) : d[xkey]) + (opt.xaxis.type === 'category' ? x.rangeBand()/2 : 0))
        + ", " + y(yAxis.getMin()) + ")"
      });

      var back = that.select('.back')[0][0] ? that.select('.back') : that.append('circle')
        .attr('class', 'back').style({'fill': 'none', 'stroke': 'white'})
      back.attr('r', 10);

      var front = that.select('.front')[0][0] ? that.select('.front') : that.append('circle')
        .attr('class', 'front').style('fill', 'white')
      front.attr('r', 6);
    }

    for (var i = 0; i < len; i++) {
      series.each(function (d, index) {
        var node = d3.select(this).select('.serie' + (i + 1))[0][0] || d3.select(this).append('g').attr('class', 'serie serie' + (i+1))[0][0];
        node && updateSeriesAttr.call(node, d, index, i);
      });
      enter.append('g')
        .attr('class', 'serie serie' + (i+1))
        .each(function (d, index) {
          updateSeriesAttr.call(this, d, index, i);
        })
    }
    series.selectAll('.serie.serie' + len + ' ~ .serie').remove();
    series.exit().remove();
  },
  renderSeries : function () {
    Area.prototype.renderSeries.call(this);
    AreaLine.prototype.renderCore.call(this);
  },
  updateSeries : function () {
    Area.prototype.updateSeries.call(this);
    AreaLine.prototype.renderCore.call(this);
  },
  afterRender : function () {
    Area.prototype.afterRender.call(this);
    this.svg[0][0].appendChild(this.svg.select('.scatterplot-g')[0][0])
  },
  updateAfterRender: function () {
    Area.prototype.updateAfterRender.call(this);
    this.svg[0][0].appendChild(this.svg.select('.scatterplot-g')[0][0])
  }
});

module.exports = AreaLine;