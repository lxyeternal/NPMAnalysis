
# CursorFlow.js  
### 🚀 Developed By | Developer Nishant  

I am working right now, there are a lot of problems, I will fix it within some time.  

A lightweight JavaScript library for interactive cursor effects, smooth scrolling, magnetic elements, and parallax zoom effects.

---

## 🚀 Installation

### Using npm
```sh
npm install cursorflow.js
```

### Using CDN
```html
<script src="https://cdn.jsdelivr.net/npm/cursorflow.js@latest"></script>
```

---

## 📖 Usage

### 1️⃣ Import in JavaScript
If installed via npm, import it in your JavaScript file:
```js
import CursorFlow from "cursorflow.js";

CursorFlow.init({
  effect: "magnetic",
  color: "#00ffaa",
});
```

If using via CDN, include it in an HTML file:
```html
<script src="https://cdn.jsdelivr.net/npm/cursorflow.js@latest"></script>
<script>
  CursorFlow.magneticEffect(".magnetic-btn", 0.3);
  CursorFlow.customCursor("circle", "#ff5733");
  CursorFlow.smoothScroll();
</script>
```

---

## ✨ Features

✔️ **Smooth Scroll** – Adds smooth scrolling effect.  
✔️ **Magnetic Elements** – Elements follow the cursor.  
✔️ **Custom Cursor** – Changes the cursor style dynamically.  
✔️ **Parallax Zoom** – Adds a zoom effect on hover.  

---

## 📌 API Reference

### `CursorFlow.smoothScroll(options)`
Enables smooth scrolling.
```js
CursorFlow.smoothScroll({ damping: 0.1 });
```

### `CursorFlow.magneticEffect(selector, strength)`
Applies a magnetic effect to elements.
```js
CursorFlow.magneticEffect(".button", 0.2);
```

### `CursorFlow.customCursor(type, color)`
Creates a custom cursor effect.
```js
CursorFlow.customCursor("circle", "#00ffcc");
```

### `CursorFlow.parallaxZoom(selector, scale, intensity)`
Adds a parallax zoom effect.
```js
CursorFlow.parallaxZoom(".image-container", 1.2, 20);
```

---

## 📝 License
This project is licensed under the **MIT License**.

## 👨‍💻 Author
**Nishant Kumar** – *Developer of CursorFlow.js*
```
