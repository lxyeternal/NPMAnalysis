export function parallaxZoom(selector, zoomStrength = 1.2, moveStrength = 20) {
    document.addEventListener("DOMContentLoaded", function () {
        const container = document.querySelector(selector);
        if (!container) return;

        const image = container.querySelector("img");
        if (!image) return;

        container.addEventListener("mousemove", (e) => {
            let { left, top, width, height } = container.getBoundingClientRect();
            let x = (e.clientX - left) / width - 0.5;
            let y = (e.clientY - top) / height - 0.5;

            let moveX = x * moveStrength; // Adjust sensitivity
            let moveY = y * moveStrength;

            image.style.transform = `translate(${moveX}px, ${moveY}px) scale(${zoomStrength})`;
        });

        container.addEventListener("mouseleave", () => {
            image.style.transform = "translate(0, 0) scale(1)";
        });
    });
}
