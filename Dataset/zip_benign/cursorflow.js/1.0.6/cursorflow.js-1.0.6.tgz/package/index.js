import { smoothScroll } from "./smoothScroll.js";
import { magneticEffect } from "./magnetic.js";
import { customCursor } from "./cursor.js";
import { parallaxZoom } from "./parallaxZoom.js";


export default {
    smoothScroll,
    magneticEffect,
    customCursor,
    parallaxZoom,
};

