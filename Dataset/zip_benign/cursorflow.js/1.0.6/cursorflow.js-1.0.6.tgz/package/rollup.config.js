export default {
    input: "index.js",
    output: {
        file: "dist/mylib.js",
        format: "umd",
        name: "CursorFlow",
    },
};
