export function customCursor(cursorType = "circle", color = "#ff5733") {
    const cursor = document.createElement("div");
    const size = 20; // Cursor size

    cursor.style.width = `${size}px`;
    cursor.style.height = `${size}px`;
    cursor.style.position = "absolute";
    cursor.style.background = color;
    cursor.style.borderRadius = "50%";
    cursor.style.pointerEvents = "none";
    cursor.style.zIndex = "9999"; // Ensure it's above other elements
    cursor.style.transition = "transform 0.1s linear"; // Smooth movement
    document.body.appendChild(cursor);

    document.addEventListener("mousemove", (e) => {
        const x = e.clientX - size / 2; // Subtract half of width
        const y = e.clientY - size / 2; // Subtract half of height

        cursor.style.transform = `translate(${x}px, ${y}px)`;
    });
}
