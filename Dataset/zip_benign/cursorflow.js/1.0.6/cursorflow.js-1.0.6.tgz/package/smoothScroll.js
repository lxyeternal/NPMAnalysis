export function smoothScroll({ damping = 0.1 } = {}) {
    document.addEventListener("scroll", () => {
        document.body.style.scrollBehavior = "smooth";
    });
}
