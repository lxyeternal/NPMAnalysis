export function magneticEffect(selector, strength = 0.2) {
    document.querySelectorAll(selector).forEach((btn) => {
        btn.addEventListener("mousemove", (e) => {
            const { left, top, width, height } = btn.getBoundingClientRect();
            const x = e.clientX - left - width / 2;
            const y = e.clientY - top - height / 2;
            btn.style.transform = `translate(${x * strength}px, ${y * strength}px)`;
        });
        btn.addEventListener("mouseleave", () => {
            btn.style.transform = "translate(0, 0)";
        });
    });
}
