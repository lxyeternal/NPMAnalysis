'use strict';

var defaultIsExtractableFile = require('./isExtractableFile.js');

module.exports = function extractFiles(
  value,
  path,
  isExtractableFile,
  parentAddFile
) {
  if (path === void 0) {
    path = '';
  }

  if (isExtractableFile === void 0) {
    isExtractableFile = defaultIsExtractableFile;
  }

  var clone;
  var files = new Map();

  var addFile =
    parentAddFile ||
    function (paths, file) {
      var stored = files.get(file);

      if (stored) {
        var _stored$;

        (_stored$ = stored[1]).push.apply(_stored$, paths);

        return stored[0];
      }

      var id = '' + files.size;
      files.set(file, [id, paths]);
      return id;
    };

  if (isExtractableFile(value)) clone = addFile([path], value);
  else {
    var prefix = path ? path + '.' : '';
    if (typeof FileList !== 'undefined' && value instanceof FileList)
      clone = Array.prototype.map.call(value, function (file, i) {
        var key = '' + prefix + i;
        return addFile([key], file);
      });
    else if (Array.isArray(value))
      clone = value.map(function (child, i) {
        var result = extractFiles(
          child,
          '' + prefix + i,
          isExtractableFile,
          addFile
        );
        return result.clone;
      });
    else if (value && value.constructor === Object) {
      clone = {};

      for (var i in value) {
        var result = extractFiles(
          value[i],
          '' + prefix + i,
          isExtractableFile,
          addFile
        );
        clone[i] = result.clone;
      }
    } else clone = value;
  }
  return {
    clone: clone,
    files: files,
  };
};
