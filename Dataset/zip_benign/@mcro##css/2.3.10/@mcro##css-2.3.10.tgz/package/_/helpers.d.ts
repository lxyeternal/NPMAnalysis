import { CSSArray } from './types';
export declare const px: (x: string | number) => string;
export declare function camelToSnake(key: string): any;
export declare function snakeToCamel(key: string): any;
export declare function expandCSSArray(given: number | Array<number | string>): CSSArray;
export declare function processArray(key: string, value: Array<number | string>, level?: number): string;
export declare function processObject(key: string, object: any): string;
