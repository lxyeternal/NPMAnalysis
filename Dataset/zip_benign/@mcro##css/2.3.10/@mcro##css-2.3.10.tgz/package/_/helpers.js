"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const cssNameMap_1 = require("./cssNameMap");
const constants_1 = require("./constants");
const toColor_1 = require("./toColor");
exports.px = (x) => typeof x === 'number' ? `${x}px` : `${+x}` === x ? `${x}px` : x;
function camelToSnake(key) {
    return cssNameMap_1.CAMEL_TO_SNAKE[key] || key;
}
exports.camelToSnake = camelToSnake;
function snakeToCamel(key) {
    return cssNameMap_1.SNAKE_TO_CAMEL[key] || key;
}
exports.snakeToCamel = snakeToCamel;
const arr3to4 = arr => [...arr, arr[1]];
const arr2to4 = arr => [...arr, arr[0], arr[1]];
const arr1to4 = arr => [...arr, arr[0], arr[0], arr[1]];
function expandCSSArray(given) {
    if (typeof given === 'number') {
        return [given, given, given, given];
    }
    if (Array.isArray(given)) {
        switch (given.length) {
            case 3:
                return arr3to4(given);
            case 2:
                return arr2to4(given);
            case 1:
                return arr1to4(given);
            default:
                return given;
        }
    }
    throw new Error('Invalid type given');
}
exports.expandCSSArray = expandCSSArray;
const objectToCSS = {
    textShadow: ({ x, y, blur, color }) => `${exports.px(x)} ${exports.px(y)} ${exports.px(blur)} ${toColor_1.toColor(color)}`,
    boxShadow: v => v.inset || v.x || v.y || v.blur || v.spread || v.color
        ? `${v.inset ? 'inset' : ''} ${exports.px(v.x)} ${exports.px(v.y)} ${exports.px(v.blur)} ${exports.px(v.spread)} ${toColor_1.toColor(v.color)}`
        : toColor_1.toColor(v),
    background: v => toColor_1.isColor(v)
        ? toColor_1.toColor(v)
        : `${toColor_1.toColor(v.color)} ${v.image || ''} ${(v.position ? v.position.join(' ') : v.position) ||
            ''} ${v.repeat || ''}`,
};
function processArrayItem(key, val, level = 0) {
    if (toColor_1.isColor(val)) {
        return toColor_1.toColor(val);
    }
    if (Array.isArray(val)) {
        return processArray(key, val, level + 1);
    }
    return typeof val === 'number' ? `${val}px` : val;
}
function processArray(key, value, level = 0) {
    if (key === 'background') {
        if (toColor_1.isColor(value)) {
            return toColor_1.toColor(value);
        }
    }
    if (constants_1.BORDER_KEY[key] && value.length === 2) {
        value.push('solid');
    }
    return value
        .map(val => processArrayItem(key, val))
        .join(level === 0 && constants_1.COMMA_JOINED[key] ? ', ' : ' ');
}
exports.processArray = processArray;
function objectValue(key, value) {
    if (objectToCSS[key]) {
        return objectToCSS[key](value);
    }
    if (key === 'scale' ||
        key === 'scaleX' ||
        key === 'scaleY' ||
        key === 'grayscale' ||
        key === 'brightness') {
        return value;
    }
    if (typeof value === 'number') {
        return `${value}px`;
    }
    return value;
}
const arrayOrObject = (arr, obj) => val => (Array.isArray(val) ? arr(val) : obj(val));
const gradients = {
    linearGradient: (key, object) => `linear-gradient(${arrayOrObject(all => processArray(key, all), ({ deg, from, to }) => `${deg || 0}deg, ${from || 'transparent'}, ${to || 'transparent'}`)(object)})`,
    radialGradient: processArray,
};
function processObject(key, object) {
    if (key === 'background' ||
        key === 'color' ||
        key === 'borderColor' ||
        key === 'backgroundColor') {
        if (object.linearGradient) {
            return gradients.linearGradient(key, object.linearGradient);
        }
        if (object.radialGradient) {
            return gradients.radialGradient(key, object.radialGradient);
        }
        if (toColor_1.isColor(object)) {
            return toColor_1.toColor(object);
        }
    }
    const toReturn = [];
    for (const subKey in object) {
        if (!object.hasOwnProperty(subKey)) {
            continue;
        }
        let value = object[subKey];
        if (Array.isArray(value)) {
            value = processArray(key, value);
        }
        else {
            value = objectValue(subKey, value);
        }
        toReturn.push(`${constants_1.TRANSFORM_KEYS_MAP[subKey] || subKey}(${value})`);
    }
    return toReturn.join(' ');
}
exports.processObject = processObject;
//# sourceMappingURL=helpers.js.map