export { configureCSS } from './config';
export { snakeToCamel, camelToSnake } from './helpers';
export { validCSSAttr, psuedoKeys } from './constants';
export { CSSPropertySet, CSSPropertySetStrict } from './cssPropertySet';
export { Transform, Color, ThemeObject } from './types';
export * from './helpers';
export declare type CSSOptions = {
    errorMessage?: string;
    snakeCase?: boolean;
};
export declare function css(styles: Object, opts?: CSSOptions): Object;
