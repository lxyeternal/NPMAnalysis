export declare type CSSOptions = {
    toColor: (a: any) => string;
    isColor: (a: any) => boolean;
};
export declare type NoS = number | string;
export declare type CSSArray = Array<NoS>;
export declare type ColorObject = {
    r: NoS;
    g: NoS;
    b: NoS;
    a?: NoS;
};
export declare type NiceColor = string | CSSArray | ColorObject;
export declare type ToCSSAble = {
    toCSS: Function;
} | {
    css: Function;
} | {
    alpha: Function;
} | any;
export declare type Color = ToCSSAble | NiceColor;
export declare type Transform = {
    x: number | string;
    y: number | string;
    z: number | string;
};
export declare type ThemeObject = {
    background: Color;
    color: Color;
    borderColor?: Color;
    backgroundBlur?: Color;
    colorBlur?: Color;
    borderColorBlur?: Color;
    backgroundHover?: Color;
    colorHover?: Color;
    borderColorHover?: Color;
    backgroundFocus?: Color;
    colorFocus?: Color;
    borderColorFocus?: Color;
    backgroundActive?: Color;
    colorActive?: Color;
    borderColorActive?: Color;
    backgroundActiveHighlight?: Color;
    colorActiveHighlight?: Color;
    borderColorActiveHighlight?: Color;
    [key: string]: Color;
};
