"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const config_1 = require("./config");
const colorNames_1 = require("./colorNames");
exports.toColor = memoizeOne((color) => {
    if (typeof color === 'string') {
        return color;
    }
    if (!color) {
        return 'transparent';
    }
    if (isColorLikeLibrary(color)) {
        return `${getColorLikeLibraryValue(color)}`;
    }
    if (Array.isArray(color)) {
        const length = color.length;
        if (length === 4) {
            return `rgba(${color.join(', ')})`;
        }
        if (length === 3) {
            return `rgb(${color.join(', ')})`;
        }
    }
    else if (color instanceof Object) {
        const clr = color;
        if (clr.a) {
            return `rgba(${clr.r}, ${clr.g}, ${clr.b}, ${clr.a})`;
        }
        return `rgb(${clr.r}, ${clr.g}, ${clr.b})`;
    }
    return color.toString();
});
exports.isColor = memoizeOne((object) => {
    if (!object) {
        return false;
    }
    if (typeof object === 'string' && isColorLikeString(object)) {
        return true;
    }
    if (Array.isArray(object)) {
        return isColorLikeArray(object);
    }
    if (typeof object === 'object') {
        return isColorLikeLibrary(object) || isColorLikeObject(object);
    }
    return false;
});
function memoizeOne(cb) {
    const Cache = new WeakMap();
    return (key) => {
        const mappable = key && typeof key === 'object';
        if (mappable) {
            const res = Cache.get(key);
            if (res) {
                return res;
            }
        }
        const newVal = cb.call(this, key);
        if (mappable) {
            Cache.set(key, newVal);
        }
        return newVal;
    };
}
function isColorLikeString(str) {
    if (str[0] === '#' && (str.length === 4 || str.length === 7)) {
        return true;
    }
    if (str.indexOf('rgb(') === 0 || str.indexOf('rgba(') === 0) {
        return true;
    }
    if (colorNames_1.colorNames[str]) {
        return true;
    }
    return false;
}
function isColorLikeArray(array) {
    return (typeof array[0] === 'number' &&
        typeof array[1] === 'number' &&
        typeof array[2] === 'number' &&
        (typeof array[3] === 'undefined' || typeof array[3] === 'number') &&
        typeof array[4] === 'undefined');
}
function isColorLikeObject(object) {
    const keyLen = Object.keys(object).length;
    if (keyLen < 3 || keyLen > 4)
        return false;
    if (keyLen === 3 && object.r && object.g && object.b)
        return true;
    if (keyLen === 4 && object.a)
        return true;
    return false;
}
function isColorLikeLibrary(val) {
    return ((config_1.Config.isColor && typeof val === 'object' && config_1.Config.isColor(val)) ||
        (typeof val.toCSS === 'function' ||
            typeof val.css === 'function' ||
            typeof val.rgb === 'function' ||
            typeof val.rgba === 'function'));
}
function getColorLikeLibraryValue(val) {
    let res = val;
    if (config_1.Config.isColor && config_1.Config.isColor(val)) {
        return config_1.Config.toColor(val);
    }
    if (typeof val.css === 'function') {
        res = val.css();
    }
    else if (typeof val.toCSS === 'function') {
        res = val.toCSS();
    }
    else if (typeof val.rgba === 'function') {
        res = val.rgba();
    }
    else if (typeof val.rgb === 'function') {
        res = val.rgb();
    }
    return res;
}
//# sourceMappingURL=toColor.js.map