"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const allCSSAttr = {};
if (typeof document !== 'undefined') {
    for (const key of Object.keys(document.body.style)) {
        allCSSAttr[key] = true;
    }
}
const cssSpecialAttr = {
    borderLeftRadius: true,
    borderRightRadius: true,
    borderBottomRadius: true,
    borderTopRadius: true,
};
exports.validCSSAttr = Object.assign({}, allCSSAttr, cssSpecialAttr);
exports.UNDEFINED = 'undefined';
exports.COLOR_KEYS = new Set(['color', 'backgroundColor', 'borderColor']);
exports.TRANSFORM_KEYS_MAP = {
    x: 'translateX',
    y: 'translateY',
    z: 'translateZ',
    dropShadow: 'drop-shadow',
};
exports.COMMA_JOINED = {
    boxShadow: true,
    transition: true,
};
exports.SHORTHANDS = {
    borderLeftRadius: ['borderTopLeftRadius', 'borderBottomLeftRadius'],
    borderRightRadius: ['borderTopRightRadius', 'borderBottomRightRadius'],
    borderBottomRadius: ['borderBottomLeftRadius', 'borderBottomRightRadius'],
    borderTopRadius: ['borderTopRightRadius', 'borderTopLeftRadius'],
};
exports.FALSE_VALUES = {
    background: 'transparent',
    backgroundColor: 'transparent',
    borderColor: 'transparent',
};
exports.BORDER_KEY = {
    border: true,
    borderLeft: true,
    borderRight: true,
    borderBottom: true,
    borderTop: true,
};
exports.psuedoKeys = {
    '&:hover': true,
    '&:active': true,
    '&:checked': true,
    '&:focus': true,
    '&:enabled': true,
    '&:disabled': true,
    '&:empty': true,
    '&:target': true,
    '&:required': true,
    '&:valid': true,
    '&:invalid': true,
    '&:before': true,
    '&:after': true,
    '&:placeholder': true,
    '&:selection': true,
};
exports.unitlessNumberProperties = new Set([
    'animationIterationCount',
    'borderImageOutset',
    'borderImageSlice',
    'borderImageWidth',
    'columnCount',
    'flex',
    'flexGrow',
    'flexPositive',
    'flexShrink',
    'flexOrder',
    'gridRow',
    'gridColumn',
    'fontWeight',
    'lineClamp',
    'opacity',
    'order',
    'orphans',
    'tabSize',
    'widows',
    'zIndex',
    'zoom',
    'fillOpacity',
    'floodOpacity',
    'stopOpacity',
    'strokeDasharray',
    'strokeDashoffset',
    'strokeMiterlimit',
    'strokeOpacity',
    'strokeWidth',
]);
//# sourceMappingURL=constants.js.map