"use strict";
function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
Object.defineProperty(exports, "__esModule", { value: true });
const helpers_1 = require("./helpers");
const cssNameMap_1 = require("./cssNameMap");
const constants_1 = require("./constants");
const toColor_1 = require("./toColor");
var config_1 = require("./config");
exports.configureCSS = config_1.configureCSS;
var helpers_2 = require("./helpers");
exports.snakeToCamel = helpers_2.snakeToCamel;
exports.camelToSnake = helpers_2.camelToSnake;
var constants_2 = require("./constants");
exports.validCSSAttr = constants_2.validCSSAttr;
exports.psuedoKeys = constants_2.psuedoKeys;
__export(require("./helpers"));
function css(styles, opts) {
    const toReturn = {};
    const shouldSnake = !opts || opts.snakeCase !== false;
    if (!styles || typeof styles !== 'object') {
        return toReturn;
    }
    for (let key in styles) {
        let value = styles[key];
        let valueType = typeof value;
        let finalKey = key;
        if (shouldSnake) {
            finalKey = cssNameMap_1.CAMEL_TO_SNAKE[key] || key;
        }
        if (value === false) {
            value === constants_1.FALSE_VALUES[key];
            valueType = typeof value;
        }
        if (valueType === constants_1.UNDEFINED || value === null || value === false) {
            continue;
        }
        let respond;
        const firstChar = key[0];
        if (valueType === 'string' || valueType === 'number') {
            if (valueType === 'number' && !constants_1.unitlessNumberProperties.has(key)) {
                value += 'px';
            }
            toReturn[finalKey] = value;
            respond = true;
        }
        else if (constants_1.COLOR_KEYS.has(key)) {
            toReturn[finalKey] = toColor_1.toColor(value);
            respond = true;
        }
        else if (Array.isArray(value)) {
            if (key === 'fontFamily') {
                toReturn[finalKey] = value.map(x => (x.indexOf(' ') ? `"${x}"` : x)).join(', ');
            }
            else if (key === 'position') {
                const isSpecific = value.length === 5;
                let index = 0;
                if (isSpecific) {
                    toReturn.position = value[0];
                    index++;
                }
                else {
                    toReturn.position = 'absolute';
                }
                toReturn.top = helpers_1.px(value[index++]);
                toReturn.right = helpers_1.px(value[index++]);
                toReturn.bottom = helpers_1.px(value[index++]);
                toReturn.left = helpers_1.px(value[index++]);
            }
            else {
                toReturn[finalKey] = helpers_1.processArray(key, value);
            }
            respond = true;
        }
        else if (firstChar === '&' ||
            firstChar === '@' ||
            key === 'from' ||
            key === 'to' ||
            constants_1.psuedoKeys[key]) {
            toReturn[finalKey] = css(value, opts);
            respond = true;
        }
        else if (valueType === 'object') {
            toReturn[finalKey] = helpers_1.processObject(key, value);
            respond = true;
        }
        else if (key === 'isolate') {
            toReturn[key] = value;
            respond = true;
        }
        if (constants_1.SHORTHANDS[key]) {
            for (let k of constants_1.SHORTHANDS[key]) {
                k = shouldSnake ? cssNameMap_1.CAMEL_TO_SNAKE[k] || k : k;
                toReturn[k] = helpers_1.px(value);
            }
        }
        if (respond) {
            continue;
        }
        throw new Error(`${(opts && opts.errorMessage) || 'Error'}: Invalid style value for ${key}: ${JSON.stringify(value)}, in styles: ${JSON.stringify(styles)}`);
    }
    return toReturn;
}
exports.css = css;
//# sourceMappingURL=css.js.map