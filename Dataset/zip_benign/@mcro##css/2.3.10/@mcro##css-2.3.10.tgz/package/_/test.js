"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const css_1 = require("./css");
console.log(css_1.css({
    color: 'red',
    alpha: 0.5,
    background: [0, 0, 0, 0.5],
    border: [1, 'red'],
    boxShadow: [0, 0, 0, [0, 0, 0, 0.5]],
}));
//# sourceMappingURL=test.js.map