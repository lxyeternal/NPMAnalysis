"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const toColor_1 = require("./toColor");
exports.Config = {
    isColor: toColor_1.isColor,
    toColor: toColor_1.toColor,
};
function configureCSS(options) {
    Object.assign(exports.Config, options);
    Object.freeze(exports.Config);
}
exports.configureCSS = configureCSS;
//# sourceMappingURL=config.js.map