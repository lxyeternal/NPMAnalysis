import { CSSOptions } from './types';
export declare const Config: CSSOptions;
export declare function configureCSS(options: Partial<CSSOptions>): void;
