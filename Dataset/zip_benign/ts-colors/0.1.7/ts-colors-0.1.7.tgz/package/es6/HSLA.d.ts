import * as Hue from './Hue'
import * as RGBA from './RGBA'
import { HSVA } from './HSVA'
import * as XYZ from './XYZ'
import * as Lab from './Lab'
import { Endomorphism } from 'fp-ts/Endomorphism'
/**
 * Represents a color using the HSL cylindrical-coordinate system.
 *
 * @category model
 * @since 0.1.5
 */
export interface HSLA {
  /**
   * A number between `0` and `360` representing the hue of the color in degrees.
   */
  readonly h: Hue.Hue
  /**
   * A number between `0` and `1` representing the percent saturation of the color
   * where `0` is completely denatured (grayscale) and `1` is fully saturated (full color).
   */
  readonly s: number
  /**
   * A number between `0` and `1` representing the percent lightness of the color
   * where `0` is completely dark (black) and `1` is completely light (white).
   */
  readonly l: number
  /**
   * A number between `0` and `1` representing the opacity or transparency of the color
   * where `0` is fully transparent and `1` is fully opaque.
   */
  readonly a: number
}
/**
 * @category constructors
 * @since 0.1.5
 */
export declare const hsla: (h: number, s: number, l: number, a: number) => HSLA
/**
 * @category constructors
 * @since 0.1.5
 */
export declare const hsl: (h: number, s: number, l: number) => HSLA
/**
 * @category constructors
 * @since 0.1.5
 */
export declare const fromRGBA: (rgba: RGBA.RGBA) => HSLA
/**
 * @category constructors
 * @since 0.1.5
 */
export declare const fromHSVA: (hsva: HSVA) => HSLA
/**
 * @category constructors
 * @since 0.1.5
 */
export declare const fromXYZ: (a_0: XYZ.XYZ) => HSLA
/**
 * @category constructors
 * @since 0.1.5
 */
export declare const fromLab: (a_0: Lab.Lab) => HSLA
/**
 * @category constructors
 * @since 0.1.5
 */
export declare const fromLCh: (a_0: import('./LCh').LCh) => HSLA
/**
 * Rotate the hue by a certain angle (in degrees).
 *
 * @since 0.1.5
 */
export declare const rotateHue: (angle: number) => (c: HSLA) => HSLA
/**
 * get the alpha channel
 *
 * @since 0.1.7
 */
export declare const alpha: (c: HSLA) => number
/**
 * set the alpha channel
 *
 * @since 0.1.7
 */
export declare const setAlpha: (alpha: number) => Endomorphism<HSLA>
/**
 * @since 0.1.5
 */
export declare const evolve: <
  F extends {
    [K in keyof HSLA]: (a: HSLA[K]) => number
  }
>(
  transformations: F
) => (c: HSLA) => HSLA
/**
 * @since 0.1.5
 */
export declare const mix: (ratio: number) => (a: HSLA) => (b: HSLA) => HSLA
/**
 * A CSS representation of the color in the form `hsl(..)` or `hsla(...)`.
 *
 * @since 0.1.5
 * @category destructors
 */
export declare const toCSS: (c: HSLA) => string
