import * as Equals from 'fp-ts/Eq'
import * as Sh from 'fp-ts/Show'
import { HSLA } from './HSLA'
import { XYZ } from './XYZ'
/**
 * Represents a color using the rgb color system
 *
 * @category model
 * @since 0.1.5
 */
export interface RGBA {
  /**
   * A number between `0` and `255` representing the red channel of the color
   */
  readonly r: Channel
  /**
   * A number between `0` and `255` representing the green channel of the color
   */
  readonly g: Channel
  /**
   * A number between `0` and `255` representing the blue channel of the color
   */
  readonly b: Channel
  /**
   * A number between `0` and `1` representing the opacity or transparency of the color
   * where `0` is fully transparent and `1` is fully opaque.
   */
  readonly a: number
}
/**
 * @since 0.1.5
 * @category constructors
 */
export declare const rgba: (r: number, g: number, b: number, a: number) => RGBA
/**
 * @since 0.1.5
 * @category constructors
 */
export declare const rgb: (r: number, g: number, b: number) => RGBA
/**
 * @since 0.1.5
 * @category constructors
 */
export declare const fromHSLA: (c: HSLA) => RGBA
/**
 * @category constructors
 * @since 0.1.5
 */
export declare const fromXYZ: ({ x, y, z }: XYZ) => RGBA
/**
 * @since 0.1.5
 */
export declare const maxChroma: (c: RGBA) => number
/**
 * @since 0.1.5
 */
export declare const minChroma: (c: RGBA) => number
/**
 * @since 0.1.5
 */
export declare const chroma: (c: RGBA) => number
/**
 * The percieved brightness of the color (A number between 0.0 and 1.0).
 * See: [https://www.w3.org/TR/AERT#color-contrast](https://www.w3.org/TR/AERT#color-contrast)
 *
 * @since 0.1.5
 */
export declare const brightness: (c: Normalized) => number
/**
 * The relative brightness of a color (normalized to 0.0 for darkest black
 * and 1.0 for lightest white), according to the WCAG definition.
 *
 * See: [https://www.w3.org/TR/2008/REC-WCAG20-20081211/#relativeluminancedef](https://www.w3.org/TR/2008/REC-WCAG20-20081211/#relativeluminancedef)
 *
 * @since 0.1.5
 */
export declare const luminance: (color: Normalized) => number
/**
 * @since 0.1.5
 */
export declare const evolve: <
  F extends {
    [K in keyof RGBA]: (a: RGBA[K]) => number
  }
>(
  transformations: F
) => (c: RGBA) => RGBA
/**
 * @since 0.1.5
 */
export declare const mix: (ratio: number) => (a: RGBA) => (b: RGBA) => RGBA
/**
 * A CSS representation of the color in the form `rgb(..)` or `rgba(...)`
 *
 * @since 0.1.5
 * @category destructors
 */
export declare const toCSS: (c: RGBA) => string
/**
 * @category instances
 * @since 0.1.5
 */
export declare const Eq: Equals.Eq<RGBA>
/**
 * @category instances
 * @since 0.1.5
 */
export declare const Show: Sh.Show<RGBA>
