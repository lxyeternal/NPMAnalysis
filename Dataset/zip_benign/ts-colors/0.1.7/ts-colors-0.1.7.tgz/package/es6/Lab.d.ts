import { HSLA } from './HSLA'
import { LCh } from './LCh'
/**
 * @category model
 * @since 0.1.5
 */
export interface Lab {
  /**
   * The lightness of the color. 0.0 gives absolute black and 100.0 give the brightest white.
   */
  readonly l: number
  readonly a: number
  readonly b: number
}
/**
 * @category constructors
 * @since 0.1.5
 */
export declare const lab: (l: number, a: number, b: number) => Lab
/**
 * @since 0.1.5
 * @category constructors
 */
export declare const fromHSLA: (c: HSLA) => Lab
/**
 * @category constructors
 * @since 0.1.5
 */
export declare const fromLCh: ({ l, c, h }: LCh) => Lab
/**
 * @since 0.1.5
 */
export declare const evolve: <
  F extends {
    [K in keyof Lab]: (a: Lab[K]) => number
  }
>(
  transformations: F
) => (c: Lab) => Lab
/**
 * @since 0.1.5
 */
export declare const mix: (ratio: number) => (a: Lab) => (b: Lab) => Lab
