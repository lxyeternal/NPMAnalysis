import * as Ord from 'fp-ts/Ord'
export declare const deg2rad: number
export declare const rad2deg: number
export declare const mod: (x: number) => (y: number) => number
export declare const square: (x: number) => number
export declare type Path = {
  readonly from: number
  readonly to: number
}
export declare const ordPath: Ord.Ord<Path>
/**
 * Linearly interpolate between two values.
 */
export declare const interpolate: (
  fraction: number
) => (a: number) => (b: number) => number
/**
 * Linearly interpolate between two angles. Always take the shortest path
 * along the circle.
 */
export declare const interpolateAngle: (
  fraction: number
) => (a: number) => (b: number) => number
