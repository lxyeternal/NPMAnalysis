/**
 * X11 colors as specified by the CSS3 specification (except black and white).
 * See: https://www.w3.org/TR/css3-color/#svg-color
 *
 * @since 0.1.0
 */
/**
 * @since 0.1.0
 */
export declare const aliceblue: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const antiquewhite: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const aqua: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const aquamarine: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const azure: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const beige: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const bisque: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const blanchedalmond: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const blue: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const blueviolet: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const brown: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const burlywood: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const cadetblue: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const chartreuse: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const chocolate: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const coral: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const cornflowerblue: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const cornsilk: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const crimson: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const cyan: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const darkblue: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const darkcyan: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const darkgoldenrod: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const darkgray: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const darkgreen: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const darkgrey: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const darkkhaki: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const darkmagenta: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const darkolivegreen: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const darkorange: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const darkorchid: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const darkred: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const darksalmon: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const darkseagreen: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const darkslateblue: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const darkslategray: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const darkslategrey: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const darkturquoise: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const darkviolet: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const deeppink: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const deepskyblue: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const dimgray: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const dimgrey: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const dodgerblue: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const firebrick: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const floralwhite: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const forestgreen: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const fuchsia: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const gainsboro: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const ghostwhite: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const gold: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const goldenrod: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const gray: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const green: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const greenyellow: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const grey: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const honeydew: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const hotpink: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const indianred: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const indigo: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const ivory: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const khaki: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const lavender: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const lavenderblush: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const lawngreen: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const lemonchiffon: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const lightblue: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const lightcoral: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const lightcyan: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const lightgoldenrodyellow: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const lightgray: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const lightgreen: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const lightgrey: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const lightpink: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const lightsalmon: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const lightseagreen: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const lightskyblue: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const lightslategray: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const lightslategrey: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const lightsteelblue: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const lightyellow: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const lime: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const limegreen: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const linen: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const magenta: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const maroon: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const mediumaquamarine: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const mediumblue: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const mediumorchid: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const mediumpurple: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const mediumseagreen: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const mediumslateblue: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const mediumspringgreen: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const mediumturquoise: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const mediumvioletred: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const midnightblue: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const mintcream: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const mistyrose: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const moccasin: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const navajowhite: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const navy: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const oldlace: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const olive: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const olivedrab: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const orange: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const orangered: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const orchid: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const palegoldenrod: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const palegreen: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const paleturquoise: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const palevioletred: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const papayawhip: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const peachpuff: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const peru: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const pink: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const plum: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const powderblue: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const purple: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const red: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const rosybrown: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const royalblue: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const saddlebrown: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const salmon: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const sandybrown: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const seagreen: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const seashell: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const sienna: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const silver: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const skyblue: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const slateblue: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const slategray: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const slategrey: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const snow: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const springgreen: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const steelblue: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const tan: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const teal: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const thistle: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const tomato: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const turquoise: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const violet: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const wheat: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const whitesmoke: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const yellow: import('./HSLA').HSLA
/**
 * @since 0.1.0
 */
export declare const yellowgreen: import('./HSLA').HSLA
