/**
 * @since 0.1.0
 */
import * as O from 'fp-ts/Option';
/**
 * @since 0.1.0
 */
export var binary = 2;
/**
 * @since 0.1.0
 */
export var octal = 8;
/**
 * @since 0.1.0
 */
export var decimal = 10;
/**
 * @since 0.1.0
 */
export var hexadecimal = 16;
/**
 * @since 0.1.0
 */
export var base36 = 36;
/**
 * Create a valid radix value
 *
 * @since 0.1.0
 */
export var radix = function (n) {
    return n >= 2 && n <= 36 ? O.some(n) : O.none;
};
/**
 * Parse a string to an int with a radix
 *
 * @example
 *
 * import * as Int orsfrom 'ts-colors/Int'
 *
 * const s = ''
 *
 * Int.fromStringAs(Int.hexadecimal)(s)
 *
 * @since 0.1.0
 */
export var fromStringAs = function (radix) {
    var digits;
    if (radix < 11) {
        digits = '[0-' + (radix - 1).toString() + ']';
    }
    else if (radix === 11) {
        digits = '[0-9a]';
    }
    else {
        digits = '[0-9a-' + String.fromCharCode(86 + radix) + ']';
    }
    var pattern = new RegExp('^[\\+\\-]?' + digits + '+$', 'i');
    return function (s) {
        if (pattern.test(s)) {
            var i = parseInt(s, radix);
            return (i | 0) === i ? O.some(i) : O.none;
        }
        return O.none;
    };
};
/**
 * Parse a string to an int
 *
 * @since 0.1.0
 */
export var fromString = fromStringAs(decimal);
/**
 * @since 0.1.0
 */
export var toStringAs = function (r) {
    return function (n) {
        return n.toString(r);
    };
};
//# sourceMappingURL=Int.js.map