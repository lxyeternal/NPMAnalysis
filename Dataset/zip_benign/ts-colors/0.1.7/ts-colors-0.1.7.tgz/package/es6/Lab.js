/**
 * A `Color` represented L, a and b coordinates in the Lab color space.
 *
 * Note: See documentation for [`xyz`](./XYZ.ts.html). The same restrictions
 * apply here.
 *
 * @since 0.1.5
 */
import { pipe } from 'fp-ts/function';
import * as struct from 'fp-ts/struct';
import * as XYZ from './XYZ';
import { deg2rad, interpolate } from './math';
/**
 * @category constructors
 * @since 0.1.5
 */
export var lab = function (l, a, b) { return ({
    l: l,
    a: a,
    b: b
}); };
/**
 * @since 0.1.5
 * @category constructors
 */
export var fromHSLA = function (c) {
    var cut = Math.pow(6.0 / 29.0, 3.0);
    var f = function (t) {
        return t > cut
            ? Math.pow(t, 1.0 / 3.0)
            : (1.0 / 3.0) * Math.pow(29.0 / 6.0, 2.0) * t + 4.0 / 29.0;
    };
    var rec = XYZ.fromHSLA(c);
    var fy = f(rec.y / XYZ.D65.yn);
    var l = 116.0 * fy - 16.0;
    var a = 500.0 * (f(rec.x / XYZ.D65.xn) - fy);
    var b = 200.0 * (fy - f(rec.z / XYZ.D65.zn));
    return lab(l, a, b);
};
/**
 * @category constructors
 * @since 0.1.5
 */
export var fromLCh = function (_a) {
    var l = _a.l, c = _a.c, h = _a.h;
    var a = c * Math.cos(h * deg2rad);
    var b = c * Math.sin(h * deg2rad);
    return lab(l, a, b);
};
/**
 * @since 0.1.5
 */
export var evolve = function (t) { return function (c) {
    return pipe(c, struct.evolve(t), function (_a) {
        var l = _a.l, a = _a.a, b = _a.b;
        return lab(l, a, b);
    });
}; };
/**
 * @since 0.1.5
 */
export var mix = function (ratio) {
    return function (a) {
        return function (b) {
            var i = interpolate(ratio);
            return pipe(b, evolve({
                l: i(a.l),
                a: i(a.a),
                b: i(a.b)
            }));
        };
    };
};
//# sourceMappingURL=Lab.js.map