import { HSLA } from './HSLA'
import * as Lab from './Lab'
/**
 * @category model
 * @since 0.1.5
 */
export interface XYZ {
  /**
   * X is the scale of what can be seen as a response curve for the cone
   * cells in the human eye. Its range depends
   * on the white point and goes from 0.0 to 0.95047 for the default D65.
   */
  readonly x: number
  /**
   * Y is the luminance of the color, where 0.0 is black and 1.0 is white.
   */
  readonly y: number
  /**
   * Z is the scale of what can be seen as the blue stimulation. Its range
   * depends on the white point and goes from 0.0 to 1.08883 for the
   * default D65.
   */
  readonly z: number
}
/**
 * @category constructors
 * @since 0.1.5
 */
export declare const xyz: (x: number, y: number, z: number) => XYZ
/**
 * @category constructors
 * @since 0.1.5
 */
export declare const fromHSLA: (c: HSLA) => XYZ
/**
 * @category constructors
 * @since 0.1.5
 */
export declare const fromLab: ({ l, a, b }: Lab.Lab) => XYZ
