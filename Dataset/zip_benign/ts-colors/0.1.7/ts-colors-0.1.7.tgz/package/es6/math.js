import { pipe } from 'fp-ts/function';
import * as Ord from 'fp-ts/Ord';
import * as RNEA from 'fp-ts/ReadonlyNonEmptyArray';
export var deg2rad = Math.PI / 180.0;
export var rad2deg = 180.0 / Math.PI;
export var mod = function (x) {
    return function (y) {
        return ((x % y) + y) % y;
    };
};
export var square = function (x) { return Math.pow(x, 2.0); };
var dist = function (_a) {
    var from = _a.from, to = _a.to;
    return Math.abs(to - from);
};
export var ordPath = Ord.fromCompare(function (a, b) {
    var da = dist(a);
    var db = dist(b);
    if (da === db) {
        return 0;
    }
    return da > db ? 1 : -1;
});
/**
 * Linearly interpolate between two values.
 */
export var interpolate = function (fraction) {
    return function (a) {
        return function (b) {
            return a + fraction * (b - a);
        };
    };
};
/**
 * Linearly interpolate between two angles. Always take the shortest path
 * along the circle.
 */
export var interpolateAngle = function (fraction) {
    return function (a) {
        return function (b) {
            var paths = [
                { from: a, to: b },
                { from: a, to: b + 360.0 },
                { from: a + 360.0, to: b }
            ];
            var shortest = pipe(paths, RNEA.sort(ordPath), RNEA.head);
            return interpolate(fraction)(shortest.from)(shortest.to);
        };
    };
};
//# sourceMappingURL=math.js.map