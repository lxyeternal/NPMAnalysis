interface UnitIntervalBrand {
  readonly UnitInterval: unique symbol
}
/**
 * A number between `0` and `1`
 *
 * @since 0.1.0
 * @category model
 */
export declare type UnitInterval = number & UnitIntervalBrand
export declare const unitInterval: (r: number) => UnitInterval
export {}
