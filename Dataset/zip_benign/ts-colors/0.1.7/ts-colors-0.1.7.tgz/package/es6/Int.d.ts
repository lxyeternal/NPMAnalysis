/**
 * @since 0.1.0
 */
import * as O from 'fp-ts/Option'
declare type Int = number
/**
 * The number of unique digits (including zero) used to represent integers in
 * a specific base.
 *
 * @since 0.1.0
 */
export declare type Radix = number
/**
 * @since 0.1.0
 */
export declare const binary: Radix
/**
 * @since 0.1.0
 */
export declare const octal: Radix
/**
 * @since 0.1.0
 */
export declare const decimal: Radix
/**
 * @since 0.1.0
 */
export declare const hexadecimal: Radix
/**
 * @since 0.1.0
 */
export declare const base36: Radix
/**
 * Create a valid radix value
 *
 * @since 0.1.0
 */
export declare const radix: (n: Int) => O.Option<Radix>
/**
 * Parse a string to an int with a radix
 *
 * @example
 *
 * import * as Int orsfrom 'ts-colors/Int'
 *
 * const s = ''
 *
 * Int.fromStringAs(Int.hexadecimal)(s)
 *
 * @since 0.1.0
 */
export declare const fromStringAs: (r: Radix) => (s: string) => O.Option<number>
/**
 * Parse a string to an int
 *
 * @since 0.1.0
 */
export declare const fromString: (s: string) => O.Option<number>
/**
 * @since 0.1.0
 */
export declare const toStringAs: (r: Radix) => (n: number) => string
export {}
