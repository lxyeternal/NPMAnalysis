/**
 * CIE LCh, a polar version of [`Lab`](./Lab.ts.html).
 * Note: See documentation for [`xyz`](./XYZ.ts.html). The same restrictions apply here.
 *
 * See: [https://en.wikipedia.org/wiki/Lab_color_space](https://en.wikipedia.org/wiki/Lab_color_space)
 *
 * @since 0.1.5
 */
import { pipe } from 'fp-ts/function';
import * as struct from 'fp-ts/struct';
import { clipHue, hue } from './Hue';
import * as Lab from './Lab';
import { interpolate, interpolateAngle, rad2deg } from './math';
/**
 * @since 0.1.5
 * @category constructors
 */
export var lch = function (l, c, h) { return ({
    l: l,
    c: c,
    h: hue(h)
}); };
/**
 * @since 0.1.5
 * @category constructors
 */
export var fromHSLA = function (hsla) {
    var _a = Lab.fromHSLA(hsla), l = _a.l, a = _a.a, b = _a.b;
    var c = Math.sqrt(a * a + b * b);
    var h = clipHue(Math.atan2(b, a) * rad2deg);
    return lch(l, c, h);
};
/**
 * @since 0.1.5
 */
export var evolve = function (t) { return function (c) {
    return pipe(c, struct.evolve(t), function (_a) {
        var l = _a.l, c = _a.c, h = _a.h;
        return lch(l, c, h);
    });
}; };
/**
 * @since 0.1.5
 */
export var mix = function (ratio) {
    return function (a) {
        return function (b) {
            var i = interpolate(ratio);
            var ia = interpolateAngle(ratio);
            return pipe(b, evolve({
                l: i(a.l),
                c: i(a.c),
                h: ia(a.h)
            }));
        };
    };
};
//# sourceMappingURL=LCh.js.map