import * as RGBA from './RGBA'
interface HueBrand {
  readonly Hue: unique symbol
}
/**
 * A number between `0` and `360` representing the hue of a color in degrees.
 *
 * @since 0.1.0
 */
export declare type Hue = number & HueBrand
/**
 * A number between `0` and `360` representing the hue of a color in degrees.
 *
 * @since 0.1.5
 */
export declare const hue: (n: number) => Hue
/**
 * Assert that the hue angle is in the interval [0, 360].
 *
 * @since 0.1.0
 */
export declare const clipHue: (n: number) => Hue
/**
 * @category constructors
 * @since 0.1.5
 */
export declare const fromRGBA: (rgba: RGBA.RGBA) => Hue
export {}
