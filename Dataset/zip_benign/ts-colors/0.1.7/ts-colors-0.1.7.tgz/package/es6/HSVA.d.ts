/**
 * A color represented by the HSV color model
 *
 * @since 0.1.5
 */
import { HSLA } from './HSLA'
import { Hue } from './Hue'
/**
 * @category model
 * @since 0.1.5
 */
export interface HSVA {
  /**
   * A number between `0` and `360` representing the hue of the color in degrees.
   */
  readonly h: Hue
  /**
   * A number between `0` and `1` representing the percent saturation of the color
   * where `0` is completely denatured (grayscale) and `1` is fully saturated (full color).
   */
  readonly s: number
  /**
   * Value
   */
  readonly v: number
  /**
   * A number between `0` and `1` representing the opacity or transparency of the color
   * where `0` is fully transparent and `1` is fully opaque.
   */
  readonly a: number
}
/**
 * @since 0.1.5
 * @category constructors
 */
export declare const hsva: (h: number, s: number, v: number, a: number) => HSVA
/**
 * @since 0.1.5
 * @category constructors
 */
export declare const hsv: (h: number, s: number, v: number) => HSVA
/**
 * @since 0.1.5
 * @category constructors
 */
export declare const fromHSLA: (c: HSLA) => HSVA
