import { Color } from './Color'
/**
 * @category model
 * @since 0.1.0
 */
export declare type BlendMode = 'multiply' | 'screen' | 'overlay'
/**
 * Blend two colors with a specified blend mode. The first color is the
 * background color, the second one is the foreground color. The resulting
 * alpha value is calculated as arithmetic mean.
 *
 * @since 0.1.0
 */
export declare const blend: (
  mode: BlendMode
) => (a: Color) => (b: Color) => Color
/**
 * @since 0.1.0
 */
export declare const multiply: (a: Color) => (b: Color) => Color
/**
 * @since 0.1.0
 */
export declare const screen: (a: Color) => (b: Color) => Color
/**
 * @since 0.1.0
 */
export declare const overlay: (a: Color) => (b: Color) => Color
