/**
 * @since 0.1.0
 */
import { absurd } from 'fp-ts/function';
import { rgba2 } from './Color';
import { normalizedFromHSLA } from './RGBA';
/**
 * Blend two RGB channel values (numbers between 0.0 and 1.0).
 *
 * @internal
 * @since 0.1.0
 */
export var blendChannel = function (mode) {
    return function (a) {
        return function (b) {
            switch (mode) {
                case 'multiply': {
                    return a * b;
                }
                case 'screen': {
                    return 1.0 - (1.0 - a) * (1.0 - b);
                }
                case 'overlay': {
                    if (a < 0.5) {
                        return 2.0 * (a * b);
                    }
                    return 1.0 - 2.0 * (1.0 - a) * (1.0 - b);
                }
                default: {
                    return absurd(mode);
                }
            }
        };
    };
};
/**
 * Blend two colors with a specified blend mode. The first color is the
 * background color, the second one is the foreground color. The resulting
 * alpha value is calculated as arithmetic mean.
 *
 * @since 0.1.0
 */
export var blend = function (mode) {
    return function (a) {
        return function (b) {
            var ac = normalizedFromHSLA(a);
            var bc = normalizedFromHSLA(b);
            var bcm = blendChannel(mode);
            return rgba2(bcm(ac.r)(bc.r), bcm(ac.g)(bc.g), bcm(ac.b)(bc.b), (ac.a + bc.a) / 2.0);
        };
    };
};
/**
 * @since 0.1.0
 */
export var multiply = blend('multiply');
/**
 * @since 0.1.0
 */
export var screen = blend('screen');
/**
 * @since 0.1.0
 */
export var overlay = blend('overlay');
//# sourceMappingURL=Blending.js.map