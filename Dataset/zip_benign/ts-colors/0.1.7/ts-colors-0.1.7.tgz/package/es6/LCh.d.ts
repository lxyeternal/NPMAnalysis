import { HSLA } from './HSLA'
import { Hue } from './Hue'
/**
 * @category model
 * @since 0.1.5
 */
export interface LCh {
  /**
   * The lightness of the color, 0.0 gives absolute black and 100.0 gives the brightest white.
   */
  readonly l: number
  /**
   * Chroma, the colorfulness of the color. It's similar to saturation.
   */
  readonly c: number
  /**
   * A number between `0` and `360` representing the hue of the color in degrees.
   */
  readonly h: Hue
}
/**
 * @since 0.1.5
 * @category constructors
 */
export declare const lch: (l: number, c: number, h: number) => LCh
/**
 * @since 0.1.5
 * @category constructors
 */
export declare const fromHSLA: (c: HSLA) => LCh
/**
 * @since 0.1.5
 */
export declare const evolve: <
  F extends {
    [K in keyof LCh]: (a: LCh[K]) => number
  }
>(
  transformations: F
) => (c: LCh) => LCh
/**
 * @since 0.1.5
 */
export declare const mix: (ratio: number) => (a: LCh) => (b: LCh) => LCh
