/**
 * A `Color` represented by XYZ coordinates in the CIE 1931 color space. Note
 * that a `Color` always represents a color in the sRGB gamut (colors that
 * can be represented on a typical computer screen) while the XYZ color space
 * is bigger.
 *
 * See:
 * - [https://en.wikipedia.org/wiki/CIE_1931_color_space](https://en.wikipedia.org/wiki/CIE_1931_color_space)
 * - [https://en.wikipedia.org/wiki/SRGB](https://en.wikipedia.org/wiki/SRGB)
 *
 * @since 0.1.5
 */
import * as number from 'fp-ts/number';
import * as Ord from 'fp-ts/Ord';
import * as RGBA from './RGBA';
/**
 * Illuminant D65 constants
 *
 * @internal
 */
export var D65 = { xn: 0.95047, yn: 1.0, zn: 1.08883 };
var clampNumber = Ord.clamp(number.Ord);
/**
 * @category constructors
 * @since 0.1.5
 */
export var xyz = function (x, y, z) { return ({
    x: clampNumber(0.0, D65.xn)(x),
    y: clampNumber(0.0, D65.yn)(y),
    z: clampNumber(0.0, D65.zn)(z)
}); };
/**
 * @category constructors
 * @since 0.1.5
 */
export var fromHSLA = function (c) {
    var finv = function (c) {
        return c <= 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
    };
    var rec = RGBA.normalizedFromHSLA(c);
    var r = finv(rec.r);
    var g = finv(rec.g);
    var b = finv(rec.b);
    var x = 0.4124 * r + 0.3576 * g + 0.1805 * b;
    var y = 0.2126 * r + 0.7152 * g + 0.0722 * b;
    var z = 0.0193 * r + 0.1192 * g + 0.9505 * b;
    return xyz(x, y, z);
};
/**
 * @category constructors
 * @since 0.1.5
 */
export var fromLab = function (_a) {
    var l = _a.l, a = _a.a, b = _a.b;
    var delta = 6.0 / 29.0;
    var finv = function (t) {
        return t > delta ? Math.pow(t, 3.0) : 3.0 * delta * delta * (t - 4.0 / 29.0);
    };
    var l2 = (l + 16.0) / 116.0;
    var x = D65.xn * finv(l2 + a / 500.0);
    var y = D65.yn * finv(l2);
    var z = D65.zn * finv(l2 - b / 200.0);
    return xyz(x, y, z);
};
//# sourceMappingURL=XYZ.js.map