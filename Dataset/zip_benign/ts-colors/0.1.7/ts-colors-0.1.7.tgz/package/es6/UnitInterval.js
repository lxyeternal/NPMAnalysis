import * as Ord from 'fp-ts/Ord';
import * as number from 'fp-ts/number';
var clampNumber = Ord.clamp(number.Ord);
var clamp = clampNumber(0, 1);
export var unitInterval = function (r) {
    return clamp(r);
};
//# sourceMappingURL=UnitInterval.js.map