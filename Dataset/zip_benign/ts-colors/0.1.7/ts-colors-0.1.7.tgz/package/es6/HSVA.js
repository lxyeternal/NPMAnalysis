import { clipHue } from './Hue';
import { unitInterval } from './UnitInterval';
/**
 * @since 0.1.5
 * @category constructors
 */
export var hsva = function (h, s, v, a) { return ({
    h: clipHue(h),
    s: unitInterval(s),
    v: unitInterval(v),
    a: unitInterval(a)
}); };
/**
 * @since 0.1.5
 * @category constructors
 */
export var hsv = function (h, s, v) { return hsva(h, s, v, 1.0); };
/**
 * @since 0.1.5
 * @category constructors
 */
export var fromHSLA = function (_a) {
    var h = _a.h, s = _a.s, l = _a.l, a = _a.a;
    var tmp = s * (l < 0.5 ? l : 1.0 - l);
    var hue = clipHue(h);
    var saturation = (2.0 * tmp) / (l + tmp);
    var v = l + tmp;
    if (l === 0) {
        return hsva(hue, (2.0 * s) / (1.0 + s), 0.0, a);
    }
    if (s === 0 && l === 1) {
        return hsva(hue, 0.0, 1.0, a);
    }
    return hsva(hue, saturation, v, a);
};
//# sourceMappingURL=HSVA.js.map