/**
 * @since 0.1.0
 */
import * as Ord from 'fp-ts/Ord'
import * as Equals from 'fp-ts/Eq'
import * as Sh from 'fp-ts/Show'
import * as O from 'fp-ts/Option'
import { Endomorphism } from 'fp-ts/Endomorphism'
import * as HSLA from './HSLA'
import * as HSVA from './HSVA'
import * as RGBA from './RGBA'
import * as XYZ from './XYZ'
import * as Lab from './Lab'
import * as LCh from './LCh'
/**
 * @category model
 * @since 0.1.0
 */
export declare type ColorSpace = 'RGB' | 'HSL' | 'LCh' | 'Lab'
/**
 *  Colors are represented by their HSL values (hue, saturation, lightness) internally,
 *  as this provides more flexibility than storing RGB values.
 *
 * @category model
 * @since 0.1.0
 */
export declare type Color = HSLA.HSLA
/**
 * Create a `Color` from Hue, Saturation, Lightness and Alpha values. The
 * Hue is given in degrees, as a `Number` between 0.0 and 360.0. Saturation,
 * Lightness and Alpha are numbers between 0.0 and 1.0.
 *
 * @category constructors
 * @since 0.1.0
 */
export declare const hsla: (h: number, s: number, l: number, a: number) => Color
/**
 * Create a `Color` from Hue, Saturation, Lightness and Alpha values. The
 * Hue is given in degrees, as a `Number` between 0.0 and 360.0. Saturation,
 * Lightness and Alpha are numbers between 0.0 and 1.0.
 *
 * @category constructors
 * @since 0.1.0
 */
export declare const hsl: (h: number, s: number, l: number) => Color
/**
 * Create a `Color` from integer RGB values between 0 and 255 and a floating
 * point alpha value between 0.0 and 1.0.
 *
 * RGB to HSL conversion algorithm adapted from
 * https://en.wikipedia.org/wiki/HSL_and_HSV
 *
 * @category constructors
 * @since 0.1.0
 */
export declare const rgba: (r: number, g: number, b: number, a: number) => Color
/**
 * Create a `Color` from integer RGB values between 0 and 255.
 *
 * @category constructors
 * @since 0.1.0
 */
export declare const rgb: (r: number, g: number, b: number) => Color
/**
 * Create a `Color` from RGB and alpha values between 0.0 and 1.0.
 *
 * @category constructors
 * @since 0.1.0
 */
export declare const rgba2: (
  r: number,
  g: number,
  b: number,
  a: number
) => Color
/**
 * Create a `Color` from RGB values between 0.0 and 1.0.
 *
 * @category constructors
 * @since 0.1.0
 */
export declare const rgb2: (r: number, g: number, b: number) => Color
/**
 * Create a `Color` from Hue, Saturation, Value and Alpha values. The
 * Hue is given in degrees, as a `Number` between 0.0 and 360.0. Saturation,
 * Value and Alpha are numbers between 0.0 and 1.0.
 *
 * @category constructors
 * @since 0.1.0
 */
export declare const hsva: (h: number, s: number, v: number, a: number) => Color
/**
 * Create a `Color` from Hue, Saturation and Value values. The Hue is
 * given in degrees, as a `Number` between 0.0 and 360.0. Both Saturation and
 * Value are numbers between 0.0 and 1.0.
 *
 * @category constructors
 * @since 0.1.0
 */
export declare const hsv: (h: number, s: number, v: number) => Color
/**
 * Create a `Color` from XYZ coordinates in the CIE 1931 color space. Note
 * that a `Color` always represents a color in the sRGB gamut (colors that
 * can be represented on a typical computer screen) while the XYZ color space
 * is bigger. This function will tend to create fully saturated colors at the
 * edge of the sRGB gamut if the coordinates lie outside the sRGB range.
 *
 * See:
 * - https://en.wikipedia.org/wiki/CIE_1931_color_space
 * - https://en.wikipedia.org/wiki/SRGB
 *
 * @category constructors
 * @since 0.1.0
 */
export declare const xyz: (x: number, y: number, z: number) => Color
/**
 * Create a `Color` from L, a and b coordinates in the Lab color space.
 * Note: See documentation for `xyz`. The same restrictions apply here.
 *
 * See: https://en.wikipedia.org/wiki/Lab_color_space
 *
 * @category constructors
 * @since 0.1.0
 */
export declare const lab: (l: number, a: number, b: number) => Color
/**
 * Create a `Color` from lightness, chroma and hue coordinates in the CIE LCh
 * color space. This is a cylindrical transform of the Lab color space.
 * Note: See documentation for `xyz`. The same restrictions apply here.
 *
 * See: https://en.wikipedia.org/wiki/Lab_color_space
 *
 * @category constructors
 * @since 0.1.0
 */
export declare const lch: (l: number, c: number, h: number) => Color
/**
 * Parse a hexadecimal RGB code of the form `#rgb` or `#rrggbb`. The `#`
 * character is required. Each hexadecimal digit is of the form `[0-9a-fA-F]`
 * (case insensitive). Returns `Option.none` if the string is in a wrong format.
 *
 * @category constructors
 * @since 0.1.0
 */
export declare const fromHexString: (hex: string) => O.Option<Color>
/**
 * Converts an integer to a color (RGB representation). `0` is black and
 * `0xffffff` is white. Values outside this range will be clamped.
 *
 * This function is useful if you want to hard-code Hex values. For example:
 *
 * @example
 *
 * import * as C from 'ts-colors/Color'
 *
 * C.fromInt(0xff0000)
 *
 * @category constructors
 * @since 0.1.0
 */
export declare const fromInt: (i: number) => Color
/**
 * Pure black.
 *
 * @category constructors
 * @since 0.1.0
 */
export declare const black: HSLA.HSLA
/**
 * Pure white.
 *
 * @category constructors
 * @since 0.1.0
 */
export declare const white: HSLA.HSLA
/**
 * Create a gray tone from a lightness values (0.0 is black, 1.0 is white).
 *
 * @category constructors
 * @since 0.1.0
 */
export declare const graytone: (l: number) => Color
/**
 * Get the color hue in the interval [0, 360].
 *
 * @since 0.1.4
 * @category destructors
 */
export declare const hue: (c: Color) => number
/**
 * Convert a `Color` to its red, green, blue and alpha values. The RGB values
 * are integers in the range from 0 to 255. The alpha channel is a number
 * between 0.0 and 1.0.
 *
 * @since 0.1.0
 * @category destructors
 */
export declare const toRGBA: (c: Color) => RGBA.RGBA
/**
 * Convert a `Color` to its Hue, Saturation, Lightness and Alpha values. See
 * `hsla` for the ranges of each channel.
 *
 * @since 0.1.0
 * @category destructors
 */
export declare const toHSLA: (c: Color) => HSLA.HSLA
/**
 * Convert a `Color` to its Hue, Saturation, Value and Alpha values. See
 * `hsva` for the ranges of each channel.
 *
 * @since 0.1.0
 * @category destructors
 */
export declare const toHSVA: (c: Color) => HSVA.HSVA
/**
 * Get XYZ coordinates according to the CIE 1931 color space.
 *
 * See:
 * - https://en.wikipedia.org/wiki/CIE_1931_color_space
 * - https://en.wikipedia.org/wiki/SRGB
 *
 * @since 0.1.0
 * @category destructors
 */
export declare const toXYZ: (c: Color) => XYZ.XYZ
/**
 * Get L, a and b coordinates according to the Lab color space.
 *
 * See: https://en.wikipedia.org/wiki/Lab_color_space
 *
 * @since 0.1.0
 * @category destructors
 */
export declare const toLab: (c: Color) => Lab.Lab
/**
 * Get L, C and h coordinates according to the CIE LCh color space.
 * See: https://en.wikipedia.org/wiki/Lab_color_space
 *
 * @since 0.1.0
 * @category destructors
 */
export declare const toLCh: (c: Color) => LCh.LCh
/**
 * @since 0.1.0
 * @category destructors
 */
export declare const toHexString: (c: Color) => string
/**
 * A CSS representation of the color
 *
 * @since 0.1.5
 * @category destructors
 */
export declare const toCSS: (s: ColorSpace) => (c: Color) => string
/**
 * A CSS representation of the color in the form `hsl(..)` or `hsla(...)`.
 *
 * @since 0.1.5
 * @category destructors
 */
export declare const toHSLAString: (c: Color) => string
/**
 * Use [toHSLAString](#toHSLAString) instead
 *
 * @since 0.1.0
 * @category destructors
 * @deprecated
 */
export declare const cssStringHSLA: (c: Color) => string
/**
 * A CSS representation of the color in the form `rgb(..)` or `rgba(...)`
 *
 * @since 0.1.5
 * @category destructors
 */
export declare const toRGBAString: (c: Color) => string
/**
 * Use [toRGBAString](#toRGBAString) instead
 *
 * @since 0.1.0
 * @category destructors
 * @deprecated
 */
export declare const cssStringRGBA: (c: Color) => string
/**
 * Rotate the hue of a `Color` by a certain angle (in degrees).
 *
 * @since 0.1.0
 */
export declare const rotateHue: (angle: number) => (c: Color) => Color
/**
 * Get the complementary color (hue rotated by 180°).
 *
 * @since 0.1.0
 */
export declare const complementary: (c: Color) => Color
/**
 * Lighten a color by adding a certain amount (number between -1.0 and 1.0)
 * to the lightness channel. If the number is negative, the color is
 * darkened.
 *
 * @since 0.1.0
 */
export declare const lighten: (f: number) => (c: Color) => Color
/**
 * Darken a color by subtracting a certain amount (number between -1.0 and
 * 1.0) from the lightness channel. If the number is negative, the color is
 * lightened.
 *
 * @since 0.1.0
 */
export declare const darken: (f: number) => Endomorphism<Color>
/**
 * Increase the saturation of a color by adding a certain amount (number
 * between -1.0 and 1.0) to the saturation channel. If the number is
 * negative, the color is desaturated.
 *
 * @since 0.1.0
 */
export declare const saturate: (f: number) => (c: Color) => Color
/**
 * Decrease the saturation of a color by subtracting a certain amount (number
 * between -1.0 and 1.0) from the saturation channel. If the number is
 * negative, the color is saturated.
 *
 * @since 0.1.0
 */
export declare const desaturate: (f: number) => Endomorphism<Color>
/**
 * Convert a color to a gray tone with the same perceived luminance (see [luminance](#luminance))
 *
 * @since 0.1.0
 */
export declare const toGray: Endomorphism<Color>
/**
 * A function that interpolates between two colors. It takes a start color,
 * an end color, and a ratio in the interval [0.0, 1.0]. It returns the
 * mixed color.
 *
 * @since 0.1.0
 */
export declare type Interpolator = (
  a: Color
) => (b: Color) => (ratio: number) => Color
/**
 * Mix two colors by linearly interpolating between them in the RGB color space.
 *
 * @since 0.1.0
 */
export declare const mix: (space: ColorSpace) => Interpolator
/**
 * Mix two colors by linearly interpolating between them in the  HSL colorspace.
 * The shortest path is chosen along the circle of hue values.
 *
 * @since 0.1.0
 */
export declare const mixHSL: Interpolator
/**
 * Mix two colors by linearly interpolating between them in the RGB color space.
 *
 * @since 0.1.0
 */
export declare const mixRGB: Interpolator
/**
 * Mix two colors by linearly interpolating between them in the LCh color space.
 *
 * @since 0.1.0
 */
export declare const mixLCh: Interpolator
/**
 * Mix two colors by linearly interpolating between them in the Lab color space.
 *
 * @since 0.1.0
 */
export declare const mixLab: Interpolator
/**
 * get the alpha channel of a color
 *
 * @since 0.1.7
 */
export declare const alpha: (c: Color) => number
/**
 * get the alpha channel of a color
 *
 * @since 0.1.7
 */
export declare const setAlpha: (alpha: number) => Endomorphism<Color>
/**
 * The percieved brightness of the color (A number between 0.0 and 1.0).
 * See: https://www.w3.org/TR/AERT#color-contrast
 *
 * @since 0.1.0
 */
export declare const brightness: (c: Color) => number
/**
 * The relative brightness of a color (normalized to 0.0 for darkest black
 * and 1.0 for lightest white), according to the WCAG definition.
 *
 * See: https://www.w3.org/TR/2008/REC-WCAG20-20081211/#relativeluminancedef
 *
 * @since 0.1.0
 */
export declare const luminance: (color: Color) => number
/**
 * The contrast ratio of two colors. A minimum contrast ratio of 4.5 is
 * recommended to ensure that text is readable on a colored background. The
 * contrast ratio is symmetric on both arguments:
 * `contrast c1 c2 == contrast c2 c1`.
 *
 * See http://www.w3.org/TR/2008/REC-WCAG20-20081211/#contrast-ratiodef
 *
 * @since 0.1.0
 */
export declare const contrast: (c1: Color) => (c2: Color) => number
/**
 * Determine whether a color is perceived as a light color.
 *
 * @since 0.1.0
 */
export declare const isLight: (c: Color) => boolean
/**
 * Determine whether text of one color is readable on a background of a
 * different color (see `contrast`). This function is symmetric in both
 * arguments.
 *
 * @since 0.1.0
 */
export declare const isReadable: (c1: Color) => (c2: Color) => boolean
/**
 * Return a readable foreground text color (either `black` or `white`) for a
 * given background color.
 *
 * @since 0.1.0
 */
export declare const textColor: (c: Color) => Color
/**
 * Compute the perceived 'distance' between two colors according to the CIE76
 * delta-E standard. A distance below ~2.3 is not noticable.
 *
 * See: https://en.wikipedia.org/wiki/Color_difference
 *
 * @since 0.1.0
 */
export declare const distance: (a: Color) => (b: Color) => number
/**
 * @category instances
 * @since 0.1.0
 *
 * - The `Eq` instance compares two `Color`s by comparing their (integer) RGB
 *   values. This is different from comparing the HSL values (for example,
 *   HSL has many different representations of black (arbitrary hue and
 *   saturation values).
 */
export declare const Eq: Equals.Eq<Color>
/**
 * @category instances
 * @since 0.1.0
 */
export declare const OrdLuminance: Ord.Ord<Color>
/**
 * @category instances
 * @since 0.1.4
 */
export declare const OrdBrightness: Ord.Ord<Color>
/**
 * @category instances
 * @since 0.1.0
 */
export declare const Show: Sh.Show<Color>
