/**
 * @since 0.1.5
 */
import * as Ord from 'fp-ts/Ord';
import * as Equals from 'fp-ts/Eq';
import * as Sh from 'fp-ts/Show';
import * as number from 'fp-ts/number';
import * as struct from 'fp-ts/struct';
import { unitInterval } from './UnitInterval';
import { interpolate } from './math';
import { pipe } from 'fp-ts/function';
var clampChannel = Ord.clamp(number.Ord)(0, 255);
/**
 * @since 0.1.5
 * @internal
 */
export var channel = function (n) {
    return pipe(Math.round(n), clampChannel);
};
/**
 * @since 0.1.5
 * @internal
 */
export var denormalizeChannel = function (n) {
    return pipe(Math.round(n * 255.0), channel);
};
/**
 * @since 0.1.5
 * @internal
 */
export var normalizedChannel = unitInterval;
/**
 * @since 0.1.5
 * @category constructors
 */
export var rgba = function (r, g, b, a) { return ({
    r: channel(r),
    g: channel(g),
    b: channel(b),
    a: unitInterval(a)
}); };
/**
 * @since 0.1.5
 * @category constructors
 */
export var rgb = function (r, g, b) { return rgba(r, g, b, 1.0); };
/**
 * @since 0.1.5
 * @category constructors
 * @internal
 */
export var normalized = function (r, g, b, a) { return ({
    r: normalizedChannel(r),
    g: normalizedChannel(g),
    b: normalizedChannel(b),
    a: unitInterval(a)
}); };
/**
 * @since 0.1.5
 * @category constructors
 * @internal
 */
export var normalize = function (c) {
    return normalized(c.r / 255, c.g / 255, c.b / 255, c.a);
};
/**
 * @since 0.1.5
 * @category constructors
 * @internal
 */
export var normalizedFromHSLA = function (_a) {
    var h = _a.h, s = _a.s, l = _a.l, a = _a.a;
    var ch = h / 60.0;
    var chr = (1.0 - Math.abs(2.0 * l - 1.0)) * s;
    var m = l - chr / 2.0;
    var x = chr * (1.0 - Math.abs((ch % 2.0) - 1.0));
    var channels = function () {
        if (ch < 1.0) {
            return { r: chr, g: x, b: 0.0 };
        }
        if (1.0 <= ch && ch < 2.0) {
            return { r: x, g: chr, b: 0.0 };
        }
        if (2.0 <= ch && ch < 3.0) {
            return { r: 0.0, g: chr, b: x };
        }
        if (3.0 <= ch && ch < 4.0) {
            return { r: 0.0, g: x, b: chr };
        }
        if (4.0 <= ch && ch < 5.0) {
            return { r: x, g: 0.0, b: chr };
        }
        return { r: chr, g: 0.0, b: x };
    };
    var rgb = channels();
    return normalized(rgb.r + m, rgb.g + m, rgb.b + m, a);
};
/**
 * @since 0.1.5
 * @category constructors
 * @internal
 */
export var fromNormalized = function (c) {
    return rgba(denormalizeChannel(c.r), denormalizeChannel(c.g), denormalizeChannel(c.b), c.a);
};
/**
 * @since 0.1.5
 * @category constructors
 */
export var fromHSLA = function (c) {
    return pipe(normalizedFromHSLA(c), fromNormalized);
};
/**
 * @category constructors
 * @since 0.1.5
 */
export var fromXYZ = function (_a) {
    var x = _a.x, y = _a.y, z = _a.z;
    var f = function (c) {
        return c <= 0.0031308 ? 12.92 * c : 1.055 * Math.pow(c, 1.0 / 2.4) - 0.055;
    };
    var r = f(3.2406 * x - 1.5372 * y - 0.4986 * z);
    var g = f(-0.9689 * x + 1.8758 * y + 0.0415 * z);
    var b = f(0.0557 * x - 0.204 * y + 1.057 * z);
    return rgb(r * 255, g * 255, b * 255);
};
/**
 * @since 0.1.5
 */
export var maxChroma = function (_a) {
    var r = _a.r, g = _a.g, b = _a.b;
    return Math.max(Math.max(r, g), b);
};
/**
 * @since 0.1.5
 */
export var minChroma = function (_a) {
    var r = _a.r, g = _a.g, b = _a.b;
    return Math.min(Math.min(r, g), b);
};
/**
 * @since 0.1.5
 */
export var chroma = function (c) { return maxChroma(c) - minChroma(c); };
/**
 * The percieved brightness of the color (A number between 0.0 and 1.0).
 * See: [https://www.w3.org/TR/AERT#color-contrast](https://www.w3.org/TR/AERT#color-contrast)
 *
 * @since 0.1.5
 */
export var brightness = function (c) {
    return (299.0 * c.r + 587.0 * c.g + 114.0 * c.b) / 1000.0;
};
/**
 * The relative brightness of a color (normalized to 0.0 for darkest black
 * and 1.0 for lightest white), according to the WCAG definition.
 *
 * See: [https://www.w3.org/TR/2008/REC-WCAG20-20081211/#relativeluminancedef](https://www.w3.org/TR/2008/REC-WCAG20-20081211/#relativeluminancedef)
 *
 * @since 0.1.5
 */
export var luminance = function (rgba) {
    // const rgba = normalize(c)
    var f = function (c) {
        if (c <= 0.03928) {
            return c / 12.92;
        }
        return Math.pow((c + 0.055) / 1.055, 2.4);
    };
    var r = f(rgba.r);
    var g = f(rgba.g);
    var b = f(rgba.b);
    return 0.2126 * r + 0.7152 * g + 0.0722 * b;
};
/**
 * @since 0.1.5
 */
export var evolve = function (t) { return function (c) {
    return pipe(c, struct.evolve(t), function (_a) {
        var r = _a.r, g = _a.g, b = _a.b, a = _a.a;
        return rgba(r, g, b, a);
    });
}; };
/**
 * @since 0.1.5
 */
export var mix = function (ratio) {
    return function (a) {
        return function (b) {
            var i = interpolate(ratio);
            return pipe(b, evolve({
                r: i(a.r),
                g: i(a.g),
                b: i(a.b),
                a: i(a.a)
            }));
        };
    };
};
/**
 * A CSS representation of the color in the form `rgb(..)` or `rgba(...)`
 *
 * @since 0.1.5
 * @category destructors
 */
export var toCSS = function (c) {
    return c.a === 1.0
        ? "rgb(" + c.r + ", " + c.g + ", " + c.b + ")"
        : "rgba(" + c.r + ", " + c.g + ", " + c.b + ", " + c.a + ")";
};
/**
 * @category instances
 * @since 0.1.5
 */
export var Eq = Equals.struct({
    r: number.Eq,
    g: number.Eq,
    b: number.Eq,
    a: number.Eq
});
/**
 * @category instances
 * @since 0.1.5
 */
export var Show = Sh.struct({
    r: number.Show,
    g: number.Show,
    b: number.Show,
    a: number.Show
});
//# sourceMappingURL=RGBA.js.map