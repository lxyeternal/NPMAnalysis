/**
 * @since 0.1.5
 */
import { flow, pipe } from 'fp-ts/function';
import * as struct from 'fp-ts/struct';
import * as Hue from './Hue';
import { unitInterval } from './UnitInterval';
import * as RGBA from './RGBA';
import * as XYZ from './XYZ';
import * as Lab from './Lab';
import { interpolate, interpolateAngle } from './math';
/**
 * @category constructors
 * @since 0.1.5
 */
export var hsla = function (h, s, l, a) { return ({
    h: Hue.hue(h),
    s: unitInterval(s),
    l: unitInterval(l),
    a: unitInterval(a)
}); };
/**
 * @category constructors
 * @since 0.1.5
 */
export var hsl = function (h, s, l) { return hsla(h, s, l, 1.0); };
/**
 * @category constructors
 * @since 0.1.5
 */
export var fromRGBA = function (rgba) {
    var maxChroma = RGBA.maxChroma(rgba);
    var minChroma = RGBA.minChroma(rgba);
    var chroma = RGBA.chroma(rgba);
    var hue = Hue.fromRGBA(rgba);
    var lightness = (maxChroma + minChroma) / (255.0 * 2.0);
    var saturation = chroma === 0 ? 0 : chroma / 255 / (1.0 - Math.abs(2.0 * lightness - 1.0));
    return hsla(hue, saturation, lightness, rgba.a);
};
/**
 * @category constructors
 * @since 0.1.5
 */
export var fromHSVA = function (_a) {
    var h = _a.h, s = _a.s, v = _a.v, a = _a.a;
    var _b = pipe((2.0 - s) * v, function (tmp) { return ({
        saturation: (s * v) / (tmp < 1.0 ? tmp : 2.0 - tmp),
        lightness: tmp / 2.0
    }); }), saturation = _b.saturation, lightness = _b.lightness;
    if (v === 0) {
        return hsla(h, s / (2.0 - s), 0.0, a);
    }
    if (s === 0 && v === 1.0) {
        return hsla(h, 0.0, 1.0, a);
    }
    return hsla(h, saturation, lightness, a);
};
/**
 * @category constructors
 * @since 0.1.5
 */
export var fromXYZ = flow(RGBA.fromXYZ, fromRGBA);
/**
 * @category constructors
 * @since 0.1.5
 */
export var fromLab = flow(XYZ.fromLab, fromXYZ);
/**
 * @category constructors
 * @since 0.1.5
 */
export var fromLCh = flow(Lab.fromLCh, fromLab);
/**
 * Rotate the hue by a certain angle (in degrees).
 *
 * @since 0.1.5
 */
export var rotateHue = function (angle) {
    return function (_a) {
        var h = _a.h, s = _a.s, l = _a.l, a = _a.a;
        return hsla(h + angle, s, l, a);
    };
};
/**
 * get the alpha channel
 *
 * @since 0.1.7
 */
export var alpha = function (_a) {
    var a = _a.a;
    return a;
};
/**
 * set the alpha channel
 *
 * @since 0.1.7
 */
export var setAlpha = function (a) {
    return function (_a) {
        var h = _a.h, s = _a.s, l = _a.l;
        return hsla(h, s, l, a);
    };
};
/**
 * @since 0.1.5
 */
export var evolve = function (t) { return function (c) {
    return pipe(c, struct.evolve(t), function (_a) {
        var h = _a.h, s = _a.s, l = _a.l, a = _a.a;
        return hsla(h, s, l, a);
    });
}; };
/**
 * @since 0.1.5
 */
export var mix = function (ratio) {
    return function (a) {
        return function (b) {
            var i = interpolate(ratio);
            var ia = interpolateAngle(ratio);
            return pipe(b, evolve({
                h: ia(a.h),
                s: i(a.s),
                l: i(a.l),
                a: i(a.a)
            }));
        };
    };
};
/**
 * A CSS representation of the color in the form `hsl(..)` or `hsla(...)`.
 *
 * @since 0.1.5
 * @category destructors
 */
export var toCSS = function (_a) {
    var h = _a.h, s = _a.s, l = _a.l, a = _a.a;
    var p = function (n) {
        return pipe(Math.round(100.0 * (n * 100.0)) / 100.0, function (n) { return n + "%"; });
    };
    var saturation = p(s);
    var lightness = p(l);
    return a == 1.0
        ? "hsl(" + h + ", " + saturation + ", " + lightness + ")"
        : "hsla(" + h + ", " + saturation + ", " + lightness + ", " + a + ")";
};
//# sourceMappingURL=HSLA.js.map