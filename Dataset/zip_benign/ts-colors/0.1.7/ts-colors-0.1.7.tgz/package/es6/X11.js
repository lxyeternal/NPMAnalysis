/**
 * X11 colors as specified by the CSS3 specification (except black and white).
 * See: https://www.w3.org/TR/css3-color/#svg-color
 *
 * @since 0.1.0
 */
import { rgb } from './Color';
/**
 * @since 0.1.0
 */
export var aliceblue = rgb(240, 248, 255);
/**
 * @since 0.1.0
 */
export var antiquewhite = rgb(250, 235, 215);
/**
 * @since 0.1.0
 */
export var aqua = rgb(0, 255, 255);
/**
 * @since 0.1.0
 */
export var aquamarine = rgb(127, 255, 212);
/**
 * @since 0.1.0
 */
export var azure = rgb(240, 255, 255);
/**
 * @since 0.1.0
 */
export var beige = rgb(245, 245, 220);
/**
 * @since 0.1.0
 */
export var bisque = rgb(255, 228, 196);
/**
 * @since 0.1.0
 */
export var blanchedalmond = rgb(255, 235, 205);
/**
 * @since 0.1.0
 */
export var blue = rgb(0, 0, 255);
/**
 * @since 0.1.0
 */
export var blueviolet = rgb(138, 43, 226);
/**
 * @since 0.1.0
 */
export var brown = rgb(165, 42, 42);
/**
 * @since 0.1.0
 */
export var burlywood = rgb(222, 184, 135);
/**
 * @since 0.1.0
 */
export var cadetblue = rgb(95, 158, 160);
/**
 * @since 0.1.0
 */
export var chartreuse = rgb(127, 255, 0);
/**
 * @since 0.1.0
 */
export var chocolate = rgb(210, 105, 30);
/**
 * @since 0.1.0
 */
export var coral = rgb(255, 127, 80);
/**
 * @since 0.1.0
 */
export var cornflowerblue = rgb(100, 149, 237);
/**
 * @since 0.1.0
 */
export var cornsilk = rgb(255, 248, 220);
/**
 * @since 0.1.0
 */
export var crimson = rgb(220, 20, 60);
/**
 * @since 0.1.0
 */
export var cyan = rgb(0, 255, 255);
/**
 * @since 0.1.0
 */
export var darkblue = rgb(0, 0, 139);
/**
 * @since 0.1.0
 */
export var darkcyan = rgb(0, 139, 139);
/**
 * @since 0.1.0
 */
export var darkgoldenrod = rgb(184, 134, 11);
/**
 * @since 0.1.0
 */
export var darkgray = rgb(169, 169, 169);
/**
 * @since 0.1.0
 */
export var darkgreen = rgb(0, 100, 0);
/**
 * @since 0.1.0
 */
export var darkgrey = rgb(169, 169, 169);
/**
 * @since 0.1.0
 */
export var darkkhaki = rgb(189, 183, 107);
/**
 * @since 0.1.0
 */
export var darkmagenta = rgb(139, 0, 139);
/**
 * @since 0.1.0
 */
export var darkolivegreen = rgb(85, 107, 47);
/**
 * @since 0.1.0
 */
export var darkorange = rgb(255, 140, 0);
/**
 * @since 0.1.0
 */
export var darkorchid = rgb(153, 50, 204);
/**
 * @since 0.1.0
 */
export var darkred = rgb(139, 0, 0);
/**
 * @since 0.1.0
 */
export var darksalmon = rgb(233, 150, 122);
/**
 * @since 0.1.0
 */
export var darkseagreen = rgb(143, 188, 143);
/**
 * @since 0.1.0
 */
export var darkslateblue = rgb(72, 61, 139);
/**
 * @since 0.1.0
 */
export var darkslategray = rgb(47, 79, 79);
/**
 * @since 0.1.0
 */
export var darkslategrey = rgb(47, 79, 79);
/**
 * @since 0.1.0
 */
export var darkturquoise = rgb(0, 206, 209);
/**
 * @since 0.1.0
 */
export var darkviolet = rgb(148, 0, 211);
/**
 * @since 0.1.0
 */
export var deeppink = rgb(255, 20, 147);
/**
 * @since 0.1.0
 */
export var deepskyblue = rgb(0, 191, 255);
/**
 * @since 0.1.0
 */
export var dimgray = rgb(105, 105, 105);
/**
 * @since 0.1.0
 */
export var dimgrey = rgb(105, 105, 105);
/**
 * @since 0.1.0
 */
export var dodgerblue = rgb(30, 144, 255);
/**
 * @since 0.1.0
 */
export var firebrick = rgb(178, 34, 34);
/**
 * @since 0.1.0
 */
export var floralwhite = rgb(255, 250, 240);
/**
 * @since 0.1.0
 */
export var forestgreen = rgb(34, 139, 34);
/**
 * @since 0.1.0
 */
export var fuchsia = rgb(255, 0, 255);
/**
 * @since 0.1.0
 */
export var gainsboro = rgb(220, 220, 220);
/**
 * @since 0.1.0
 */
export var ghostwhite = rgb(248, 248, 255);
/**
 * @since 0.1.0
 */
export var gold = rgb(255, 215, 0);
/**
 * @since 0.1.0
 */
export var goldenrod = rgb(218, 165, 32);
/**
 * @since 0.1.0
 */
export var gray = rgb(128, 128, 128);
/**
 * @since 0.1.0
 */
export var green = rgb(0, 128, 0);
/**
 * @since 0.1.0
 */
export var greenyellow = rgb(173, 255, 47);
/**
 * @since 0.1.0
 */
export var grey = rgb(128, 128, 128);
/**
 * @since 0.1.0
 */
export var honeydew = rgb(240, 255, 240);
/**
 * @since 0.1.0
 */
export var hotpink = rgb(255, 105, 180);
/**
 * @since 0.1.0
 */
export var indianred = rgb(205, 92, 92);
/**
 * @since 0.1.0
 */
export var indigo = rgb(75, 0, 130);
/**
 * @since 0.1.0
 */
export var ivory = rgb(255, 255, 240);
/**
 * @since 0.1.0
 */
export var khaki = rgb(240, 230, 140);
/**
 * @since 0.1.0
 */
export var lavender = rgb(230, 230, 250);
/**
 * @since 0.1.0
 */
export var lavenderblush = rgb(255, 240, 245);
/**
 * @since 0.1.0
 */
export var lawngreen = rgb(124, 252, 0);
/**
 * @since 0.1.0
 */
export var lemonchiffon = rgb(255, 250, 205);
/**
 * @since 0.1.0
 */
export var lightblue = rgb(173, 216, 230);
/**
 * @since 0.1.0
 */
export var lightcoral = rgb(240, 128, 128);
/**
 * @since 0.1.0
 */
export var lightcyan = rgb(224, 255, 255);
/**
 * @since 0.1.0
 */
export var lightgoldenrodyellow = rgb(250, 250, 210);
/**
 * @since 0.1.0
 */
export var lightgray = rgb(211, 211, 211);
/**
 * @since 0.1.0
 */
export var lightgreen = rgb(144, 238, 144);
/**
 * @since 0.1.0
 */
export var lightgrey = rgb(211, 211, 211);
/**
 * @since 0.1.0
 */
export var lightpink = rgb(255, 182, 193);
/**
 * @since 0.1.0
 */
export var lightsalmon = rgb(255, 160, 122);
/**
 * @since 0.1.0
 */
export var lightseagreen = rgb(32, 178, 170);
/**
 * @since 0.1.0
 */
export var lightskyblue = rgb(135, 206, 250);
/**
 * @since 0.1.0
 */
export var lightslategray = rgb(119, 136, 153);
/**
 * @since 0.1.0
 */
export var lightslategrey = rgb(119, 136, 153);
/**
 * @since 0.1.0
 */
export var lightsteelblue = rgb(176, 196, 222);
/**
 * @since 0.1.0
 */
export var lightyellow = rgb(255, 255, 224);
/**
 * @since 0.1.0
 */
export var lime = rgb(0, 255, 0);
/**
 * @since 0.1.0
 */
export var limegreen = rgb(50, 205, 50);
/**
 * @since 0.1.0
 */
export var linen = rgb(250, 240, 230);
/**
 * @since 0.1.0
 */
export var magenta = rgb(255, 0, 255);
/**
 * @since 0.1.0
 */
export var maroon = rgb(128, 0, 0);
/**
 * @since 0.1.0
 */
export var mediumaquamarine = rgb(102, 205, 170);
/**
 * @since 0.1.0
 */
export var mediumblue = rgb(0, 0, 205);
/**
 * @since 0.1.0
 */
export var mediumorchid = rgb(186, 85, 211);
/**
 * @since 0.1.0
 */
export var mediumpurple = rgb(147, 112, 219);
/**
 * @since 0.1.0
 */
export var mediumseagreen = rgb(60, 179, 113);
/**
 * @since 0.1.0
 */
export var mediumslateblue = rgb(123, 104, 238);
/**
 * @since 0.1.0
 */
export var mediumspringgreen = rgb(0, 250, 154);
/**
 * @since 0.1.0
 */
export var mediumturquoise = rgb(72, 209, 204);
/**
 * @since 0.1.0
 */
export var mediumvioletred = rgb(199, 21, 133);
/**
 * @since 0.1.0
 */
export var midnightblue = rgb(25, 25, 112);
/**
 * @since 0.1.0
 */
export var mintcream = rgb(245, 255, 250);
/**
 * @since 0.1.0
 */
export var mistyrose = rgb(255, 228, 225);
/**
 * @since 0.1.0
 */
export var moccasin = rgb(255, 228, 181);
/**
 * @since 0.1.0
 */
export var navajowhite = rgb(255, 222, 173);
/**
 * @since 0.1.0
 */
export var navy = rgb(0, 0, 128);
/**
 * @since 0.1.0
 */
export var oldlace = rgb(253, 245, 230);
/**
 * @since 0.1.0
 */
export var olive = rgb(128, 128, 0);
/**
 * @since 0.1.0
 */
export var olivedrab = rgb(107, 142, 35);
/**
 * @since 0.1.0
 */
export var orange = rgb(255, 165, 0);
/**
 * @since 0.1.0
 */
export var orangered = rgb(255, 69, 0);
/**
 * @since 0.1.0
 */
export var orchid = rgb(218, 112, 214);
/**
 * @since 0.1.0
 */
export var palegoldenrod = rgb(238, 232, 170);
/**
 * @since 0.1.0
 */
export var palegreen = rgb(152, 251, 152);
/**
 * @since 0.1.0
 */
export var paleturquoise = rgb(175, 238, 238);
/**
 * @since 0.1.0
 */
export var palevioletred = rgb(219, 112, 147);
/**
 * @since 0.1.0
 */
export var papayawhip = rgb(255, 239, 213);
/**
 * @since 0.1.0
 */
export var peachpuff = rgb(255, 218, 185);
/**
 * @since 0.1.0
 */
export var peru = rgb(205, 133, 63);
/**
 * @since 0.1.0
 */
export var pink = rgb(255, 192, 203);
/**
 * @since 0.1.0
 */
export var plum = rgb(221, 160, 221);
/**
 * @since 0.1.0
 */
export var powderblue = rgb(176, 224, 230);
/**
 * @since 0.1.0
 */
export var purple = rgb(128, 0, 128);
/**
 * @since 0.1.0
 */
export var red = rgb(255, 0, 0);
/**
 * @since 0.1.0
 */
export var rosybrown = rgb(188, 143, 143);
/**
 * @since 0.1.0
 */
export var royalblue = rgb(65, 105, 225);
/**
 * @since 0.1.0
 */
export var saddlebrown = rgb(139, 69, 19);
/**
 * @since 0.1.0
 */
export var salmon = rgb(250, 128, 114);
/**
 * @since 0.1.0
 */
export var sandybrown = rgb(244, 164, 96);
/**
 * @since 0.1.0
 */
export var seagreen = rgb(46, 139, 87);
/**
 * @since 0.1.0
 */
export var seashell = rgb(255, 245, 238);
/**
 * @since 0.1.0
 */
export var sienna = rgb(160, 82, 45);
/**
 * @since 0.1.0
 */
export var silver = rgb(192, 192, 192);
/**
 * @since 0.1.0
 */
export var skyblue = rgb(135, 206, 235);
/**
 * @since 0.1.0
 */
export var slateblue = rgb(106, 90, 205);
/**
 * @since 0.1.0
 */
export var slategray = rgb(112, 128, 144);
/**
 * @since 0.1.0
 */
export var slategrey = rgb(112, 128, 144);
/**
 * @since 0.1.0
 */
export var snow = rgb(255, 250, 250);
/**
 * @since 0.1.0
 */
export var springgreen = rgb(0, 255, 127);
/**
 * @since 0.1.0
 */
export var steelblue = rgb(70, 130, 180);
/**
 * @since 0.1.0
 */
export var tan = rgb(210, 180, 140);
/**
 * @since 0.1.0
 */
export var teal = rgb(0, 128, 128);
/**
 * @since 0.1.0
 */
export var thistle = rgb(216, 191, 216);
/**
 * @since 0.1.0
 */
export var tomato = rgb(255, 99, 71);
/**
 * @since 0.1.0
 */
export var turquoise = rgb(64, 224, 208);
/**
 * @since 0.1.0
 */
export var violet = rgb(238, 130, 238);
/**
 * @since 0.1.0
 */
export var wheat = rgb(245, 222, 179);
/**
 * @since 0.1.0
 */
export var whitesmoke = rgb(245, 245, 245);
/**
 * @since 0.1.0
 */
export var yellow = rgb(255, 255, 0);
/**
 * @since 0.1.0
 */
export var yellowgreen = rgb(154, 205, 50);
//# sourceMappingURL=X11.js.map