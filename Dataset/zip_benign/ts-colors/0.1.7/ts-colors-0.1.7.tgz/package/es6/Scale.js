var __spreadArray = (this && this.__spreadArray) || function (to, from) {
    for (var i = 0, il = from.length, j = to.length; i < il; i++, j++)
        to[j] = from[i];
    return to;
};
/**
 * @since 0.1.0
 */
import * as Ord from 'fp-ts/Ord';
import * as number from 'fp-ts/number';
import * as RA from 'fp-ts/ReadonlyArray';
import * as A from 'fp-ts/Array';
import * as O from 'fp-ts/Option';
import * as boolean from 'fp-ts/boolean';
import * as string from 'fp-ts/string';
import * as C from './Color';
import { constant, flow, pipe } from 'fp-ts/function';
import { intercalate } from 'fp-ts/Foldable';
import { red, yellow } from './X11';
import { unitInterval } from './UnitInterval';
var ratio = unitInterval;
/**
 * Create a color stop from a given `Color` and a number between 0 and 1.
 * If the number is outside this range, it is clamped.
 *
 * @category constructors
 * @since 0.1.0
 */
export var colorStop = function (c, r) { return [c, ratio(r)]; };
/**
 * @category constructors
 * @since 0.1.0
 */
export var colorStops = function (l, m, r) {
    return pipe(m, 
    // clamp color stop ratios
    RA.map(function (_a) {
        var c = _a[0], r = _a[1];
        return colorStop(c, r);
    }), 
    // sort stops by ratio
    RA.sort(OrdColorStop), function (m) { return [l, m, r]; });
};
/**
 * Create a color scale. The color space is used for interpolation between
 * different stops. The first `Color` defines the left end (color at ratio
 * 0.0), the list of stops defines possible intermediate steps and the second
 * `Color` argument defines the right end point (color at ratio 1.0).
 *
 * @category constructors
 * @since 0.1.0
 */
export var colorScale = function (space, l, m, r) { return ({
    mode: space,
    stops: colorStops(l, m, r)
}); };
/**
 * A scale of colors from black to white.
 *
 * @category constructors
 * @since 0.1.0
 */
export var grayscale = colorScale('RGB', C.black, [], C.white);
/**
 * Extract the ratio out of a ColorStop
 *
 * @category destructors
 * @since 0.1.0
 */
export var stopRatio = function (_a) {
    var r = _a[1];
    return r;
};
/**
 * Extract the color out of a ColorStop
 *
 * @category destructors
 * @since 0.1.0
 */
export var stopColor = function (_a) {
    var c = _a[0];
    return c;
};
var OrdColorStop = Ord.contramap(stopRatio)(number.Ord);
/**
 * Extract the color out of a ColorStop
 *
 * @category destructors
 * @since 0.1.6
 */
export var stops = function (_a) {
    var stops = _a.stops;
    return stops;
};
/**
 * get the first color of the scale
 *
 * @since 0.1.4
 */
export var first = flow(stops, function (_a) {
    var first = _a[0];
    return first;
});
/**
 * get the last color of the scale
 *
 * @since 0.1.4
 */
export var last = flow(stops, function (_a) {
    var last = _a[2];
    return last;
});
/**
 * get the middle colors of the scale
 *
 * @since 0.1.4
 * @internal
 */
export var middle = flow(stops, function (_a) {
    var middle = _a[1];
    return middle;
});
/**
 * get the `ColorSpace` mode of the scale
 *
 * @since 0.1.4
 */
export var mode = function (s) { return s.mode; };
/**
 * change the `ColorSpace` mode of the scale
 *
 * @since 0.1.4
 */
export var changeMode = function (space) {
    return function (_a) {
        var stops = _a.stops;
        return colorScale.apply(void 0, __spreadArray([space], stops));
    };
};
/**
 * transform a scale to an ReadonlyArray of ColorStops
 *
 * @category destructors
 * @since 0.1.4
 */
export var toReadonlyArray = function (scale) {
    return pipe(middle(scale), RA.prepend(colorStop(first(scale), 0)), RA.append(colorStop(last(scale), 1)));
};
/**
 * Use [toReadonlyArray](#toReadonlyArray)
 *
 * @category destructors
 * @since 0.1.0
 * @deprecated
 */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export var toArray = toReadonlyArray;
/**
 * returns the amount of color stops in the scale
 *
 * @category destructors
 * @since 0.1.4
 */
export var length = flow(toReadonlyArray, function (x) { return x.length; });
/**
 * Like `combineColorStops`, but the width of the "transition zone" can be specified as the
 * first argument.
 *
 * @example
 *
 * import * as S from 'ts-colors/Scale'
 * import * as X11 from 'ts-colors/X11'
 *
 * const stops = S.colorStops(X11.yellow, [], X11.blue)
 *
 * S.combineStops(0.0005)(0.5)(stops)
 *
 * @since 0.1.0
 */
export var combineStops = function (epsilon) {
    return function (x) {
        return function (_a) {
            var aStart = _a[0], aMiddle = _a[1], aEnd = _a[2];
            return function (_a) {
                var bStart = _a[0], bMiddle = _a[1], bEnd = _a[2];
                var startStops = pipe(aMiddle, RA.map(function (stop) {
                    return pipe(stopRatio(stop), function (ratio) { return ratio / (1.0 / x); }, function (ratio) { return colorStop(stopColor(stop), ratio); });
                }));
                var midStops = [colorStop(aEnd, x - epsilon), colorStop(bStart, x)];
                var endStops = pipe(bMiddle, RA.map(function (stop) {
                    return pipe(stopRatio(stop), function (ratio) { return x + ratio / (1.0 / (1.0 - x)); }, function (ratio) { return colorStop(stopColor(stop), ratio); });
                }));
                var stops = __spreadArray(__spreadArray(__spreadArray([], startStops), midStops), endStops);
                return colorStops(aStart, stops, bEnd);
            };
        };
    };
};
/**
 * @internal
 * @since 0.1.4
 */
export var epsilon = 0.000001;
/**
 * Concatenates two color scales. The first argument specifies the transition point as
 * a number between zero and one. The color right at the transition point is the first
 * color of the second color scale.
 *
 * @example
 *
 * import * as S from 'ts-colors/Scale'
 * import * as X11 from 'ts-colors/X11'
 *
 * const stops = S.colorStops(X11.yellow, [], X11.blue)

 * S.combineColorStops(0.4)(stops)
 *
 * @since 0.1.0
 */
export var combineColorStops = combineStops(epsilon);
/**
 * Concatenates two color scales. The first argument specifies the transition point as
 * a number between zero and one. The color right at the transition point is the first
 * color of the second color scale.
 *
 * @since 0.1.4
 */
export var combine = function (e) { return function (a) { return function (b) {
    var c = combineColorStops(e);
    return pipe(b.stops, c(a.stops), function (s) { return colorScale.apply(void 0, __spreadArray([a.mode], s)); });
}; }; };
/**
 * reverses `ColorStops`
 *
 * @since 0.1.0
 * @internal
 */
export var reverseStops = function (_a) {
    var start = _a[0], stops = _a[1], end = _a[2];
    return pipe(stops, RA.reverse, RA.map(function (_a) {
        var c = _a[0], r = _a[1];
        return colorStop(c, 1 - r);
    }), function (stops) { return [end, stops, start]; });
};
/**
 * Reverses a color scale
 *
 * @since 0.1.4
 */
export var reverse = function (_a) {
    var mode = _a.mode, stops = _a.stops;
    return colorScale.apply(void 0, __spreadArray([mode], reverseStops(stops)));
};
/**
 * Create `ColorStops` from a list of colors such that they will be evenly
 * spaced on the scale.
 *
 * @since 0.1.0
 * @internal
 */
export var uniformStops = function (s, m, e) {
    var length = m.length;
    var n = 1 + length;
    var stops = A.zipWith(A.range(1, n), m, function (i, c) {
        return colorStop(c, i / n);
    });
    return colorStops(s, stops, e);
};
/**
 * Create a uniform color scale from a list of colors that will be evenly
 * spaced on the scale.
 *
 * @since 0.1.0
 */
export var uniformScale = function (mode) {
    return function (s, m, e) {
        return pipe(uniformStops(s, m, e), function (stops) { return colorScale.apply(void 0, __spreadArray([mode], stops)); });
    };
};
var insertBy = function (_a) {
    var compare = _a.compare;
    return function (a) {
        return function (bs) {
            return pipe(bs, RA.findIndex(function (b) { return compare(a, b) === 1; }), O.fold(function () { return pipe(bs, RA.append(a)); }, function (i) { return RA.unsafeInsertAt(i, a, bs); }));
        };
    };
};
var insertByRatio = insertBy(OrdColorStop);
/**
 * Add a stop to a list of `ColorStops`.
 *
 * @since 0.1.0
 * @internal
 */
export var insertStop = function (c, r) {
    return function (_a) {
        var s = _a[0], m = _a[1], e = _a[2];
        return pipe(colorStop(c, r), function (stop) { return pipe(m, insertByRatio(stop)); }, function (stops) { return colorStops(s, RA.toArray(stops), e); });
    };
};
/**
 * Add a stop to a color scale.
 *
 * @since 0.1.0
 */
export var addStop = function (c, r) {
    return function (_a) {
        var mode = _a.mode, stops = _a.stops;
        return pipe(stops, insertStop(c, r), function (_a) {
            var s = _a[0], m = _a[1], e = _a[2];
            return colorScale(mode, s, RA.toArray(m), e);
        });
    };
};
var between = Ord.between(number.Ord);
/**
 * Get the color at a specific point on the color scale (number between 0 and
 * 1). If the number is smaller than 0, the color at 0 is returned. If the
 * number is larger than 1, the color at 1 is returned.
 *
 * @since 0.1.0
 * @internal
 */
export var simpleSampler = function (interpolate) {
    return function (_a) {
        var start = _a[0], middle = _a[1], end = _a[2];
        return function (x) {
            if (x < 0) {
                return start;
            }
            if (x > 1) {
                return end;
            }
            var sample = function (c1, left, cs) {
                return pipe(cs, RA.matchLeft(constant(c1), function (_a, rest) {
                    var c2 = _a[0], right = _a[1];
                    /* istanbul ignore next */
                    if (left === right) {
                        return c1;
                    }
                    return pipe(x, between(left, right), boolean.fold(function () { return sample(c2, right, rest); }, function () {
                        var p = (x - left) / (right - left);
                        return interpolate(c1)(c2)(p);
                    }));
                }));
            };
            var stops = pipe(middle, RA.append(colorStop(end, 1.0)));
            return sample(start, 0, stops);
        };
    };
};
/**
 * Get the color at a specific point on the color scale by linearly
 * interpolating between its colors.
 *
 * @since 0.1.0
 */
export var sample = function (_a) {
    var mode = _a.mode, stops = _a.stops;
    return pipe(stops, simpleSampler(C.mix(mode)));
};
/**
 * Takes a sampling function and returns a list of colors that is sampled via
 * that function. The number of colors can be specified.
 *
 * @since 0.1.0
 * @internal
 */
export var makeColors = function (f) {
    return function (n) {
        if (n === 0) {
            return [];
        }
        if (n === 1) {
            return [f(0)];
        }
        return A.makeBy(n, function (i) { return f(i / (n - 1)); });
    };
};
/**
 * A list of colors that is sampled from a color scale. The number of colors
 * can be specified.
 *
 * @since 0.1.0
 */
export var sampleColors = function (x) {
    return function (scale) {
        return pipe(x, makeColors(sample(scale)));
    };
};
/**
 * Modify a list of  `ColorStops` by applying the given function to each color
 * stop. The first argument is the position of the color stop.
 *
 * @since 0.1.0
 * @internal
 */
export var modifyColorStops = function (f) {
    return function (_a) {
        var start = _a[0], middle = _a[1], end = _a[2];
        return colorStops(f(0, start), pipe(middle, RA.map(function (_a) {
            var c = _a[0], r = _a[1];
            return colorStop(f(r, c), r);
        }), RA.toArray), f(1, end));
    };
};
/**
 * Modify the colors of a scale by applying the given function to each
 * color stop. The first argument is the position of the color stop.
 *
 * @since 0.1.4
 */
export var modify = function (f) {
    return function (_a) {
        var mode = _a.mode, stops = _a.stops;
        return pipe(stops, modifyColorStops(f), function (stops) { return colorScale.apply(void 0, __spreadArray([mode], stops)); });
    };
};
/**
 * A spectrum of fully saturated hues (HSL color space).
 *
 * @since 0.1.0
 */
export var spectrum = pipe({
    end: C.hsl(0.0, 1.0, 0.5),
    stops: pipe(A.range(1, 35), A.map(function (i) { return colorStop(C.hsl(10.0 * i, 1.0, 0.5), i / 36.0); }))
}, function (_a) {
    var end = _a.end, stops = _a.stops;
    return colorScale('HSL', end, stops, end);
});
/**
 * A perceptually-uniform, diverging color scale from blue to red, similar to
 * the ColorBrewer scale 'RdBu'.
 *
 * @since 0.1.0
 */
export var blueToRed = pipe({
    gray: C.fromInt(0xf7f7f7),
    red: C.fromInt(0xb2182b),
    blue: C.fromInt(0x2166ac)
}, function (_a) {
    var red = _a.red, gray = _a.gray, blue = _a.blue;
    return uniformScale('Lab')(blue, [gray], red);
});
/**
 * A perceptually-uniform, multi-hue color scale from yellow to red, similar
 * to the ColorBrewer scale YlOrRd.
 *
 * @since 0.1.0
 */
export var yellowToRed = pipe({
    yellow: C.fromInt(0xffffcc),
    orange: C.fromInt(0xfd8d3c),
    red: C.fromInt(0x800026)
}, function (_a) {
    var yellow = _a.yellow, orange = _a.orange, red = _a.red;
    return uniformScale('Lab')(yellow, [orange], red);
});
/**
 * A color scale that represents 'hot' colors.
 *
 * @since 0.1.0
 */
export var hot = colorScale('RGB', C.black, [colorStop(red, 0.5), colorStop(yellow, 0.75)], C.white);
/**
 * A color scale that represents 'cool' colors.
 *
 * @since 0.1.0
 */
export var cool = colorScale('RGB', C.hsl(180.0, 1.0, 0.6), [], C.hsl(300.0, 1.0, 0.5));
/**
 * Takes number of stops `ColorStops` should contain, function to generate
 * missing colors and `ColorStops` itself.
 *
 * @since 0.1.0
 * @internal
 */
export var minColorStops = function (sampler) {
    return function (n) {
        return function (stops) {
            if (n === 0) {
                return stops;
            }
            var additionalStops = pipe(n > 2, boolean.fold(constant([]), function () {
                return pipe(A.range(1, n - 1), A.map(function (step) {
                    var frac = ratio(step / n);
                    return pipe(frac, sampler(stops), function (c) { return colorStop(c, frac); });
                }));
            }));
            return pipe(additionalStops, A.reduce(stops, function (stops, _a) {
                var c = _a[0], r = _a[1];
                return pipe(stops, insertStop(c, r));
            }));
        };
    };
};
var intercalateAS = intercalate(string.Monoid, RA.Foldable);
var cssColorStopsRGB = function (_a) {
    var s = _a[0], m = _a[1], e = _a[2];
    if (RA.isEmpty(m)) {
        return C.toHSLAString(s) + ", " + C.toHSLAString(e);
    }
    var percentage = function (r) { return r * 100.0 + "%"; };
    var toString = function (_a) {
        var c = _a[0], r = _a[1];
        return C.toHSLAString(c) + " " + percentage(r);
    };
    var stops = pipe(m, RA.map(toString), function (stop) { return intercalateAS(', ', stop); });
    return C.toHSLAString(s) + ", " + stops + ", " + C.toHSLAString(e);
};
/**
 * A CSS representation of the color scale in the form of a comma-separated
 * list of color stops. This list can be used in a `linear-gradient` or
 * a similar construct.
 *
 * Note that CSS uses the RGB space for color interpolation. Consequently, if
 * the color scale is in RGB mode, this is just a list of all defined color
 * stops.
 *
 * For other color spaces, the color scale is sampled at (at least) 10
 * different points. This should give a reasonable approximation to the true
 * gradient in the specified color space.
 *
 * @since 0.1.0
 */
export var cssColorStops = function (_a) {
    var mode = _a.mode, stops = _a.stops;
    if (mode === 'RGB') {
        return cssColorStopsRGB(stops);
    }
    var interpolate = C.mix(mode);
    var sample = simpleSampler(interpolate);
    var sampleSteps = minColorStops(sample);
    return pipe(stops, sampleSteps(10), cssColorStopsRGB);
};
//# sourceMappingURL=Scale.js.map