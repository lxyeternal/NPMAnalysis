import * as C from './Color'
import { Endomorphism } from 'fp-ts/Endomorphism'
import { UnitInterval } from './UnitInterval'
declare type Ratio = UnitInterval
/**
 * A point on the color scale.
 *
 * @since 0.1.0
 * @category model
 */
export declare type ColorStop = readonly [C.Color, Ratio]
/**
 * Represents all `ColorStops` in a color scale. The first `Color` defines the left end
 * (color at ratio 0.0), the list of stops defines possible intermediate steps
 * and the second `Color` argument defines the right end point (color at ratio 1.0).
 *
 * @since 0.1.0
 * @category model
 */
export declare type ColorStops = readonly [
  first: C.Color,
  middle: ReadonlyArray<ColorStop>,
  last: C.Color
]
/**
 * A color scale is represented by a list of `ColorStops` and a `ColorSpace` that is
 * used for interpolation between the stops.
 *
 * @since 0.1.0
 * @category model
 */
export declare type ColorScale = {
  readonly mode: C.ColorSpace
  readonly stops: ColorStops
}
/**
 * Create a color stop from a given `Color` and a number between 0 and 1.
 * If the number is outside this range, it is clamped.
 *
 * @category constructors
 * @since 0.1.0
 */
export declare const colorStop: (c: C.Color, r: number) => ColorStop
/**
 * @category constructors
 * @since 0.1.0
 */
export declare const colorStops: (
  l: C.Color,
  m: ReadonlyArray<readonly [C.Color, number]>,
  r: C.Color
) => ColorStops
/**
 * Create a color scale. The color space is used for interpolation between
 * different stops. The first `Color` defines the left end (color at ratio
 * 0.0), the list of stops defines possible intermediate steps and the second
 * `Color` argument defines the right end point (color at ratio 1.0).
 *
 * @category constructors
 * @since 0.1.0
 */
export declare const colorScale: (
  space: C.ColorSpace,
  l: C.Color,
  m: ReadonlyArray<readonly [C.Color, number]>,
  r: C.Color
) => ColorScale
/**
 * A scale of colors from black to white.
 *
 * @category constructors
 * @since 0.1.0
 */
export declare const grayscale: ColorScale
/**
 * Extract the ratio out of a ColorStop
 *
 * @category destructors
 * @since 0.1.0
 */
export declare const stopRatio: (s: ColorStop) => Ratio
/**
 * Extract the color out of a ColorStop
 *
 * @category destructors
 * @since 0.1.0
 */
export declare const stopColor: (s: ColorStop) => C.Color
/**
 * Extract the color out of a ColorStop
 *
 * @category destructors
 * @since 0.1.6
 */
export declare const stops: (s: ColorScale) => ColorStops
/**
 * get the first color of the scale
 *
 * @since 0.1.4
 */
export declare const first: (c: ColorScale) => C.Color
/**
 * get the last color of the scale
 *
 * @since 0.1.4
 */
export declare const last: (c: ColorScale) => C.Color
/**
 * get the `ColorSpace` mode of the scale
 *
 * @since 0.1.4
 */
export declare const mode: (s: ColorScale) => C.ColorSpace
/**
 * change the `ColorSpace` mode of the scale
 *
 * @since 0.1.4
 */
export declare const changeMode: (
  space: C.ColorSpace
) => (scale: ColorScale) => ColorScale
/**
 * transform a scale to an ReadonlyArray of ColorStops
 *
 * @category destructors
 * @since 0.1.4
 */
export declare const toReadonlyArray: (
  s: ColorScale
) => ReadonlyArray<ColorStop>
/**
 * Use [toReadonlyArray](#toReadonlyArray)
 *
 * @category destructors
 * @since 0.1.0
 * @deprecated
 */
export declare const toArray: (s: ColorScale) => ColorStop[]
/**
 * returns the amount of color stops in the scale
 *
 * @category destructors
 * @since 0.1.4
 */
export declare const length: (s: ColorScale) => number
/**
 * Like `combineColorStops`, but the width of the "transition zone" can be specified as the
 * first argument.
 *
 * @example
 *
 * import * as S from 'ts-colors/Scale'
 * import * as X11 from 'ts-colors/X11'
 *
 * const stops = S.colorStops(X11.yellow, [], X11.blue)
 *
 * S.combineStops(0.0005)(0.5)(stops)
 *
 * @since 0.1.0
 */
export declare const combineStops: (
  e: number
) => (x: number) => (a: ColorStops) => (b: ColorStops) => ColorStops
/**
 * Concatenates two color scales. The first argument specifies the transition point as
 * a number between zero and one. The color right at the transition point is the first
 * color of the second color scale.
 *
 * @example
 *
 * import * as S from 'ts-colors/Scale'
 * import * as X11 from 'ts-colors/X11'
 *
 * const stops = S.colorStops(X11.yellow, [], X11.blue)

 * S.combineColorStops(0.4)(stops)
 *
 * @since 0.1.0
 */
export declare const combineColorStops: (
  x: number
) => (a: ColorStops) => (b: ColorStops) => ColorStops
/**
 * Concatenates two color scales. The first argument specifies the transition point as
 * a number between zero and one. The color right at the transition point is the first
 * color of the second color scale.
 *
 * @since 0.1.4
 */
export declare const combine: (
  e: number
) => (a: ColorScale) => (b: ColorScale) => ColorScale
/**
 * Reverses a color scale
 *
 * @since 0.1.4
 */
export declare const reverse: Endomorphism<ColorScale>
/**
 * Create a uniform color scale from a list of colors that will be evenly
 * spaced on the scale.
 *
 * @since 0.1.0
 */
export declare const uniformScale: (
  mode: C.ColorSpace
) => (s: C.Color, m: C.Color[], e: C.Color) => ColorScale
/**
 * Add a stop to a color scale.
 *
 * @since 0.1.0
 */
export declare const addStop: (
  c: C.Color,
  r: number
) => (s: ColorScale) => ColorScale
/**
 * Get the color at a specific point on the color scale by linearly
 * interpolating between its colors.
 *
 * @since 0.1.0
 */
export declare const sample: (s: ColorScale) => (x: number) => C.Color
/**
 * A list of colors that is sampled from a color scale. The number of colors
 * can be specified.
 *
 * @since 0.1.0
 */
export declare const sampleColors: (
  x: number
) => (scale: ColorScale) => C.Color[]
/**
 * Modify the colors of a scale by applying the given function to each
 * color stop. The first argument is the position of the color stop.
 *
 * @since 0.1.4
 */
export declare const modify: (
  f: (i: number, c: C.Color) => C.Color
) => (s: ColorScale) => ColorScale
/**
 * A spectrum of fully saturated hues (HSL color space).
 *
 * @since 0.1.0
 */
export declare const spectrum: ColorScale
/**
 * A perceptually-uniform, diverging color scale from blue to red, similar to
 * the ColorBrewer scale 'RdBu'.
 *
 * @since 0.1.0
 */
export declare const blueToRed: ColorScale
/**
 * A perceptually-uniform, multi-hue color scale from yellow to red, similar
 * to the ColorBrewer scale YlOrRd.
 *
 * @since 0.1.0
 */
export declare const yellowToRed: ColorScale
/**
 * A color scale that represents 'hot' colors.
 *
 * @since 0.1.0
 */
export declare const hot: ColorScale
/**
 * A color scale that represents 'cool' colors.
 *
 * @since 0.1.0
 */
export declare const cool: ColorScale
/**
 * A CSS representation of the color scale in the form of a comma-separated
 * list of color stops. This list can be used in a `linear-gradient` or
 * a similar construct.
 *
 * Note that CSS uses the RGB space for color interpolation. Consequently, if
 * the color scale is in RGB mode, this is just a list of all defined color
 * stops.
 *
 * For other color spaces, the color scale is sampled at (at least) 10
 * different points. This should give a reasonable approximation to the true
 * gradient in the specified color space.
 *
 * @since 0.1.0
 */
export declare const cssColorStops: (s: ColorScale) => string
export {}
