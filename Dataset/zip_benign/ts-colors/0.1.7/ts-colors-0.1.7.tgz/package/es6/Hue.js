/**
 * @since 0.1.0
 */
import { pipe } from 'fp-ts/function';
import { Ord } from 'fp-ts/number';
import { between } from 'fp-ts/Ord';
import { mod } from './math';
import * as RGBA from './RGBA';
/**
 * A number between `0` and `360` representing the hue of a color in degrees.
 *
 * @since 0.1.5
 */
export var hue = function (n) { return clipHue(n); };
/**
 * Assert that the hue angle is in the interval [0, 360].
 *
 * @since 0.1.0
 */
export var clipHue = function (hue) {
    return (between(Ord)(0, 360)(hue) ? hue : mod(hue)(360));
};
/**
 * @category constructors
 * @since 0.1.5
 */
export var fromRGBA = function (rgba) {
    var chroma = RGBA.chroma(rgba);
    var maxChroma = RGBA.maxChroma(rgba);
    var r = rgba.r / 255;
    var g = rgba.g / 255;
    var b = rgba.b / 255;
    var c = chroma / 255;
    var n = function (x) { return hue(60.0 * x); };
    if (chroma === 0) {
        return hue(0);
    }
    if (maxChroma === rgba.r) {
        return pipe((g - b) / c, function (x) { return mod(x)(6.0); }, n);
    }
    if (maxChroma === rgba.g) {
        return n((b - r) / c + 2.0);
    }
    return n((r - g) / c + 4.0);
};
//# sourceMappingURL=Hue.js.map