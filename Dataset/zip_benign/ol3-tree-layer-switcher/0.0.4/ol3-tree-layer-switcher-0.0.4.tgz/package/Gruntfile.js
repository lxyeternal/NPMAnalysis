module.exports = function (grunt) {
    grunt.initConfig({
        browserify: {
            dist: {
                files: {
                    'dist/ol3-tree-layer-switcher.js': ['src/js/index.js']
                }
            }
        },
        uglify: {
            editor: {
                files: {
                    'dist/ol3-tree-layer-switcher.min.js': ['dist/ol3-tree-layer-switcher.js']
                }
            }
        }

    });

    grunt.loadNpmTasks('grunt-browserify');
    grunt.loadNpmTasks('grunt-contrib-uglify');
    grunt.registerTask('build', ['browserify', 'uglify']);
    grunt.registerTask('default', ['build']);

};

