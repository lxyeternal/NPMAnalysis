var TreeLayerSwitcherItem = require('./TreeLayerSwitcherItem');


/**
 * @description "Create a tree layer switcher <div>"
 * @constructor
 * @param {string} div "id attribute from the TreeLayerSwitcher <div>"
 * @param {OpenLayers.Map} map "Map OpenLayers using TreeLayerSwitcher"
 * @returns {undefined}
 */
var TreeLayerSwitcher = function (div, map) {
    this.map = map;
    this.layers = Array();
    this.root = new TreeLayerSwitcherItem(div, null, map);
    this.root.name = div;
    var self = this;
    this.root.getTreeLayerSwitcher = function () {
        return self;
    };
    // ajout au DOM de la div existante
    this.div = document.getElementById(div);
    this.div.className = "ign-tls-layers-menu";
    this.root.div = this.div;
    this.root.treelayerSwitcherItems = [];
    this.root.treelayerSwitcherItems[this.root.name] = this.root;

    map.getView().on('change:resolution', function (e) {
        self.updateLayersEntriesColorByZoom();
    });


};

/**
 * Change la couleur de titre (gris ou non) d'un TreeLayerSwitcherItem lié au layer passé en paramètre
 * 
 * @param {OpenLayers.Layer.WMS} layer
 */
TreeLayerSwitcher.prototype.updateLayerEntryColorByZoom = function (layer) {
    if (layer === null) {
        return;
    }

    /* Récupération du treeLayerSwitcherItem correspondant au layers */
    var tlsi;
    var treeLayerSwitcherItem;
    for (var layerEntryName in this.root.treelayerSwitcherItems) {
        treeLayerSwitcherItem = this.root.treelayerSwitcherItems[layerEntryName];
        if (treeLayerSwitcherItem.layer === layer) {
            tlsi = treeLayerSwitcherItem;
            continue;
        }

        if (treeLayerSwitcherItem.parent === layer) {
            tlsi = treeLayerSwitcherItem;
            continue;
        }
    }

    var inRange = this.layerIsInRange(layer);

    if (tlsi !== undefined) {

        /* Si le TLSI parent n'est pas un layer et n'est pas null, 
         * on regarde si au moins un de ses enfants est inRange pour changer sa couleur */
        if (tlsi.parent !== null && typeof tlsi.parent.U === "undefined") {
            var parentInRange = false;
            for (var i in tlsi.parent.children) {
                if (tlsi.parent.children[i].layer !== null && typeof tlsi.parent.children[i].layer.U !== "undefined") {

                    if (this.layerIsInRange(tlsi.parent.children[i].layer)) {
                        parentInRange = true;
                        continue;
                    }
                }
            }

            if (parentInRange) {
                if (tlsi.parent.div.className.match(/notInZoomRange/g)) {
                    tlsi.parent.div.className = tlsi.parent.div.className.replace(/notInZoomRange/g, "");
                }
            } else {
                if (!tlsi.parent.div.className.match(/notInZoomRange/g)) {
                    tlsi.parent.div.className += " notInZoomRange";
                }
            }
        }

        if (inRange) {
            if (tlsi.div.className.match(/notInZoomRange/g)) {
                tlsi.div.className = tlsi.div.className.replace(/notInZoomRange/g, "");
            }
        } else {
            if (!tlsi.div.className.match(/notInZoomRange/g)) {
                tlsi.div.className += " notInZoomRange";
            }
        }
    }
    return;
};

/**
 *  Change la couleur de titre (gris ou non) de tous les TreeLayerSwitcherItems du TreeLayerSwitcher
 */
TreeLayerSwitcher.prototype.updateLayersEntriesColorByZoom = function () {
    for (var key in this.layers) {
        this.updateLayerEntryColorByZoom(this.layers[key]);
    }
};

/**
 * @description "Add a layer to the TreeLayerSwitcher"
 * @param {string} path "configure the place of the layer in the TreeLayerSwitcher arborescence (ex. : 'parent/branch1')" 
 * @param {OpenLayers.Layer.WMS} layerconfig "Configuration of layers"
 * @param {OpenLayers.Layer.WMS} layer "layer to put in the treeLayerSwitcher"
 * @param {number} opacity "Value between 0 and 100"
 * @param {boolean} isParent 
 * @param {boolean}  isVisible "init visibility of the layer and its checkbox associate"
 * @returns {TreeLayerSwitcherItem} TreeLayerSwitcherItem ajouté au TreeLayerSwitcher
 */
TreeLayerSwitcher.prototype.addLayer = function (path, layerconfig, layer, opacity, isParent, isVisible) {
    var current = this.root;
    if (path !== undefined) {
        var parts = path.split('/');
    } else {
        var parts = new Array();
    }
    for (var i in parts) {
        var next = current.getOrCreateChild(parts[i], current);
        current = next;
    }
    if (isParent) {
        current.setParentLayer(this.root, layerconfig, layer, opacity, isVisible);
    } else {
        current.setLayer(this.root, layerconfig, layer, opacity, isVisible);
    }

    this.layers[current.checkbox.id] = layer;

    return current;
};

/**
 * @description "Close the TreeLayerSwitcher"
 * @returns {undefined}
 */
TreeLayerSwitcher.prototype.closeMenuLayers = function () {
    var self = this;
    var layersToHide = document.getElementsByClassName('ign-tls-layer-menu');
    for (var i in layersToHide) {
        if (layersToHide[i] instanceof HTMLElement) {
            $(layersToHide[i]).hide("fast");
        }
    }

    $(this.divTitle).off('click');
    $(this.divTitle).on('click', function () {
        self.openMenuLayers();
    });
};

/**
 * @description "Open the TreeLayerSwitcher"
 * @returns {undefined}
 */
TreeLayerSwitcher.prototype.openMenuLayers = function () {
    var self = this;
    var layersToShow = document.getElementsByClassName('ign-tls-layer-menu');
    for (var i in layersToShow) {
        if (layersToShow[i] instanceof HTMLElement) {
            $(layersToShow[i]).show("fast");
        }
    }
    $(this.divTitle).off('click');
    $(this.divTitle).on('click', function () {
        self.closeMenuLayers();
    });
};


/**
 * @function initCheckboxState
 *
 * @description "init the state of the checkboxes (checked or not)"
 * 
 */
TreeLayerSwitcher.prototype.initCheckboxState = function () {

    // initialisation de toutes les checkbox du treelayerswitcher : décochées
    var allCheckboxes = $('#' + this.root.div.id + ' input:checkbox');
    for (var key in allCheckboxes) {
        allCheckboxes[key].checked = false;
    }

    var layer = null;
    // parcourir les layers et agregas contenues dans treelayerSwitcherItems
    for (var layerName in this.root.treelayerSwitcherItems) {

        // si le treeLayerSwitcherItem a bien une checkbox associé
        if (this.root.treelayerSwitcherItems[layerName].checkbox) {
            var checkboxId = this.root.treelayerSwitcherItems[layerName].checkbox.id;
            layer = this.root.treelayerSwitcherItems[layerName].layer;

            if (layer === null) {
                layer = this.root.treelayerSwitcherItems[layerName].parent;
            }


            // si le treeLayerSwitcherItem a bien un layer associé
            if (layer && typeof layer.U !== 'undefined') {

                // si la checkbox existe dans le DOM
                if ($('#' + checkboxId)[0]) {
                    var exist = false;
                    var coche = false;
                    // vérifier l'existance du layer dans la map
                    this.map.getLayers().forEach(function (layerInMap) {
                        if (layerInMap === layer) {
                            exist = true;
                        }
                    });
                    if (exist) {
                        // vérifier si la visibilité du layer est true or false
                        if (layer.getVisible()) {
                            coche = true;
                        }
                    }

                    //mise a jour des checkboxes et répercution de l'activation sur lescheckboxes enfants et parents
                    if (coche) {

                        if (this.root.treelayerSwitcherItems[layerName].children.length !== 0) {

                            for (var i in this.root.treelayerSwitcherItems[layerName].children) {
                                if (this.root.treelayerSwitcherItems[layerName].children[i].checkbox.checked !== true) {
                                    this.root.treelayerSwitcherItems[layerName].children[i].checkbox.checked = true;
                                    $(this.root.treelayerSwitcherItems[layerName].children[i].checkbox).trigger('change', [false]);
                                }
                            }
                        } else {
                            if (!$(this.root.treelayerSwitcherItems[layerName].checkbox)[0].checked) {
                                $(this.root.treelayerSwitcherItems[layerName].checkbox)[0].checked = true;
                                $(this.root.treelayerSwitcherItems[layerName].checkbox).trigger('change', [false]);
                            }
                        }

                    }


                }
            }

        }
    }
};

/**
 * @function getCheckboxIdByLayerName
 * @description get the id of the layer's checkbox
 * @param {String} layerName
 * @returns {String|null}
 */
TreeLayerSwitcher.prototype.getCheckboxIdByLayerName = function (layerName) {
    for (var name in this.root.treelayerSwitcherItems) {
        if (name === layerName) {
            return this.root.treelayerSwitcherItems[name].checkbox.id;
        }
    }

    return null;
};

/**
 * @function getLayerNameByCheckboxId
 * @description get the layerName of the checkbox 
 * @param {String} checkboxId
 * 
 * @returns {String|null}
 */
TreeLayerSwitcher.prototype.getLayerNameByCheckboxId = function (checkboxId) {
    for (var name in this.root.treelayerSwitcherItems) {
        if (this.root.treelayerSwitcherItems[name].checkbox && this.root.treelayerSwitcherItems[name].checkbox.id === checkboxId) {
            return name;
        }
    }
    return null;
};


TreeLayerSwitcher.prototype.layerIsInRange = function (layer) {

    return (layer.getMinResolution() <= this.map.getView().getResolution()
            && layer.getMaxResolution() >= this.map.getView().getResolution());
};

module.exports = TreeLayerSwitcher;
