
/**
 * @description "Create a TreeLayerSwitcherItem html element"
 * @constructor
 * @param {string} name "name of the TreeLayerSwitcherItem"
 * @param {TreeLayerSwitcherItem} parent "TreeLayerSwitcherItem parent"
 * @param {OpenLayersMap} map "Map OpenLayers"
 * @returns {undefined}
 */
var TreeLayerSwitcherItem = function (name, parent, map) {
    var self = this;
    this.parent = parent || null;
    this.name = name;
    //id de l'enfant = id du parent + nom de l'enfant
    if (this.parent) {
        if (this.parent.checkbox) {
            name = this.parent.checkbox.id.replace(/id_/g, "") + '-' + name;
        }
    }

    var id = "id_" + name.replace(/[.]/g, "\\.").replace(/[ ]/g, "_").toLowerCase();
    this.layer = null;
    this.children = [];
    // HTML DOM object
    if (!this.isRoot()) {
        this.deployAllChildren = document.createElement('a');
        this.deployAllChildren.className = "ign-tls-deployChildren";
        this.span = document.createElement('span');
        this.span.className = "glyphicon glyphicon-chevron-right";
        this.divChildren = document.createElement('div');
        this.divChildren.className = "ign-tls-children";
        //div de base
        this.div = document.createElement("div");
        this.div.className = "ign-tls-layer-menu";
        // paragraphe
        var domTitle = document.createElement("p");
        //div de rabattement (pour opacité, etc.)
        this.domFlapDiv = document.createElement("div");
        this.domFlapDiv.className = "ign-tls-flapDiv";
        //boutton de rabatement d'opacité
        this.domPlusButton = document.createElement("a");
        this.domPlusButton.className = "display-ign-tls-FlapDiv";
        this.domSpanPlusButton = document.createElement("span");
        this.domSpanPlusButton.className = "glyphicon glyphicon-cog";
        // checkbox
        this.checkbox = document.createElement('input');
        this.checkbox.type = 'checkbox';
        this.checkbox.id = id;
        // label
        this.domLabel = document.createElement('label');
        this.domLabel.htmlFor = id;
        //on rempli le texte du label plus tard, lors de l'ajout du layer,
        //pour recuperer la description du layer

        //slide opacity
        this.slideDiv = document.createElement('div');
        //evenements onchange des checkbox
        $(this.checkbox).on('change', function (event, triggerCustom) {
            console.log(event);
            if (triggerCustom === undefined) {
                var triggerCustom = true;
            }
            self.handleCheckboxChange(event, triggerCustom);
            self.setCheckboxParent(this.id);
        });
        // evenement custom 
        $(this).on('custom', function (event) {
            self.handleCheckboxCustom(event);
        });
        $(this.domPlusButton).on('click', function (event) {
            self.openFlapDiv(event);
        });
        //boutton deployant les layers fils
        $(this.deployAllChildren).on('click', function (event) {
            self.deployAllChildren.className = "ign-tls-unDeployChildren";
            self.divChildren.className += " deployed";
            self.span.className = self.span.className.replace("glyphicon glyphicon-chevron-right", "glyphicon glyphicon-chevron-down");
            self.deployChild(event);
        });
        //construction du menu

        //bouton deployant opacité
        this.domPlusButton.appendChild(this.domSpanPlusButton);
        domTitle.appendChild(this.checkbox);
        domTitle.appendChild(this.domLabel);
        domTitle.appendChild(this.deployAllChildren);
        domTitle.appendChild(this.domPlusButton);
        this.domFlapDiv.appendChild(this.slideDiv);
        $(this.slideDiv).width(100);
        this.div.appendChild(domTitle);
        this.div.appendChild(this.domFlapDiv);
    }

};

/**
 * @description Indique s'il sagit de la racine de l'arbre
 * @returns {Boolean}
 */
TreeLayerSwitcherItem.prototype.isRoot = function () {
    return this.parent === null;
};

/**
 * @description "Define the layer parent associate to the TreeLayerSwitcherItem"
 * 
 * @param {TreeLayerSwitcherItem} root "TreeLayerSwitcherItem which is the root element"
 * @param {OpenLayers.Layer.WMS} layerconfig "Configuration of layers"
 * @param {OpenLayers.Layer.WMS} layer "layer to put in the treeLayerSwitcher"
 * @param {number} opacity "Value between 0 and 100"
 * @param {boolean} isVisible "init visibility of the layer and its checkbox associate"
 * 
 * @returns {undefined}
 */
TreeLayerSwitcherItem.prototype.setParentLayer = function (root, layerconfig, layer, opacity, isVisible) {
    // reference a la racine
    this.root = root;
    // definition du parent courant
    if (layer !== null) {
        this.parent = layer;
        this.parent.setVisible(isVisible);
    } else {
        this.parent = layerconfig.name;
        this.parent.CLASS_NAME = null;
    }


    var labelContent = layerconfig.title;
    this.domLabel.textContent = labelContent;
    this.domLabel.innerText = labelContent; //ie 7 et 8
    this.domLabel.title = labelContent;
    this.checkbox.checked = true;
    var self = this;
    this.opacity = opacity * 100;
    $(this.slideDiv).slider({
        min: 0,
        max: 100,
        value: (opacity * 100)
    }).on('slideStop', function (ev) {
        self.handleSliderDivChange(ev.value);
    });

};

/**
 * @description "Define the layer associate to the TreeLayerSwitcherItem"
 * 
 * @param {TreeLayerSwitcherItem} root "TreeLayerSwitcherItem which is the root element"
 * @param {OpenLayers.Layer.WMS} layerconfig "Configuration of layers"
 * @param {OpenLayers.Layer.WMS} layer "layer to put in the treeLayerSwitcher"
 * @param {number} opacity "Value between 0 and 100"
 * @param {boolean} isVisible "init visibility of the layer and its checkbox associate"
 * @returns {undefined}
 */
TreeLayerSwitcherItem.prototype.setLayer = function (root, layerconfig, layer, opacity, isVisible) {
    // reference a la racine
    this.root = root;
    // definition de la couche
    if (layer !== null) {
        this.layer = layer;
        this.layer.setVisible(isVisible);
    } else {
        this.layer = layerconfig;
        this.layer.CLASS_NAME = null;
    }

    var labelContent = layerconfig.title;
    this.domLabel.textContent = labelContent;
    this.domLabel.innerText = labelContent; //ie 7 et 8
    this.domLabel.title = labelContent;
    this.checkbox.checked = true;
    var self = this;
    this.opacity = opacity * 100;
    $(this.slideDiv).slider({
        min: 0,
        max: 100,
        value: (opacity * 100)
    }).on('slideStop', function (ev) {
        self.handleSliderDivChange(ev.value);
    });

};

/**
 * @description "Set the visibility of the layer of the TreeLayerSwitcherItem"
 * @param {boolean} active "true : is active"
 * @param {boolean} triggerCustom "Sert au declenchement de la recherche d'un parent"
 * 
 * @returns {undefined}
 */
TreeLayerSwitcherItem.prototype.setActive = function (active, triggerCustom) {

    // propagation de l'état de la checkbox aux enfants
    for (var i in this.children) {
        if (this.children[i].checkbox.checked !== active) {
            this.children[i].checkbox.checked = active;
            var checkbox = this.children[i].checkbox;
            $(checkbox).trigger('change', [false]);
        }
    }

    // declenchement recherche parent
    if (triggerCustom) {
        $(this).trigger('custom');
    }
};

/**
 * @function updateVisibilities
 * 
 * @description "Update visibilities."
 */
TreeLayerSwitcherItem.prototype.updateVisibilities = function () {
    // parcours des enfants
    for (var i in this.root.children) {
        this.root.children[i].updateVisibility(false);
    }
};

/**
 * @function updateVisibility
 * 
 * @description "Update visibility."
 * 
 * @param {boolean} parentVisible "Visibility of the parent layer"
 */
TreeLayerSwitcherItem.prototype.updateVisibility = function (parentVisible) {

    /*
     * recherche si un des enfants a une opacité différente
     */
    var isOneChildWithDifferentOpacity = false;

    /*
     * Calcul si l'un des enfant est inactif
     */
    var isOneChildrenUnchecked = false;

    for (var i in this.children) {
        if (this.opacity !== this.children[i].opacity) {
            isOneChildWithDifferentOpacity = true;
        }
        if (!this.children[i].checkbox.checked) {
            isOneChildrenUnchecked = true;
        }
    }


    /*
     * On met a jour les enfant
     */
    for (var i in this.children) {
        /*
         * Calcul si l'element courant - ici un parent - est actif
         */
        var parentChecked = this.checkbox.checked;
        /*
         * Calcul si l'element courant est une couche
         */
        var isParentALayer = this.layer !== null && typeof this.layer.U !== "undefined"
                || this.parent !== null && typeof this.parent.U !== "undefined";
        /*
         * Calcul si l'element courant est visible
         */
        var isParentVisible = parentChecked && isParentALayer && !isOneChildrenUnchecked && !isOneChildWithDifferentOpacity;
        /*
         * Mis a jour de la visibilite de l'enfant
         */
        this.children[i].updateVisibility(isParentVisible);
    }

    /*
     * La couche est visible si 
     * - elle est active
     * - son parent n'est pas visible
     * 		- le parent est inactif
     * 		- l'un des enfant est inactif
     * - si aucun de ses enfant n'est inactif
     * - si aucun de ses enfant a une opacité différente
     */
    if (this.checkbox.checked && !parentVisible && !isOneChildrenUnchecked && !isOneChildWithDifferentOpacity) {
        console.log(1);
        this.setLayerVisibility(true);
    } else {
        console.log(2);
        this.setLayerVisibility(false);
    }
};

/**
 * @function setLayerVisibility
 *  
 * @description "Set layer visibility"
 * 
 * @param {boolean} visible "True to set the layer visible"
 */
TreeLayerSwitcherItem.prototype.setLayerVisibility = function (visible) {
    /*
     * la couche est porté par
     * - layer, agregat simple
     * - parent, agregat d'agregats
     */
    if (this.layer !== null && typeof this.layer.U !== "undefined") {
        this.layer.setVisible(visible);
    }
    if (this.parent !== null && typeof this.parent.U !== "undefined") {
        this.parent.setVisible(visible);
    }
};

/**
 * @description "Set the opacity of the layer of the TreeLayerSwitcherItem"
 * @param {int} opacity "number between 0 and 100 where  0 = 0% visible, 50 = 50% transparent, 100 = 100% visible"
 * @returns {undefined}
 */
TreeLayerSwitcherItem.prototype.setOpacity = function (opacity) {
    this.opacity = opacity;
    $(this.slideDiv).slider('setValue', opacity);
    // activation/desaction de l'état de la layer
    if (this.layer !== null && typeof this.layer.U !== "undefined") {
        this.layer.setOpacity(opacity / 100);
    }

    // slider 
    if (this.parent !== null && typeof this.parent.U !== "undefined") {
        this.parent.setOpacity(opacity / 100);
    }

    // propagation de l'opacité aux enfants
    for (var i in this.children) {
        this.children[i].setOpacity(opacity);
    }

};

/**
 * @description "Set Opacity of the layer when value of the slider from TreelayerSwitcherItem associate is changed"
 * @param {int} opacity "number between 0 and 100 where  0 = 0% visible, 50 = 50% transparent, 100 = 100% visible"
 * @returns {undefined}
 */
TreeLayerSwitcherItem.prototype.handleSliderDivChange = function (opacity) {
    this.setOpacity(opacity);
    this.updateVisibilities();
};

/**
 * @description "Set visibility of the layer when value of the checkbox from TreelayerSwitcherItem associate is changed"
 * 
 * @param {object} event "event which contains the checkbox checked or unChecked"
 * @param {boolean} triggerCustom "Sert au declenchement de la recherche d'un parent"
 * 
 */
TreeLayerSwitcherItem.prototype.handleCheckboxChange = function (event, triggerCustom) {
    var visibility = event.target.checked;
    this.setActive(visibility, triggerCustom);
};

/**
 * @description "handle checkbox custom"
 *  
 */
TreeLayerSwitcherItem.prototype.handleCheckboxCustom = function () {
    this.updateVisibilities();
};


/**
 * @description "Open the div of the opacity slider"
 * @returns {undefined}
 */
TreeLayerSwitcherItem.prototype.openFlapDiv = function () {
    var self = this;
    this.domFlapDiv.className = "displayed ign-tls-flapDiv";
    this.domSpanPlusButton.className = "glyphicon glyphicon-cog activate";
    $(this.domPlusButton).off('click');
    $(this.domPlusButton).on('click', function () {
        self.closeFlapDiv();
    });
};

/**
 * @description "Close the div of the opacity slider"
 * @returns {undefined}
 */
TreeLayerSwitcherItem.prototype.closeFlapDiv = function () {
    var self = this;
    this.domFlapDiv.className = "ign-tls-flapDiv";
    this.domSpanPlusButton.className = "glyphicon glyphicon-cog";
    $(this.domPlusButton).off('click');
    $(this.domPlusButton).on('click', function () {
        self.openFlapDiv();
    });
};


/**
 * @description "Indique si le noeud est un noeud terminal"
 * @return {boolean} true if the TreeLayerSwitcherItem is a leaf
 */
TreeLayerSwitcherItem.prototype.isLeaf = function () {
    return this.children.length === 0;
};

/**
 * @description "Return the TreeLayerSwitcherItem child by name"
 * @param {string} name "Name of the TreeLayerSwitcherItem child"
 * @return {TreeLayerSwitcherItem|null} "return null if no child found"
 */
TreeLayerSwitcherItem.prototype.getChildByName = function (name) {
    for (var i in this.children) {
        if (this.children[i].name === name) {
            return this.children[i];
        }
    }
    return null;
};

/**
 * @description "undeploy children of a TreeLayerSwitcherItem"
 * @return {undefined}
 */
TreeLayerSwitcherItem.prototype.unDeployChild = function () {
    //montrer child
    var self = this;
    $(this.deployAllChildren).off();
    $(this.deployAllChildren).on('click', function (event) {
        self.deployAllChildren.className = "ign-tls-unDeployChildren";
        self.divChildren.className += " deployed";
        self.span.className = self.span.className.replace("glyphicon glyphicon-chevron-right", "glyphicon glyphicon-chevron-down");
        self.deployChild(event);
    });
};

/**
 * @description "deploy children of a TreeLayerSwitcherItem"
 * @return {undefined}
 */
TreeLayerSwitcherItem.prototype.deployChild = function () {
    //cacher child
    var self = this;
    $(this.deployAllChildren).off();
    $(this.deployAllChildren).on('click', function (event) {
        self.deployAllChildren.className = "ign-tls-deployChildren";
        self.divChildren.className = self.divChildren.className.replace(/ deployed/g, "");
        self.span.className = self.span.className.replace("glyphicon glyphicon-chevron-down", "glyphicon glyphicon-chevron-right");
        self.unDeployChild(event);
    });
};

/**
 * @description "Create a TreeLayerSwitcherItem child"
 * @param {string} name "name of the TreeLayerSwitcherItem child"
 * @param {string} parent "name of the TreeLayerSwitcherItem parent"
 * @return {TreeLayerSwitcherItem} "The child crafted"
 */
TreeLayerSwitcherItem.prototype.createChild = function (name, parent) {
    var self;
    if (this.root) {
        self = this.root;
    } else {
        self = this;
    }


    var child = new TreeLayerSwitcherItem(name, parent, self.getTreeLayerSwitcher().map);
    // ajout à TreeLayerSwitcher 
    if (this.root !== undefined) {
        this.root.treelayerSwitcherItems[name] = child;
    } else {
        this.treelayerSwitcherItems[name] = child;
    }
    // ajout à l'arbre
    this.children.push(child);
    // ajout au DOM
    if (this.div.className.match(/parent/g)) {
        //this.deployAllChildren.title = name; //afficher le nom de la couche sur le +/-
        this.deployAllChildren.appendChild(this.span);
        //place les enfants dans un <div class="layer-menu parent"><div class="children">
        this.divChildren.appendChild(child.div);
        this.div.appendChild(this.divChildren);
    } else {
        this.div.appendChild(child.div);
    }
    return child;
};

/**
 * @description "Get or Create a TreeLayerSwitcherItem child"
 * @param {string} name "name of the TreeLayerSwitcherItem child"
 * @param {string} parent "name of the TreeLayerSwitcherItem parent"
 * @return {TreeLayerSwitcherItem} "The child recupered or crafted"
 */
TreeLayerSwitcherItem.prototype.getOrCreateChild = function (name, parent) {
    var child = this.getChildByName(name);
    if (child !== null) {
        if (!child.div.className.match(/parent/g)) {
            child.div.className += ' parent';
        }
        return child;
    } else {
        return this.createChild(name, parent);
    }
};

/**
 * @description "Get the ids of all checkox parent"
 * @param {string} checkboxId "id of checkbox"
 * @return {Array} "An array of string"
 */
TreeLayerSwitcherItem.prototype.getAllCheckboxParentId = function (checkboxId) {
    var chaineId = $('#' + checkboxId)[0].id;
    var splitId = chaineId.split('-');
    var arrayOfId = new Array();
    for (var i = 0; i < splitId.length; i++) {
        if (i === 0) {
            arrayOfId[i] = splitId[i];
        } else {
            arrayOfId[i] = arrayOfId[i - 1] + '-' + splitId[i];
        }
    }
    return arrayOfId;
};

/**
 * @description "Get the ids of all checkbox brother"
 * @param {string} checkboxId "id of checkbox"
 * @return {Array} "An array of string"
 */
TreeLayerSwitcherItem.prototype.getAllCheckboxBrotherAndNephewId = function (checkboxId) {
    var arrayOfCheckboxBrotherAndNephewId = [];
    var arrayOfId = this.getAllCheckboxParentId(checkboxId);
    var parentP = $('#' + arrayOfId[arrayOfId.length - 2]).parent('p');
    if (parentP.parents('div')[0] === undefined) {
        return;
    }
    var divOfBrothers = $(parentP.parents('div')[0]).children('.ign-tls-children')[0];

    var arrayOfAllInputs = $(divOfBrothers.getElementsByTagName('input'));
    var patchKey = 0;
    var occurence = arrayOfAllInputs.length.valueOf();
    for (var i = 0; i < occurence; i++) {

        var checkbox = arrayOfAllInputs[i - patchKey];
        if (typeof checkbox === "object") {

            if (checkbox.id.indexOf(checkboxId) !== 0) {
                arrayOfCheckboxBrotherAndNephewId.push(checkbox.id);
            }
        }
    }

    return arrayOfCheckboxBrotherAndNephewId;
};

/**
 * @description "set all the parents checkbox "
 * @param {string} checkboxId "id of checkbox"
 */
TreeLayerSwitcherItem.prototype.setCheckboxParent = function (checkboxId) {
    //on recupere les checkbox parents
    var checkboxParents = this.getAllCheckboxParentId(checkboxId);

    //la derniere valeur est l'id de la checkboxc courante,
    // l'avant derniere l'id de la checkbox parent
    var checkboxParent = checkboxParents[checkboxParents.length - 2];

    if (!checkboxParents[checkboxParents.length - 2]) {
        //pas de parents
        return;
    }

    //on recupere les checkbox soeurs et nieces
    var checkboxBrothers = this.getAllCheckboxBrotherAndNephewId(checkboxId);
    if ($('#' + checkboxId)[0].checked) {
        //si la checkbox est cochée 

        //on coche la checkbox "parent"

        if (!$('#' + checkboxParent)[0].checked) {
            $('#' + checkboxParent)[0].checked = true;
        }

        this.setCheckboxParent(checkboxParent);
        return checkboxParent;
    } else {
        //si la checkbox est décochée

        //si une seule checkbox soeur/niece est coché, on ne décoche pas le parent
        //sinon on le décoche
        var no_coche = true;
        for (var key in checkboxBrothers) {
            if ($('#' + checkboxBrothers[key])[0].checked) {
                no_coche = false;
            }
        }

        if (no_coche) {

            if ($('#' + checkboxParent)[0].checked) {
                $('#' + checkboxParent)[0].checked = false;
            }
            this.setCheckboxParent(checkboxParent);
            return checkboxParent;
        }
    }
};


module.exports = TreeLayerSwitcherItem;