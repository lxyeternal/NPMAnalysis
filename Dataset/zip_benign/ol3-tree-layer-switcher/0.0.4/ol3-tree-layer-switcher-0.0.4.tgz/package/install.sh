#uglifyjs node_modules/excanvas/excanvas.compiled.js -o js/excanvas.compiled.js 

browserify js/index.js | uglifyjs > js/rpg.min.js 
 