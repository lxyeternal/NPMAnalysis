var codeFromLine = `${process.argv[2]}`;

var Pitboss = require('./lib/pitboss-ng').Pitboss;

var sandbox = new Pitboss(codeFromLine);

setTimeout(() => {
  sandbox.run({}, function (err, result) {
    console.log('Result:', result);
    setTimeout(() => {
      sandbox.kill();
      process.exit(0);
    }, 10);
  });
}, 10);
