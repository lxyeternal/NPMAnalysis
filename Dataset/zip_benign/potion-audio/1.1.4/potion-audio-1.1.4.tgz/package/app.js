var AudioManager = require('./index');

var manager = new AudioManager();

manager.setVolume(0.1);
manager.load('/music/music.mp3', function(bg) {
  manager.load('/music/1.wav', {
    done: function(hit) {
      window.bg = bg;
      window.hit = hit;
      // bg.play();
      // window.omg = hit.loop();
    },

    error: function() {
    },

    progress: function() {
      console.log('progress');
    }
  });
});


window.manager = manager;
