import type { PropsWithChildren } from "react";
export declare const Button: ({ children }: PropsWithChildren) => import("react").JSX.Element;
