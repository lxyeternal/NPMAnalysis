import type { T_StyledGeneratorItem } from "./StyledGenerator.type";
export type T_StyledGeneratorStyled = {
    $onMobile?: T_StyledGeneratorItem;
    $onTabletOrMobile?: T_StyledGeneratorItem;
    $onTablet?: T_StyledGeneratorItem;
    $onDesktopOrTablet?: T_StyledGeneratorItem;
    $onDesktop?: T_StyledGeneratorItem;
    $onAll?: T_StyledGeneratorItem;
    $hasOnClick: boolean;
};
export declare const generatePropsStyled: (props: any) => {
    cursor?: string | undefined;
    display: string;
    transitionProperty: string;
};
