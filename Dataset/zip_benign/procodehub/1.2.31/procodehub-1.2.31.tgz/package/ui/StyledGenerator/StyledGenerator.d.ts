/// <reference types="react" />
import type { T_StyledGenerator } from "./StyledGenerator.type";
export declare const generateProps: (props: T_StyledGenerator) => {
    $onMobile: import("./StyledGenerator.type").T_StyledGeneratorItem | undefined;
    $onTabletOrMobile: import("./StyledGenerator.type").T_StyledGeneratorItem | undefined;
    $onTablet: import("./StyledGenerator.type").T_StyledGeneratorItem | undefined;
    $onDesktopOrTablet: import("./StyledGenerator.type").T_StyledGeneratorItem | undefined;
    $onDesktop: import("./StyledGenerator.type").T_StyledGeneratorItem | undefined;
    $onAll: import("./StyledGenerator.type").T_StyledGeneratorItem | undefined;
    $onClick: ((e: import("react").MouseEvent<HTMLDivElement, MouseEvent>) => void) | undefined;
    $hasOnClick: boolean;
    id: string | undefined;
    ref: import("react").RefObject<HTMLDivElement> | undefined;
    as: import("../theme").T_Tag | undefined;
};
