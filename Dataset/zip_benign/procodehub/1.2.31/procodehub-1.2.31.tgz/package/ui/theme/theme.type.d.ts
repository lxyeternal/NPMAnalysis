import config from "../../../../procode.config";
export type T_ProcodeConfigUser = typeof config;
export type T_ThemeColors = T_ProcodeConfigUser["colors"]["light"];
export type T_ThemeGradients = T_ProcodeConfigUser["gradients"]["light"];
export type T_ThemeShadows = T_ProcodeConfigUser["shadows"]["light"];
export type T_ThemeFontSizes = T_ProcodeConfigUser["fontSizes"];
export type T_ThemeFontWeights = T_ProcodeConfigUser["fontWeights"];
export type T_ThemeFontLineHeights = T_ProcodeConfigUser["fontLineHeights"];
export type T_ThemeFontLetterSpacings = T_ProcodeConfigUser["fontLetterSpacings"];
export type T_ThemeSpacings = T_ProcodeConfigUser["spacings"];
export type T_ThemeBorderRadius = T_ProcodeConfigUser["borderRadius"];
export type T_ThemeMedias = T_ProcodeConfigUser["media"];
export type T_ThemeMode = {
    isDarkMode: boolean;
    isLightMode: boolean;
};
export type T_Color = keyof T_ThemeColors;
export type T_Gradient = keyof T_ThemeGradients;
export type T_Shadow = keyof T_ThemeShadows;
export type T_FontSize = keyof T_ThemeFontSizes;
export type T_FontWeight = keyof T_ThemeFontWeights;
export type T_FontLineHeight = keyof T_ThemeFontLineHeights;
export type T_FontLetterSpacing = keyof T_ThemeFontLetterSpacings;
export type T_Spacing = keyof T_ThemeSpacings;
export type T_BorderRadius = keyof T_ThemeBorderRadius;
export type T_Media = keyof T_ThemeMedias;
export type T_FontDecoration = "initial" | "inherit" | "underline" | "overline" | "line-through" | "none";
export type T_ImageFormat = "svg" | "webp";
export type T_Tag = "div" | "section" | "footer" | "article" | "header" | "main" | "nav" | "search" | "span" | "a" | "ul" | "ol" | "li" | "p" | "h1" | "h2" | "h3" | "h4" | "h5" | "h6";
export type T_Cursor = "pointer" | "auto" | "grab" | "grabbing" | "no-drop" | "none" | "text" | "wait";
export type T_Display = "initial" | "inherit" | "inline" | "block" | "flex" | "inline-flex" | "none";
export type T_FlexItemJustifyContent = "flex-start" | "flex-end" | "center" | "space-between" | "space-around" | "space-evenly";
export type T_FlexItemAlignItems = "flex-start" | "flex-end" | "center" | "stretch" | "unset";
export type T_FlexItemFlexDirection = "row" | "row-reverse" | "column" | "column-reverse";
export type T_WhiteSpace = "normal" | "nowrap" | "pre" | "pre-line" | "pre-wrap" | "initial" | "inherit";
export type T_FlexItemFlexWrap = "wrap" | "nowrap" | "wrap-reverse";
export type T_FontAlign = "center" | "left" | "right";
export type T_Overflow = "visible" | "hidden" | "clip" | "scroll" | "auto";
export type T_BorderStyle = "none" | "dotted" | "inset" | "dashed" | "solid" | "double" | "groove" | "ridge" | "outset";
export type T_AnimationTransitionTimingFunction = "ease" | "linear" | "ease-in" | "ease-out" | "ease-in-out" | "step-start" | "step-end" | "inherit";
export type T_AnimationTransitionDuration = "0.25s" | "0.3s" | "0.5s" | "0.7s" | "1s" | "3s" | "5s" | "10s";
export type T_AnimationIterationCount = number | "infinite" | "initial" | "inherit";
export type T_AnimationDirection = "normal" | "reverse" | "alternate" | "alternate-reverse";
export type T_Position = "static" | "relative" | "absolute" | "sticky" | "fixed";
export type T_UserSelect = "auto" | "none";
export type T_Sign = "plus" | "minus";
export type T_Animation = {
    transitionTimingFunction: T_AnimationTransitionTimingFunction;
    transitionDuration: T_AnimationTransitionDuration;
    iterationCount: T_AnimationIterationCount;
    direction: T_AnimationDirection;
};
export interface ProcodeTheme {
    colors: T_ThemeColors;
    gradients: T_ThemeGradients;
    shadows: T_ThemeShadows;
    fontSize: T_ThemeFontSizes;
    fontWeight: T_ThemeFontWeights;
    fontLineHeight: T_ThemeFontLineHeights;
    fontLetterSpacing: T_ThemeFontLetterSpacings;
    borderRadius: T_ThemeBorderRadius;
    spacings: T_ThemeSpacings;
    media: T_ThemeMedias;
    mode: T_ThemeMode;
    animation: T_Animation;
    animationGradient: T_Animation;
}
export type T_ProcodeConfig = {
    colors: {
        light: T_ThemeColors;
        dark?: T_ThemeColors;
    };
    gradients: {
        light: T_ThemeGradients;
        dark?: T_ThemeGradients;
    };
    shadows: {
        light: T_ThemeShadows;
        dark?: T_ThemeShadows;
    };
    fontSizes: T_ThemeFontSizes;
    fontWeights: T_ThemeFontWeights;
    fontLineHeights: T_ThemeFontLineHeights;
    fontLetterSpacings: T_ThemeFontLetterSpacings;
    borderRadius: T_ThemeBorderRadius;
    spacings: T_ThemeSpacings;
    media: T_ThemeMedias;
    animation: T_Animation;
};
