type T_GenerateTheme = {
    isDarkMode: boolean;
};
export declare const generateTheme: ({ isDarkMode }: T_GenerateTheme) => {
    colors: any;
    gradients: any;
    shadows: any;
    animation: any;
    animationGradient: any;
    borderRadius: any;
    fontSize: any;
    fontWeight: any;
    fontLineHeight: any;
    fontLetterSpacing: any;
    media: any;
    spacings: any;
    mode: {
        isDarkMode: boolean;
        isLightMode: boolean;
    };
};
export {};
