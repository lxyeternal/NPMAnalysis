import type { T_Text } from "./Text.type";
export declare const generateProps: (props: T_Text) => {
    $onMobile: import("./Text.type").T_TextItem | undefined;
    $onTabletOrMobile: import("./Text.type").T_TextItem | undefined;
    $onTablet: import("./Text.type").T_TextItem | undefined;
    $onDesktopOrTablet: import("./Text.type").T_TextItem | undefined;
    $onDesktop: import("./Text.type").T_TextItem | undefined;
    $onAll: import("./Text.type").T_TextItem | undefined;
    id: string | undefined;
    as: import("../theme").T_Tag;
};
