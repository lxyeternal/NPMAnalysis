import type { T_TextItem } from "./Text.type";
export type T_TextStyled = {
    $onMobile?: T_TextItem;
    $onTabletOrMobile?: T_TextItem;
    $onTablet?: T_TextItem;
    $onDesktopOrTablet?: T_TextItem;
    $onDesktop?: T_TextItem;
    $onAll?: T_TextItem;
};
export declare const generatePropsStyled: (props: any) => {
    [x: number]: any;
    display: string;
    transitionProperty: string;
};
