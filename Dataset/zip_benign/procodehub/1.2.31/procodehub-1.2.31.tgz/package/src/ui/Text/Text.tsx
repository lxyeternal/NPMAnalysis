import type {T_Text} from "./Text.type";

export const generateProps = (props: T_Text) => {
  return {
    $onMobile: props.onMobile,
    $onTabletOrMobile: props.onTabletOrMobile,
    $onTablet: props.onTablet,
    $onDesktopOrTablet: props.onDesktopOrTablet,
    $onDesktop: props.onDesktop,
    $onAll: props.onAll,
    id: props.id,
    as: props.tag,
  };
};
