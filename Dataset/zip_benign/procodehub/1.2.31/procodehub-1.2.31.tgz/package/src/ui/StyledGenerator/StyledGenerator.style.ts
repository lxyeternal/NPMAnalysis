import type {T_StyledGeneratorItem} from "./StyledGenerator.type";
import type {ProcodeTheme} from "../theme/theme.type";

export type T_StyledGeneratorStyled = {
  $onMobile?: T_StyledGeneratorItem;
  $onTabletOrMobile?: T_StyledGeneratorItem;
  $onTablet?: T_StyledGeneratorItem;
  $onDesktopOrTablet?: T_StyledGeneratorItem;
  $onDesktop?: T_StyledGeneratorItem;
  $onAll?: T_StyledGeneratorItem;
  $hasOnClick: boolean;
};

const generateMediaPropsStyled = (
  theme: ProcodeTheme,
  mediaProps?: T_StyledGeneratorItem
) => {
  if (!mediaProps) {
    return {
      display: "none",
    };
  }

  //display
  let display = "block";
  if (mediaProps.flex) {
    display = "flex";
  } else if (mediaProps.display) {
    display = mediaProps.display;
  }

  //position object
  let positionObject = {};
  if (mediaProps?.position) {
    positionObject = {
      position: mediaProps.position.value,
      ...(typeof mediaProps.position?.zIndex === "number"
        ? {
            zIndex: mediaProps.position.zIndex,
          }
        : {}),
      ...(mediaProps.position?.top
        ? {
            top: mediaProps.position.top,
          }
        : {}),
      ...(mediaProps.position?.bottom
        ? {
            bottom: mediaProps.position.bottom,
          }
        : {}),
      ...(mediaProps.position?.left
        ? {
            left: mediaProps.position.left,
          }
        : {}),
      ...(mediaProps.position?.right
        ? {
            right: mediaProps.position.right,
          }
        : {}),
    };
  }

  //flex object
  let flexObject = {};
  if (mediaProps?.flex) {
    flexObject = {
      ...(mediaProps.flex?.justifyContent
        ? {
            justifyContent: mediaProps.flex.justifyContent,
          }
        : {}),
      ...(mediaProps.flex?.flexGrow
        ? {
            flexGrow: mediaProps.flex.flexGrow,
          }
        : {}),
      ...(mediaProps.flex?.flexWrap
        ? {
            flexWrap: mediaProps.flex.flexWrap,
          }
        : {}),
      ...(mediaProps.flex?.alignItems
        ? {
            alignItems: mediaProps.flex.alignItems,
          }
        : {}),
      ...(mediaProps.flex?.flexDirection
        ? {
            flexDirection: mediaProps.flex.flexDirection,
          }
        : {}),
      ...(mediaProps.flex?.gap
        ? {
            gap:
              typeof mediaProps.flex.gap === "number"
                ? theme.spacings[mediaProps.flex.gap]
                : `${
                    //@ts-ignore
                    mediaProps.flex.gap.y
                      ? //@ts-ignore
                        theme.spacings[mediaProps.flex.gap.y]
                      : theme.spacings[0]
                  } ${
                    //@ts-ignore
                    mediaProps.flex.gap.x
                      ? //@ts-ignore
                        theme.spacings[mediaProps.flex.gap.x]
                      : theme.spacings[0]
                  }`,
          }
        : {}),
    };
  }

  //size object
  let sizeObject = {};
  if (mediaProps?.size) {
    sizeObject = {
      ...(mediaProps.size?.width
        ? {
            width: mediaProps.size.width,
          }
        : {}),
      ...(mediaProps.size?.maxWidth
        ? {
            maxWidth: mediaProps.size.maxWidth,
          }
        : {}),
      ...(mediaProps.size?.minWidth
        ? {
            minWidth: mediaProps.size.minWidth,
          }
        : {}),
      ...(mediaProps.size?.height
        ? {
            height: mediaProps.size.height,
          }
        : {}),
      ...(mediaProps.size?.minHeight
        ? {
            minHeight: mediaProps.size.minHeight,
          }
        : {}),
      ...(mediaProps.size?.maxHeight
        ? {
            maxHeight: mediaProps.size.maxHeight,
          }
        : {}),
    };
  }

  //border object
  let borderObject = {};
  if (mediaProps?.border) {
    borderObject = {
      ...(mediaProps.border
        ? {
            //@ts-ignore
            border: `${mediaProps.border.size}px ${mediaProps.border.style} ${
              theme.colors[mediaProps.border.color]
            }`,
          }
        : {}),
    };
  }

  //border radius object
  let borderRadiusObject = {};
  if (mediaProps?.borderRadius) {
    borderRadiusObject = {
      ...(mediaProps.borderRadius?.all
        ? {
            borderRadius: theme.borderRadius[mediaProps.borderRadius.all],
          }
        : {}),
      ...(typeof mediaProps.borderRadius?.topLeft === "number"
        ? {
            borderTopLeftRadius:
              theme.borderRadius[mediaProps.borderRadius.topLeft],
          }
        : {}),
      ...(typeof mediaProps.borderRadius?.topRight === "number"
        ? {
            borderTopRightRadius:
              theme.borderRadius[mediaProps.borderRadius.topRight],
          }
        : {}),
      ...(typeof mediaProps.borderRadius?.bottomLeft === "number"
        ? {
            borderBottomLeftRadius:
              theme.borderRadius[mediaProps.borderRadius.bottomLeft],
          }
        : {}),
      ...(typeof mediaProps.borderRadius?.bottomRight === "number"
        ? {
            borderBottomRightRadius:
              theme.borderRadius[mediaProps.borderRadius.bottomRight],
          }
        : {}),
    };
  }

  //spacings object
  let spacingsObject = {};
  if (mediaProps?.spacing) {
    spacingsObject = {
      ...(mediaProps.spacing.margin
        ? {
            margin: `${mediaProps.spacing.sign === "minus" ? "-" : ""}${
              theme.spacings[mediaProps.spacing.margin]
            }`,
          }
        : {}),
      ...(mediaProps.spacing.marginTop
        ? {
            marginTop: `${mediaProps.spacing.sign === "minus" ? "-" : ""}${
              theme.spacings[mediaProps.spacing.marginTop]
            }`,
          }
        : {}),
      ...(mediaProps.spacing.marginBottom
        ? {
            marginBottom: `${mediaProps.spacing.sign === "minus" ? "-" : ""}${
              theme.spacings[mediaProps.spacing.marginBottom]
            }`,
          }
        : {}),
      ...(mediaProps.spacing.marginLeft
        ? {
            marginLeft: `${mediaProps.spacing.sign === "minus" ? "-" : ""}${
              theme.spacings[mediaProps.spacing.marginLeft]
            }`,
          }
        : {}),
      ...(mediaProps.spacing.marginRight
        ? {
            marginRight: `${mediaProps.spacing.sign === "minus" ? "-" : ""}${
              theme.spacings[mediaProps.spacing.marginRight]
            }`,
          }
        : {}),
      ...(mediaProps.spacing.padding
        ? {
            padding: `${mediaProps.spacing.sign === "minus" ? "-" : ""}${
              theme.spacings[mediaProps.spacing.padding]
            }`,
          }
        : {}),
      ...(mediaProps.spacing.paddingTop
        ? {
            paddingTop: `${mediaProps.spacing.sign === "minus" ? "-" : ""}${
              theme.spacings[mediaProps.spacing.paddingTop]
            }`,
          }
        : {}),
      ...(mediaProps.spacing.paddingBottom
        ? {
            paddingBottom: `${mediaProps.spacing.sign === "minus" ? "-" : ""}${
              theme.spacings[mediaProps.spacing.paddingBottom]
            }`,
          }
        : {}),
      ...(mediaProps.spacing.paddingLeft
        ? {
            paddingLeft: `${mediaProps.spacing.sign === "minus" ? "-" : ""}${
              theme.spacings[mediaProps.spacing.paddingLeft]
            }`,
          }
        : {}),
      ...(mediaProps.spacing.paddingRight
        ? {
            paddingRight: `${mediaProps.spacing.sign === "minus" ? "-" : ""}${
              theme.spacings[mediaProps.spacing.paddingRight]
            }`,
          }
        : {}),
    };
  }

  //overflow object
  let overflowObject = {};
  if (mediaProps.overflow) {
    overflowObject = {
      ...(typeof mediaProps.overflow === "string"
        ? {
            overflow: mediaProps.overflow,
          }
        : {
            ...(mediaProps.overflow?.x
              ? {
                  overflowX: mediaProps.overflow.x,
                }
              : {}),
            ...(mediaProps.overflow?.y
              ? {
                  overflowY: mediaProps.overflow.y,
                }
              : {}),
          }),
    };
  }

  //extra object
  const extraObject = {
    ...(mediaProps.userSelect
      ? {
          userSelect: mediaProps.userSelect,
        }
      : {}),
    ...(mediaProps.align
      ? {
          textAlign: mediaProps.align,
        }
      : {}),
    ...(mediaProps.backgroundColor
      ? {
          backgroundColor: theme.colors[mediaProps.backgroundColor],
        }
      : {}),
    ...(mediaProps.backgroundGradient && !mediaProps.backgroundColor
      ? {
          backgroundImage: theme.gradients[mediaProps.backgroundGradient],
        }
      : {}),
  };

  return {
    display,
    ...positionObject,
    ...flexObject,
    ...sizeObject,
    ...borderObject,
    ...borderRadiusObject,
    ...spacingsObject,
    ...overflowObject,
    ...extraObject,
  };
};

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const generatePropsStyled = (props: any) => {
  return {
    display: "none",
    transitionProperty:
      "padding, background-color, opacity, color, width, border-radius",
    ...(props.$hasOnClick
      ? {
          cursor: "pointer",
        }
      : {}),
    [props.theme.media.isMobile]:
      props.$onMobile && generateMediaPropsStyled(props.theme, props.$onMobile),
    [props.theme.media.isTabletOrMobile]:
      props.$onTabletOrMobile &&
      generateMediaPropsStyled(props.theme, props.$onTabletOrMobile),
    [props.theme.media.isTablet]:
      props.$onTablet && generateMediaPropsStyled(props.theme, props.$onTablet),
    [props.theme.media.isDesktopOrTablet]:
      props.$onDesktopOrTablet &&
      generateMediaPropsStyled(props.theme, props.$onDesktopOrTablet),
    [props.theme.media.isDesktop]:
      props.$onDesktop &&
      generateMediaPropsStyled(props.theme, props.$onDesktop),
    [props.theme.media.isAll]:
      props.$onAll && generateMediaPropsStyled(props.theme, props.$onAll),
  };
};
