import type {T_TextItem} from "./Text.type";
import type {ProcodeTheme} from "../theme/theme.type";

export type T_TextStyled = {
  $onMobile?: T_TextItem;
  $onTabletOrMobile?: T_TextItem;
  $onTablet?: T_TextItem;
  $onDesktopOrTablet?: T_TextItem;
  $onDesktop?: T_TextItem;
  $onAll?: T_TextItem;
};

const generateMediaPropsText = (
  theme: ProcodeTheme,
  mediaProps?: T_TextItem
) => {
  if (!mediaProps) {
    return {
      display: "none",
    };
  }

  //color object
  let colorObject = {};
  if (mediaProps.color) {
    colorObject = {
      color: theme.colors[mediaProps.color],
    };
  }

  //size object
  let sizeObject = {};
  if (mediaProps.font) {
    sizeObject = {
      fontSize: theme.fontSize[mediaProps.font.size],
      lineHeight: theme.fontLineHeight[mediaProps.font.lineHeight],
      letterSpacing: `${
        mediaProps.font.letterSpacingSign === "plus" ? "" : "-"
      }${theme.fontLetterSpacing[mediaProps.font.letterSpacing]}`,
    };
  }

  //gradient object
  let gradientObject = {};
  if (mediaProps.gradient && !mediaProps.color) {
    gradientObject = {
      backgroundImage: theme.gradients[mediaProps.gradient],
      backgroundClip: "text",
      "-webkit-background-clip": "text",
      color: "transparent",
      "-webkit-text-fill-color": "transparent",
      //@ts-ignore
      ...(mediaProps.gradient?.includes("Animation") && theme.animationGradient
        ? {
            backgroundSize: "500% auto",
            animation: `textGradientAnimation ${theme.animationGradient?.transitionDuration} ${theme.animationGradient?.transitionTimingFunction} ${theme.animationGradient?.iterationCount} ${theme.animationGradient?.direction}`,
            "@keyframes textGradientAnimation": {
              "0%": {
                backgroundPosition: "0% 50%",
              },
              "100%": {
                backgroundPosition: "100% 50%",
              },
            },
          }
        : {}),
    };
  }

  //extra object
  const extraObject = {
    fontWeight: mediaProps.weight
      ? theme.fontWeight[mediaProps.weight]
      : theme.fontWeight["regular"],
    textAlign: mediaProps.align ? mediaProps.align : "left",
    ...(mediaProps.decoration
      ? {
          fontDecoration: mediaProps.decoration,
        }
      : {}),
    ...(mediaProps.whiteSpace
      ? {
          whiteSpace: mediaProps.whiteSpace,
        }
      : {}),
  };

  ////////////span

  //color object span
  let colorObjectSpan = {};
  let extraObjectSpan = {};
  let gradientObjectSpan = {};
  if (mediaProps?.span) {
    colorObjectSpan = {
      ...(mediaProps.span.color
        ? {
            color: theme.colors[mediaProps.span.color],
          }
        : {}),
    };

    //extra object
    extraObjectSpan = {
      fontWeight: mediaProps.span.weight
        ? theme.fontWeight[mediaProps.span.weight]
        : theme.fontWeight["bold"],
      textAlign: mediaProps.align ? mediaProps.align : "left",
      ...(mediaProps.span.decoration
        ? {
            fontDecoration: mediaProps.span.decoration,
          }
        : {}),
    };

    //gradient object
    if (mediaProps.span.gradient && !mediaProps.span.color) {
      gradientObjectSpan = {
        backgroundImage: theme.gradients[mediaProps.span.gradient],
        backgroundClip: "text",
        "-webkit-background-clip": "text",
        color: "transparent",
        "-webkit-text-fill-color": "transparent",
        //@ts-ignore
        ...(mediaProps.span.gradient?.includes("Animation") &&
        theme.animationGradient
          ? {
              backgroundSize: "500% auto",
              animation: `textSpanGradientAnimation ${theme.animationGradient?.transitionDuration} ${theme.animationGradient?.transitionTimingFunction} ${theme.animationGradient?.iterationCount} ${theme.animationGradient?.direction}`,
              "@keyframes textSpanGradientAnimation": {
                "0%": {
                  backgroundPosition: "0% 50%",
                },
                "100%": {
                  backgroundPosition: "100% 50%",
                },
              },
            }
          : {}),
      };
    }
  }

  return {
    display: "block",
    ...sizeObject,
    ...colorObject,
    ...gradientObject,
    ...extraObject,
    span: {
      transitionProperty: "color, background-image",
      ...colorObjectSpan,
      ...gradientObjectSpan,
      ...extraObjectSpan,
    },
  };
};

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const generatePropsStyled = (props: any) => {
  return {
    display: "none",
    transitionProperty: "padding, background-color, opacity, color, width",
    [props.theme.media.isMobile]:
      props.$onMobile && generateMediaPropsText(props.theme, props.$onMobile),
    [props.theme.media.isTabletOrMobile]:
      props.$onTabletOrMobile &&
      generateMediaPropsText(props.theme, props.$onTabletOrMobile),
    [props.theme.media.isTablet]:
      props.$onTablet && generateMediaPropsText(props.theme, props.$onTablet),
    [props.theme.media.isDesktopOrTablet]:
      props.$onDesktopOrTablet &&
      generateMediaPropsText(props.theme, props.$onDesktopOrTablet),
    [props.theme.media.isDesktop]:
      props.$onDesktop && generateMediaPropsText(props.theme, props.$onDesktop),
    [props.theme.media.isAll]:
      props.$onAll && generateMediaPropsText(props.theme, props.$onAll),
  };
};
