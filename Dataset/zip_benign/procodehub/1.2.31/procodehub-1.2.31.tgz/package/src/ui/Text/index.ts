export * from "./Text.type";
export * from "./Text";
export * from "./Text.style";
