import type {PropsWithChildren} from "react";

export const Button = ({children}: PropsWithChildren) => {
  return <div>{children}</div>;
};
