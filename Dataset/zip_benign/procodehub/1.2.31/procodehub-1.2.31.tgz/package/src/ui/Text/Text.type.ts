import type {
  T_FontAlign,
  T_Sign,
  T_Color,
  T_Gradient,
  T_FontWeight,
  T_FontDecoration,
  T_WhiteSpace,
  T_FontLetterSpacing,
  T_FontSize,
  T_FontLineHeight,
  T_Tag,
} from "../theme/theme.type";

type T_TextItemFont = {
  size: T_FontSize;
  lineHeight: T_FontLineHeight;
  letterSpacing: T_FontLetterSpacing;
  letterSpacingSign: T_Sign;
};

export type T_TextItem = {
  font: T_TextItemFont;
  weight?: T_FontWeight;
  align?: T_FontAlign;
  decoration?: T_FontDecoration;
  color?: T_Color;
  gradient?: T_Gradient;
  whiteSpace?: T_WhiteSpace;
  span?: {
    weight?: T_FontWeight;
    decoration?: T_FontDecoration;
    color?: T_Color;
    gradient?: T_Gradient;
  };
};

export type T_Text = {
  onMobile?: T_TextItem;
  onTabletOrMobile?: T_TextItem;
  onTablet?: T_TextItem;
  onDesktopOrTablet?: T_TextItem;
  onDesktop?: T_TextItem;
  onAll?: T_TextItem;
  id?: string;
  tag: T_Tag;
};
