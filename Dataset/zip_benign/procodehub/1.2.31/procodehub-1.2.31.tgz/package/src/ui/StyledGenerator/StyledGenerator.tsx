import type {T_StyledGenerator} from "./StyledGenerator.type";

export const generateProps = (props: T_StyledGenerator) => {
  return {
    $onMobile: props.onMobile,
    $onTabletOrMobile: props.onTabletOrMobile,
    $onTablet: props.onTablet,
    $onDesktopOrTablet: props.onDesktopOrTablet,
    $onDesktop: props.onDesktop,
    $onAll: props.onAll,
    $onClick: props.onClick,
    $hasOnClick: !!props.onClick,
    id: props.id,
    ref: props.refStyledGenerator,
    as: props.tag,
  };
};
