import type {
  T_ThemeColors,
  T_ThemeFontSizes,
  T_ThemeFontWeights,
  T_ThemeFontLineHeights,
  T_ThemeFontLetterSpacings,
  T_ThemeBorderRadius,
  T_ThemeSpacings,
  T_ThemeMedias,
  T_ThemeMode,
  T_Animation,
  T_ThemeGradients,
  T_ThemeShadows,
} from "./theme.type";
// import type {} from "styled-components";
//@ts-ignore
import config from "../../../../procode.config";

type T_GenerateTheme = {
  isDarkMode: boolean;
};

export const generateTheme = ({isDarkMode}: T_GenerateTheme) => {
  return {
    colors: config.colors
      ? isDarkMode
        ? config.colors.dark
        : config.colors.light
      : {},
    gradients: config.gradients
      ? isDarkMode
        ? config.gradients.dark
        : config.gradients.light
      : {},
    shadows: config.shadows
      ? isDarkMode
        ? config.shadows.dark
        : config.shadows.light
      : {},
    animation: config.animation ?? {},
    animationGradient: config.animationGradient ?? {},
    borderRadius: config.borderRadius ?? {},
    fontSize: config.fontSizes ?? {},
    fontWeight: config.fontWeights ?? {},
    fontLineHeight: config.fontLineHeights ?? {},
    fontLetterSpacing: config.fontLetterSpacings ?? {},
    media: config.media ?? {},
    spacings: config.spacings ?? {},
    mode: {
      isDarkMode: !!isDarkMode,
      isLightMode: !!!isDarkMode,
    },
  };
};

// declare module "styled-components" {
//   export interface DefaultTheme {
//     colors: T_ThemeColors;
//     gradients: T_ThemeGradients;
//     shadows: T_ThemeShadows;
//     fontSize: T_ThemeFontSizes;
//     fontWeight: T_ThemeFontWeights;
//     fontLineHeight: T_ThemeFontLineHeights;
//     fontLetterSpacing: T_ThemeFontLetterSpacings;
//     borderRadius: T_ThemeBorderRadius;
//     spacings: T_ThemeSpacings;
//     media: T_ThemeMedias;
//     mode: T_ThemeMode;
//     animation: T_Animation;
//     animationGradient: T_Animation;
//   }
// }
