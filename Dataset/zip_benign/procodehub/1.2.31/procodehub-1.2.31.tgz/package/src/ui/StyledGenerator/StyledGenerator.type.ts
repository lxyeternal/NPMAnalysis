import type {RefObject} from "react";
import type {
  T_BorderRadius,
  T_BorderStyle,
  T_Display,
  T_FlexItemAlignItems,
  T_FlexItemFlexDirection,
  T_FlexItemFlexWrap,
  T_FlexItemJustifyContent,
  T_FontAlign,
  T_Overflow,
  T_Position,
  T_Sign,
  T_Spacing,
  T_Tag,
  T_UserSelect,
  T_Color,
  T_Gradient,
} from "../theme/theme.type";

type T_StyledGeneratorItemSpacing = {
  margin?: T_Spacing;
  marginTop?: T_Spacing;
  marginBottom?: T_Spacing;
  marginLeft?: T_Spacing;
  marginRight?: T_Spacing;
  padding?: T_Spacing;
  paddingTop?: T_Spacing;
  paddingBottom?: T_Spacing;
  paddingLeft?: T_Spacing;
  paddingRight?: T_Spacing;
  sign?: T_Sign;
};

type T_StyledGeneratorItemSize = {
  width?: string;
  maxWidth?: string;
  minWidth?: string;
  height?: string;
  minHeight?: string;
  maxHeight?: string;
};

type T_StyledGeneratorItemOverflow =
  | {
      x?: T_Overflow;
      y?: T_Overflow;
    }
  | T_Overflow;

export type T_StyledGeneratorItemFlexGap = {
  x?: T_Spacing;
  y?: T_Spacing;
};

type T_StyledGeneratorItemFlex = {
  justifyContent?: T_FlexItemJustifyContent;
  flexGrow?: number;
  gap?: T_StyledGeneratorItemFlexGap | T_Spacing;
  alignItems?: T_FlexItemAlignItems;
  flexDirection?: T_FlexItemFlexDirection;
  flexWrap?: T_FlexItemFlexWrap;
  withoutAlignItems?: boolean;
};

export type T_StyledGeneratorBorderRadius = {
  all?: T_BorderRadius;
  topLeft?: T_BorderRadius;
  topRight?: T_BorderRadius;
  bottomLeft?: T_BorderRadius;
  bottomRight?: T_BorderRadius;
};

type T_StyledGeneratorBorder = {
  size: T_Spacing;
  style: T_BorderStyle;
  color: T_Color;
};

export type T_StyledGeneratorPosition = {
  value: T_Position;
  zIndex?: number;
  top?: string;
  bottom?: string;
  left?: string;
  right?: string;
};

export type T_StyledGeneratorItem = {
  spacing?: T_StyledGeneratorItemSpacing;
  size?: T_StyledGeneratorItemSize;
  flex?: T_StyledGeneratorItemFlex;
  align?: T_FontAlign;
  border?: T_StyledGeneratorBorder;
  borderRadius?: T_StyledGeneratorBorderRadius;
  overflow?: T_StyledGeneratorItemOverflow;
  position?: T_StyledGeneratorPosition;
  display?: T_Display;
  userSelect?: T_UserSelect;
  backgroundColor?: T_Color;
  backgroundGradient?: T_Gradient;
};

export type T_StyledGenerator = {
  onMobile?: T_StyledGeneratorItem;
  onTabletOrMobile?: T_StyledGeneratorItem;
  onTablet?: T_StyledGeneratorItem;
  onDesktopOrTablet?: T_StyledGeneratorItem;
  onDesktop?: T_StyledGeneratorItem;
  onAll?: T_StyledGeneratorItem;
  id?: string;
  onClick?: (e: React.MouseEvent<HTMLDivElement>) => void;
  refStyledGenerator?: RefObject<HTMLDivElement>;
  tag?: T_Tag;
};
