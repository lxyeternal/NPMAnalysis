export async function waitForAction(time = 1000) {
  await new Promise(resolve => setTimeout(resolve, time));
}
