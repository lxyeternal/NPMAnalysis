type T_SortArray<T> = {
  array: T[];
  path?: keyof T;
  sort?: "ASC" | "DESC";
};

export const sortArray = <T>({
  array = [],
  path,
  sort = "DESC",
}: T_SortArray<T>) => {
  const newArray = [...array];
  newArray?.sort((a, b) => {
    const firstItemToSort = path ? a?.[path] : a;
    const secondItemToSort = path ? b?.[path] : b;
    if (firstItemToSort && secondItemToSort) {
      if (firstItemToSort < secondItemToSort) {
        if (sort === "ASC") {
          return -1;
        } else {
          return 1;
        }
      } else if (firstItemToSort > secondItemToSort) {
        if (sort === "ASC") {
          return 1;
        } else {
          return -1;
        }
      } else {
        return 0;
      }
    } else {
      return 0;
    }
  });

  return newArray;
};

export const sortArrayFromDate = <T>({
  array = [],
  path,
  sort = "DESC",
}: T_SortArray<T>) => {
  const newArray = [...array];
  newArray?.sort((a, b) => {
    const firstItemToSort = path ? new Date(`${a?.[path]}`) : new Date(`${a}`);
    const secondItemToSort = path ? new Date(`${b?.[path]}`) : new Date(`${b}`);
    if (firstItemToSort && secondItemToSort) {
      if (firstItemToSort < secondItemToSort) {
        if (sort === "ASC") {
          return -1;
        } else {
          return 1;
        }
      } else if (firstItemToSort > secondItemToSort) {
        if (sort === "ASC") {
          return 1;
        } else {
          return -1;
        }
      } else {
        return 0;
      }
    } else {
      return 0;
    }
  });

  return newArray;
};
