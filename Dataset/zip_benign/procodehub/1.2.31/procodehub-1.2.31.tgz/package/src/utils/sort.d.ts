type T_SortArray<T> = {
    array: T[];
    path?: keyof T;
    sort?: "ASC" | "DESC";
};
export declare const sortArray: <T>({ array, path, sort, }: T_SortArray<T>) => T[];
export declare const sortArrayFromDate: <T>({ array, path, sort, }: T_SortArray<T>) => T[];
export {};
