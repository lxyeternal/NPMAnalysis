import type { MouseEvent } from "react";
type T_GenerateButtonsEffectClick = {
    element: HTMLButtonElement | HTMLDivElement | null | undefined;
    event: MouseEvent<HTMLButtonElement | HTMLDivElement | HTMLAnchorElement, globalThis.MouseEvent>;
    rippleClassName: string;
};
export declare const generateButtonsEffectClick: ({ element, event, rippleClassName, }: T_GenerateButtonsEffectClick) => void;
export {};
