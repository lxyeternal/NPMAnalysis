import type { MouseEvent } from "react";

type T_GenerateButtonsEffectClick = {
  element: HTMLButtonElement | HTMLDivElement | null | undefined;
  event: MouseEvent<
    HTMLButtonElement | HTMLDivElement | HTMLAnchorElement,
    globalThis.MouseEvent
  >;
  rippleClassName: string;
};

export const generateButtonsEffectClick = ({
  element,
  event,
  rippleClassName,
}: T_GenerateButtonsEffectClick) => {
  if (!element) {
    return;
  }

  const rect = element.getBoundingClientRect();
  const x = event.clientX - rect.left;
  const y = event.clientY - rect.top;
  const diameter = Math.max(element.clientWidth, element.clientHeight);

  const circle = document.createElement("span");

  circle.style.height = `${diameter}px`;
  circle.style.width = `${diameter}px`;
  circle.style.left = `${x - diameter / 2}px`;
  circle.style.top = `${y - diameter / 2}px`;
  circle.classList.add(rippleClassName);

  element.appendChild(circle);

  setTimeout(() => {
    const firstRipple = element.querySelector(`.${rippleClassName}`);
    if (firstRipple) {
      element.removeChild(firstRipple);
    }
  }, 600);
};
