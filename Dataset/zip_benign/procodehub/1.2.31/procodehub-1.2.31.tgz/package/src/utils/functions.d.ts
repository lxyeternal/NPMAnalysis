export declare function waitForAction(time?: number): Promise<void>;
