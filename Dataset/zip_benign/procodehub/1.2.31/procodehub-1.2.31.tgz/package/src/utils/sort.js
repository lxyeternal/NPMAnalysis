export const sortArray = ({ array = [], path, sort = "DESC", }) => {
    const newArray = [...array];
    newArray === null || newArray === void 0 ? void 0 : newArray.sort((a, b) => {
        const firstItemToSort = path ? a === null || a === void 0 ? void 0 : a[path] : a;
        const secondItemToSort = path ? b === null || b === void 0 ? void 0 : b[path] : b;
        if (firstItemToSort && secondItemToSort) {
            if (firstItemToSort < secondItemToSort) {
                if (sort === "ASC") {
                    return -1;
                }
                else {
                    return 1;
                }
            }
            else if (firstItemToSort > secondItemToSort) {
                if (sort === "ASC") {
                    return 1;
                }
                else {
                    return -1;
                }
            }
            else {
                return 0;
            }
        }
        else {
            return 0;
        }
    });
    return newArray;
};
export const sortArrayFromDate = ({ array = [], path, sort = "DESC", }) => {
    const newArray = [...array];
    newArray === null || newArray === void 0 ? void 0 : newArray.sort((a, b) => {
        const firstItemToSort = path ? new Date(`${a === null || a === void 0 ? void 0 : a[path]}`) : new Date(`${a}`);
        const secondItemToSort = path ? new Date(`${b === null || b === void 0 ? void 0 : b[path]}`) : new Date(`${b}`);
        if (firstItemToSort && secondItemToSort) {
            if (firstItemToSort < secondItemToSort) {
                if (sort === "ASC") {
                    return -1;
                }
                else {
                    return 1;
                }
            }
            else if (firstItemToSort > secondItemToSort) {
                if (sort === "ASC") {
                    return 1;
                }
                else {
                    return -1;
                }
            }
            else {
                return 0;
            }
        }
        else {
            return 0;
        }
    });
    return newArray;
};
