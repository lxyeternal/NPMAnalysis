import resolve from "@rollup/plugin-node-resolve";
import commonjs from "@rollup/plugin-commonjs";
import {terser} from "rollup-plugin-terser";
import typescript from "@rollup/plugin-typescript";
import babel from "@rollup/plugin-babel";

export default {
  input: "src/index.tsx",
  output: {
    file: "index.js", // Plik wyjściowy paczki (w katalogu głównym)
    format: "esm", // Format wyjściowy, np. UMD, CommonJS, ES Module
    sourcemap: true, // Opcjonalnie: generowanie sourcemaps
    interop: "compat",
  },
  plugins: [
    resolve({extensions: [".js", ".jsx", ".ts", ".tsx"]}), // Rozwiązywanie zależności z node_modules
    commonjs(), // Konwersja CommonJS do ES6, jeśli jest potrzebna
    typescript(), // Obsługa TypeScript
    babel({
      babelHelpers: "bundled",
      extensions: [".ts", ".tsx"],
      presets: [
        "@babel/preset-env",
        ["@babel/preset-react", {runtime: "automatic"}],
      ],
      plugins: ["@emotion/babel-plugin"],
    }), // Obsługa JSX
    terser(), // Minifikacja kodu, opcjonalnie
  ],
};
