import * as React from "react";
declare const TreeModalPortal: React.FC<{
    children: React.ReactChild;
}>;
export default TreeModalPortal;
