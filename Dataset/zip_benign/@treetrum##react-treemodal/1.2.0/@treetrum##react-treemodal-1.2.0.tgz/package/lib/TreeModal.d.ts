import * as React from "react";
interface PropsType {
    isOpen: boolean;
    children: React.ReactChild;
    onClose: () => void;
    overlayColor?: string;
}
declare const TreeModal: React.FC<PropsType>;
export { TreeModal };
export default TreeModal;
