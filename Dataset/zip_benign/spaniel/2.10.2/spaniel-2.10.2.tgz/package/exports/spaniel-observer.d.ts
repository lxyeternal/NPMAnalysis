import { DOMMargin, DOMString, SpanielObserverEntry, SpanielObserverInit, SpanielObserverInterface, SpanielRecord, SpanielThreshold, SpanielTrackedElement } from './interfaces';
import { SpanielIntersectionObserver } from './intersection-observer';
export declare function DOMMarginToRootMargin(d: DOMMargin): DOMString;
export declare class SpanielObserver<ObservePayload = undefined> implements SpanielObserverInterface<ObservePayload> {
    callback: (entries: SpanielObserverEntry<ObservePayload>[]) => void;
    observer: SpanielIntersectionObserver | IntersectionObserver;
    thresholds: SpanielThreshold[];
    recordStore: {
        [key: string]: SpanielRecord<ObservePayload>;
    };
    queuedEntries: SpanielObserverEntry<ObservePayload>[];
    private paused;
    private usingNativeIo;
    private onWindowClosed;
    private onTabHidden;
    private onTabShown;
    constructor(callback: (entries: SpanielObserverEntry<ObservePayload>[]) => void, options?: SpanielObserverInit);
    private _onWindowClosed;
    private setAllHidden;
    private _onTabHidden;
    private generateObserverTimestamp;
    private _onTabShown;
    private internalCallback;
    private flushQueuedEntries;
    private generateSpanielEntry;
    private handleRecordExiting;
    private handleThresholdExiting;
    private handleObserverEntry;
    disconnect(): void;
    destroy(): void;
    unobserve(element: SpanielTrackedElement): void;
    observe(target: Element, payload: ObservePayload): string;
}
