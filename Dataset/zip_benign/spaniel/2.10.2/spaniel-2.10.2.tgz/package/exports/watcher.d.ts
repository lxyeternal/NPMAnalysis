import { SpanielObserver } from './spaniel-observer';
import { DOMString, DOMMargin, SpanielTrackedElement, WatcherCallbackOptions } from './interfaces';
export interface WatcherConfig {
    ratio?: number;
    time?: number;
    rootMargin?: DOMString | DOMMargin;
    root?: SpanielTrackedElement;
    ALLOW_CACHED_SCHEDULER?: boolean;
    BACKGROUND_TAB_FIX?: boolean;
    USE_NATIVE_IO?: boolean;
}
export declare type EventName = 'impressed' | 'exposed' | 'visible' | 'impression-complete';
export { WatcherCallbackOptions };
export declare type WatcherCallback = (eventName: EventName, callback: WatcherCallbackOptions) => void;
export interface Threshold {
    label: EventName;
    time: number;
    ratio: number;
}
interface WatcherObservePayload {
    callback: (label: string, opts: WatcherCallbackOptions) => void;
}
export declare class Watcher {
    observer: SpanielObserver<WatcherObservePayload>;
    constructor(config?: WatcherConfig);
    watch(el: Element, callback: WatcherCallback): void;
    unwatch(el: Element): void;
    disconnect(): void;
    destroy(): void;
}
