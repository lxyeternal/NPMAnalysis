import { SpanielClientRectInterface } from './metal/interfaces';
export declare function calculateIsIntersecting({ intersectionRect }: {
    intersectionRect: ClientRect;
}): boolean;
export declare function getBoundingClientRect(element: Element): SpanielClientRectInterface;
export declare function throttle(cb: Function, thottleDelay?: number, scope?: Window & typeof globalThis): () => void;
/**
 * Calculate duration from end/start timestamps, round to nearest integer
 *
 * @param end - end timestamp for calculating the duration
 * @param start - start timestamp for calculating the duration
 */
export declare function calculateDuration(end: number, start: number): number;
