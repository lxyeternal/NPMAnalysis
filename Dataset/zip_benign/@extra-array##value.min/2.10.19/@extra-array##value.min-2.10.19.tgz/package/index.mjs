function value(x, r = Math.random()) {
    var i = Math.floor(r * x.length);
    return x[i];
}
export { value as default };
