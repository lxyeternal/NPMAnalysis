const array = require("extra-array");

var x = [1, 2, 3];
array.value(x);

array.value(x, 0.5);
