Picks an arbitrary value.
[:package:](https://www.npmjs.com/package/@extra-array/value)
[:smiley_cat:](https://github.com/orgs/nodef/packages?repo_name=extra-array)
[:running:](https://npm.runkit.com/@extra-array/value)
[:vhs:](https://asciinema.org/a/332152)
[:moon:](https://www.npmjs.com/package/@extra-array/value.min)
[:scroll:](https://unpkg.com/@extra-array/value/)
[:newspaper:](https://nodef.github.io/extra-array/)
[:blue_book:](https://github.com/nodef/extra-array/wiki/)

> Similar: [value], [values], [hasValue], [searchValue].

> This is part of package [extra-array].

[extra-array]: https://www.npmjs.com/package/extra-array

> This is browserified, minified version of [@extra-array/value].<br>
> It is exported as global variable **array_value**.<br>
> CDN: [unpkg], [jsDelivr].

[@extra-array/value]: https://www.npmjs.com/package/@extra-array/value
[unpkg]: https://unpkg.com/@extra-array/value.min
[jsDelivr]: https://cdn.jsdelivr.net/npm/@extra-array/value.min

<br>

```javascript
array.value(x, [r]);
// x: an array
// r: random seed 0->1
```

```javascript
const array = require("extra-array");

var x = [1, 2, 3];
array.value(x);
// 3

array.value(x, 0.5);
// 2
```

<br>
<br>


## References

- [Array.sample: sugarjs](https://sugarjs.com/docs/#/Array/sample)

[value]: https://github.com/nodef/extra-array/wiki/value
[values]: https://github.com/nodef/extra-array/wiki/values
[hasValue]: https://github.com/nodef/extra-array/wiki/hasValue
[searchValue]: https://github.com/nodef/extra-array/wiki/searchValue
