const path = require('path');

const TerserPlugin = require('terser-webpack-plugin');

module.exports = {
  mode: 'development',
  entry: './src/lib/index.js',
  // experiments: {
  //   outputModule: true
  // },
  output: {
    filename: '[name].js',
    libraryTarget: 'umd',
    path: path.resolve(__dirname, 'dist'),
    library: ['raindrop'],
    // library: {
    //   type:'module'
    // }
  },
  optimization: {
    minimizer: [
      new TerserPlugin({
        extractComments: false,
        terserOptions: {
          compress: {
            drop_console: true
          }
        }
      })
    ]
  },
  externals: {
    'echarts/lib/echarts': 'echarts'
  }

};
