# PerpAggregator
This project has typescript implementation of how we can interact with contracts and use it in UI


# Sample Code 

```

// import {  swapPath } from "./domain/synthetics/orders/swapPath";
// import { ARBITRUM, getRpcUrl } from "./config/chains";
// import { useMarketInfo } from "./domain/synthetics/markets/useMarketInfo";
// import { BigNumber, ethers } from "ethers";
// import { getGasPrice } from "./domain/synthetics/fees/useGasPrice";
// import { useGasLimits } from "./domain/synthetics/fees/useGasLimits";
// import { estimateExecuteIncreaseOrderGasLimit, getExecutionFee } from "./domain/synthetics/fees/utils/executionFee";
// import { GasLimitsConfig } from "./domain/synthetics/fees/types";
// import { createIncreaseOrder } from "./domain/synthetics/orders/createIncreaseOrder";
// import { getSwapPathStats } from "./domain/synthetics/trade/utils/swapStats";
// import { kuseSwapRoutes } from "./domain/synthetics/trade/useSwapRoute";
// import { cancelOrdersTxn } from "./domain/synthetics/orders/cancelOrder";

// async function bootstrap() {
//   const {marketsInfoData}=await useMarketInfo(ARBITRUM)
//   const marketAddress='0x47c031236e19d024b42f8AE6780E44A573170703'
//   const marketInfo = marketsInfoData[marketAddress];
//   console.log(marketInfo);
  
//   const url = getRpcUrl(ARBITRUM)?.[0];
//   const provider = new ethers.providers.JsonRpcProvider(url);
//   const privateKey = process.env.PRIVATE_KEY as string;
//   const wallet = new ethers.Wallet(privateKey, provider);
//   const execFee=await exec()
  // const swapP=['0x47c031236e19d024b42f8AE6780E44A573170703']
  // const swap= getSwapPathStats({
  //   marketsInfoData:marketsInfoData,
  //   swapPath:swapP,
  //   initialCollateralAddress:"0x2f2a2543B76A4166549F7aaB2e75Bef0aefC5B0f",
  //   wrappedNativeTokenAddress:"0x82aF49447D8a07e3bd95BD0d56f35241523fBab1",
  //   usdIn: BigNumber.from('0x02034ea2c876458ba412da680000'),
  //   shouldApplyPriceImpact:false,
  //   shouldUnwrapNativeToken:false

  // })
 
  

  // const positionInfo ={
  //   isLong : false,
  //   sizeInUsd : BigNumber.from("188453000000000000000000000000000"),
  //   market: ethers.utils.getAddress("0x70d95587d40A2caf56bd97485aB3Eec10Bee6336"),
  //   collateralAmount:BigNumber.from("9930471606974805")
  // }
  const execFee=await exec()

  // const data   = await createClosePosition(marketInfo, wallet, ARBITRUM, positionInfo)
  // console.log('Hashs', data);

  const hashsx = await createDecreaseOrder(marketInfo, wallet, ARBITRUM,execFee)
  console.log('Hashs', hashsx);
  // const hash=await cancelOrdersTxn(ARBITRUM,wallet,['0x7d5c470655a19429153a1be5f3262b079e38025150fee56c67811a9ef5dcb1fc',
  // '0x2ac7d17d7f1f818866184ebff2a41b2788f3c635fdac308bdfac67490bfef621'],execFee)
  // console.log(hash);
  
  // const hash = await createIncreaseOrder(marketInfo,marketsInfoData, wallet, '0.0001', '10.00', ARBITRUM, '0.3', false, true,execFee,3,'0x2f2a2543B76A4166549F7aaB2e75Bef0aefC5B0f',"40000");
  // console.log('Hash', hash);



//   const { positionsInfoData } = await usePositionsInfo(ARBITRUM, {
//     account: wallet.address,
//     marketsInfoData: marketsInfoData,
//     tokensData: tokensData,
//     pricesUpdatedAt: pricesUpdatedAt,
//     showPnlInLeverage: true,
//   });

//   const parsedPosition = [];
//   for (const key in positionsInfoData) {
//     const position = positionsInfoData[key];
//     const poolName = getMarketPoolName(position.marketInfo);
//     const indexName = getMarketIndexName(position.marketInfo);
//     console.log("PPPPPP",position);
    
//     parsedPosition.push({
//       InitialCollateral: formatUsd(position.collateralUsd),
//       PnL: formatUsd(position.pnl),
//       PnLAfterFees: formatDeltaUsd(position.pnlAfterFees, position.pnlAfterFeesPercentage),
//       Market: position.marketAddress,
//       EntryPrice: formatUsd(position.entryPrice, { displayDecimals: position?.indexToken?.priceDecimals }),
//       MarkPrice: formatUsd(position.markPrice, { displayDecimals: position?.indexToken?.priceDecimals }),
//       LiqPrice: formatUsd(position.liquidationPrice, { displayDecimals: position?.indexToken?.priceDecimals }),
//       isLong: position.isLong,
//       NetValue: formatUsd(position.netValue),
//       PoolName: poolName,
//       IndexName: indexName,
//     });
//   }

//   console.log(parsedPosition);

//   // const hashs = await createDecreaseOrder(marketInfo, wallet, ARBITRUM);
//   // console.log('hashs', hashs);
}

bootstrap();
```

## Execution Fee

```typescript=
import { getGasPrice } from './domain/synthetics/fees/useGasPrice';
import { useGasLimits } from './domain/synthetics/fees/useGasLimits';
import { estimateExecuteIncreaseOrderGasLimit, getExecutionFee } from './domain/synthetics/fees/utils/executionFee';
import { GasLimitsConfig } from './domain/synthetics/fees/types';

const exec=async () => {
  const activeChain = ARBITRUM;

  const gasPrice = await getGasPrice(activeChain);
  console.log('gasPrice', gasPrice.toString());

  const gasLimits = await useGasLimits(activeChain);
  console.log('gasLimits', gasLimits);

  const { marketsInfoData, tokensData, pricesUpdatedAt } = await useMarketInfo(activeChain);

  const estimatedGas = estimateExecuteIncreaseOrderGasLimit(gasLimits.gasLimits as GasLimitsConfig, {
    swapPath: [],
  });

  const executionFee = getExecutionFee(activeChain, gasLimits.gasLimits, tokensData, estimatedGas, gasPrice);
  console.log('executionFee', executionFee.feeTokenAmount);
  return executionFee.feeTokenAmount
};



```