export declare const TRIGGER_PREFIX_ABOVE = ">";
export declare const TRIGGER_PREFIX_BELOW = "<";
export declare const TOAST_AUTO_CLOSE_TIME = 7000;
export declare const WS_LOST_FOCUS_TIMEOUT: number;
export declare const PERCENTAGE_SUGGESTIONS: number[];
export declare const MAX_METAMASK_MOBILE_DECIMALS = 5;
export declare const INPUT_LABEL_SEPARATOR = ":";
//# sourceMappingURL=ui.d.ts.map