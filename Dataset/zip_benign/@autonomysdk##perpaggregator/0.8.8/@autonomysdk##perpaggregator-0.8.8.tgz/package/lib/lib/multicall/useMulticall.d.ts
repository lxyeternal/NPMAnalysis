import { ethers } from "ethers";
import { CacheKey } from "./types";
export declare function useMulticall(chainId: number, signer: ethers.Signer, params: {
    key: CacheKey;
    request: any;
    refreshInterval?: number | null;
    parseResponse?: (result: any) => any;
}): Promise<any>;
//# sourceMappingURL=useMulticall.d.ts.map