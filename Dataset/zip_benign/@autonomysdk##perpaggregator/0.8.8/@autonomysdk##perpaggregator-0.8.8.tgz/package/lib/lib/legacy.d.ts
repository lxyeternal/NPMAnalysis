export declare const PRECISION: import("ethers").BigNumber;
//# sourceMappingURL=legacy.d.ts.map