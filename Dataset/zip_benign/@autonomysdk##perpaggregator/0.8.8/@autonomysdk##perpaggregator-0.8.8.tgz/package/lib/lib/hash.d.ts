export declare function hashData(dataTypes: any, dataValues: any): string;
export declare function hashString(string: string): string;
//# sourceMappingURL=hash.d.ts.map