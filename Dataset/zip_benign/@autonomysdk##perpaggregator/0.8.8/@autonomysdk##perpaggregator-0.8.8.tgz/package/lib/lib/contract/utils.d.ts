import { BigNumber, Contract } from "ethers";
export declare function getGasLimit(contract: Contract, method: any, params?: any[], value?: BigNumber | number): Promise<BigNumber>;
//# sourceMappingURL=utils.d.ts.map