import { BigNumber, BigNumberish } from "ethers";
export declare function bigNumberify(n?: BigNumberish): BigNumber;
export declare function expandDecimals(n: BigNumberish, decimals: number): BigNumber;
export declare function getLimitedDisplay(amount: BigNumber, tokenDecimals: number, opts?: {
    maxThreshold?: string;
    minThreshold?: string;
}): {
    symbol: string;
    value: BigNumber;
};
export declare const trimZeroDecimals: (amount: string) => string;
export declare const limitDecimals: (amount: BigNumberish, maxDecimals?: number) => string;
export declare const padDecimals: (amount: BigNumberish, minDecimals: number) => string;
export declare const formatAmount: (amount: BigNumberish | undefined, tokenDecimals: number, displayDecimals?: number, useCommas?: boolean, defaultValue?: string) => string;
export declare const formatKeyAmount: (map: any, key: string, tokenDecimals: number, displayDecimals: number, useCommas?: boolean) => string;
export declare const formatArrayAmount: (arr: any[], index: number, tokenDecimals: number, displayDecimals?: number, useCommas?: boolean) => string;
export declare const formatAmountFree: (amount: BigNumberish, tokenDecimals: number, displayDecimals?: number) => string;
export declare function formatUsd(usd?: BigNumber, opts?: {
    fallbackToZero?: boolean;
    displayDecimals?: number;
    maxThreshold?: string;
    minThreshold?: string;
}): string;
export declare function formatDeltaUsd(deltaUsd?: BigNumber, percentage?: BigNumber, opts?: {
    fallbackToZero?: boolean;
}): string;
export declare function formatPercentage(percentage?: BigNumber, opts?: {
    fallbackToZero?: boolean;
    signed?: boolean;
}): string;
export declare function formatTokenAmount(amount?: BigNumber, tokenDecimals?: number, symbol?: string, opts?: {
    showAllSignificant?: boolean;
    displayDecimals?: number;
    fallbackToZero?: boolean;
    useCommas?: boolean;
    minThreshold?: string;
    maxThreshold?: string;
}): string;
export declare function formatTokenAmountWithUsd(tokenAmount?: BigNumber, usdAmount?: BigNumber, tokenSymbol?: string, tokenDecimals?: number, opts?: {
    fallbackToZero?: boolean;
    displayDecimals?: number;
}): string;
export declare const parseValue: (value: string, tokenDecimals: number) => BigNumber;
export declare function numberWithCommas(x: BigNumberish): string;
export declare function roundUpDivision(a: BigNumber, b: BigNumber): BigNumber;
export declare function roundUpMagnitudeDivision(a: BigNumber, b: BigNumber): BigNumber;
export declare function applyFactor(value: BigNumber, factor: BigNumber): BigNumber;
export declare function getBasisPoints(numerator: BigNumber, denominator: BigNumber): BigNumber;
export declare function basisPointsToFloat(basisPoints: BigNumber): BigNumber;
export declare function roundToTwoDecimals(n: any): number;
export declare function sumBigNumbers(...args: any[]): any;
export declare function removeTrailingZeros(amount: string | number): string | number;
//# sourceMappingURL=numbers.d.ts.map