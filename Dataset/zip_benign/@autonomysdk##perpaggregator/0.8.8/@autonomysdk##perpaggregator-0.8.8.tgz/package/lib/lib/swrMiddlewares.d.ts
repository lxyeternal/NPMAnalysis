import { Cache, Fetcher, Key } from "swr";
export type SWRGCMiddlewareConfig = {
    clearUnusedKeys?: boolean;
};
export declare const swrGCMiddleware: (useSWRNext: any) => (key: Key, fetcher: Fetcher, config: {
    clearUnusedKeys?: boolean;
    cache: Cache;
}) => any;
//# sourceMappingURL=swrMiddlewares.d.ts.map