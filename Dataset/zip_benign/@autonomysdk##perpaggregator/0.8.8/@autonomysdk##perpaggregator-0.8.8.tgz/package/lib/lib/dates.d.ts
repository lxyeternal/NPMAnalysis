export declare function formatDateTime(time: number): string;
export declare function formatDate(time: number): string;
export declare function formatTVDate(date: Date): string;
export declare function formatTVTime(date: Date): string;
export declare function getTimeRemaining(time: number): string;
export declare function isValidTimestamp(timestamp: any): boolean;
//# sourceMappingURL=dates.d.ts.map