import { BigNumber } from "ethers";
export declare const formatUsdValue: (usd: BigNumber) => Promise<string>;
export declare const parseValue: (value: string, tokenDecimals: number) => BigNumber;
//# sourceMappingURL=formatUsd.d.ts.map