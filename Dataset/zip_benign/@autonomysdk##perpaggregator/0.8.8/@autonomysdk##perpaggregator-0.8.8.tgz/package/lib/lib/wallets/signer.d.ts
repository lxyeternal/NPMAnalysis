import { ethers } from "ethers";
export declare function getSigner(): Promise<ethers.Wallet>;
//# sourceMappingURL=signer.d.ts.map