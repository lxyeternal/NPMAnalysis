export default function useWallet(): {
    account: `0x${string}`;
    active: boolean;
    connector: import("@wagmi/connectors/dist/base-84a689bb").C<any, any, any>;
    chainId: number;
    signer: import("ethers").Signer;
};
//# sourceMappingURL=useWallet.d.ts.map