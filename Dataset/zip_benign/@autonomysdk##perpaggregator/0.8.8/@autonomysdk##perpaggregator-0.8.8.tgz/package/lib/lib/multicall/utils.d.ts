import { PublicClient } from "viem";
import { MulticallRequestConfig, MulticallResult } from "./types";
import { Signer } from "ethers";
export declare const MAX_TIMEOUT = 2000;
export declare function executeMulticall(chainId: number, signer: Signer | undefined, request: MulticallRequestConfig<any>): Promise<MulticallResult<any>>;
export declare class Multicall {
    chainId: number;
    rpcUrl: string;
    static instances: {
        [chainId: number]: Multicall | undefined;
    };
    static getInstance(chainId: number): Promise<Multicall>;
    static getViemClient(chainId: number, rpcUrl: string): {
        account: undefined;
        batch?: {
            multicall?: boolean | {
                batchSize?: number;
                wait?: number;
            };
        };
        cacheTime: number;
        chain: any;
        key: string;
        name: string;
        pollingInterval: number;
        request: import("viem").EIP1193RequestFn<import("viem").PublicRpcSchema>;
        transport: import("viem").TransportConfig<"http", import("viem").EIP1193RequestFn<undefined>> & {
            fetchOptions?: Omit<RequestInit, "body">;
            url?: string;
        };
        type: string;
        uid: string;
        call: (parameters: import("viem").CallParameters<any>) => Promise<import("viem").CallReturnType>;
        createBlockFilter: () => Promise<{
            id: `0x${string}`;
            request: import("viem").EIP1193RequestFn<readonly [{
                Method: "eth_getFilterChanges";
                Parameters: [filterId: `0x${string}`];
                ReturnType: `0x${string}`[] | {
                    address: `0x${string}`;
                    blockHash: `0x${string}`;
                    blockNumber: `0x${string}`;
                    data: `0x${string}`;
                    logIndex: `0x${string}`;
                    transactionHash: `0x${string}`;
                    transactionIndex: `0x${string}`;
                    removed: boolean;
                }[];
            }, {
                Method: "eth_getFilterLogs";
                Parameters: [filterId: `0x${string}`];
                ReturnType: {
                    address: `0x${string}`;
                    blockHash: `0x${string}`;
                    blockNumber: `0x${string}`;
                    data: `0x${string}`;
                    logIndex: `0x${string}`;
                    transactionHash: `0x${string}`;
                    transactionIndex: `0x${string}`;
                    removed: boolean;
                }[];
            }, {
                Method: "eth_uninstallFilter";
                Parameters: [filterId: `0x${string}`];
                ReturnType: boolean;
            }]>;
            type: "block";
        }>;
        createContractEventFilter: () => const;
        extend: () => const;
    };
    viemClient: PublicClient;
    constructor(chainId: number, rpcUrl: string);
    call(request: MulticallRequestConfig<any>, maxTimeout: number): Promise<MulticallResult<any>>;
}
//# sourceMappingURL=utils.d.ts.map