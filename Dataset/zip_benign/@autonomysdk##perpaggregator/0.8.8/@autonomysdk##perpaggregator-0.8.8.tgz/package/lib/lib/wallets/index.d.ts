export type NetworkMetadata = {
    chainId: string;
    chainName: string;
    nativeCurrency: {
        name: string;
        symbol: string;
        decimals: number;
    };
    rpcUrls: string[];
    blockExplorerUrls: string[];
};
export declare function shortenAddressOrEns(address: string, length: number): string;
//# sourceMappingURL=index.d.ts.map