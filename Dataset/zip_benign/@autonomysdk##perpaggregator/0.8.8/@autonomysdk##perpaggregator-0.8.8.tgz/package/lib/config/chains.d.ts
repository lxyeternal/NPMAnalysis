import { NetworkMetadata } from 'lib/wallets';
export declare const ARBITRUM = 42161;
export declare const ARBITRUM_GOERLI = 421613;
export declare const FEES_HIGH_BPS = 50;
export declare const DEFAULT_CHAIN_ID = 421613;
export declare const CHAIN_ID = 421613;
export declare const HIGH_EXECUTION_FEES_MAP: {
    42161: number;
};
export declare const EXECUTION_FEE_MULTIPLIER_MAP: {
    42161: number;
};
export declare const CHIAN_NAMES_MAP: {
    421613: string;
    42161: string;
};
export declare const GAS_PRICE_ADJUSTMENT_MAP: {
    42161: string;
};
export declare const EXECUTION_FEE_CONFIG_V2: {
    [chainId: number]: {
        shouldUseMaxPriorityFeePerGas: boolean;
        defaultBufferBps?: number;
    };
};
export declare const RPC_PROVIDERS: {
    421613: string[];
    42161: string[];
};
export declare const FALLBACK_PROVIDERS: {
    421613: string[];
    42161: string[];
};
export declare const NETWORK_METADATA: {
    [chainId: number]: NetworkMetadata;
};
export declare const getConstant: (chainId: number, key: string) => any;
export declare function getChainName(chainId: number): any;
export declare function getRpcUrl(chainId: number): string | undefined;
export declare function getExplorerUrl(chainId: any): "https://goerli.arbiscan.io/" | "https://arbiscan.io/";
export declare function getFallbackRpcUrl(chainId: number): string | undefined;
export declare function getHighExecutionFee(chainId: any): any;
export declare function getExecutionFeeMultiplier(chainId: any): any;
//# sourceMappingURL=chains.d.ts.map