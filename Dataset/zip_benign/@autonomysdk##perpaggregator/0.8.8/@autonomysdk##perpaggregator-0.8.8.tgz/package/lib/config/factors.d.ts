import { BigNumber, BigNumberish } from "ethers";
export declare const BASIS_POINTS_DIVISOR = 10000;
export declare const GMBOT_REFFERAL = "0x676d626f74000000000000000000000000000000000000000000000000000000";
export declare const MAX_LEVERAGE: number;
export declare const MAX_ALLOWED_LEVERAGE: number;
export declare const DEFAULT_SLIPPAGE_AMOUNT = 30;
export declare const DEFAULT_HIGHER_SLIPPAGE_AMOUNT = 100;
export declare const HIGH_PRICE_IMPACT_BPS = 80;
export declare const DEFAULT_ACCEPABLE_PRICE_IMPACT_BPS = 100;
export declare function bigNumberify(n?: BigNumberish): BigNumber;
export declare function expandDecimals(n: BigNumberish, decimals: number): BigNumber;
//# sourceMappingURL=factors.d.ts.map