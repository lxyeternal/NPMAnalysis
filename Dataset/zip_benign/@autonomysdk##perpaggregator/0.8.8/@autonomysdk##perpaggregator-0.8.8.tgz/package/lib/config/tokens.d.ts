export declare const WRAPPED_TOKENS_MAP: {
    [chainId: number]: any;
};
export declare const NATIVE_TOKEN_TOKENS_MAP: {
    [chainId: number]: any;
};
export declare const TOKENS_MAP: {
    [chainId: number]: {
        [address: string]: any;
    };
};
export declare const NATIVE_TOKENS_MAP: {
    [chainId: number]: any;
};
export declare const V2_TOKENS: {
    [chainId: number]: any[];
};
export declare const V1_TOKENS: {
    [chainId: number]: any[];
};
export declare function isValidToken(chainId: number, address: string): boolean;
export declare function getWhitelistedV1Tokens(chainId: number): any[];
export declare function getV1Tokens(chainId: number): any[];
export declare const TOKENS: {
    [chainId: number]: any;
};
export declare const NATIVE_TOKEN_ADDRESS = "0x0000000000000000000000000000000000000000";
export declare function convertTokenAddress(chainId: number, address: string, convertTo?: "wrapped" | "native"): any;
export declare function getV2Tokens(chainId: number): any[];
export declare function getTokensMap(chainId: number): {
    [address: string]: any;
};
export declare function getWrappedToken(chainId: number): any;
export declare function getToken(chainId: number, address: string): any;
//# sourceMappingURL=tokens.d.ts.map