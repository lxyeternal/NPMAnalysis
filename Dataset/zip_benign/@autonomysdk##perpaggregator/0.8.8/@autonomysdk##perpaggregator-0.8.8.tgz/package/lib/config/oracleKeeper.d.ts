export declare function getOracleKeeperUrl(chainId: number, index: number): string;
export declare function getOracleKeeperNextIndex(chainId: number, currentIndex: number): number;
export declare function getOracleKeeperRandomIndex(chainId: number, bannedIndexes?: number[]): number;
//# sourceMappingURL=oracleKeeper.d.ts.map