export declare function getContract(chainId: number, name: string): string;
//# sourceMappingURL=contract.d.ts.map