export type TickersResponse = {
    minPrice: string;
    maxPrice: string;
    oracleDecimals: number;
    tokenSymbol: string;
    tokenAddress: string;
    updatedAt: number;
}[];
export type DayPriceCandle = {
    tokenSymbol: string;
    high: number;
    low: number;
    open: number;
    close: number;
};
export declare function useOracleKeeperFetcher(chainId: number): {
    oracleKeeperUrl: string;
    fetchTickers(): Promise<TickersResponse>;
    fetch24hPrices(): Promise<DayPriceCandle[]>;
    fetchOracleCandles(tokenSymbol: string, period: string, limit: number): Promise<null>;
};
export declare function getNormalizedTokenSymbol(tokenSymbol: any): any;
//# sourceMappingURL=useOracleKeeperFetcher.d.ts.map