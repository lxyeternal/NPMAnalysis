import { MarketInfo, MarketsInfoData } from "./../../../../domain/synthetics/markets/types";
import { BigNumber } from "ethers";
import { MarketsGraph, SwapEstimator, SwapRoute } from "./../types";
export declare function getMarketsGraph(markets: MarketInfo[]): MarketsGraph;
export declare const createSwapEstimator: (marketsInfoData: MarketsInfoData) => SwapEstimator;
export declare function getBestSwapPath(routes: SwapRoute[], usdIn: BigNumber, estimator: SwapEstimator): string[];
export declare function findAllPaths(marketsInfoData: MarketsInfoData, graph: MarketsGraph, from: string, to: string, maxDepth?: number): SwapRoute[];
//# sourceMappingURL=swapRouting.d.ts.map