export declare function getParsedOrders(chainId: number, address: string): Promise<any[]>;
//# sourceMappingURL=parsedOrders.d.ts.map