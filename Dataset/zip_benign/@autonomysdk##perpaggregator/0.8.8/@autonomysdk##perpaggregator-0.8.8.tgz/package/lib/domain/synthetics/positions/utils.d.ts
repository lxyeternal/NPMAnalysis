import { BigNumber } from "ethers";
import { MarketInfo } from "../markets/types";
import { TokenData } from "../tokens/types";
export declare function getPositionKey(account: string, marketAddress: string, collateralAddress: string, isLong: boolean): string;
export declare function getPositionPendingFeesUsd(p: {
    pendingFundingFeesUsd: BigNumber;
    pendingBorrowingFeesUsd: BigNumber;
}): BigNumber;
export declare function getPositionPnlUsd(p: {
    marketInfo: MarketInfo;
    sizeInUsd: BigNumber;
    sizeInTokens: BigNumber;
    markPrice: BigNumber;
    isLong: boolean;
}): BigNumber;
export declare function getPositionValueUsd(p: {
    indexToken: any;
    sizeInTokens: BigNumber;
    markPrice: BigNumber;
}): BigNumber;
export declare function getPositionNetValue(p: {
    collateralUsd: BigNumber;
    pendingFundingFeesUsd: BigNumber;
    pendingBorrowingFeesUsd: BigNumber;
    pnl: BigNumber;
    closingFeeUsd: BigNumber;
}): BigNumber;
export declare function getLeverage(p: {
    sizeInUsd: BigNumber;
    collateralUsd: BigNumber;
    pnl: BigNumber | undefined;
    pendingFundingFeesUsd: BigNumber;
    pendingBorrowingFeesUsd: BigNumber;
}): BigNumber;
export declare function getLiquidationPrice(p: {
    sizeInUsd: BigNumber;
    sizeInTokens: BigNumber;
    collateralAmount: BigNumber;
    collateralUsd: BigNumber;
    collateralToken: TokenData;
    marketInfo: MarketInfo;
    pendingFundingFeesUsd: BigNumber;
    pendingBorrowingFeesUsd: BigNumber;
    minCollateralUsd: BigNumber;
    isLong: boolean;
    useMaxPriceImpact?: boolean;
    userReferralInfo: any | undefined;
}): BigNumber;
//# sourceMappingURL=utils.d.ts.map