import { MarketInfo } from "./../../../../domain/synthetics/markets/types";
import { BigNumber } from "ethers";
import { TokenPrices } from "domain/synthetics/tokens/types";
import { OrderType } from "./../../../../domain/synthetics/orders/types";
export declare function getAcceptablePriceInfo(p: {
    marketInfo: MarketInfo;
    isIncrease: boolean;
    isLong: boolean;
    indexPrice: BigNumber;
    sizeDeltaUsd: BigNumber;
    maxNegativePriceImpactBps?: BigNumber;
}): {
    acceptablePrice: BigNumber;
    acceptablePriceDeltaBps: BigNumber;
    priceImpactDeltaAmount: BigNumber;
    priceImpactDeltaUsd: BigNumber;
    priceImpactDiffUsd: BigNumber;
};
export declare function getShouldUseMaxPrice(isIncrease: boolean, isLong: boolean): boolean;
export declare function applySlippageToPrice(allowedSlippage: number, price: BigNumber, isIncrease: boolean, isLong: boolean): BigNumber;
export declare function applySlippageToMinOut(allowedSlippage: number, minOutputAmount: BigNumber): BigNumber;
export declare function getMarkPrice(p: {
    prices: TokenPrices;
    isIncrease: boolean;
    isLong: boolean;
}): BigNumber;
export declare function getEntryPrice(p: {
    sizeInUsd: BigNumber;
    sizeInTokens: BigNumber;
    indexToken: any;
}): BigNumber;
export declare function getTriggerDecreaseOrderType(p: {
    triggerPrice: BigNumber;
    markPrice: BigNumber;
    isLong: boolean;
}): OrderType.LimitDecrease | OrderType.StopLossDecrease;
//# sourceMappingURL=prices.d.ts.map