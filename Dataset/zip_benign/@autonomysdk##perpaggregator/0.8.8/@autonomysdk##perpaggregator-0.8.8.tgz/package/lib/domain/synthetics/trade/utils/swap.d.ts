import { BigNumber } from "ethers";
import { FindSwapPath } from "./types";
import { SwapAmounts } from "./types";
import { MarketsInfoData } from "./../../../../domain/synthetics/markets/types";
export declare function getSwapAmountsByFromValue(p: {
    tokenIn: any;
    tokenOut: any;
    amountIn: BigNumber;
    triggerRatio?: any;
    isLimit: boolean;
    findSwapPath: FindSwapPath;
    marketsInfoData: MarketsInfoData;
}): SwapAmounts;
//# sourceMappingURL=swap.d.ts.map