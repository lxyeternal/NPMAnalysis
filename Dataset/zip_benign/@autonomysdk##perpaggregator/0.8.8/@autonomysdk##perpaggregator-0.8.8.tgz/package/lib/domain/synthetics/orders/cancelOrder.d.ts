export type CancelOrderParams = {
    orderKeys: string[];
    setPendingTxns: (txns: any) => void;
};
export declare function cancelOrdersTxn(chainId: number, wallet: any, orderKeys: string[], executionFee: any): Promise<any>;
//# sourceMappingURL=cancelOrder.d.ts.map