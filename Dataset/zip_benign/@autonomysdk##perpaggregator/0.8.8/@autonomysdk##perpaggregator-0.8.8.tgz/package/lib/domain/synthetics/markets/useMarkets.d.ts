import 'dotenv/config';
type MarketsResult = {
    marketsData?: any;
    marketsAddresses?: string[];
};
export declare function getActiveMarkets(chainId: number): string[];
export declare function useMarkets(chainId: number): Promise<MarketsResult>;
export {};
//# sourceMappingURL=useMarkets.d.ts.map