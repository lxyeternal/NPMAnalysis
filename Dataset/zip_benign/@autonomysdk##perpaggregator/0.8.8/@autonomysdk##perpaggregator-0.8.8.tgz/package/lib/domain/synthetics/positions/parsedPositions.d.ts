export declare function getParsedPositions(chainId: number, address: string): Promise<any[]>;
//# sourceMappingURL=parsedPositions.d.ts.map