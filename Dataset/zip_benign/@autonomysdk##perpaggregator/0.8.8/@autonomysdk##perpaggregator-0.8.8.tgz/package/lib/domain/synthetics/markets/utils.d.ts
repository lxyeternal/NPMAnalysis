import { BigNumber } from "ethers";
import { TokenPrices } from "../tokens/types";
import { ContractMarketPrices, Market, MarketInfo } from "./types";
export declare function getOppositeCollateral(marketInfo: MarketInfo, tokenAddress: string): any;
export declare function getTokenPoolType(marketInfo: MarketInfo, tokenAddress: string): "long" | "short";
export declare function getMarketFullName(p: {
    longToken: any;
    shortToken: any;
    indexToken: any;
    isSpotOnly: boolean;
}): string;
export declare function getMarketIndexName(p: {
    indexToken: any;
    isSpotOnly: boolean;
}): string;
export declare function getMarketPoolName(p: {
    longToken: any;
    shortToken: any;
}): any;
export declare function getContractMarketPrices(tokensData: any, market: Market): ContractMarketPrices | undefined;
export declare function convertToContractTokenPrices(prices: TokenPrices, tokenDecimals: number): {
    min: BigNumber;
    max: BigNumber;
};
export declare function convertToContractPrice(price: BigNumber, tokenDecimals: number): BigNumber;
export declare function getPoolUsdWithoutPnl(marketInfo: MarketInfo, isLong: boolean, priceType: "minPrice" | "maxPrice" | "midPrice"): BigNumber;
export declare function getCappedPoolPnl(p: {
    marketInfo: MarketInfo;
    poolUsd: BigNumber;
    isLong: boolean;
    maximize: boolean;
}): BigNumber;
export declare function getAvailableUsdLiquidityForCollateral(marketInfo: MarketInfo, isLong: boolean): BigNumber;
export declare function getReservedUsd(marketInfo: MarketInfo, isLong: boolean): BigNumber;
//# sourceMappingURL=utils.d.ts.map