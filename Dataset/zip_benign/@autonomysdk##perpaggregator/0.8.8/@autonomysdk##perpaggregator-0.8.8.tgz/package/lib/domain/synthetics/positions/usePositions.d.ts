import 'dotenv/config';
import { PositionsData } from './types';
type PositionsResult = {
    positionsData?: PositionsData;
    allPossiblePositionsKeys?: string[];
};
export declare function usePositions({ chainId, marketsInfoData, tokensData, account }: {
    chainId: any;
    marketsInfoData: any;
    tokensData: any;
    account: any;
}): Promise<PositionsResult>;
export {};
//# sourceMappingURL=usePositions.d.ts.map