import { BigNumber } from "ethers";
export type SwapPathStats = {
    swapPath: string[];
    swapSteps: SwapStats[];
    targetMarketAddress?: string;
    totalSwapPriceImpactDeltaUsd: BigNumber;
    totalSwapFeeUsd: BigNumber;
    totalFeesDeltaUsd: BigNumber;
    tokenInAddress: string;
    tokenOutAddress: string;
    usdOut: BigNumber;
    amountOut: BigNumber;
};
export type SwapStats = {
    marketAddress: string;
    tokenInAddress: string;
    tokenOutAddress: string;
    isWrap: boolean;
    isUnwrap: boolean;
    isOutLiquidity?: boolean;
    swapFeeAmount: BigNumber;
    swapFeeUsd: BigNumber;
    priceImpactDeltaUsd: BigNumber;
    amountIn: BigNumber;
    amountInAfterFees: BigNumber;
    usdIn: BigNumber;
    amountOut: BigNumber;
    usdOut: BigNumber;
};
export type SwapAmounts = {
    amountIn: BigNumber;
    usdIn: BigNumber;
    amountOut: BigNumber;
    usdOut: BigNumber;
    priceIn: BigNumber;
    priceOut: BigNumber;
    swapPathStats: SwapPathStats | undefined;
    minOutputAmount: BigNumber;
};
export type FindSwapPath = (usdIn: BigNumber, opts: {
    byLiquidity?: boolean;
}) => SwapPathStats | undefined;
//# sourceMappingURL=types.d.ts.map