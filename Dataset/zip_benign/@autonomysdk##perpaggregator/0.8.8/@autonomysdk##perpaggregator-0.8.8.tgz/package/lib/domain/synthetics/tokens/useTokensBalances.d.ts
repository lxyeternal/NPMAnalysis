import { BigNumber } from 'ethers';
type TokenBalancesData = {
    [tokenAddress: string]: BigNumber;
};
type BalancesDataResult = {
    balancesData?: TokenBalancesData;
};
export declare function useTokenBalances(chainId: number, account: string): Promise<BalancesDataResult>;
export {};
//# sourceMappingURL=useTokensBalances.d.ts.map