import { BigNumber } from "ethers";
export declare enum OrderType {
    MarketSwap = 0,
    LimitSwap = 1,
    MarketIncrease = 2,
    LimitIncrease = 3,
    MarketDecrease = 4,
    LimitDecrease = 5,
    StopLossDecrease = 6,
    Liquidation = 7
}
export declare enum DecreasePositionSwapType {
    NoSwap = 0,
    SwapPnlTokenToCollateralToken = 1,
    SwapCollateralTokenToPnlToken = 2
}
export type OrderError = {
    msg: string;
    level: "error" | "warning";
};
export type Order = {
    key: string;
    account: string;
    callbackContract: string;
    initialCollateralTokenAddress: string;
    marketAddress: string;
    decreasePositionSwapType: DecreasePositionSwapType;
    receiver: string;
    swapPath: string[];
    contractAcceptablePrice: BigNumber;
    contractTriggerPrice: BigNumber;
    callbackGasLimit: BigNumber;
    executionFee: BigNumber;
    initialCollateralDeltaAmount: BigNumber;
    minOutputAmount: BigNumber;
    sizeDeltaUsd: BigNumber;
    updatedAtBlock: BigNumber;
    isFrozen: boolean;
    isLong: boolean;
    orderType: OrderType;
    shouldUnwrapNativeToken: boolean;
    data: string;
};
export type OrdersData = {
    [orderKey: string]: Order;
};
export type OrdersInfoData = {
    [orderKey: string]: any;
};
//# sourceMappingURL=types.d.ts.map