import 'dotenv/config';
import { MarketsInfoData } from '../markets/types';
import { TokensData } from '../tokens/types';
import { PositionsInfoData } from './types';
type PositionsInfoResult = {
    positionsInfoData?: PositionsInfoData;
};
export declare function usePositionsInfo(chainId: number, p: {
    account: string | null | undefined;
    marketsInfoData?: MarketsInfoData;
    tokensData?: TokensData;
    pricesUpdatedAt?: number;
    showPnlInLeverage: boolean;
}): Promise<PositionsInfoResult>;
export {};
//# sourceMappingURL=usePositionsInfo.d.ts.map