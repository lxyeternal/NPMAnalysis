import { TokensData } from "./../../../../domain/synthetics/tokens/types";
import { ExecutionFee, GasLimitsConfig } from "../types";
import { BigNumber } from "ethers";
export declare const USD_DECIMALS = 30;
export declare function getExecutionFee(chainId: number, gasLimts: any, tokensData: TokensData, estimatedGasLimit: BigNumber, gasPrice: BigNumber): ExecutionFee | undefined;
export declare function estimateExecuteIncreaseOrderGasLimit(gasLimits: GasLimitsConfig, order: {
    swapPath?: string[];
    callbackGasLimit?: BigNumber;
}): BigNumber;
//# sourceMappingURL=executionFee.d.ts.map