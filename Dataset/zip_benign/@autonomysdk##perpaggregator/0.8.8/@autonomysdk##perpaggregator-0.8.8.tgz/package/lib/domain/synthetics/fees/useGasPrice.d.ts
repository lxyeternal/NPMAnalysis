import { BigNumber } from 'ethers';
export declare function getGasPrice(chainId: number, bufferBps?: number, adjustmentMap?: any): Promise<BigNumber>;
//# sourceMappingURL=useGasPrice.d.ts.map