import { BigNumber, Contract } from 'ethers';
import { GasLimitsConfig } from './types';
type GasLimitsResult = {
    gasLimits?: GasLimitsConfig;
};
export declare function useGasLimits(chainId: number): Promise<GasLimitsResult>;
export declare function getGasLimit(contract: Contract, method: any, params?: any[], value?: BigNumber | number): Promise<BigNumber>;
export {};
//# sourceMappingURL=useGasLimits.d.ts.map