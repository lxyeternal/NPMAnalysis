import { BigNumber } from "ethers";
export declare function getSwapFee(marketInfo: any, swapAmount: BigNumber, forPositiveImpact: boolean): BigNumber;
//# sourceMappingURL=index.d.ts.map