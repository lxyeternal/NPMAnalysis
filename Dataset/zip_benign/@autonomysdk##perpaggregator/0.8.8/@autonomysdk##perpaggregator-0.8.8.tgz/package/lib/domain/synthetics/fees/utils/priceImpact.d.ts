import { BigNumber } from "ethers";
import { MarketInfo } from "./../../../../domain/synthetics/markets/types";
import { TokenData } from "../../../../domain/synthetics/tokens/types";
export declare function getPriceImpactForPosition(marketInfo: MarketInfo, sizeDeltaUsd: BigNumber, isLong: boolean, opts?: {
    fallbackToZero?: boolean;
}): BigNumber;
export declare function getPriceImpactUsd(p: {
    currentLongUsd: BigNumber;
    currentShortUsd: BigNumber;
    nextLongUsd: BigNumber;
    nextShortUsd: BigNumber;
    factorPositive: BigNumber;
    factorNegative: BigNumber;
    exponentFactor: BigNumber;
    fallbackToZero?: boolean;
}): BigNumber;
export declare function calculateImpactForSameSideRebalance(p: {
    currentDiff: BigNumber;
    nextDiff: BigNumber;
    hasPositiveImpact: boolean;
    factor: BigNumber;
    exponentFactor: BigNumber;
}): BigNumber;
export declare function calculateImpactForCrossoverRebalance(p: {
    currentDiff: BigNumber;
    nextDiff: BigNumber;
    factorPositive: BigNumber;
    factorNegative: BigNumber;
    exponentFactor: BigNumber;
}): BigNumber;
export declare function applyImpactFactor(diff: BigNumber, factor: BigNumber, exponent: BigNumber): BigNumber;
export declare function applySwapImpactWithCap(marketInfo: any, token: any, priceImpactDeltaUsd: BigNumber): BigNumber;
export declare function getPriceImpactForSwap(marketInfo: MarketInfo, tokenA: TokenData, tokenB: TokenData, usdDeltaTokenA: BigNumber, usdDeltaTokenB: BigNumber, opts?: {
    fallbackToZero?: boolean;
}): BigNumber;
export declare function getNextPoolAmountsParams(p: {
    marketInfo: MarketInfo;
    longToken: TokenData;
    shortToken: TokenData;
    longPoolAmount: BigNumber;
    shortPoolAmount: BigNumber;
    longDeltaUsd: BigNumber;
    shortDeltaUsd: BigNumber;
}): {
    longPoolUsd: BigNumber;
    shortPoolUsd: BigNumber;
    nextLongPoolUsd: BigNumber;
    nextShortPoolUsd: BigNumber;
};
export declare function getPositionFee(marketInfo: MarketInfo, sizeDeltaUsd: BigNumber, forPositiveImpact: boolean, referralInfo: {
    totalRebateFactor: BigNumber;
    discountFactor: BigNumber;
} | undefined): {
    positionFeeUsd: BigNumber;
    discountUsd: BigNumber;
    totalRebateUsd: BigNumber;
};
export declare function getPriceImpactByAcceptablePrice(p: {
    sizeDeltaUsd: BigNumber;
    acceptablePrice: BigNumber;
    indexPrice: BigNumber;
    isLong: boolean;
    isIncrease: boolean;
}): {
    priceImpactDeltaUsd: BigNumber;
    priceImpactDeltaAmount: BigNumber;
};
export declare function getCappedPositionImpactUsd(marketInfo: MarketInfo, sizeDeltaUsd: BigNumber, isLong: boolean, opts?: {
    fallbackToZero?: boolean;
}): BigNumber;
//# sourceMappingURL=priceImpact.d.ts.map