import { TokensData } from "./types";
type TokensDataResult = {
    tokensData?: TokensData;
    pricesUpdatedAt?: number;
};
export declare function useTokensData(chainId: number): Promise<TokensDataResult>;
export {};
//# sourceMappingURL=useTokensData.d.ts.map