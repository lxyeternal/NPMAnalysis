export declare function usePositionswithPNL(chainId: number, address: string): Promise<void>;
//# sourceMappingURL=usePnL.d.ts.map