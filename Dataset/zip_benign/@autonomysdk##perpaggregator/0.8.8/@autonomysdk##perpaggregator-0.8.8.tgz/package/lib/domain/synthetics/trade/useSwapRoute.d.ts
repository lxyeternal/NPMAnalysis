import { MarketsInfoData } from "./../../../domain/synthetics/markets/types";
import { BigNumber } from "ethers";
export type SwapRoutesResult = {
    maxSwapLiquidity: BigNumber;
    maxLiquiditySwapPath?: string[];
    swapPathStats: any;
};
export declare function useSwapRoutes(p: {
    usdIn: BigNumber;
    marketsInfoData?: MarketsInfoData;
    fromTokenAddress?: string;
    toTokenAddress?: string;
    isLimit?: boolean;
}): SwapRoutesResult;
export declare const findSwapPath: (usdIn: BigNumber, opts: {
    byLiquidity?: boolean;
}, marketsInfoData: any, estimator: any, allRoutes: any, fromTokenAddress: any, wrappedToken: any, toTokenAddress: any) => import("./utils/types").SwapPathStats;
//# sourceMappingURL=useSwapRoute.d.ts.map