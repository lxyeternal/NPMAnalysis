import { MarketInfo, MarketsInfoData } from "./../../../../domain/synthetics/markets/types";
import { BigNumber } from "ethers";
import { SwapPathStats, SwapStats } from "./types";
export declare function getSwapPathStats(p: {
    marketsInfoData: MarketsInfoData;
    swapPath: string[];
    initialCollateralAddress: string;
    wrappedNativeTokenAddress: string;
    usdIn: BigNumber;
    shouldUnwrapNativeToken: boolean;
    shouldApplyPriceImpact: boolean;
}): SwapPathStats | undefined;
export declare function getSwapStats(p: {
    marketInfo: MarketInfo;
    tokenInAddress: string;
    tokenOutAddress: string;
    usdIn: BigNumber;
    shouldApplyPriceImpact: boolean;
}): SwapStats;
export declare function getMaxSwapPathLiquidity(p: {
    marketsInfoData: MarketsInfoData;
    swapPath: string[];
    initialCollateralAddress: string;
}): BigNumber;
//# sourceMappingURL=swapStats.d.ts.map