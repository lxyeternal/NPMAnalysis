import { MarketsInfoData } from './types';
export declare const MAX_PNL_FACTOR_FOR_TRADERS_KEY: string;
export type MarketsInfoResult = {
    marketsInfoData?: MarketsInfoData;
    tokensData?: any;
    pricesUpdatedAt?: number;
};
export declare function useMarketInfo(chainId: number): Promise<MarketsInfoResult>;
//# sourceMappingURL=useMarketInfo.d.ts.map