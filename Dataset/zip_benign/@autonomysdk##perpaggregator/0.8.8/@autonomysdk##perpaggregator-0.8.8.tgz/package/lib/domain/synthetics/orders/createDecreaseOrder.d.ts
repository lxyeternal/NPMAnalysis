import { BigNumber } from 'ethers';
export declare const createDecreaseOrder: (marketsInfoData: any, wallet: any, chain: number, executionFee: BigNumber) => Promise<any>;
//# sourceMappingURL=createDecreaseOrder.d.ts.map