import 'dotenv/config';
export declare function usePositions(chainId: number, address: string): Promise<any>;
//# sourceMappingURL=usePositions.d.ts.map