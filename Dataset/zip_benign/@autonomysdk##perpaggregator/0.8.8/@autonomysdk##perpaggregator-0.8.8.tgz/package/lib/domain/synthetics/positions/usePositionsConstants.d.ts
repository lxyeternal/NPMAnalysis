import { BigNumber } from 'ethers';
import 'dotenv/config';
export type PositionsConstantsResult = {
    minCollateralUsd?: BigNumber;
    minPositionSizeUsd?: BigNumber;
};
export declare function usePositionsConstants(chainId: number): Promise<PositionsConstantsResult>;
//# sourceMappingURL=usePositionsConstants.d.ts.map