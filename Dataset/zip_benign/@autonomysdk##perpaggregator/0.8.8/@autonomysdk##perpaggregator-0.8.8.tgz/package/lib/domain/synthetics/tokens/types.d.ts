import { BigNumber } from "ethers";
export type TokenPrices = {
    minPrice: BigNumber;
    maxPrice: BigNumber;
};
export type TokenData = any & {
    prices: TokenPrices;
    balance?: BigNumber;
    totalSupply?: BigNumber;
};
export type TokensRatio = {
    ratio: BigNumber;
    largestToken: any;
    smallestToken: any;
};
export type TokenBalancesData = {
    [tokenAddress: string]: BigNumber;
};
export type TokenPricesData = {
    [address: string]: TokenPrices;
};
export type TokensAllowanceData = {
    [tokenAddress: string]: BigNumber;
};
export type TokensData = {
    [address: string]: TokenData;
};
export type InfoTokens = {
    [key: string]: any;
};
//# sourceMappingURL=types.d.ts.map