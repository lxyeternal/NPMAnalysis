import { BigNumber } from 'ethers';
export declare const createClosePosition: (marketInfo: any, marketsInfoData: any, tokensData: any, wallet: any, chain: number, postionInfo: any, executionFee: BigNumber, orderType: number, triggerPriceInputValue?: string) => Promise<any>;
//# sourceMappingURL=createClosePosition.d.ts.map