export declare const getAddressTokenData: (initialCollateralMarketTokenData: any, initialCollateralAddress: string) => Promise<any>;
//# sourceMappingURL=swapPath.d.ts.map