import { TokenPricesData } from './types';
type TokenPricesDataResult = {
    pricesData?: TokenPricesData;
    updatedAt?: number;
};
export declare function useTokenRecentPrices(chainId: number): Promise<TokenPricesDataResult>;
export {};
//# sourceMappingURL=useTokenRecentPricesData.d.ts.map