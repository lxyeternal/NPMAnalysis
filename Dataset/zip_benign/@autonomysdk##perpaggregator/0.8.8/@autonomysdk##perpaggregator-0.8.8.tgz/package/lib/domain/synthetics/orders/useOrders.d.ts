import { OrdersData } from './types';
export declare function useOrders(chainId: number, account?: string): Promise<{
    ordersData?: OrdersData;
}>;
//# sourceMappingURL=useOrders.d.ts.map