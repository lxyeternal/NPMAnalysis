import { InfoTokens, TokenPrices, TokensData } from "./types";
import { BigNumber } from "ethers";
export declare const PRECISION: BigNumber;
export declare function getTokenData(tokensData?: TokensData, address?: string, convertTo?: "wrapped" | "native"): any;
export declare function parseOraclePrice(price: string, tokenDecimals: number, oracleDecimals: number): BigNumber;
export declare function getTokenInfo(infoTokens: InfoTokens, tokenAddress: string, replaceNative?: boolean, nativeTokenAddress?: string): any;
export declare function getMostAbundantStableToken(chainId: number, infoTokens: InfoTokens): any;
export declare function adjustForDecimals(amount: any, divDecimals: any, mulDecimals: any): any;
export declare function convertToUsd(tokenAmount: BigNumber | undefined, tokenDecimals: number | undefined, price: BigNumber | undefined): BigNumber;
export declare function convertToTokenAmount(usd: BigNumber | undefined, tokenDecimals: number | undefined, price: BigNumber | undefined): BigNumber;
export declare function convertToContractPrice(price: BigNumber, tokenDecimals: number): BigNumber;
export declare function getMidPrice(prices: TokenPrices): BigNumber;
export declare function getIsEquivalentTokens(token1: any, token2: any): boolean;
export declare function parseContractPrice(price: BigNumber, tokenDecimals: number): BigNumber;
export declare function getAmountByRatio(p: {
    fromToken: any;
    toToken: any;
    fromTokenAmount: BigNumber;
    ratio: BigNumber;
    shouldInvertRatio?: boolean;
}): BigNumber;
//# sourceMappingURL=utils.d.ts.map