'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

const branchBar = {
	_minifiedClass: 'branch-bar--minified',
	_hiddenClass: 'branch-bar--hidden',
	_storageSettings: null,
	_folderId: null,
	_settingsKey: null,
	_dom: {
		bar: null,
		toggles: null,
		pageSelects: null,
	},
	_isLocalStorageEnabled: function () {
		var test = 'branch-bar-test';

		try {
			localStorage.setItem(test, test);
			localStorage.removeItem(test);
			return true;
		} catch (e) {
			return false;
		}
	},
	_isMinified: function () {
		return this._dom.bar.className.split(' ').indexOf(this._minifiedClass) >= 0;
	},
	_getSettings: function () {
		var settings = null;

		if (!this._isLocalStorageEnabled()) {
			return null;
		}
		this._folderId = this._dom.bar.getAttribute('data-folder-id');
		this._settingsKey = 'branch-bar--' + this._folderId;
		if (this._settingsKey) {
			try {
				settings = JSON.parse(localStorage.getItem(this._settingsKey));
				return settings;
			} catch (e) {
				return null;
			}
		}

		return settings;
	},
	_updateSettings: function () {
		if (!this._isLocalStorageEnabled()) {
			return false;
		}

		if (!this._storageSettings) {
			this._storageSettings = {};
		}

		this._storageSettings.minified = this._isMinified();

		try {
			localStorage.setItem(
				this._settingsKey,
				JSON.stringify(this._storageSettings)
			);
			return true;
		} catch (e) {
			return false;
		}
	},
	_toggleMinified: function () {
		if (this._isMinified()) {
			var reg = new RegExp('(\\s|^)' + this._minifiedClass + '(\\s|$)');
			this._dom.bar.className = this._dom.bar.className.replace(reg, ' ');
		} else {
			this._dom.bar.className += ' ' + this._minifiedClass;
		}
	},
	_initToggles: function () {
		var self = this;

		this._dom.toggles = this._dom.bar.getElementsByClassName(
			'js-branch-bar__toggle'
		);

		for (var i = 0, l = this._dom.toggles.length; i < l; i++) {
			this._dom.toggles[i].addEventListener(
				'click',
				function () {
					self._toggleMinified();
					self._updateSettings();
				},
				false
			);
		}
	},
	_initPageSelects: function () {
		this._dom.pageSelects = this._dom.bar.getElementsByClassName(
			'js-branch-bar__page-select'
		);

		for (var i = 0, l = this._dom.pageSelects.length; i < l; i++) {
			this._dom.pageSelects[i].addEventListener(
				'change',
				function (e) {
					var val = e.target.value;

					if (val) {
						window.location.href = val;
					}
				},
				false
			);
		}
	},
	_showBar: function () {
		var reg = new RegExp('(\\s|^)' + this._hiddenClass + '(\\s|$)');
		var self = this;

		self._dom.bar.className = self._dom.bar.className.replace(reg, ' ');

		// Remove inline display:none style
		if (self._dom.bar.style.display === 'none') {
			self._dom.bar.style.display = '';
		}
	},
	_setCSSVar(name, value) {
		var prefix = '--branch-bar-';

		document.documentElement.style.setProperty(prefix + name, value);
	},
	_updateCSSVars: function (settings) {
		if (settings.zIndex) {
			this._setCSSVar('z-index', settings.zIndex);
		}

		if (settings.bgColor) {
			this._setCSSVar('bg-color', settings.bgColor);
		}

		if (settings.colorLight) {
			this._setCSSVar('color-light', settings.colorLight);
		}

		if (settings.colorDark) {
			this._setCSSVar('color-dark', settings.colorDark);
		}

		if (settings.shadowColor) {
			this._setCSSVar('shadow-color', settings.shadowColor);
		}
	},
	init: function (options) {
		var settings = options || {};

		this._updateCSSVars(settings);

		this._dom.bar = document.getElementById('js-branch-bar'); // Assumes only one bar per page

		if (this._dom.bar) {
			this._storageSettings = this._getSettings();

			// If user left the bar open
			if (this._storageSettings && !this._storageSettings.minified) {
				this._toggleMinified();
			}

			this._initToggles();
			this._initPageSelects();

			this._showBar();
		}
	},
};

exports.branchBar = branchBar;
exports["default"] = branchBar;
