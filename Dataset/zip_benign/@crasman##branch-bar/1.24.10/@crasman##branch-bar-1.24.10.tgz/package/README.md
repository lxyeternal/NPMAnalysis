# @crasman/branch-bar

To be used in Stage with `branch-helper` module. This package contains the client side JS / CSS for branch bar.

# Usage with Webpack

```js
import '@crasman/branch-bar/styles.css';
import { branchBar } from '@crasman/branch-bar';

branchBar.init({
	zIndex: 20000, // Default: 20000
	bgColor: '#000', // Default #00b2a9
	colorLight: '#f0f', // Default #fff
	colorDark: '#ff0', // Default #000
	shadowColor: 'rgba(255, 255, 255, 0.2)', // Default rgba(0, 0, 0, 0.4)
});
```

You can use `@import '@crasman/branch-bar'` when importing styles in SCSS file

If you want to define styles with CSS instead, you can use these CSS variables:

- `--branch-bar-z-index`
- `--branch-bar-bg-color`
- `--branch-bar-color-light`
- `--branch-bar-color-dark`
- `--branch-bar-shadow-color`
