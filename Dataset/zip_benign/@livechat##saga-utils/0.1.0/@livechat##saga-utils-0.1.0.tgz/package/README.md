# @livechat/saga-utils

---

## Utils

* [backoffRetry](#backoffretry-reducer)(min, max, saga, ...args)
* [safe](#safe-config-callback)(saga, ...args)
* [waitForState](#waitforstate-config)(selector, ...args)

### `backoffRetry(min, max, saga, ...args)`

Example usage

```js
import { backoffRetry } from '@livechat/saga-utils'

function* mightThrowSaga() {
  if (Math.random() > 0.5) {
    return 42
  }

  throw new Error('Answer has not been found.')
}

function* someSaga() {
  const answer = yield call(backoffRetry, 100, 20000, mightThrowSaga)
}
```

### `safe(saga, ...args)`

```js
import { safe } from '@livechat/saga-utils'

function* mightThrowSaga(random) {
  if (random > 0.5) {
    return 42
  }

  throw new Error('Answer has not been found.')
}

function* someSaga() {
  yield fork(safe, mightThrowSaga, Math.random())
  // ... you can safely proceed
}
```

### `waitForState(selector, ...args)`

```js
import { waitForState } from '@livechat/saga-utils'

const getActiveChatId = state => state.activeChat

function* someSaga() {
  const activeChatId = yield call(waitForState, getActiveChatId)
}
```
