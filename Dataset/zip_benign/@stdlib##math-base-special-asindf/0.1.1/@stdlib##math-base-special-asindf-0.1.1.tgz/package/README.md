<!--

@license Apache-2.0

Copyright (c) 2024 The Stdlib Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

-->


<details>
  <summary>
    About stdlib...
  </summary>
  <p>We believe in a future in which the web is a preferred environment for numerical computation. To help realize this future, we've built stdlib. stdlib is a standard library, with an emphasis on numerical and scientific computation, written in JavaScript (and C) for execution in browsers and in Node.js.</p>
  <p>The library is fully decomposable, being architected in such a way that you can swap out and mix and match APIs and functionality to cater to your exact preferences and use cases.</p>
  <p>When you use stdlib, you can be absolutely certain that you are using the most thorough, rigorous, well-written, studied, documented, tested, measured, and high-quality code out there.</p>
  <p>To join us in bringing numerical computing to the web, get started by checking us out on <a href="https://github.com/stdlib-js/stdlib">GitHub</a>, and please consider <a href="https://opencollective.com/stdlib">financially supporting stdlib</a>. We greatly appreciate your continued support!</p>
</details>

# asindf

[![NPM version][npm-image]][npm-url] [![Build Status][test-image]][test-url] [![Coverage Status][coverage-image]][coverage-url] <!-- [![dependencies][dependencies-image]][dependencies-url] -->

> Compute the [arcsine][arcsine] (in degrees) of a single-precision floating-point number.

<section class="installation">

## Installation

```bash
npm install @stdlib/math-base-special-asindf
```

</section>

<section class="usage">

## Usage

```javascript
var asindf = require( '@stdlib/math-base-special-asindf' );
```

#### asindf( x )

Computes the [arcsine][arcsine] (in degrees) of a single-precision floating-point number.

```javascript
var sqrtf = require( '@stdlib/math-base-special-sqrtf' );

var v = asindf( 0.0 );
// returns 0.0

v = asindf( 0.5 );
// returns ~30.0

v = asindf( sqrtf( 2.0 ) / 2.0 );
// returns ~45.0

v = asindf( sqrtf( 3.0 ) / 2.0 );
// returns ~60.0

v = asindf( NaN );
// returns NaN
```

The domain of `x` is restricted to `[-1,1]`. If `|x| > 1`, the function returns `NaN`.

```javascript
var v = asindf( -3.14 );
// returns NaN
```

</section>

<!-- /.usage -->

<section class="examples">

## Examples

<!-- eslint no-undef: "error" -->

```javascript
var linspace = require( '@stdlib/array-base-linspace' );
var asindf = require( '@stdlib/math-base-special-asindf' );

var x = linspace( -1.0, 1.0, 100 );

var i;
for ( i = 0; i < x.length; i++ ) {
    console.log( asindf( x[ i ] ) );
}
```

</section>

<!-- /.examples -->

<!-- C interface documentation. -->

* * *

<section class="c">

## C APIs

<!-- Section to include introductory text. Make sure to keep an empty line after the intro `section` element and another before the `/section` close. -->

<section class="intro">

</section>

<!-- /.intro -->

<!-- C usage documentation. -->

<section class="usage">

### Usage

```c
#include "stdlib/math/base/special/asindf.h"
```

#### stdlib_base_asindf( x )

Computes the [arcsine][arcsine] (in degrees) of a single-precision floating-point number.

```c
float out = stdlib_base_asindf( 0.0f );
// returns 0.0f

out = stdlib_base_asindf( 0.5f );
// returns ~30.0f
```

The function accepts the following arguments:

-   **x**: `[in] float` input value.

```c
float stdlib_base_asindf( const float x );
```

</section>

<!-- /.usage -->

<!-- C API usage notes. Make sure to keep an empty line after the `section` element and another before the `/section` close. -->

<section class="notes">

</section>

<!-- /.notes -->

<!-- C API usage examples. -->

<section class="examples">

### Examples

```c
#include "stdlib/math/base/special/asindf.h"
#include <stdio.h>

int main( void ) {
    const float x[] = { 1.0f, 0.45f, -0.89f, 0.33f, -0.78f, -0.22f, 0.66f, 0.11f, -0.55f, 0.0f };
    
    float v;
    int i;
    for ( i = 0; i < 10; i++ ) {
        v = stdlib_base_asindf( x[ i ] );
        printf( "asind(%f) = %f\n", x[ i ], v );
    }
}
```

</section>

<!-- /.examples -->

</section>

<!-- /.c -->

<!-- Section for related `stdlib` packages. Do not manually edit this section, as it is automatically populated. -->

<section class="related">

</section>

<!-- /.related -->

<!-- Section for all links. Make sure to keep an empty line after the `section` element and another before the `/section` close. -->


<section class="main-repo" >

* * *

## Notice

This package is part of [stdlib][stdlib], a standard library for JavaScript and Node.js, with an emphasis on numerical and scientific computing. The library provides a collection of robust, high performance libraries for mathematics, statistics, streams, utilities, and more.

For more information on the project, filing bug reports and feature requests, and guidance on how to develop [stdlib][stdlib], see the main project [repository][stdlib].

#### Community

[![Chat][chat-image]][chat-url]

---

## License

See [LICENSE][stdlib-license].


## Copyright

Copyright &copy; 2016-2024. The Stdlib [Authors][stdlib-authors].

</section>

<!-- /.stdlib -->

<!-- Section for all links. Make sure to keep an empty line after the `section` element and another before the `/section` close. -->

<section class="links">

[npm-image]: http://img.shields.io/npm/v/@stdlib/math-base-special-asindf.svg
[npm-url]: https://npmjs.org/package/@stdlib/math-base-special-asindf

[test-image]: https://github.com/stdlib-js/math-base-special-asindf/actions/workflows/test.yml/badge.svg?branch=v0.1.1
[test-url]: https://github.com/stdlib-js/math-base-special-asindf/actions/workflows/test.yml?query=branch:v0.1.1

[coverage-image]: https://img.shields.io/codecov/c/github/stdlib-js/math-base-special-asindf/main.svg
[coverage-url]: https://codecov.io/github/stdlib-js/math-base-special-asindf?branch=main

<!--

[dependencies-image]: https://img.shields.io/david/stdlib-js/math-base-special-asindf.svg
[dependencies-url]: https://david-dm.org/stdlib-js/math-base-special-asindf/main

-->

[chat-image]: https://img.shields.io/gitter/room/stdlib-js/stdlib.svg
[chat-url]: https://app.gitter.im/#/room/#stdlib-js_stdlib:gitter.im

[stdlib]: https://github.com/stdlib-js/stdlib

[stdlib-authors]: https://github.com/stdlib-js/stdlib/graphs/contributors

[umd]: https://github.com/umdjs/umd
[es-module]: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Modules

[deno-url]: https://github.com/stdlib-js/math-base-special-asindf/tree/deno
[deno-readme]: https://github.com/stdlib-js/math-base-special-asindf/blob/deno/README.md
[umd-url]: https://github.com/stdlib-js/math-base-special-asindf/tree/umd
[umd-readme]: https://github.com/stdlib-js/math-base-special-asindf/blob/umd/README.md
[esm-url]: https://github.com/stdlib-js/math-base-special-asindf/tree/esm
[esm-readme]: https://github.com/stdlib-js/math-base-special-asindf/blob/esm/README.md
[branches-url]: https://github.com/stdlib-js/math-base-special-asindf/blob/main/branches.md

[stdlib-license]: https://raw.githubusercontent.com/stdlib-js/math-base-special-asindf/main/LICENSE

[arcsine]: https://en.wikipedia.org/wiki/Inverse_trigonometric_functions

<!-- <related-links> -->

<!-- </related-links> -->

</section>

<!-- /.links -->
