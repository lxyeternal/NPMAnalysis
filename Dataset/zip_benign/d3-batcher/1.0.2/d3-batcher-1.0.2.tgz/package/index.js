var compact = require('lodash.compact');

function Batcher(createOpts) {
  var specsByIdByTag = {};

  function addSpecs(specs) {
    compact(specs).forEach(addSpec);
  }

  function addSpec(spec) {
    if (!spec.tag) {
      throw new TypeError('Tag in spec is missing.');
    }
    if (!spec.id) {
      throw new TypeError('Id in spec is missing.');
    }

    var specsById = specsByIdByTag[spec.tag];
    if (!specsById) {
      specsById = {};
      specsByIdByTag[spec.tag] = specsById;
    }
    specsById[spec.id] = spec;
  }

  function getBatches() {
    var batches = {};

    for (var tag in specsByIdByTag) {
      var specsById = specsByIdByTag[tag];
      var specsForTag = [];
      if (specsById) {
        for (var id in specsById) {
          specsForTag.push(specsById[id]);
        }
      }
      batches[tag] = specsForTag;
    }
    return batches;
  }

  function clear() {
    specsByIdByTag = {};
  }

  return {
    addSpecs: addSpecs,
    getBatches: getBatches,
    clear: clear
  };
}

module.exports = Batcher;
