import { EmitterSubscription } from 'react-native';
import type { AVAudioSessionCategory, AVAudioSessionMode, EmitterSubscriptionNoop, RingMuteSwitchEventCallback, RingerEventCallback, RingerModeType, setCheckIntervalType, VolumeManagerSetVolumeConfig, VolumeResult } from './types';
/**
 * Returns the current ringer mode. Android only.
 * @returns {Promise<RingerModeType | undefined>} - The current ringer mode or undefined if not Android.
 */
export declare function getRingerMode(): Promise<RingerModeType | undefined>;
/**
 * Sets the current device's ringer mode. Android only.
 * @param {RingerModeType} mode - The ringer mode to set
 * @returns {Promise<RingerModeType | undefined>} - The new ringer mode or undefined if not Android.
 */
export declare function setRingerMode(mode: RingerModeType): Promise<RingerModeType | undefined>;
/**
 * iOS only. Enables or disables the audio session. When enabled, the session's category is set to ambient, allowing the audio from this session to mix with other audio currently playing on the device.
 * @param {boolean} [enabled=true] - Whether to enable or disable the audio session.
 * @param {boolean} [async=true] - Whether to perform the operation asynchronously. When set to true, this function will not block the UI thread.
 * @returns {Promise<void>} - Resolves when the operation has finished. If an error occurs, it will be rejected with an instance of Error.
 */
export declare function enable(enabled?: boolean, async?: boolean): Promise<void>;
/**
 * iOS only. Activates or deactivates the audio session. Does not change the audio session's category. When the session is deactivated, other audio sessions that had been interrupted by this one are reactivated and notified.
 * @param {boolean} [value=true] - Whether to activate or deactivate the audio session.
 * @param {boolean} [async=true] - Whether to perform the operation asynchronously. When set to true, this function will not block the JavaScript thread.
 * @returns {Promise<void>} - Resolves when the operation has finished. If an error occurs, it will be rejected with an instance of Error. On Android, this function returns undefined.
 */
export declare function setActive(value?: boolean, async?: boolean): Promise<void>;
/**
 * Sets the audio session category. iOS only.
 * @param {AVAudioSessionCategory} value - The category to set
 * @param {boolean} [mixWithOthers=false] - Allow audio to mix with others
 * @returns {Promise<void>} - Resolves when the operation has finished
 */
export declare function setCategory(value: AVAudioSessionCategory, mixWithOthers?: boolean): Promise<void>;
/**
 * Sets the audio session mode. iOS only.
 * @param {AVAudioSessionMode} value - The mode to set
 * @returns {Promise<void>} - Resolves when the operation has finished
 */
export declare function setMode(value: AVAudioSessionMode): Promise<void>;
/**
 * Enables or disables the VolumeManager in silent mode. iOS only.
 * @param {boolean} [enabled=true] - Enable or disable the VolumeManager in silent mode
 * @returns {Promise<void>} - Resolves when the operation has finished
 */
export declare function enableInSilenceMode(enabled?: boolean): Promise<void>;
/**
 * Checks if Do Not Disturb access is granted. Android only.
 * @returns {Promise<boolean | undefined>} - Do Not Disturb access status or undefined if not Android.
 */
export declare function checkDndAccess(): Promise<boolean | undefined>;
/**
 * Requests Do Not Disturb access. Android only.
 * @returns {Promise<boolean | undefined>} - Do Not Disturb access request result or undefined if not Android.
 */
export declare function requestDndAccess(): Promise<boolean | undefined>;
/**
 * Get the current device volume.
 * @returns {Promise<VolumeResult>} - Returns a promise that resolves to an object with the volume value.
 */
export declare function getVolume(): Promise<VolumeResult>;
/**
 * Set the current device volume.
 * @param {number} value - The volume value to set. Must be between 0 and 1.
 * @param {VolumeManagerSetVolumeConfig} [config={}] - Additional configuration for setting the volume.
 * @returns {Promise<void>} - Resolves when the operation has finished
 */
export declare function setVolume(value: number, config?: VolumeManagerSetVolumeConfig): Promise<void>;
/**
 * Shows or hides the native volume UI.
 * @param {object} config - An object with a boolean property 'enabled' to show or hide the native volume UI
 * @returns {Promise<void>} - Resolves when the operation has

 finished
 */
export declare function showNativeVolumeUI(config: {
    enabled: boolean;
}): Promise<void>;
/**
 * Adds a listener for volume changes.
 * @param {(result: VolumeResult) => void} callback - Function to be called when volume changes
 * @returns {EmitterSubscription} - The subscription to the volume change event
 */
export declare function addVolumeListener(callback: (result: VolumeResult) => void): EmitterSubscription;
/**
 * Adds a silent mode listener. iOS only.
 * @param {RingMuteSwitchEventCallback} callback - Function to be called when silent mode changes
 * @returns {EmitterSubscription | EmitterSubscriptionNoop} - The subscription to the silent mode change event
 */
export declare const addSilentListener: (callback: RingMuteSwitchEventCallback) => EmitterSubscription | EmitterSubscriptionNoop;
/**
 * Sets the interval for the native silence check. iOS only.
 * @param {number} value - The interval in milliseconds
 */
export declare const setNativeSilenceCheckInterval: setCheckIntervalType;
/**
 * Checks if ringer listener is enabled. Android only.
 * @returns {Promise<boolean>} - The ringer listener status
 */
export declare const isRingerListenerEnabled: () => Promise<boolean>;
/**
 * Adds a ringer mode listener. Android only.
 * @param {RingerEventCallback} callback - Function to be called when ringer mode changes
 * @returns {EmitterSubscription | EmitterSubscriptionNoop} - The subscription to the ringer mode change event
 */
export declare const addRingerListener: (callback: RingerEventCallback) => EmitterSubscription | EmitterSubscriptionNoop;
/**
 * Removes a ringer mode listener. Android only.
 * @param {EmitterSubscription | EmitterSubscriptionNoop} listener - The ringer mode listener to remove
 */
export declare const removeRingerListener: (listener: EmitterSubscription | EmitterSubscriptionNoop) => void;
/**
 * Exported object that includes all functions
 */
export declare const VolumeManager: {
    addVolumeListener: typeof addVolumeListener;
    getVolume: typeof getVolume;
    setVolume: typeof setVolume;
    showNativeVolumeUI: typeof showNativeVolumeUI;
    isRingerListenerEnabled: () => Promise<boolean>;
    addSilentListener: (callback: RingMuteSwitchEventCallback) => EmitterSubscription | EmitterSubscriptionNoop;
    addRingerListener: (callback: RingerEventCallback) => EmitterSubscription | EmitterSubscriptionNoop;
    removeRingerListener: (listener: EmitterSubscription | EmitterSubscriptionNoop) => void;
    setNativeSilenceCheckInterval: setCheckIntervalType;
    getRingerMode: typeof getRingerMode;
    setRingerMode: typeof setRingerMode;
    checkDndAccess: typeof checkDndAccess;
    requestDndAccess: typeof requestDndAccess;
    enable: typeof enable;
    setActive: typeof setActive;
    setCategory: typeof setCategory;
    setMode: typeof setMode;
    enableInSilenceMode: typeof enableInSilenceMode;
};
export default VolumeManager;
//# sourceMappingURL=native.d.ts.map