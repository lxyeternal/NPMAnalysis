import type { BaseElement } from "./BaseElement";
import { LayoutConstructor, LayoutFactory } from "@md5crypt/layout";
import { ElementTypes } from "./ElementTypes";
import { Texture } from "@pixi/core";
export type PixiElementConfig = ElementTypes[keyof ElementTypes];
export declare class PixiLayoutFactory extends LayoutFactory<BaseElement, PixiElementConfig> {
    onResolveAsset?: (key: string) => Texture;
    resolveAsset(asset: string | Texture | undefined | null): Texture<import("@pixi/core").Resource>;
    register<T extends keyof ElementTypes>(type: T, constructor: LayoutConstructor<BaseElement, ElementTypes[T]>): void;
}
