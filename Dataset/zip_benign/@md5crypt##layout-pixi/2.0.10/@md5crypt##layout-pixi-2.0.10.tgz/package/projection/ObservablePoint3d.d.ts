import { ObservablePoint } from "@pixi/math";
import { IPointData3d } from "./IPointData3d";
export declare class ObservablePoint3d<T = any> extends ObservablePoint<T> {
    constructor(callback: (this: T) => void, scope: T, x?: number, y?: number, z?: number);
    clone(cb?: (this: T) => any, scope?: any): ObservablePoint3d<T>;
    set(x?: number, y?: number, z?: number): this;
    copyFrom(p: IPointData3d): this;
    equals(p: IPointData3d): boolean;
    get z(): number;
    set z(value: number);
}
