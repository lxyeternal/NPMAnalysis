import { BatchRenderer, Renderer, ViewableBuffer, ExtensionMetadata, IBatchableElement } from "@pixi/core";
export declare class ProjectionRenderer extends BatchRenderer {
    static readonly extension: ExtensionMetadata;
    constructor(renderer: Renderer);
    packInterleavedGeometry(element: IBatchableElement, attributeBuffer: ViewableBuffer, indexBuffer: Uint16Array, aIndex: number, iIndex: number): void;
}
