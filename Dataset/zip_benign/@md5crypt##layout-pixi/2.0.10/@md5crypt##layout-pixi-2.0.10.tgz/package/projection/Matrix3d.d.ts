import { Matrix } from "@pixi/math";
export declare class Matrix3d {
    readonly mat4: Float64Array;
    constructor();
    setToTranslation(tx: number, ty: number, tz: number): void;
    setToRotationTranslationScale(quat: Float64Array, tx: number, ty: number, tz: number, sx: number, sy: number, sz: number): void;
    translate(tx: number, ty: number, tz: number): void;
    scale(x: number, y: number, z?: number): void;
    scaleAndTranslate(scaleX: number, scaleY: number, scaleZ: number, tx: number, ty: number, tz: number): void;
    identity(): void;
    set(matrix: Matrix3d): void;
    setToMultLegacy(pt: Matrix, lt: Matrix3d): void;
    setToMult(pt: Matrix3d, lt: Matrix3d): void;
    copyTo(matrix: Matrix): Matrix;
    isFrontFace(): boolean;
    getDepth(): number;
    static glMatrixMat4Multiply(out: Float64Array, a: Float64Array, b: Float64Array): Float64Array;
}
