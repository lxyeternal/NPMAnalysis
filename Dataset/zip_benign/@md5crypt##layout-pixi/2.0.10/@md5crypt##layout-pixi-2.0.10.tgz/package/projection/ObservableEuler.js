export class ObservableEuler {
    constructor(callback, scope, x = 0, y = 0, z = 0) {
        this._quatUpdateId = -1;
        this._quatDirtyId = 0;
        this._x = x;
        this._y = y;
        this._z = z;
        this._sign = 1;
        this._callback = callback;
        this._scope = scope;
        this.quaternion = new Float64Array(4);
        this.quaternion[3] = 1;
        this._quatUpdateId = -1;
        this._quatDirtyId = 0;
        this.update();
    }
    get sign() {
        return this._sign;
    }
    set sign(value) {
        if (this._sign !== value) {
            this._sign = value;
            this._quatDirtyId += 1;
            this._callback.call(this._scope);
        }
    }
    get x() {
        return this._x;
    }
    set x(value) {
        if (this._x !== value) {
            this._x = value;
            this._quatDirtyId += 1;
            this._callback.call(this._scope);
        }
    }
    get y() {
        return this._y;
    }
    set y(value) {
        if (this._y !== value) {
            this._y = value;
            this._quatDirtyId += 1;
            this._callback.call(this._scope);
        }
    }
    get z() {
        return this._z;
    }
    set z(value) {
        if (this._z !== value) {
            this._z = value;
            this._quatDirtyId += 1;
            this._callback.call(this._scope);
        }
    }
    get pitch() {
        return this._x;
    }
    set pitch(value) {
        if (this._x !== value) {
            this._x = value;
            this._quatDirtyId += 1;
            this._callback.call(this._scope);
        }
    }
    get yaw() {
        return this._y;
    }
    set yaw(value) {
        if (this._y !== value) {
            this._y = value;
            this._quatDirtyId += 1;
            this._callback.call(this._scope);
        }
    }
    get roll() {
        return this._z;
    }
    set roll(value) {
        if (this._z !== value) {
            this._z = value;
            this._quatDirtyId += 1;
            this._callback.call(this._scope);
        }
    }
    set(x, y, z) {
        const _x = x || 0;
        const _y = y || 0;
        const _z = z || 0;
        if (this._x !== _x || this._y !== _y || this._z !== _z) {
            this._x = _x;
            this._y = _y;
            this._z = _z;
            this._quatDirtyId += 1;
            this._callback.call(this._scope);
        }
        return this;
    }
    copyFrom(euler) {
        const _x = euler.x;
        const _y = euler.y;
        const _z = euler.z;
        if (this._x !== _x || this._y !== _y || this._z !== _z) {
            this._x = _x;
            this._y = _y;
            this._z = _z;
            this._quatDirtyId += 1;
            this._callback.call(this._scope);
        }
        return this;
    }
    copyTo(p) {
        p.set(this._x, this._y, this._z);
        return p;
    }
    equals(euler) {
        return this._x === euler.x && this._y === euler.y && this._z === euler.z;
    }
    update() {
        if (this._quatUpdateId === this._quatDirtyId) {
            return false;
        }
        this._quatUpdateId = this._quatDirtyId;
        const c1 = Math.cos(this._x / 2);
        const c2 = Math.cos(this._y / 2);
        const c3 = Math.cos(this._z / 2);
        const s = this._sign;
        const s1 = s * Math.sin(this._x / 2);
        const s2 = s * Math.sin(this._y / 2);
        const s3 = s * Math.sin(this._z / 2);
        const q = this.quaternion;
        q[0] = (s1 * c2 * c3) + (c1 * s2 * s3);
        q[1] = (c1 * s2 * c3) - (s1 * c2 * s3);
        q[2] = (c1 * c2 * s3) + (s1 * s2 * c3);
        q[3] = (c1 * c2 * c3) - (s1 * s2 * s3);
        return true;
    }
}
//# sourceMappingURL=ObservableEuler.js.map