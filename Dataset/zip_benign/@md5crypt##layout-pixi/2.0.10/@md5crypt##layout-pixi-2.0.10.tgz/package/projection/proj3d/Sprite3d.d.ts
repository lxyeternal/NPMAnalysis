import { Sprite } from "@pixi/sprite";
import { Renderer, Texture } from "@pixi/core";
import { Transform3d } from "./Transform3d";
export declare const enum BackTextureTransform {
    NONE = 0,
    MIRROR_VERTICAL = 1,
    MIRROR_HORIZONTAL = 2
}
export declare const enum Sprite3dFaces {
    NONE = 0,
    FRONT = 1,
    BACK = 2,
    BOTH = 3
}
export declare class Sprite3d extends Sprite {
    transform: Transform3d;
    private _culledByFrustrum;
    private _backUvs;
    private _frontUvs;
    private _backTextureID;
    private _frontTexture;
    private _backTexture;
    private _backTextureTransform;
    faces: Sprite3dFaces;
    constructor(texture: Texture);
    isFrontFace(forceUpdate?: boolean): boolean;
    getDepth(forceUpdate?: boolean): number;
    calculateVertices(): void;
    calculateBounds(): void;
    containsPoint(): boolean;
    _render(renderer: Renderer): void;
    get euler(): import("..").ObservableEuler<any>;
    get position(): import("..").ObservablePoint3d<any>;
    get scale(): import("..").ObservablePoint3d<any>;
    get pivot(): import("..").ObservablePoint3d<any>;
    set texture(value: Texture);
    get texture(): Texture;
    set frontTexture(value: Texture);
    get frontTexture(): Texture;
    set backTexture(value: Texture | null);
    get backTexture(): Texture | null;
    set backTextureTransform(value: BackTextureTransform);
    get backTextureTransform(): BackTextureTransform;
}
