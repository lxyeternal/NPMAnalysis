import { Container } from "@pixi/display";
import { CameraTransform3d } from "./CameraTransform3d";
export class Camera3d extends Container {
    constructor() {
        super();
        this._far = 0;
        this._near = 0;
        this._focus = 0;
        this._orthographic = false;
        this.transform = new CameraTransform3d();
        this.setPlanes(400, 10, 10000, false);
    }
    get far() {
        return this._far;
    }
    set far(value) {
        if (this._far != value) {
            this._far = value;
        }
        this.updatePlanes();
    }
    get near() {
        return this._near;
    }
    set near(value) {
        if (this._near != value) {
            this._near = value;
        }
        this.updatePlanes();
    }
    get focus() {
        return this._focus;
    }
    set focus(value) {
        if (this._focus != value) {
            this._focus = value;
        }
        this.updatePlanes();
    }
    get orthographic() {
        return this._orthographic;
    }
    set orthographic(value) {
        if (this.orthographic != value) {
            this.orthographic = value;
        }
        this.updatePlanes();
    }
    get position3d() {
        return this.transform.position3d;
    }
    get pivot3d() {
        return this.transform.pivot3d;
    }
    get scale3d() {
        return this.transform.scale3d;
    }
    setPlanes(focus, near = 10, far = 10000, orthographic = false) {
        this._focus = focus;
        this._near = near;
        this._far = far;
        this._orthographic = orthographic;
        this.updatePlanes();
    }
    updatePlanes() {
        this.transform.setPlanes(this._focus, this._near, this._far, this._orthographic);
    }
}
//# sourceMappingURL=Camera3d.js.map