import { Container } from "@pixi/display";
import { CameraTransform3d } from "./CameraTransform3d";
export declare class Camera3d extends Container {
    transform: CameraTransform3d;
    private _far;
    private _near;
    private _focus;
    private _orthographic;
    constructor();
    get far(): number;
    set far(value: number);
    get near(): number;
    set near(value: number);
    get focus(): number;
    set focus(value: number);
    get orthographic(): boolean;
    set orthographic(value: boolean);
    get position3d(): import("..").ObservablePoint3d<any>;
    get pivot3d(): import("..").ObservablePoint3d<any>;
    get scale3d(): import("..").ObservablePoint3d<any>;
    setPlanes(focus: number, near?: number, far?: number, orthographic?: boolean): void;
    private updatePlanes;
}
