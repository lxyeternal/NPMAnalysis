import { Container } from "@pixi/display";
import { Transform3d } from "./Transform3d";
export declare class Container3d extends Container {
    transform: Transform3d;
    constructor();
    isFrontFace(forceUpdate?: boolean): boolean;
    getDepth(forceUpdate?: boolean): number;
    get euler(): import("..").ObservableEuler<any>;
    get position(): import("..").ObservablePoint3d<any>;
    get scale(): import("..").ObservablePoint3d<any>;
    get pivot(): import("..").ObservablePoint3d<any>;
}
