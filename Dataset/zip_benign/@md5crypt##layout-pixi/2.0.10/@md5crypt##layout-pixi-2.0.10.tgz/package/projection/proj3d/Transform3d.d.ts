import { Transform } from "@pixi/math";
import { Matrix3d } from "../Matrix3d";
import { ObservableEuler } from "../ObservableEuler";
import { ObservablePoint3d } from "../ObservablePoint3d";
import { CameraTransform3d } from "./CameraTransform3d";
export declare class Transform3d extends Transform {
    readonly localTransform3d: Matrix3d;
    readonly worldTransform3d: Matrix3d;
    readonly position: ObservablePoint3d;
    readonly scale: ObservablePoint3d;
    readonly euler: ObservableEuler;
    readonly pivot: ObservablePoint3d;
    onUpdate?: () => void;
    constructor();
    updateLocalTransform(): void;
    updateTransform(parentTransform: Transform3d | CameraTransform3d): void;
    set rotation(value: number);
    get rotation(): number;
}
