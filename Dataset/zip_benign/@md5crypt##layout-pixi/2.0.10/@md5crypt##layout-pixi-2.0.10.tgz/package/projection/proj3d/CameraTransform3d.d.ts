import { Transform } from "@pixi/math";
import { Matrix3d } from "../Matrix3d";
import { ObservablePoint3d } from "../ObservablePoint3d";
export declare class CameraTransform3d extends Transform {
    readonly position3d: ObservablePoint3d;
    readonly scale3d: ObservablePoint3d;
    readonly pivot3d: ObservablePoint3d;
    private _cameraMatrix;
    readonly localTransform3d: Matrix3d;
    readonly worldTransform3d: Matrix3d;
    constructor();
    updateLocalTransform(): void;
    updateTransform(parentTransform: Transform): void;
    setPlanes(focus: number, near: number, far: number, orthographic: boolean): void;
}
