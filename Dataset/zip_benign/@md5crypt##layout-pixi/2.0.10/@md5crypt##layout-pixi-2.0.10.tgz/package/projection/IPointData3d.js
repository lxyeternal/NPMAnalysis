export {};
//# sourceMappingURL=IPointData3d.js.map