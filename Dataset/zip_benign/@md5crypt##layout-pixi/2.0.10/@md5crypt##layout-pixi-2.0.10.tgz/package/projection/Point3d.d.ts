import { IPointData3d } from "./IPointData3d";
export declare class Point3d implements IPointData3d {
    x: number;
    y: number;
    z: number;
    constructor(x?: number, y?: number, z?: number);
    clone(): Point3d;
    copyFrom(p: IPointData3d): this;
    copyTo(p: Point3d): Point3d;
    equals(p: IPointData3d): boolean;
    set(x?: number, y?: number, z?: number): this;
}
