export class Point3d {
    constructor(x = 0, y = 0, z = 0) {
        this.x = 0;
        this.y = 0;
        this.z = 0;
        this.x = x;
        this.y = y;
        this.z = z;
    }
    clone() {
        return new Point3d(this.x, this.y, this.z);
    }
    copyFrom(p) {
        return this.set(p.x, p.y, p.z);
    }
    copyTo(p) {
        p.set(this.x, this.y, this.z);
        return p;
    }
    equals(p) {
        return (p.x === this.x) && (p.y === this.y) && (p.z == this.z);
    }
    set(x = 0, y = x, z = 0) {
        this.x = x;
        this.y = y;
        this.z = z;
        return this;
    }
}
//# sourceMappingURL=Point3d.js.map