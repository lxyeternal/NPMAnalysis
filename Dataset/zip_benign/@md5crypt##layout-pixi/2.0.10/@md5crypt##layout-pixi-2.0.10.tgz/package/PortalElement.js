import { BaseElement } from "./BaseElement";
import { DisplayObject } from "@pixi/display";
class PortalContainer extends DisplayObject {
    constructor() {
        super();
        this.sortDirty = false;
        this.alphaControl = false;
        this.children = [];
    }
    calculateBounds() {
    }
    updateTransform() {
        this.worldAlpha = this.alpha * this.parent.worldAlpha;
    }
    render(renderer) {
        if (this.visible) {
            const children = this.children;
            for (let i = 0; i < children.length; i += 1) {
                const child = children[i];
                if (child.visible && !child.renderable) {
                    const originalAlpha = child.alpha;
                    if (this.alphaControl && child.worldAlpha > 0) {
                        child.alpha = this.worldAlpha / child.parent.worldAlpha;
                        child.updateTransform();
                    }
                    child.renderable = true;
                    child.render(renderer);
                    child.renderable = false;
                    child.alpha = originalAlpha;
                }
            }
        }
    }
    addChild(child) {
        this.children.push(child);
    }
    addChildAt(child, index) {
        this.children.splice(index, 0, child);
    }
    getChildIndex(child) {
        return this.children.indexOf(child);
    }
    removeChild(child) {
        const index = this.children.indexOf(child);
        if (index >= 0) {
            this.children.splice(index, 1);
        }
    }
    removeChildAt(index) {
        this.children.splice(index, 1);
    }
}
export class PortalElement extends BaseElement {
    static register(factory) {
        factory.register("portal", config => new this(factory, config));
    }
    constructor(factory, config) {
        super(factory, config, new PortalContainer());
        this.handle.alphaControl = config.alphaControl || false;
    }
    add(element) {
        this.handle.addChild(element instanceof BaseElement ? element.handle : element);
    }
    remove(element) {
        this.handle.removeChild(element instanceof BaseElement ? element.handle : element);
    }
    get alphaControl() {
        return this.handle.alphaControl;
    }
    set alphaControl(value) {
        this.handle.alphaControl = value;
    }
}
//# sourceMappingURL=PortalElement.js.map