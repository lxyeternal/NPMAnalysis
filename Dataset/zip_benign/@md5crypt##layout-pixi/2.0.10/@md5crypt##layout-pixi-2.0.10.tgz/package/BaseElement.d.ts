import { LayoutElement, LayoutElementConfig } from "@md5crypt/layout";
import { DisplayObject } from "@pixi/display";
import type { PixiEvent, PixiEventMapping, PixiEventType } from "./events";
import { PixiLayoutFactory, PixiElementConfig } from "./PixiLayoutFactory";
import { Matrix } from "@pixi/math";
export declare const enum BlendMode {
    NORMAL = 0,
    ADD = 1,
    MULTIPLY = 2,
    SCREEN = 3
}
export interface BaseElementConfig<TYPE extends string = string, SELF extends BaseElement = any> extends LayoutElementConfig<PixiElementConfig, SELF> {
    type: TYPE;
    /**
     * z index works only for controlling render order inside direct parent
     *
     * utilizes the PIXI sorted flag on container
     * @defaultValue 0
     */
    zIndex?: number;
    /**
     * 0 being transparent and 1 fully opaque
     * @defaultValue 1
     */
    alpha?: number;
    /**
     * in degrees, rotates around the {@link pivot} point
     * @defaultValue 0
     */
    rotation?: number;
    /**
     * mirrors object by internally setting negative scale
     * @defaultValue false
     */
    flipped?: false | "vertical" | "horizontal";
    /**
     * when set object becomes an interaction target and will receive interaction events
     * @defaultValue false
     */
    interactive?: boolean;
    /**
     * when set disables interaction event interaction processing for the entire subtree. The element itself
     * can still be interactive.
     * @defaultValue false
     */
    noPropagation?: boolean;
    /**
     * element pivot point (center point for this element's rotation) with values relative to the elements's size
     * * array with [x, y] values or single number that get expanded to [x, x]
     * * [0, 0] is top left corner
     * * [0.5, 0.5] is center
     * * [1, 1] is bottom right
     * * any other values are also valid
     * @defaultValue [0, 0]
     */
    pivot?: [number, number] | number;
    /**
     * elements with button mode set will affect mouse cursor when hovered
     */
    buttonMode?: boolean;
}
export declare abstract class BaseElement<HANDLE extends DisplayObject = DisplayObject> extends LayoutElement<PixiElementConfig, BaseElement> {
    readonly config: Readonly<BaseElementConfig>;
    readonly factory: PixiLayoutFactory;
    /** the underlying PIXI object */
    readonly handle: HANDLE;
    protected _xPivot: number;
    protected _yPivot: number;
    protected _flipped: "vertical" | "horizontal" | false;
    protected constructor(factory: PixiLayoutFactory, config: Readonly<BaseElementConfig>, handle: HANDLE);
    /** apply the flip value by setting scale sign */
    protected applyFlip(): void;
    /**
     * register an event handler on a element in this element tree
     * @param event - event name
     * @param element - the element path on which the event should be registered on
     * @param callback - the event handler
     *
     * @returns callback as passed to function
     */
    on<T extends PixiEventType>(event: T, element: string, callback: (event: PixiEvent<PixiEventMapping[T]>) => void): (event: PixiEvent) => void;
    /**
     * register an event handler on multiple element in this element tree
     * @param event - event name
     * @param elements - array of element paths on which the event should be registered on
     * @param callback - the event handler
     *
     * @returns callback as passed to function
     */
    on<T extends PixiEventType>(event: T, element: string[], callback: (event: PixiEvent<PixiEventMapping[T]>) => void): (event: PixiEvent) => void;
    /**
     * register an event handler on this element
     * @param event - event name
     * @param callback - the event handler
     *
     * @returns callback as passed to function
     */
    on<T extends PixiEventType>(event: T, callback: (event: PixiEvent<PixiEventMapping[T]>) => void): (event: PixiEvent) => void;
    /**
     * calculate the transform matrix for this element
     *
     * it will not necessary be the same as the underlying PIXI's objects localTransform
     *
     * the matrix is not cached and created on demand
     *
     * @param matrix - by default a new matrix is created each call, if an matrix is passed it will be used instead
     * of creating a new object
     *
     * @returns the resulting matrix
     */
    getLocalMatrix(matrix?: Matrix): Matrix;
    /**
     * get scale as set on pixi world transform
     * note that this value updates only when world transform updates so before render
     *
     * @returns element global scale
     */
    get globalScale(): number;
    /** final left value that should be used by display objects */
    protected get pivotedLeft(): number;
    /** final top value that should be used by display objects */
    protected get pivotedTop(): number;
    get enabled(): boolean;
    set enabled(value: boolean);
    /** {@inheritDoc BaseElementConfig.zIndex} */
    get zIndex(): number;
    set zIndex(value: number);
    /** {@inheritDoc BaseElementConfig.alpha} */
    get alpha(): number;
    set alpha(value: number);
    /** {@inheritDoc BaseElementConfig.rotation} */
    get rotation(): number;
    set rotation(value: number);
    /** {@inheritDoc BaseElementConfig.flipped} */
    get flipped(): false | "vertical" | "horizontal";
    set flipped(value: false | "vertical" | "horizontal");
    /** {@inheritDoc BaseElementConfig.interactive} */
    get interactive(): boolean;
    set interactive(value: boolean);
    /** {@inheritDoc BaseElementConfig.noPropagation} */
    get noPropagation(): boolean;
    set noPropagation(value: boolean);
    /** x component of rotation pivot point */
    get xPivot(): number;
    set xPivot(value: number);
    /** y component of rotation pivot point */
    get yPivot(): number;
    set yPivot(value: number);
    /** {@inheritDoc BaseElementConfig.buttonMode} */
    get buttonMode(): boolean;
    set buttonMode(value: boolean);
}
