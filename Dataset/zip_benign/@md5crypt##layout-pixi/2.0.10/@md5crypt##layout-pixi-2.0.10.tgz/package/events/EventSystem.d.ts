import { DisplayObject } from "@pixi/display";
import type { ExtensionMetadata, Renderer } from "@pixi/core";
import { EventEmitter } from "@pixi/utils";
import { PixiEvent } from "./PixiEvent";
declare global {
    namespace GlobalMixins {
        interface DisplayObject {
            interactive: boolean;
            interactiveChildren: boolean;
            hitArea?: {
                contains(x: number, y: number): boolean;
            };
            cursor?: string;
            get buttonMode(): boolean;
            set buttonMode(value: boolean);
        }
    }
}
export declare class EventSystem extends EventEmitter {
    static extension: ExtensionMetadata;
    private static _point;
    private static treeWalk;
    readonly renderer: Renderer;
    readonly handleEvent: (e: MouseEvent) => any;
    autoPreventDefault: boolean;
    queueEvents: boolean;
    private _lastCursor;
    private _cursor;
    private _cursorControl;
    private _capturedEvents;
    private _pointerMoved;
    private _lastMoveEvent;
    private _lastEvent;
    private _trackingData;
    private _captureTouchEvents;
    constructor(renderer: Renderer);
    private getTrackingData;
    update(): void;
    cancelEvent(event: PixiEvent): void;
    processEvent(event: PixiEvent, root: DisplayObject): void;
    destroy(): void;
    private setCursorMode;
    get lastMoveEvent(): PixiEvent<MouseEvent> | null;
    get lastEvent(): PixiEvent<MouseEvent> | null;
    get cursor(): string;
    set cursor(value: string);
    get cursorControl(): "auto" | "forced" | "disabled";
    set cursorControl(value: "auto" | "forced" | "disabled");
    get cursorCurrent(): string;
    get captureTouchEvents(): boolean;
    set captureTouchEvents(value: boolean);
}
