import { Point } from "@pixi/math";
import { DisplayObject } from "@pixi/display";
export interface PixiEventMapping {
    "pointerdown": PointerEvent;
    "pointermove": PointerEvent;
    "pointerout": PointerEvent;
    "pointerover": PointerEvent;
    "pointertap": PointerEvent;
    "pointerup": PointerEvent;
    "pointerupoutside": PointerEvent;
    "wheel": WheelEvent;
}
export type PixiEventType = keyof PixiEventMapping;
export declare class PixiEvent<T extends MouseEvent = MouseEvent> {
    readonly global: Point;
    readonly originalEvent: T;
    readonly pointerId: number;
    readonly isPrimary: boolean;
    readonly button: number;
    readonly buttons: number;
    readonly pointerType: "mouse" | "touch";
    private _target;
    getLocalPosition(displayObject: DisplayObject, point?: Point): Point;
    get target(): DisplayObject | null;
    /** @deprecated comparability level with old interaction api */
    get data(): this;
}
