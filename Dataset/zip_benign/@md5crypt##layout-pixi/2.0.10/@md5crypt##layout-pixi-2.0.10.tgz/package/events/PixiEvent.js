import { Point } from "@pixi/math";
export class PixiEvent {
    // @internal
    constructor(event, renderer) {
        this.__type = event.type;
        this.originalEvent = event;
        if (event instanceof PointerEvent) {
            this.pointerId = event.pointerId;
            this.isPrimary = event.isPrimary;
            this.pointerType = event.pointerType == "mouse" ? "mouse" : "touch";
        }
        else {
            this.pointerId = -1;
            this.pointerType = "mouse";
            this.isPrimary = false;
        }
        this.button = event.button;
        this.buttons = event.buttons;
        this._target = null;
        const view = renderer.view;
        const rect = view.getBoundingClientRect();
        this.global = new Point(((event.clientX - rect.left) * (view.width / rect.width)) / renderer.resolution, ((event.clientY - rect.top) * (view.height / rect.height)) / renderer.resolution);
    }
    getLocalPosition(displayObject, point) {
        return displayObject.worldTransform.applyInverse(this.global, point);
    }
    get target() {
        return this._target;
    }
    /* @internal */
    set target(value) {
        this._target = value;
    }
    /** @deprecated comparability level with old interaction api */
    get data() {
        return this;
    }
}
//# sourceMappingURL=PixiEvent.js.map