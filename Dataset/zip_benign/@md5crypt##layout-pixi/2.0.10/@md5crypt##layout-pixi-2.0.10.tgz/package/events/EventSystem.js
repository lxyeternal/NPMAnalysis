import { Container, DisplayObject } from "@pixi/display";
import { ExtensionType } from "@pixi/core";
import { Point } from "@pixi/math";
import { EventEmitter } from "@pixi/utils";
import { PixiEvent } from "./PixiEvent";
DisplayObject.mixin({
    interactive: false,
    interactiveChildren: true,
    get buttonMode() {
        return this.cursor ? true : false;
    },
    set buttonMode(value) {
        if (value) {
            if (!this.cursor) {
                this.cursor = "pointer";
            }
        }
        else {
            this.cursor = undefined;
        }
    }
});
export class EventSystem extends EventEmitter {
    static treeWalk(displayObject, point, callback) {
        let hit = false;
        if (displayObject.interactive) {
            if (displayObject.hitArea) {
                const tempPoint = this._point;
                displayObject.worldTransform.applyInverse(point, tempPoint);
                hit = displayObject.hitArea.contains(tempPoint.x, tempPoint.y);
            }
            else if (displayObject.containsPoint) {
                hit = displayObject.containsPoint(point);
            }
            if (!hit) {
                return false;
            }
        }
        if (displayObject instanceof Container && displayObject.interactiveChildren) {
            const children = displayObject.children;
            for (let i = children.length - 1; i >= 0; i -= 1) {
                if (children[i].visible && this.treeWalk(children[i], point, callback)) {
                    if (hit) {
                        callback(displayObject);
                    }
                    return true;
                }
            }
        }
        if (hit) {
            callback(displayObject);
        }
        return hit;
    }
    constructor(renderer) {
        super();
        this.renderer = renderer;
        this.autoPreventDefault = false;
        this.queueEvents = true;
        this._captureTouchEvents = true;
        this._pointerMoved = false;
        this._lastMoveEvent = null;
        this._lastEvent = null;
        this._capturedEvents = [];
        this._trackingData = new Map();
        this._cursorControl = "auto";
        this._lastCursor = "";
        this._cursor = "";
        this.handleEvent = (event) => {
            if (this.autoPreventDefault) {
                event.preventDefault();
            }
            const pixiEvent = new PixiEvent(event, this.renderer);
            if (this.queueEvents) {
                this._capturedEvents.push(pixiEvent);
            }
            else {
                const lastObjectRendered = this.renderer._lastObjectRendered;
                if (!lastObjectRendered) {
                    this._capturedEvents.push(pixiEvent);
                }
                else {
                    this._lastEvent = pixiEvent;
                    this.processEvent(pixiEvent, lastObjectRendered);
                    if (pixiEvent.__type == "pointermove") {
                        this._pointerMoved = true;
                        this._lastMoveEvent = pixiEvent;
                    }
                }
            }
        };
        const view = this.renderer.view;
        view.style.touchAction = "none";
        const options = { capture: true, passive: false };
        document.addEventListener("pointermove", this.handleEvent, options);
        document.addEventListener("wheel", this.handleEvent, options);
        view.addEventListener("pointerdown", this.handleEvent, options);
        globalThis.addEventListener("pointercancel", this.handleEvent, options);
        globalThis.addEventListener("pointerup", this.handleEvent, options);
    }
    getTrackingData(event) {
        let data = this._trackingData.get(event.pointerId);
        if (!data) {
            data = {
                tapSet: new Set(),
                hoverSet: new Set(),
                canceled: false
            };
            this._trackingData.set(event.pointerId, data);
        }
        return data;
    }
    update() {
        const lastObjectRendered = this.renderer._lastObjectRendered;
        if (!lastObjectRendered) {
            return;
        }
        const events = this._capturedEvents;
        let pointerMoved = this._pointerMoved;
        if (events.length) {
            for (let i = 0; i < events.length; i += 1) {
                const event = events[i];
                this.processEvent(event, lastObjectRendered);
                if (event.__type == "pointermove") {
                    pointerMoved = true;
                    this._lastMoveEvent = event;
                }
            }
            this._lastEvent = events[events.length - 1];
            this._capturedEvents = [];
        }
        if (!pointerMoved && this._lastMoveEvent && this._lastMoveEvent.pointerType == "mouse") {
            this._lastMoveEvent.__type = "pointerupdate";
            this.processEvent(this._lastMoveEvent, lastObjectRendered);
        }
        this._pointerMoved = false;
    }
    cancelEvent(event) {
        this.getTrackingData(event).canceled = true;
    }
    processEvent(event, root) {
        switch (event.__type) {
            case "pointerupdate":
                event.target = null;
            /* falls through */
            case "pointermove":
                if (event.pointerType == "mouse") {
                    const trackingData = this.getTrackingData(event);
                    let cursor = null;
                    const hoverSet = new Set();
                    const lastHoverSet = trackingData.hoverSet;
                    EventSystem.treeWalk(root, event.global, x => {
                        if (!event.target) {
                            event.target = x;
                        }
                        if (!cursor && x.cursor) {
                            cursor = x.cursor;
                        }
                        if (event.__type == "pointermove") {
                            x.emit("pointermove", event);
                        }
                        if (!lastHoverSet.delete(x)) {
                            x.emit("pointerover", event);
                        }
                        hoverSet.add(x);
                    });
                    lastHoverSet.forEach(x => x.interactive && x.emit("pointerout", event));
                    trackingData.hoverSet = hoverSet;
                    if (!cursor) {
                        cursor = this._cursor || "default";
                    }
                    if (this._cursorControl == "auto" && this._lastCursor != cursor) {
                        this._lastCursor = cursor;
                        this.renderer.view.style.cursor = cursor;
                    }
                }
                else {
                    EventSystem.treeWalk(root, event.global, x => x.emit("pointermove", event));
                }
                if (event.__type == "pointermove") {
                    this.emit("pointermove", event);
                }
                break;
            case "pointerdown": {
                const trackingData = this.getTrackingData(event);
                const tapSet = trackingData.tapSet;
                trackingData.canceled = false;
                if (tapSet.size) {
                    tapSet.forEach(x => x.interactive && x.emit("pointerupoutside", event));
                    tapSet.clear();
                }
                EventSystem.treeWalk(root, event.global, x => {
                    if (!event.target) {
                        event.target = x;
                    }
                    x.emit("pointerdown", event);
                    tapSet.add(x);
                });
                this.emit("pointerdown", event);
                break;
            }
            case "pointerup": {
                const trackingData = this.getTrackingData(event);
                const tapSet = trackingData.tapSet;
                if (trackingData.canceled) {
                    event.__type = "pointercancel";
                    const tapSet = this.getTrackingData(event).tapSet;
                    if (tapSet.size) {
                        tapSet.forEach(x => x.interactive && x.emit("pointerupoutside", event));
                        tapSet.clear();
                    }
                    this.emit("pointerup", event);
                }
                else {
                    EventSystem.treeWalk(root, event.global, x => {
                        if (!event.target) {
                            event.target = x;
                        }
                        x.emit("pointerup", event);
                        if (tapSet.has(x)) {
                            tapSet.delete(x);
                            x.emit("pointertap", event);
                        }
                    });
                    if (tapSet.size) {
                        tapSet.forEach(x => x.interactive && x.emit("pointerupoutside", event));
                        tapSet.clear();
                    }
                    this.emit("pointerup", event);
                    this.emit("pointetap", event);
                }
                break;
            }
            case "pointercancel": {
                const tapSet = this.getTrackingData(event).tapSet;
                if (tapSet.size) {
                    tapSet.forEach(x => x.interactive && x.emit("pointerupoutside", event));
                    tapSet.clear();
                }
                this.emit("pointerup", event);
                break;
            }
            case "wheel":
                EventSystem.treeWalk(root, event.global, x => {
                    if (!event.target) {
                        event.target = x;
                    }
                    x.emit("wheel", event);
                });
                this.emit("wheel", event);
                break;
        }
    }
    destroy() {
        const view = this.renderer.view;
        view.style.removeProperty("touch-action");
        view.style.removeProperty("cursor");
        const options = { capture: true, passive: false };
        document.removeEventListener("pointermove", this.handleEvent, options);
        document.removeEventListener("wheel", this.handleEvent, options);
        view.removeEventListener("pointerdown", this.handleEvent, options);
        globalThis.removeEventListener("pointercancel", this.handleEvent, options);
        globalThis.removeEventListener("pointerup", this.handleEvent, options);
    }
    setCursorMode(mode, cursor) {
        if (mode == "auto") {
            this._lastCursor = "";
        }
        else if (mode == "forced") {
            this._lastCursor = cursor || "default";
            this.renderer.view.style.cursor = this._lastCursor;
        }
        else {
            this._lastCursor = "";
            this.renderer.view.style.removeProperty("cursor");
        }
    }
    get lastMoveEvent() {
        return this._lastMoveEvent;
    }
    get lastEvent() {
        return this._lastEvent;
    }
    get cursor() {
        return this._cursor;
    }
    set cursor(value) {
        this._cursor = value;
        this.setCursorMode(this._cursorControl, value);
    }
    get cursorControl() {
        return this._cursorControl;
    }
    set cursorControl(value) {
        this._cursorControl = value;
        this.setCursorMode(value, this._cursor);
    }
    get cursorCurrent() {
        return this._lastCursor;
    }
    get captureTouchEvents() {
        return this._captureTouchEvents;
    }
    set captureTouchEvents(value) {
        this._captureTouchEvents = value;
        this.renderer.view.style.touchAction = value ? "none" : "auto";
    }
}
EventSystem.extension = {
    name: "eventSystem",
    type: [
        ExtensionType.RendererPlugin,
        ExtensionType.CanvasRendererPlugin
    ]
};
EventSystem._point = new Point(0, 0);
//# sourceMappingURL=EventSystem.js.map