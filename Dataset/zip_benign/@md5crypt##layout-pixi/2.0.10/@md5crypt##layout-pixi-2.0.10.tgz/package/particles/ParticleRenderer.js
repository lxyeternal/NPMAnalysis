import { ObjectRenderer, Buffer, Geometry, State } from "@pixi/core";
import { ExtensionType } from "@pixi/extensions";
import { TYPES, DRAW_MODES } from "@pixi/constants";
import { createIndicesForQuads, correctBlendMode } from "@pixi/utils";
import ParticleShader from "./ParticleShader";
class ParticleGeometry extends Geometry {
    constructor(size) {
        super();
        this._size = size;
        this._data = new ArrayBuffer(4 * 20 /* CONST.WORDS_PER_QUAD */ * size);
        this._f32 = new Float32Array(this._data);
        this._i32 = new Uint32Array(this._data);
        const indexBuffer = new Buffer(new ArrayBuffer(0), true, true);
        const buffer = new Buffer(this._data, false, false);
        indexBuffer.update(createIndicesForQuads(size));
        this.addAttribute("aVertexPosition", buffer, 2, false, TYPES.FLOAT, 20 /* CONST.STRIDE */, 0 /* CONST.POS_VERTEX_POSITION */ * 4)
            .addAttribute("aTextureCoord", buffer, 2, false, TYPES.FLOAT, 20 /* CONST.STRIDE */, 2 /* CONST.POS_TEXTURE_COORD */ * 4)
            .addAttribute("aColor", buffer, 4, true, TYPES.UNSIGNED_BYTE, 20 /* CONST.STRIDE */, 4 /* CONST.POS_COLOR */ * 4)
            .addIndex(indexBuffer);
        this._buffer = buffer;
    }
    update(size) {
        this._buffer.update(new Float32Array(this._data, 0, size * 20 /* CONST.WORDS_PER_QUAD */));
    }
    get size() {
        return this._size;
    }
    set size(value) {
        if (this._size != value) {
            this._size = value;
            this.getIndex().update(createIndicesForQuads(value));
            const data = new ArrayBuffer(4 * 20 /* CONST.WORDS_PER_QUAD */ * value);
            this._data = data;
            this._i32 = new Uint32Array(data);
            this._f32 = new Float32Array(data);
        }
    }
    get float32DataView() {
        return this._f32;
    }
    get uint32DataView() {
        return this._i32;
    }
}
export class ParticleRenderer extends ObjectRenderer {
    constructor(renderer) {
        super(renderer);
        this._tmpPoint = { x: 0, y: 0 };
        this._geometry = new ParticleGeometry(ParticleRenderer.INITIAL_SIZE);
        this._state = State.for2d();
        renderer.runners.contextChange.add(this);
        this._batchedContainers = [];
    }
    contextChange() {
        if (!this._shader) {
            this._shader = new ParticleShader();
        }
    }
    render(container) {
        if (this._batchedContainers.length) {
            const firstContainer = this._batchedContainers[0];
            const wt1 = container.worldTransform;
            const wt2 = firstContainer.worldTransform;
            const canBatch = (firstContainer.baseTexture == container.baseTexture &&
                firstContainer.blendMode == container.blendMode &&
                (wt1.a == wt2.a && wt1.b == wt2.b && wt1.c == wt2.c && wt1.d == wt2.d));
            if (!canBatch) {
                this.flush();
            }
        }
        this._batchedContainers.push(container);
    }
    renderContainer(container, i32, f32, offset) {
        const worldAlpha = container.worldAlpha;
        const point = this._tmpPoint;
        if (this._batchedContainers.length > 1) {
            point.x = container.worldTransform.tx;
            point.y = container.worldTransform.ty;
            this._batchedContainers[0].worldTransform.applyInverse(point, point);
        }
        else {
            point.x = 0;
            point.y = 0;
        }
        const xContainerOffset = point.x;
        const yContainerOffset = point.y;
        for (const pool of container.pools) {
            const sortBuffer = pool.__sortBuffer;
            const count = pool.count;
            let rendered = 0;
            // this for loop is odd
            // it iterates over "i" but checks condition on "rendered"
            // this is an optimization to not iterate over the whole sort buffer when only a part of it is used
            for (let i = 0; rendered < count; i += 1) {
                const item = sortBuffer[i];
                if (item == null) {
                    continue;
                }
                // clear the sort buffer entry
                // this is not done in particle pool and has to be done here
                sortBuffer[i] = null;
                rendered += 1;
                if (item.alpha == 0) {
                    continue;
                }
                const cos = Math.cos(item.angle);
                const sin = Math.sin(item.angle);
                const a = cos * item.xScale;
                const b = sin * item.xScale;
                const c = -sin * item.yScale;
                const d = cos * item.yScale;
                const width = item._width;
                const height = item._height;
                const xOffset = width * item.xAnchor;
                const yOffset = height * item.yAnchor;
                const tx = item.x - xOffset * a - yOffset * c + xContainerOffset;
                const ty = item.y - xOffset * b - yOffset * d + yContainerOffset;
                const uvs = item._uvs;
                const color = item.tint | (255 * worldAlpha * item.alpha) << 24;
                f32[offset + 0] = tx;
                f32[offset + 1] = ty;
                f32[offset + 2] = uvs[0];
                f32[offset + 3] = uvs[1];
                i32[offset + 4] = color;
                f32[offset + 5] = (a * width) + tx;
                f32[offset + 6] = (b * width) + ty;
                f32[offset + 7] = uvs[2];
                f32[offset + 8] = uvs[3];
                i32[offset + 9] = color;
                f32[offset + 10] = (a * width) + (c * height) + tx;
                f32[offset + 11] = (d * height) + (b * width) + ty;
                f32[offset + 12] = uvs[4];
                f32[offset + 13] = uvs[5];
                i32[offset + 14] = color;
                f32[offset + 15] = (c * height) + tx;
                f32[offset + 16] = (d * height) + ty;
                f32[offset + 17] = uvs[6];
                f32[offset + 18] = uvs[7];
                i32[offset + 19] = color;
                offset += 20 /* CONST.WORDS_PER_QUAD */;
            }
        }
        return offset;
    }
    flush() {
        const containers = this._batchedContainers;
        let requiredSize = 0;
        for (let i = 0; i < containers.length; i += 1) {
            requiredSize += containers[i].count;
        }
        if (this._geometry.size < requiredSize) {
            this._geometry.size = Math.pow(2, Math.round(Math.log2(requiredSize)) + 1);
        }
        const i32 = this._geometry.uint32DataView;
        const f32 = this._geometry.float32DataView;
        let offset = 0;
        for (let i = 0; i < containers.length; i += 1) {
            offset = this.renderContainer(containers[i], i32, f32, offset);
        }
        if (offset == 0) {
            // nothing to do!
            return;
        }
        this._state.blendMode = correctBlendMode(containers[0].blendMode, true);
        const quads = offset / 20 /* CONST.WORDS_PER_QUAD */;
        this._geometry.update(quads);
        this._shader.uniforms.uSampler = containers[0].baseTexture;
        this._shader.uniforms.translationMatrix = containers[0].transform.worldTransform.toArray(true);
        this.renderer.state.set(this._state);
        this.renderer.shader.bind(this._shader);
        this.renderer.geometry.bind(this._geometry, this._shader);
        this.renderer.geometry.draw(DRAW_MODES.TRIANGLES, 6 /* CONST.INDICES_PER_QUAD */ * quads, 0);
        this._batchedContainers = [];
    }
}
ParticleRenderer.INITIAL_SIZE = 512;
ParticleRenderer.extension = {
    name: "particle",
    type: ExtensionType.RendererPlugin
};
//# sourceMappingURL=ParticleRenderer.js.map