import { ParticlePool } from "./ParticlePool";
import { ParticleContainer } from "./ParticleContainer";
import { ParticleEmitterBehavior } from "./ParticleEmitterBehavior";
export declare class ParticleEmitter {
    private _behaviors;
    private _initBehaviorList;
    private _updateBehaviorList;
    private _pool;
    private _container;
    private _reminder;
    private _emitTimer;
    private _waveCounter;
    private _destroyed;
    waveSize: number | (() => number);
    waveCount: number;
    emitDuration: number;
    frequency: number;
    timeScale: number;
    onEmitterStart?: () => void;
    onEmitterStop?: () => void;
    constructor(container: ParticleContainer, poolSize: number);
    addBehaviors(...behaviors: ParticleEmitterBehavior[]): void;
    addBehavior<T extends ParticleEmitterBehavior>(behavior: T): T;
    addBehavior<T extends ParticleEmitterBehavior>(behavior: T, order: number): T;
    addBehavior<T extends ParticleEmitterBehavior>(behavior: T, executionOrder: number, initOder: number): T;
    getBehavior<T extends ParticleEmitterBehavior>(behaviorClass: {
        new (...args: any): T;
    }): T;
    startEmitter(override?: number): void;
    stopEmitter(): void;
    emit(waveSize?: number): void;
    update(deltaMs: number): void;
    destroy(): void;
    get destroyed(): boolean;
    get emitting(): boolean;
    get container(): ParticleContainer;
    get pool(): ParticlePool;
}
