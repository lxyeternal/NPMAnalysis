import { Particle } from "./Particle";
export declare class ParticlePool {
    private _size;
    private _data;
    private _sortBuffer;
    private _pivot;
    private _index;
    constructor(size: number);
    next(): Particle | null;
    remove(): Particle | null;
    create(): Particle | null;
    createMany(count?: number): number;
    clear(): void;
    seek(value: number): void;
    get remaining(): number;
    get count(): number;
    get capacity(): number;
    get data(): Particle[];
    get offset(): number;
    get empty(): boolean;
}
