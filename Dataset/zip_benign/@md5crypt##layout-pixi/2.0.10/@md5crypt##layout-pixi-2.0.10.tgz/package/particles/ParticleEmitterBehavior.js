export class ParticleEmitterBehavior {
    get order() {
        return 0;
    }
    get initOrder() {
        return this.order;
    }
    onEmitterAssign() {
    }
    init(pool, amount) {
    }
    update(pool, deltaMs) {
    }
    get emitter() {
        return this._emitter;
    }
    /* @internal */
    set emitter(value) {
        this._emitter = value;
        this.onEmitterAssign();
    }
}
//# sourceMappingURL=ParticleEmitterBehavior.js.map