export class Particle {
    constructor() {
        /* @internal */
        this._uvs = null;
        /* @internal */
        this._width = 0;
        /* @internal */
        this._height = 0;
        /* @internal */
        this._order = 0;
        this.x = 0;
        this.y = 0;
        this.angle = 0;
        this.tint = 0xFFFFFF;
        this.xScale = 1;
        this.yScale = 1;
        this.xAnchor = 0.5;
        this.yAnchor = 0.5;
        this.alpha = 1;
        this.data = {};
    }
    copyFrom(src) {
        this.x = src.x;
        this.y = src.y;
        this.angle = src.angle;
        this.tint = src.tint;
        this.xScale = src.xScale;
        this.yScale = src.yScale;
        this.xAnchor = src.xAnchor;
        this.yAnchor = src.yAnchor;
        this.alpha = src.alpha;
        this._uvs = src._uvs;
        this._width = src._width;
        this._height = src._height;
    }
    set texture(texture) {
        this._uvs = texture._uvs.uvsFloat32;
        this._width = texture.width;
        this._height = texture.height;
    }
    set scale(value) {
        this.xScale = value;
        this.yScale = value;
    }
    get scale() {
        return this.xScale;
    }
}
//# sourceMappingURL=Particle.js.map