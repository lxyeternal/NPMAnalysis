import { Renderer, ObjectRenderer } from "@pixi/core";
import { ExtensionMetadata } from "@pixi/extensions";
import { ParticleContainer } from "./ParticleContainer";
export declare class ParticleRenderer extends ObjectRenderer {
    static INITIAL_SIZE: number;
    static readonly extension: ExtensionMetadata;
    private _shader;
    private _geometry;
    private _state;
    private _tmpPoint;
    private _batchedContainers;
    constructor(renderer: Renderer);
    contextChange(): void;
    render(container: ParticleContainer): void;
    private renderContainer;
    flush(): void;
}
