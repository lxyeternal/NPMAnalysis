import { Texture } from "@pixi/core";
import { DisplayObject } from "@pixi/display";
import { BLEND_MODES } from "@pixi/constants";
export class ParticleContainer extends DisplayObject {
    constructor() {
        super();
        this.sortDirty = false;
        this.baseTexture = Texture.EMPTY.baseTexture;
        this.blendMode = BLEND_MODES.NORMAL;
        this._pools = new Set();
    }
    addPool(pool) {
        this._pools.add(pool);
    }
    removePool(pool) {
        this._pools.delete(pool);
    }
    calculateBounds() {
        // no-op
    }
    removeChild(child) {
        // no-op
    }
    render(renderer) {
        if (!this.visible || this.worldAlpha <= 0 || !this.renderable || this.count == 0) {
            return;
        }
        const plugin = renderer.plugins.particle;
        renderer.batch.setObjectRenderer(plugin);
        plugin.render(this);
    }
    get pools() {
        return this._pools.values();
    }
    get count() {
        let sum = 0;
        for (const pool of this._pools) {
            sum += pool.count;
        }
        return sum;
    }
}
//# sourceMappingURL=ParticleContainer.js.map