import { Texture } from "@pixi/core";
export declare class Particle {
    x: number;
    y: number;
    angle: number;
    tint: number;
    xScale: number;
    yScale: number;
    xAnchor: number;
    yAnchor: number;
    alpha: number;
    data: Record<string, any>;
    copyFrom(src: Particle): void;
    set texture(texture: Texture);
    set scale(value: number);
    get scale(): number;
}
