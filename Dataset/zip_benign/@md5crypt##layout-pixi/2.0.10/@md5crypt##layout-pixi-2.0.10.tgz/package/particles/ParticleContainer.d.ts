import { Renderer, BaseTexture } from "@pixi/core";
import { DisplayObject } from "@pixi/display";
import { BLEND_MODES } from "@pixi/constants";
import { ParticlePool } from "./ParticlePool";
export declare class ParticleContainer extends DisplayObject {
    sortDirty: boolean;
    baseTexture: BaseTexture;
    blendMode: BLEND_MODES;
    private _pools;
    constructor();
    addPool(pool: ParticlePool): void;
    removePool(pool: ParticlePool): void;
    calculateBounds(): void;
    removeChild(child: DisplayObject): void;
    render(renderer: Renderer): void;
    get pools(): IterableIterator<ParticlePool>;
    get count(): number;
}
