import { ParticlePool } from "./ParticlePool";
import { ParticleEmitter } from "./ParticleEmitter";
export declare class ParticleEmitterBehavior {
    private _emitter;
    get order(): number;
    get initOrder(): number;
    protected onEmitterAssign(): void;
    init(pool: ParticlePool, amount: number): void;
    update(pool: ParticlePool, deltaMs: number): void;
    get emitter(): ParticleEmitter;
}
