import { ParticleEmitter } from "./ParticleEmitter";
import { ParticleEmitterBehavior } from "./ParticleEmitterBehavior";
import { ParticleContainer } from "./ParticleContainer";
interface FactoryClass {
    new (config: Record<string, any>): ParticleEmitterBehavior;
    type: string;
}
export interface ParticleEmitterFactoryConfig {
    frequency: number;
    poolSize: number;
    behaviors: {
        type: string;
        config: Record<string, any>;
    }[];
}
export declare class ParticleEmitterFactory {
    private _map;
    constructor();
    register(...behaviorClasses: FactoryClass[]): void;
    create(container: ParticleContainer, config: ParticleEmitterFactoryConfig): ParticleEmitter;
}
export {};
