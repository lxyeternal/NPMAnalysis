import { Shader } from "@pixi/core";
export default class ParticleShader extends Shader {
    constructor();
}
