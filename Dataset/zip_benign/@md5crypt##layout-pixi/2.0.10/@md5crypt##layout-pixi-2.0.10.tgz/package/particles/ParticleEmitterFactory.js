import { ParticleEmitter } from "./ParticleEmitter";
export class ParticleEmitterFactory {
    constructor() {
        this._map = new Map();
    }
    register(...behaviorClasses) {
        behaviorClasses.forEach(x => this._map.set(x.type, x));
    }
    create(container, config) {
        const emitter = new ParticleEmitter(container, config.poolSize);
        emitter.frequency = config.frequency;
        config.behaviors.forEach(x => {
            const behaviorClass = this._map.get(x.type);
            if (!behaviorClass) {
                throw new Error("use of unknown behavior type " + x.type);
            }
            emitter.addBehavior(new behaviorClass(x.config));
        });
        return emitter;
    }
}
//# sourceMappingURL=ParticleEmitterFactory.js.map