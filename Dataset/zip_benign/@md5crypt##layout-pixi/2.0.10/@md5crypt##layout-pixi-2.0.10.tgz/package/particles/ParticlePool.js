import { Particle } from "./Particle";
export class ParticlePool {
    constructor(size) {
        this._size = size;
        this._data = Array.from({ length: size }, (_, i) => {
            const particle = new Particle();
            particle._order = i;
            return particle;
        });
        this._sortBuffer = Array.from({ length: size }, () => null);
        this._pivot = 0;
        this._index = -1;
    }
    next() {
        const index = this._index + 1;
        if (index < this._pivot) {
            this._index = index;
            return this._data[index];
        }
        return null;
    }
    remove() {
        const index = this._index;
        const pivot = this._pivot - 1;
        if (index < 0 || pivot < 0) {
            return null;
        }
        this._pivot = pivot;
        if (index < pivot) {
            const data = this._data;
            const item = data[pivot];
            data[pivot] = data[index];
            data[index] = item;
            return item;
        }
        return null;
    }
    create() {
        const pivot = this._pivot;
        if (pivot >= this._size) {
            return null;
        }
        this._pivot += 1;
        return this._data[pivot];
    }
    createMany(count = 1) {
        const pivot = this._pivot;
        const capped = Math.min(this._size - pivot, Math.floor(count));
        this._pivot += capped;
        return capped;
    }
    clear() {
        this._pivot = 0;
        this._index = -1;
    }
    seek(value) {
        if (value <= 0) {
            this._index = -1;
        }
        else if (value >= this._pivot) {
            this._index = this._pivot - 1;
        }
        else {
            this._index = value - 1;
        }
    }
    get remaining() {
        return this._pivot - (this._index + 1);
    }
    get count() {
        return this._pivot;
    }
    get capacity() {
        return this._size;
    }
    get data() {
        return this._data;
    }
    get offset() {
        return this._index + 1;
    }
    get empty() {
        return this._pivot == 0;
    }
    /* @internal */
    get __sortBuffer() {
        // do a insert sort pass on particles to make particle z index stable over time
        // note that this function does not clear the sort buffer before sorting
        // it relies on the caller to clean up the buffer
        // if the caller does not do that everything will crash :)
        const sortBuffer = this._sortBuffer;
        const count = this._pivot;
        const data = this._data;
        for (let i = 0; i < count; i += 1) {
            const item = data[i];
            sortBuffer[item._order] = item;
        }
        return sortBuffer;
    }
}
//# sourceMappingURL=ParticlePool.js.map