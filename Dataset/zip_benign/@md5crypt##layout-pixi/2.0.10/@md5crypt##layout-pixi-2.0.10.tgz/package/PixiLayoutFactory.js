import { LayoutFactory } from "@md5crypt/layout";
import { Texture } from "@pixi/core";
export class PixiLayoutFactory extends LayoutFactory {
    resolveAsset(asset) {
        if (typeof asset == "string") {
            if (this.onResolveAsset) {
                return this.onResolveAsset(asset);
            }
            throw new Error("string has been passed but assetResolver has not been defined");
        }
        return asset || Texture.EMPTY;
    }
    register(type, constructor) {
        super.register(type, constructor);
    }
}
//# sourceMappingURL=PixiLayoutFactory.js.map