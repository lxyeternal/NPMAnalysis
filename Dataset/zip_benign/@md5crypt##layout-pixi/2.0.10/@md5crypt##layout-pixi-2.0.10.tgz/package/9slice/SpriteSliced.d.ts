import { Sprite } from "@pixi/sprite";
import { IPointData } from "@pixi/math";
export interface SliceConfiguration {
    top?: number;
    left?: number;
    bottom?: number;
    right?: number;
    vertical?: number;
    horizontal?: number;
}
export declare class SpriteSliced extends Sprite {
    private static _slicedIndices;
    private static _normalIndices;
    private static _point;
    private _isSliced;
    private _leftWidth;
    private _rightWidth;
    private _topHeight;
    private _bottomHeight;
    private get minScale();
    calculateVertices(): void;
    protected _calculateBounds(): void;
    containsPoint(point: IPointData): boolean;
    setSliced(slices: SliceConfiguration | number): this;
    get isSliced(): boolean;
    set isSliced(value: boolean);
    get leftWidth(): number;
    set leftWidth(value: number);
    get rightWidth(): number;
    set rightWidth(value: number);
    get topHeight(): number;
    set topHeight(value: number);
    get bottomHeight(): number;
    set bottomHeight(value: number);
    get width(): number;
    set width(value: number);
    get height(): number;
    set height(value: number);
}
