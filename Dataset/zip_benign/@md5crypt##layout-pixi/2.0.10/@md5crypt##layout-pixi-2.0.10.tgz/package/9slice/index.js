export * from "./SpriteSliced";
//# sourceMappingURL=index.js.map