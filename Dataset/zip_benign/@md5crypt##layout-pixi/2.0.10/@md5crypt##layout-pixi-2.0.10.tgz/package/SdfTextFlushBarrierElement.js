import { BaseElement } from "./BaseElement";
import { SdfTextFlushBarrier } from "./sdfText/index";
export class SdfTextFlushBarrierElement extends BaseElement {
    static register(factory) {
        factory.register("text-sdf-barrier", config => new this(factory, config));
    }
    constructor(factory, config) {
        super(factory, config, new SdfTextFlushBarrier());
    }
}
//# sourceMappingURL=SdfTextFlushBarrierElement.js.map