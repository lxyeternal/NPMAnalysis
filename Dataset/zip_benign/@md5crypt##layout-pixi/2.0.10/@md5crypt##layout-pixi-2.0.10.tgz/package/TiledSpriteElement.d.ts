import { BaseElement, BaseElementConfig, BlendMode } from "./BaseElement";
import { PixiLayoutFactory } from "./PixiLayoutFactory";
import { Texture } from "@pixi/core";
import { TilingSprite } from "@pixi/sprite-tiling";
export interface TiledSpriteElementConfig extends BaseElementConfig<"sprite-tiled", TiledSpriteElement> {
    image?: Texture | string;
    tint?: number;
    clampMargin?: number;
    roundPixels?: boolean;
    blendMode?: BlendMode;
}
export declare class TiledSpriteElement extends BaseElement<TilingSprite> {
    static register(factory: PixiLayoutFactory): void;
    protected constructor(factory: PixiLayoutFactory, config: TiledSpriteElementConfig, handle: TilingSprite);
    get image(): Texture;
    set image(value: Texture | string | null);
    get tint(): number;
    set tint(value: number);
    get blendMode(): BlendMode;
    set blendMode(value: BlendMode);
    get roundPixels(): boolean;
    set roundPixels(value: boolean);
    set clampMargin(value: number);
    get clampMargin(): number;
    protected onUpdate(): void;
    get contentHeight(): number;
    get contentWidth(): number;
}
export default TiledSpriteElement;
declare module "./ElementTypes" {
    interface ElementTypes {
        "sprite-tiled": TiledSpriteElementConfig;
    }
}
