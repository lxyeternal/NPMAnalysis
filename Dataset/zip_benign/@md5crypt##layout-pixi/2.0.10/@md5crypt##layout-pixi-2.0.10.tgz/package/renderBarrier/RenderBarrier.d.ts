import { Renderer } from "@pixi/core";
import { DisplayObject } from "@pixi/display";
declare global {
    namespace GlobalMixins {
        interface DisplayObject {
            renderBarrierId?: number;
        }
    }
}
export declare class RenderBarrier extends DisplayObject {
    private static barriers;
    static render(object: DisplayObject): void;
    sortDirty: boolean;
    barrierId: number;
    constructor(barrierId?: number);
    calculateBounds(): void;
    removeChild(child: DisplayObject): void;
    render(renderer: Renderer): void;
}
