import { SpriteElement } from "./SpriteElement";
import { SpriteSliced } from "./9slice/index";
// @depreciated
export class SlicedSpriteElement extends SpriteElement {
    static register(factory) {
        factory.register("sprite-sliced", config => new this(factory, config, new SpriteSliced(factory.resolveAsset(config.image))));
    }
    constructor(factory, config, handle) {
        super(factory, config, handle);
        this.scaling = super.scaling;
    }
    set scaling(value) {
        if (value == "height") {
            super.scaling = "sliced-horizontal";
        }
        else if (value == "width") {
            super.scaling = "sliced-vertical";
        }
        else {
            super.scaling = "sliced";
        }
    }
    get scaling() {
        if (super.scaling == "sliced-horizontal") {
            return "width";
        }
        else if (super.scaling == "sliced-vertical") {
            return "height";
        }
        else {
            return "none";
        }
    }
}
//# sourceMappingURL=SlicedSpriteElement.js.map