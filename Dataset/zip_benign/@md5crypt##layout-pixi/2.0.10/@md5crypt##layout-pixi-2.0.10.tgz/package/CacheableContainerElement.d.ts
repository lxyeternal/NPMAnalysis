import { PixiLayoutFactory } from "./PixiLayoutFactory";
import { ContainerElement, ContainerElementConfig } from "./ContainerElement";
import { Container } from "@pixi/display";
import { Renderer, AbstractRenderer } from "@pixi/core";
declare class CacheableContainer extends Container {
    usePotTexture: boolean;
    passthrough: boolean;
    private _sprite;
    private _texture;
    private _rendering;
    constructor();
    render(renderer: Renderer): void;
    destroy(): void;
    updateCache(renderer: Renderer): void;
}
export interface CacheableContainerElementConfig extends ContainerElementConfig<"container-cacheable", CacheableContainerElement> {
    usePotTexture?: boolean;
    passthrough?: boolean;
    renderer?: AbstractRenderer;
}
export declare class CacheableContainerElement extends ContainerElement<CacheableContainer> {
    static register(factory: PixiLayoutFactory): void;
    private _cacheDirty;
    private _renderer;
    private constructor();
    invalidate(): void;
    onUpdate(): void;
    get renderer(): AbstractRenderer | null;
    set renderer(value: AbstractRenderer | null);
    get passthrough(): boolean;
    set passthrough(value: boolean);
    get usePotTexture(): boolean;
    set usePotTexture(value: boolean);
}
export default CacheableContainerElement;
declare module "./ElementTypes" {
    interface ElementTypes {
        "container-cacheable": CacheableContainerElementConfig;
    }
}
