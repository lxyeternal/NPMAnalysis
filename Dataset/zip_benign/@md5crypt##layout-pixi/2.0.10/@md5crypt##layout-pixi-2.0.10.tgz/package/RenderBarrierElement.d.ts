import { BaseElement, BaseElementConfig } from "./BaseElement";
import { PixiLayoutFactory } from "./PixiLayoutFactory";
import { RenderBarrier } from "./renderBarrier/RenderBarrier";
export interface RenderBarrierElementConfig extends BaseElementConfig<"render-barrier", RenderBarrierElement> {
    barrierId?: number;
}
export declare class RenderBarrierElement extends BaseElement<RenderBarrier> {
    static register(factory: PixiLayoutFactory): void;
    protected constructor(factory: PixiLayoutFactory, config: RenderBarrierElementConfig);
    set barrierId(value: number);
    get barreirId(): number;
}
declare module "./ElementTypes" {
    interface ElementTypes {
        "render-barrier": RenderBarrierElementConfig;
    }
}
