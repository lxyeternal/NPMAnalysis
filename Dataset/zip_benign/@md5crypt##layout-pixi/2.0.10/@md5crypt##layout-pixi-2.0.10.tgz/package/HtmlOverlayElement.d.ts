import { BaseElement, BaseElementConfig } from "./BaseElement";
import { PixiLayoutFactory } from "./PixiLayoutFactory";
import { HtmlOverlay } from "./htmlOverlay/index";
import { Renderer } from "@pixi/core";
export interface HtmlOverlayElementConfig extends BaseElementConfig<"html", HtmlOverlayElement> {
    style?: string;
    content?: string;
    persistent?: boolean;
}
export declare class HtmlOverlayElement extends BaseElement<HtmlOverlay> {
    static register(factory: PixiLayoutFactory): void;
    private constructor();
    protected onUpdate(): void;
    set style(value: string);
    get style(): string;
    set content(value: string);
    get content(): string;
    set persistent(value: boolean);
    get persistent(): boolean;
    detach(): void;
    attach(renderer: Renderer): void;
    get htmlRoot(): HTMLDivElement;
}
export default HtmlOverlayElement;
declare module "./ElementTypes" {
    interface ElementTypes {
        "html": HtmlOverlayElementConfig;
    }
}
