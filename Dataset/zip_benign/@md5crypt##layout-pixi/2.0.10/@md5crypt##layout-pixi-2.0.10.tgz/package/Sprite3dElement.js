import { Sprite3d } from "./projection/proj3d/Sprite3d";
import { Rectangle } from "@pixi/math";
import { BaseElement } from "./BaseElement";
export class Sprite3dElement extends BaseElement {
    static register(factory) {
        factory.register("sprite-3d", config => new this(factory, config));
    }
    constructor(factory, config) {
        super(factory, config, new Sprite3d(factory.resolveAsset(config.image)));
        if (config.tint !== undefined) {
            this.handle.tint = config.tint;
        }
        if (config.blendMode !== undefined) {
            this.handle.blendMode = config.blendMode;
        }
        if (config.backImage) {
            this.handle.backTexture = factory.resolveAsset(config.backImage);
        }
        if (config.mirrorBackImage) {
            this.mirrorBackImage = config.mirrorBackImage;
        }
        if (config.faces) {
            this.faces = config.faces;
        }
    }
    onUpdate() {
        const computedWidth = this.computedWidth;
        const computedHeight = this.computedHeight;
        const texture = this.handle.texture;
        const xScale = computedWidth / texture.width;
        const yScale = computedHeight / texture.height;
        this.handle.scale.set(xScale * this._scale, yScale * this._scale);
        this.handle.pivot.set(computedWidth * this._xPivot, computedHeight * this._yPivot);
        this.applyFlip();
        this.handle.position.set(this.computedLeft + this._scale * xScale * this._xPivot * this.computedWidth, this.computedTop + this._scale * yScale * this._yPivot * this.computedHeight);
        if (this.handle.interactive) {
            this.handle.hitArea = new Rectangle(0, 0, texture.width, texture.height);
        }
    }
    get contentHeight() {
        return this.handle.texture.height;
    }
    get contentWidth() {
        return this.handle.texture.width;
    }
    set interactive(value) {
        if (super.interactive != value) {
            super.interactive = value;
            this.setDirty();
        }
    }
    get interactive() {
        return super.interactive;
    }
    get image() {
        return this.handle.frontTexture;
    }
    set image(value) {
        const texture = this.factory.resolveAsset(value);
        if (this.handle.frontTexture != texture) {
            this.handle.frontTexture = texture;
            this.setDirty();
        }
    }
    get backImage() {
        return this.handle.backTexture;
    }
    set backImage(value) {
        const texture = value === null ? null : this.factory.resolveAsset(value);
        if (this.handle.backTexture != texture) {
            this.handle.backTexture = texture;
            this.setDirty();
        }
    }
    get mirrorBackImage() {
        if (this.handle.backTextureTransform) {
            return this.handle.backTextureTransform == 2 /* BackTextureTransform.MIRROR_HORIZONTAL */ ? "horizontal" : "vertical";
        }
        else {
            return null;
        }
    }
    set mirrorBackImage(value) {
        if (value == "vertical") {
            this.handle.backTextureTransform = 1 /* BackTextureTransform.MIRROR_VERTICAL */;
        }
        else if (value == "horizontal") {
            this.handle.backTextureTransform = 2 /* BackTextureTransform.MIRROR_HORIZONTAL */;
        }
        else {
            this.handle.backTextureTransform = 0 /* BackTextureTransform.NONE */;
        }
    }
    get faces() {
        const faces = this.handle.faces;
        switch (faces) {
            case 0 /* Sprite3dFaces.NONE */:
                return "none";
            case 1 /* Sprite3dFaces.FRONT */:
                return "front";
            case 2 /* Sprite3dFaces.BACK */:
                return "back";
            default:
                return "both";
        }
    }
    set faces(value) {
        switch (value) {
            case "none":
                this.handle.faces = 0 /* Sprite3dFaces.NONE */;
                break;
            case "front":
                this.handle.faces = 1 /* Sprite3dFaces.FRONT */;
                break;
            case "back":
                this.handle.faces = 2 /* Sprite3dFaces.BACK */;
                break;
            default:
                this.handle.faces = 3 /* Sprite3dFaces.BOTH */;
        }
    }
    get tint() {
        return this.handle.tint;
    }
    set tint(value) {
        this.handle.tint = value;
    }
    get blendMode() {
        return this.handle.blendMode;
    }
    set blendMode(value) {
        this.handle.blendMode = value;
    }
    get zScale() {
        return this.handle.transform.scale.z;
    }
    set zScale(value) {
        this.handle.transform.scale.z = value;
    }
    get zPosition() {
        return this.handle.transform.position.z;
    }
    set zPosition(value) {
        this.handle.transform.position.z = value;
    }
    get zPivot() {
        return this.handle.transform.pivot.z;
    }
    set zPivot(value) {
        this.handle.transform.pivot.z = value;
    }
    get euler() {
        return this.handle.transform.euler;
    }
}
export default Sprite3dElement;
//# sourceMappingURL=Sprite3dElement.js.map