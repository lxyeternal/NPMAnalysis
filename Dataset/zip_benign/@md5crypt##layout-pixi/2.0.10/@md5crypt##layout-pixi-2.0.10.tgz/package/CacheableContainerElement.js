import { ContainerElement } from "./ContainerElement";
import { Container } from "@pixi/display";
import { RenderTexture } from "@pixi/core";
import { Sprite } from "@pixi/sprite";
import { Matrix } from "@pixi/math";
class CacheableContainer extends Container {
    constructor() {
        super();
        this._sprite = new Sprite();
        this._texture = null;
        this._rendering = false;
        this.usePotTexture = false;
        this.passthrough = false;
    }
    render(renderer) {
        if (this._rendering || this.passthrough) {
            return super.render(renderer);
        }
        if (!this.visible || this.worldAlpha <= 0 || !this.renderable) {
            return;
        }
        this._sprite.transform.worldTransform = this.transform.worldTransform;
        this._sprite.transform._worldID = this.transform._worldID;
        this._sprite.worldAlpha = this.worldAlpha;
        this._sprite.render(renderer);
    }
    destroy() {
        var _a;
        this._sprite.destroy();
        (_a = this._texture) === null || _a === void 0 ? void 0 : _a.destroy();
        super.destroy();
    }
    updateCache(renderer) {
        this._rendering = true;
        const cachedAlpha = this.alpha;
        this.alpha = 1;
        const bounds = this.getLocalBounds(undefined, true).clone().ceil(1);
        const targetWidth = this.usePotTexture ? 1 << Math.ceil(Math.log2(bounds.width)) : bounds.width;
        const targetHeight = this.usePotTexture ? 1 << Math.ceil(Math.log2(bounds.height)) : bounds.height;
        let texture = this._texture;
        if (!texture || texture.width != targetWidth || texture.height != targetHeight) {
            if (texture) {
                texture.destroy();
            }
            texture = RenderTexture.create({ width: targetWidth, height: targetHeight, resolution: 1 });
            this._texture = texture;
        }
        const matrix = new Matrix();
        this.transform.localTransform.copyTo(matrix).invert().translate(-bounds.x, -bounds.y);
        this._sprite.anchor.set(-(bounds.x / targetWidth), -(bounds.y / targetHeight));
        this._sprite.transform.updateLocalTransform();
        renderer.render(this, { renderTexture: texture, clear: true, transform: matrix, skipUpdateTransform: false });
        this.alpha = cachedAlpha;
        this._sprite.texture = texture;
        this._rendering = false;
    }
}
export class CacheableContainerElement extends ContainerElement {
    static register(factory) {
        factory.register("container-cacheable", props => new this(factory, props));
    }
    constructor(factory, config) {
        super(factory, config, new CacheableContainer());
        this._cacheDirty = false;
        this._cacheDirty = false;
        this._renderer = null;
        if (config.renderer) {
            this._renderer = config.renderer;
        }
        if (config.passthrough !== undefined) {
            this.handle.passthrough = config.passthrough;
        }
        if (config.usePotTexture !== undefined) {
            this.handle.usePotTexture = config.usePotTexture;
        }
    }
    invalidate() {
        this.setDirty();
        this._cacheDirty = true;
    }
    onUpdate() {
        super.onUpdate();
        if (this._cacheDirty && !this.handle.passthrough) {
            if (this._renderer) {
                this.handle.updateCache(this._renderer);
            }
            else {
                console.warn("CacheableContainerElement's renderer prop not set!");
            }
            this._cacheDirty = false;
        }
    }
    get renderer() {
        return this._renderer;
    }
    set renderer(value) {
        this._renderer = value;
    }
    get passthrough() {
        return this.handle.passthrough;
    }
    set passthrough(value) {
        this.handle.passthrough = value;
    }
    get usePotTexture() {
        return this.handle.usePotTexture;
    }
    set usePotTexture(value) {
        this.handle.usePotTexture = value;
    }
}
export default CacheableContainerElement;
//# sourceMappingURL=CacheableContainerElement.js.map