import { Shader } from "@pixi/core";
export default class SdfTextShader extends Shader {
    constructor(maxTextures: number);
}
