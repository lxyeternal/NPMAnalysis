import { Renderer, ObjectRenderer, BaseTexture } from "@pixi/core";
import { ExtensionMetadata } from "@pixi/extensions";
export interface SdfTextRenderObject {
    get vertexData(): Float32Array;
    get textureUidMap(): ReadonlyMap<number, BaseTexture>;
}
export declare const enum SdfTextConstants {
    INDICES_PER_QUAD = 6,
    VERTICES_PER_QUAD = 4,
    WORDS_PER_VERTEX = 8,
    WORDS_PER_QUAD = 32,
    STRIDE = 32,
    POS_VERTEX_POSITION = 0,
    POS_TEXTURE_COORD = 2,
    POS_F_WIDTH = 4,
    POS_TEXTURE_ID = 5,
    POS_THICKNESS = 6,
    POS_COLOR = 7
}
export declare class SdfTextRenderer extends ObjectRenderer {
    static MAX_TEXTURES: number;
    static FORCE_BATCH: boolean;
    static readonly extension: ExtensionMetadata;
    private _shader;
    private _geometry;
    private _batch;
    private _batchSize;
    private _vertexData;
    private _maxTextures;
    private _baseTextureList;
    private _baseTextureMap;
    private _textureIndexMap;
    private _inputOffset;
    private _state;
    constructor(renderer: Renderer);
    contextChange(): void;
    addToBatch(renderObject: SdfTextRenderObject): void;
    get empty(): boolean;
    private renderBatch;
    private processObject;
    flush(): void;
}
export default SdfTextRenderer;
