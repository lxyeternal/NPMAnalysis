export {};
//# sourceMappingURL=SdfFontData.js.map