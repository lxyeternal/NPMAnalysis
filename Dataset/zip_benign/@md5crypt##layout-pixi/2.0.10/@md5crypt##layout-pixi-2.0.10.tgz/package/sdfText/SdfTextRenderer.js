import { ObjectRenderer, Buffer, Geometry, State } from "@pixi/core";
import { ExtensionType } from "@pixi/extensions";
import { TYPES, DRAW_MODES, BLEND_MODES } from "@pixi/constants";
import { createIndicesForQuads } from "@pixi/utils";
import SdfTextShader from "./SdfTextShader";
class SdfTextGeometry extends Geometry {
    constructor() {
        super();
        const indexBuffer = new Buffer(new ArrayBuffer(0), true, true);
        indexBuffer.update(createIndicesForQuads(256 * 256));
        const buffer = new Buffer(new Float32Array(32 /* SdfTextConstants.WORDS_PER_QUAD */), false, false);
        this.addAttribute("aVertexPosition", buffer, 2, false, TYPES.FLOAT, 32 /* SdfTextConstants.STRIDE */, 0 /* SdfTextConstants.POS_VERTEX_POSITION */ * 4)
            .addAttribute("aTextureCoord", buffer, 2, false, TYPES.FLOAT, 32 /* SdfTextConstants.STRIDE */, 2 /* SdfTextConstants.POS_TEXTURE_COORD */ * 4)
            .addAttribute("aFWidth", buffer, 1, false, TYPES.FLOAT, 32 /* SdfTextConstants.STRIDE */, 4 /* SdfTextConstants.POS_F_WIDTH */ * 4)
            .addAttribute("aTextureId", buffer, 1, false, TYPES.FLOAT, 32 /* SdfTextConstants.STRIDE */, 5 /* SdfTextConstants.POS_TEXTURE_ID */ * 4)
            .addAttribute("aThickness", buffer, 1, false, TYPES.FLOAT, 32 /* SdfTextConstants.STRIDE */, 6 /* SdfTextConstants.POS_THICKNESS */ * 4)
            .addAttribute("aColor", buffer, 4, true, TYPES.UNSIGNED_BYTE, 32 /* SdfTextConstants.STRIDE */, 7 /* SdfTextConstants.POS_COLOR */ * 4)
            .addIndex(indexBuffer);
    }
}
export class SdfTextRenderer extends ObjectRenderer {
    constructor(renderer) {
        super(renderer);
        this._baseTextureList = [];
        this._baseTextureMap = new Map();
        this._textureIndexMap = new Map();
        this._batch = [];
        this._batchSize = 0;
        this._inputOffset = 0;
        this._geometry = new SdfTextGeometry();
        this._vertexData = new Float32Array(0);
        this._state = State.for2d();
        this._state.blendMode = BLEND_MODES.NORMAL_NPM;
        renderer.runners.contextChange.add(this);
    }
    contextChange() {
        if (!this._shader) {
            const gl = this.renderer.gl;
            this._maxTextures = Math.min(gl.getParameter(gl.MAX_TEXTURE_IMAGE_UNITS), SdfTextRenderer.MAX_TEXTURES);
            this._shader = new SdfTextShader(this._maxTextures);
        }
    }
    addToBatch(renderObject) {
        this._batch.push(renderObject);
        this._batchSize += renderObject.vertexData.length;
    }
    get empty() {
        return this._batch.length == 0;
    }
    renderBatch(size) {
        for (let i = 0; i < this._baseTextureList.length; i += 1) {
            this.renderer.texture.bind(this._baseTextureList[i], i);
        }
        this._geometry.getBuffer("aVertexPosition").update(this._vertexData.subarray(0, size));
        this.renderer.geometry.bind(this._geometry, this._shader);
        this.renderer.geometry.draw(DRAW_MODES.TRIANGLES, 6 /* SdfTextConstants.INDICES_PER_QUAD */ * (size / 32 /* SdfTextConstants.WORDS_PER_QUAD */), 0);
        this._baseTextureList = [];
        this._baseTextureMap.clear();
    }
    processObject(renderObject, offset) {
        const output = this._vertexData;
        const vertexData = this._inputOffset ? renderObject.vertexData.subarray(this._inputOffset) : renderObject.vertexData;
        const size = vertexData.length;
        output.set(vertexData, offset);
        let lastTextureUid = -1;
        let lastTextureId = -1;
        const textureUidMap = renderObject.textureUidMap;
        const textureIndexMap = this._textureIndexMap;
        textureIndexMap.clear();
        for (let i = 5 /* SdfTextConstants.POS_TEXTURE_ID */; i < size; i += 8 /* SdfTextConstants.WORDS_PER_VERTEX */) {
            const textureUid = output[offset + i];
            if (textureUid == lastTextureUid) {
                output[offset + i] = lastTextureId;
            }
            else {
                let textureId = textureIndexMap.get(textureUid);
                if (textureId === undefined) {
                    const baseTexture = textureUidMap.get(textureUid);
                    textureId = this._baseTextureMap.get(baseTexture);
                    if (textureId === undefined) {
                        if (this._baseTextureList.length == this._maxTextures) {
                            this.renderBatch(offset + i - 5 /* SdfTextConstants.POS_TEXTURE_ID */);
                            this._inputOffset += i - 5 /* SdfTextConstants.POS_TEXTURE_ID */;
                            return 0;
                        }
                        else {
                            textureId = this._baseTextureList.length;
                            this._baseTextureList.push(baseTexture);
                            this._baseTextureMap.set(baseTexture, textureId);
                        }
                    }
                    textureIndexMap.set(textureUid, textureId);
                }
                output[offset + i] = textureId;
                lastTextureId = textureId;
                lastTextureUid = textureUid;
            }
        }
        this._inputOffset = 0;
        return vertexData.length;
    }
    flush() {
        if (this._batch.length == 0) {
            return;
        }
        for (let i = 0; i < this._baseTextureList.length; i += 1) {
            this.renderer.texture.bind(this._baseTextureList[i], i);
        }
        this._baseTextureList = [];
        this._baseTextureMap.clear();
        this.renderer.shader.bind(this._shader);
        this.renderer.state.set(this._state);
        let vertexData;
        vertexData = this._vertexData;
        if (vertexData.length < this._batchSize) {
            vertexData = new Float32Array(1 << Math.ceil(Math.log2(this._batchSize) + 0.5));
            this._vertexData = vertexData;
        }
        let offset = 0;
        for (let i = 0; i < this._batch.length; i += 1) {
            const delta = this.processObject(this._batch[i], offset);
            if (delta == 0) {
                offset = 0;
                i -= 1;
            }
            else {
                offset += delta;
            }
        }
        if (offset) {
            this.renderBatch(offset);
        }
        this._batch = [];
        this._batchSize = 0;
    }
}
SdfTextRenderer.MAX_TEXTURES = 32;
SdfTextRenderer.FORCE_BATCH = false;
SdfTextRenderer.extension = {
    name: "sdfText",
    type: ExtensionType.RendererPlugin
};
export default SdfTextRenderer;
//# sourceMappingURL=SdfTextRenderer.js.map