import { SdfTextStyle } from "./SdfTextStyle";
export declare const enum Ascii {
    NEW_LINE = 10,
    CARRIAGE_RETURN = 13,
    SPACE = 32
}
export declare class RichText<T extends RichTextChar = RichTextChar> {
    private static charPool;
    private _defaults;
    private _chars;
    get defaults(): SdfTextStyle;
    set defaults(value: SdfTextStyle);
    get chars(): T[];
    createStyle(source?: SdfTextStyle): SdfTextStyle;
    add(symbol: number, style: SdfTextStyle): void;
    destroy(): void;
}
export interface RichTextChar {
    style: SdfTextStyle;
    symbol: number;
}
export declare class BBParser {
    static ALIGN_VALUES: string[];
    static parse<T extends RichText = RichText>(text: string): T;
}
export default BBParser;
