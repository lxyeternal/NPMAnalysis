export interface SdfFontCharData {
    id: number;
    width: number;
    height: number;
    xoffset: number;
    yoffset: number;
    xadvance: number;
    rotated: boolean;
    x: number;
    y: number;
    page: number;
}
export interface SdfFontInfoData {
    face: string;
    size: number;
}
export interface SdfFontCommonData {
    lineHeight: number;
    base: number;
}
export interface SdfFontDistanceFieldData {
    distanceRange: number;
}
export interface SdfFontKerningData {
    first: number;
    second: number;
    amount: number;
}
export interface SdfFontData {
    pages: string[];
    chars: SdfFontCharData[];
    info: SdfFontInfoData;
    common: SdfFontCommonData;
    distanceField: SdfFontDistanceFieldData;
    kernings: SdfFontKerningData[];
}
export default SdfFontData;
