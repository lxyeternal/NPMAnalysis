import { Renderer } from "@pixi/core";
import { DisplayObject } from "@pixi/display";
export declare class SdfTextFlushBarrier extends DisplayObject {
    sortDirty: boolean;
    calculateBounds(): void;
    removeChild(child: DisplayObject): void;
    render(renderer: Renderer): void;
}
export default SdfTextFlushBarrier;
