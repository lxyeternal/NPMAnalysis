export class RichText {
    constructor() {
        this._defaults = {};
        this._chars = [];
    }
    get defaults() {
        return this._defaults;
    }
    set defaults(value) {
        Object.assign(this._defaults, value);
    }
    get chars() {
        return this._chars;
    }
    createStyle(source) {
        const style = Object.create(this._defaults);
        if (source && source != this._defaults) {
            Object.assign(style, source);
        }
        return style;
    }
    add(symbol, style) {
        const char = (RichText.charPool.pop() || {});
        char.symbol = symbol;
        char.style = style;
        this._chars.push(char);
    }
    destroy() {
        for (let i = 0; i < this._chars.length; i += 1) {
            RichText.charPool.push(this._chars[i]);
        }
        this._chars = null;
    }
}
RichText.charPool = [];
export class BBParser {
    static parse(text) {
        const re = /\\(.)|(\s+)|([^\\\[]+)|\[([a-zA-Z]+)(?:=([a-zA-Z0-9#.-]+))?\]|\[\/([a-zA-Z]+)\]|./g;
        const richText = new RichText();
        let styleStack = [];
        let currentStyle = richText.defaults;
        while (true) {
            const match = re.exec(text);
            if (!match) {
                break;
            }
            if (match[1 /* BBParserGroups.ESCAPE */]) {
                richText.add(match[1 /* BBParserGroups.ESCAPE */].charCodeAt(0), currentStyle);
            }
            else if (match[2 /* BBParserGroups.WHITE_SPACE */]) {
                const str = match[2 /* BBParserGroups.WHITE_SPACE */];
                for (let i = 0; i < str.length; i += 1) {
                    const code = str.charCodeAt(i);
                    if (code == 13 /* Ascii.CARRIAGE_RETURN */) {
                        /* no op */
                    }
                    else if (code == 10 /* Ascii.NEW_LINE */) {
                        richText.add(10 /* Ascii.NEW_LINE */, currentStyle);
                    }
                    else {
                        richText.add(32 /* Ascii.SPACE */, currentStyle);
                    }
                }
            }
            else if (match[3 /* BBParserGroups.TEXT */]) {
                const str = match[3 /* BBParserGroups.TEXT */];
                for (let i = 0; i < str.length; i += 1) {
                    richText.add(str.charCodeAt(i), currentStyle);
                }
            }
            else if (match[4 /* BBParserGroups.OTAG */]) {
                styleStack.push(currentStyle);
                currentStyle = richText.createStyle(currentStyle);
                const tag = match[4 /* BBParserGroups.OTAG */];
                const value = match[5 /* BBParserGroups.OTAG_VALUE */];
                switch (tag) {
                    case "font":
                        if (value) {
                            currentStyle.fontName = value;
                        }
                        break;
                    case "color":
                        if (value) {
                            currentStyle.tint = parseInt(value.slice(1), 16);
                        }
                        break;
                    case "size":
                        if (value) {
                            currentStyle.fontSize = parseFloat(value);
                        }
                        break;
                    case "scale":
                        if (value) {
                            currentStyle.fontScale = parseFloat(value);
                        }
                        break;
                    case "lineSpacing":
                    case "letterSpacing":
                        if (value) {
                            currentStyle[tag] = parseFloat(value);
                        }
                        break;
                    case "align":
                        if (this.ALIGN_VALUES.includes(value)) {
                            currentStyle.align = value;
                        }
                        break;
                    case "thickness":
                        if (value) {
                            currentStyle.thickness = parseFloat(value);
                        }
                        break;
                    case "slant":
                        if (value) {
                            currentStyle.slant = parseFloat(value);
                        }
                        break;
                    default:
                        console.warn("invalid bb tag: ", match[0]);
                }
            }
            else if (match[6 /* BBParserGroups.CTAG */]) {
                if (styleStack.length > 0) {
                    currentStyle = styleStack.pop();
                }
                else {
                    console.warn("failed to close bb tag: ", match[6 /* BBParserGroups.CTAG */]);
                }
            }
            else {
                richText.add(match[0].charCodeAt(0), currentStyle);
                console.warn("invalid bb token: ", match[0]);
            }
        }
        richText.add(10 /* Ascii.NEW_LINE */, currentStyle);
        return richText;
    }
}
BBParser.ALIGN_VALUES = ["left", "center", "right", "justify"];
export default BBParser;
//# sourceMappingURL=BBParser.js.map