import { DisplayObject } from "@pixi/display";
export class SdfTextFlushBarrier extends DisplayObject {
    constructor() {
        super(...arguments);
        this.sortDirty = false;
    }
    calculateBounds() {
        // no-op
    }
    removeChild(child) {
        // no-op
    }
    render(renderer) {
        if (this.visible && this.renderable) {
            const plugin = renderer.plugins.sdfText;
            if (!plugin.empty) {
                renderer.batch.flush();
                plugin.flush();
            }
        }
    }
}
export default SdfTextFlushBarrier;
//# sourceMappingURL=SdfTextFlushBarrier.js.map