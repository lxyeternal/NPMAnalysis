import { BaseElement, BaseElementConfig } from "./BaseElement";
import { PixiLayoutFactory } from "./PixiLayoutFactory";
import { DisplayObject } from "@pixi/display";
import { Renderer } from "@pixi/core";
declare class PortalContainer extends DisplayObject {
    sortDirty: boolean;
    children: DisplayObject[];
    alphaControl: boolean;
    constructor();
    calculateBounds(): void;
    updateTransform(): void;
    render(renderer: Renderer): void;
    addChild(child: DisplayObject): void;
    addChildAt(child: DisplayObject, index: number): void;
    getChildIndex(child: DisplayObject): number;
    removeChild(child: DisplayObject): void;
    removeChildAt(index: number): void;
}
export interface PortalElementConfig extends BaseElementConfig<"portal", PortalElement> {
    alphaControl?: boolean;
}
export declare class PortalElement extends BaseElement<PortalContainer> {
    static register(factory: PixiLayoutFactory): void;
    private constructor();
    add(element: BaseElement | DisplayObject): void;
    remove(element: BaseElement | DisplayObject): void;
    get alphaControl(): boolean;
    set alphaControl(value: boolean);
}
declare module "./ElementTypes" {
    interface ElementTypes {
        "portal": PortalElementConfig;
    }
}
export {};
