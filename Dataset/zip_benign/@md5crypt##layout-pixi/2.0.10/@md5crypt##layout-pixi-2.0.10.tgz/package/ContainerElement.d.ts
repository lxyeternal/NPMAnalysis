import { BaseElement, BaseElementConfig } from "./BaseElement";
import { PixiLayoutFactory } from "./PixiLayoutFactory";
import { Container } from "@pixi/display";
import { Graphics } from "@pixi/graphics";
import { Sprite } from "@pixi/sprite";
export interface ContainerElementConfig<TYPE extends string = "container", SELF extends ContainerElement = ContainerElement> extends BaseElementConfig<TYPE, SELF> {
    mask?: boolean;
    sorted?: boolean;
}
export declare class ContainerElement<HANDLE extends Container = Container> extends BaseElement<HANDLE> {
    static register(factory: PixiLayoutFactory): void;
    private _mask;
    private _maskObject?;
    protected constructor(factory: PixiLayoutFactory, config: ContainerElementConfig<any, any>, handle: HANDLE);
    set interactive(value: boolean);
    get interactive(): boolean;
    get sorted(): boolean;
    set sorted(value: boolean);
    get mask(): boolean;
    set mask(value: boolean);
    get maskObject(): Sprite | Graphics | BaseElement | null;
    set maskObject(value: Sprite | Graphics | BaseElement | null);
    protected onRemoveElement(index: number): void;
    protected onInsertElement(element: BaseElement, index: number): void;
    protected onUpdate(): void;
}
export default ContainerElement;
declare module "./ElementTypes" {
    interface ElementTypes {
        container: ContainerElementConfig;
    }
}
