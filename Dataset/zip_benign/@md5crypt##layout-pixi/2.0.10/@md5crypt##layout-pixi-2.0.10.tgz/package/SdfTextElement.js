import { BaseElement } from "./BaseElement";
import { SdfText } from "./sdfText/index";
import { Rectangle } from "@pixi/math";
export class SdfTextElement extends BaseElement {
    static register(factory) {
        factory.register("text-sdf", config => new this(factory, config));
    }
    constructor(factory, config) {
        super(factory, config, new SdfText());
        this._fit = false;
        this._verticalAlign = "top";
        this._horizontalAlign = "left";
        this._lastSize = [0, 0];
        this._wordWrap = false;
        if (config.style) {
            this.handle.updateStyle(config.style);
        }
        if (config.text) {
            this.handle.text = config.text;
        }
        if (config.fit) {
            this._fit = true;
        }
        if (config.verticalAlign) {
            this._verticalAlign = config.verticalAlign;
        }
        if (config.horizontalAlign) {
            this._horizontalAlign = config.horizontalAlign;
        }
        if (config.wordWrap) {
            this._wordWrap = true;
        }
        if (config.flush !== undefined) {
            this.handle.flush = config.flush;
        }
        if (config.forceBatch !== undefined) {
            this.handle.flush = config.forceBatch;
        }
    }
    get contentHeight() {
        if (this._wordWrap) {
            this.handle.wordWrapWidth = this.computedWidth;
        }
        else {
            this.handle.wordWrapWidth = 0;
        }
        return this.handle.height;
    }
    get contentWidth() {
        if (this._wordWrap) {
            this.handle.wordWrapWidth = this.computedWidth;
        }
        else {
            this.handle.wordWrapWidth = 0;
        }
        return this.handle.width;
    }
    get fit() {
        return this._fit;
    }
    set fit(value) {
        if (this._fit != value) {
            this._fit = value;
            this._lastSize[0] = -1;
            this._lastSize[1] = -1;
            this.setDirty();
        }
    }
    get verticalAlign() {
        return this._verticalAlign;
    }
    set verticalAlign(value) {
        if (this._verticalAlign != value) {
            this._verticalAlign = value;
            this.setDirty();
        }
    }
    get horizontalAlign() {
        return this._horizontalAlign;
    }
    set horizontalAlign(value) {
        if (this._horizontalAlign != value) {
            this._horizontalAlign = value;
            this.setDirty();
        }
    }
    get wordWrap() {
        return this._wordWrap;
    }
    set wordWrap(value) {
        if (this._wordWrap != value) {
            this._lastSize[0] = -1;
            this._lastSize[1] = -1;
            this._wordWrap = value;
            this.setDirty();
        }
    }
    get text() {
        return this.handle.text;
    }
    set text(value) {
        if (this.handle.text != value) {
            this.handle.text = value;
            this.setDirty();
        }
    }
    get flush() {
        return this.handle.flush;
    }
    set flush(value) {
        this.handle.flush = value;
    }
    get forceBatch() {
        return this.handle.flush;
    }
    set forceBatch(value) {
        this.handle.forceBatch = value;
    }
    setStyle(style) {
        this.handle.setStyle(style);
        this.setDirty();
    }
    updateStyle(style) {
        this.handle.updateStyle(style);
        this.setDirty();
    }
    fitWrappedText(height) {
        let upperBound = 1;
        let lowerBound = height / this.handle.height;
        let lastSize = upperBound;
        if (lowerBound >= upperBound) {
            return;
        }
        for (let i = 0; i < 8; i += 1) {
            const currentSize = (upperBound + lowerBound) / 2;
            if (Math.abs(currentSize - lastSize) / lastSize < 0.02) {
                break;
            }
            this.handle.fontScale = currentSize;
            lastSize = currentSize;
            const scale = height / this.handle.height;
            if (scale > 1) {
                lowerBound = currentSize;
                upperBound = Math.min(upperBound, currentSize * scale);
            }
            else if (scale < 1) {
                lowerBound = Math.max(lowerBound, currentSize * scale);
                upperBound = currentSize;
            }
            else {
                return;
            }
        }
        this.handle.fontScale = lowerBound;
    }
    onUpdate() {
        const width = this.computedWidth;
        const height = this.computedHeight;
        this.handle.wordWrapWidth = this._wordWrap ? width : 0;
        this.handle.fontScale = 1;
        if (this.handle.dirty || width != this._lastSize[0] || height != this._lastSize[1]) {
            if (this._fit) {
                if (this._wordWrap) {
                    this.fitWrappedText(height);
                }
                else {
                    this.handle.fontScale = Math.min(1, width / this.handle.width, height / this.handle.height);
                }
            }
        }
        this._lastSize[0] = width;
        this._lastSize[1] = height;
        let left = 0;
        let top = 0;
        if (this._verticalAlign == "middle") {
            top = (height - this.contentHeight) / 2;
        }
        else if (this._verticalAlign == "baseline") {
            top = (height - this.contentHeight - 2 * this.handle.baseLineOffset) / 2;
        }
        else if (this._verticalAlign == "bottom") {
            top = height - this.contentHeight;
        }
        if (this._horizontalAlign == "center") {
            left = (width - this.contentWidth) / 2;
        }
        else if (this._horizontalAlign == "right") {
            left = width - this.contentWidth;
        }
        if (this.handle.interactive) {
            this.handle.hitArea = new Rectangle(0, 0, width, height);
        }
        this.handle.pivot.set(width * this._xPivot - left, height * this._yPivot - top);
        this.handle.scale.set(this._scale);
        this.applyFlip();
        this.handle.position.set(this.pivotedLeft, this.pivotedTop);
    }
}
//# sourceMappingURL=SdfTextElement.js.map