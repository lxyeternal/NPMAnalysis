import { BaseElement } from "./BaseElement";
import { TilingSprite } from "@pixi/sprite-tiling";
export class TiledSpriteElement extends BaseElement {
    static register(factory) {
        factory.register("sprite-tiled", config => new this(factory, config, new TilingSprite(factory.resolveAsset(config.image))));
    }
    constructor(factory, config, handle) {
        super(factory, config, handle);
        if (config.tint !== undefined) {
            this.handle.tint = config.tint;
        }
        if (config.clampMargin !== undefined) {
            this.clampMargin = config.clampMargin;
        }
        if (config.roundPixels !== undefined) {
            this.handle.roundPixels = config.roundPixels;
        }
        if (config.blendMode !== undefined) {
            this.handle.blendMode = config.blendMode;
        }
    }
    get image() {
        return this.handle.texture;
    }
    set image(value) {
        const texture = this.factory.resolveAsset(value);
        if (this.handle.texture != texture) {
            this.handle.texture = texture;
            this.setDirty();
        }
    }
    get tint() {
        return this.handle.tint;
    }
    set tint(value) {
        this.handle.tint = value;
    }
    get blendMode() {
        return this.handle.blendMode;
    }
    set blendMode(value) {
        this.handle.blendMode = value;
    }
    get roundPixels() {
        return this.handle.roundPixels;
    }
    set roundPixels(value) {
        this.handle.roundPixels = value;
    }
    set clampMargin(value) {
        this.handle.clampMargin = value;
    }
    get clampMargin() {
        return this.handle.clampMargin;
    }
    onUpdate() {
        const width = this.computedWidth;
        const height = this.computedHeight;
        this.handle.width = width;
        this.handle.height = height;
        this.handle.position.set(this.pivotedLeft, this.pivotedTop);
        this.handle.pivot.set(width * this._xPivot, height * this._yPivot);
        this.handle.scale.set(this._scale);
        this.applyFlip();
    }
    get contentHeight() {
        return this.handle.texture.height;
    }
    get contentWidth() {
        return this.handle.texture.width;
    }
}
export default TiledSpriteElement;
//# sourceMappingURL=TiledSpriteElement.js.map