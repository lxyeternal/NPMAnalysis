import { ContainerElement, ContainerElementConfig } from "./ContainerElement";
import { PixiLayoutFactory } from "./PixiLayoutFactory";
import { Container3d } from "./projection/proj3d/Container3d";
export interface Container3dElementConfig extends ContainerElementConfig<"container-3d", Container3dElement> {
}
export declare class Container3dElement extends ContainerElement<Container3d> {
    static register(factory: PixiLayoutFactory): void;
    get zScale(): number;
    set zScale(value: number);
    get zPosition(): number;
    set zPosition(value: number);
    get zPivot(): number;
    set zPivot(value: number);
    get euler(): import("./projection").ObservableEuler<any>;
}
export default Container3dElement;
declare module "./ElementTypes" {
    interface ElementTypes {
        "container-3d": Container3dElementConfig;
    }
}
