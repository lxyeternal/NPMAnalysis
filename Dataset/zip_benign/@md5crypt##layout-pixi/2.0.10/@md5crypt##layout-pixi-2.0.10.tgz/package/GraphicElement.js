import { BaseElement } from "./BaseElement";
import { Graphics } from "@pixi/graphics";
import { Rectangle } from "@pixi/math";
export class GraphicElement extends BaseElement {
    static register(factory) {
        factory.register("graphic", config => new this(factory, config));
    }
    constructor(factory, config) {
        super(factory, config, new Graphics());
        this.autoClear = true;
        this._onDraw = config.onDraw;
        if (config.blendMode !== undefined) {
            this.handle.blendMode = config.blendMode;
        }
        if (config.autoClear !== undefined) {
            this.autoClear = config.autoClear;
        }
        if (config.tint !== undefined) {
            this.handle.tint = config.tint;
        }
    }
    get onDraw() {
        return this._onDraw;
    }
    set onDraw(value) {
        this._onDraw = value;
        this.setDirty();
    }
    get blendMode() {
        return this.handle.blendMode;
    }
    set blendMode(value) {
        this.handle.blendMode = value;
    }
    get tint() {
        return this.handle.tint;
    }
    set tint(value) {
        this.handle.tint = value;
    }
    onUpdate() {
        const width = this.computedWidth;
        const height = this.computedHeight;
        if (this.handle.interactive) {
            this.handle.hitArea = new Rectangle(0, 0, width, height);
        }
        this.handle.position.set(this.pivotedLeft, this.pivotedTop);
        this.handle.pivot.set(width * this._xPivot, height * this._yPivot);
        this.handle.scale.set(this._scale);
        this.applyFlip();
        if (this.autoClear) {
            this.handle.clear();
        }
        if (this._onDraw) {
            this._onDraw(this);
        }
    }
}
export default GraphicElement;
//# sourceMappingURL=GraphicElement.js.map