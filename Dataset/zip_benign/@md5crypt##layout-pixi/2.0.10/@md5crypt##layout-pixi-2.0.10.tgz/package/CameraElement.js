import { ContainerElement } from "./ContainerElement";
import { Camera3d } from "./projection/proj3d/Camera3d";
export class CameraElement extends ContainerElement {
    static register(factory) {
        factory.register("camera", props => new this(factory, props));
    }
    constructor(factory, config) {
        super(factory, config, new Camera3d());
        this._projectionOffsetX = 0;
        this._projectionOffsetY = 0;
        this._projectionAnchorX = 0.5;
        this._projectionAnchorY = 0.5;
        if (config.focus !== undefined) {
            this.handle.focus = config.focus;
        }
        if (config.near !== undefined) {
            this.handle.near = config.near;
        }
        if (config.far !== undefined) {
            this.handle.far = config.far;
        }
        if (config.orthographic !== undefined) {
            this.handle.orthographic = config.orthographic;
        }
        if (config.projectionOffset !== undefined) {
            this._projectionOffsetX = config.projectionOffset[0];
            this._projectionOffsetY = config.projectionOffset[1];
        }
        if (config.projectionAnchor !== undefined) {
            if (typeof config.projectionAnchor == "number") {
                this._projectionAnchorX = config.projectionAnchor;
                this._projectionAnchorY = config.projectionAnchor;
            }
            else {
                this._projectionAnchorX = config.projectionAnchor[0];
                this._projectionAnchorY = config.projectionAnchor[1];
            }
        }
    }
    set focus(value) {
        this.handle.focus = value;
    }
    get focus() {
        return this.handle.focus;
    }
    set near(value) {
        this.handle.near = value;
    }
    get near() {
        return this.handle.near;
    }
    set far(value) {
        this.handle.far = value;
    }
    get far() {
        return this.handle.far;
    }
    set orthographic(value) {
        this.handle.orthographic = value;
    }
    get orthographic() {
        return this.handle.orthographic;
    }
    get position3d() {
        return this.handle.transform.position3d;
    }
    get pivot3d() {
        return this.handle.transform.pivot3d;
    }
    get scale3d() {
        return this.handle.transform.scale3d;
    }
    set projectionOffsetX(value) {
        if (this._projectionOffsetX != value) {
            this._projectionOffsetX = value;
            this.setDirty();
        }
    }
    get projectionOffsetX() {
        return this._projectionOffsetX;
    }
    set projectionOffsetY(value) {
        if (this._projectionOffsetY != value) {
            this._projectionOffsetY = value;
            this.setDirty();
        }
    }
    get projectionOffsetY() {
        return this._projectionOffsetY;
    }
    set projectionAnchorX(value) {
        if (this._projectionAnchorX != value) {
            this._projectionAnchorX = value;
            this.setDirty();
        }
    }
    get projectionAnchorX() {
        return this._projectionAnchorX;
    }
    set projectionAnchorY(value) {
        if (this._projectionAnchorY != value) {
            this._projectionAnchorY = value;
            this.setDirty();
        }
    }
    get projectionAnchorY() {
        return this._projectionAnchorY;
    }
    onUpdate() {
        super.onUpdate();
        const scale = this._scale;
        const offsetX = this._projectionOffsetX + this.computedWidth * this._projectionAnchorX;
        const offsetY = this._projectionOffsetY + this.computedHeight * this._projectionAnchorY;
        this.handle.position3d.set(offsetX, offsetY);
        this.handle.position.x += offsetX * scale;
        this.handle.position.y += offsetY * scale;
    }
}
export default CameraElement;
//# sourceMappingURL=CameraElement.js.map