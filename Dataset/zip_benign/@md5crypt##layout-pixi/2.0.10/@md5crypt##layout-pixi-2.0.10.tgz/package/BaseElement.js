import { LayoutElement } from "@md5crypt/layout";
import { Matrix } from "@pixi/math";
export class BaseElement extends LayoutElement {
    constructor(factory, config, handle) {
        super(factory, config);
        this.handle = handle;
        this._flipped = false;
        this._xPivot = 0.5;
        this._yPivot = 0.5;
        if (config.enabled === false) {
            this.handle.visible = false;
        }
        if (config.zIndex) {
            this.handle.zIndex = config.zIndex;
        }
        if (config.interactive) {
            this.interactive = true;
        }
        if (config.noPropagation) {
            this.noPropagation = true;
        }
        if (config.alpha !== undefined) {
            this.alpha = config.alpha;
        }
        if (config.rotation) {
            this.rotation = config.rotation;
        }
        if (config.flipped) {
            this.flipped = config.flipped;
        }
        if (config.pivot) {
            if (Array.isArray(config.pivot)) {
                this._xPivot = config.pivot[0];
                this._yPivot = config.pivot[1];
            }
            else {
                this._xPivot = config.pivot;
                this._yPivot = config.pivot;
            }
        }
        if (config.buttonMode !== undefined) {
            this.handle.buttonMode = config.buttonMode;
        }
    }
    /** apply the flip value by setting scale sign */
    applyFlip() {
        const value = this._flipped;
        if (value == "vertical") {
            this.handle.scale.x = Math.abs(this.handle.scale.x);
            this.handle.scale.y = -Math.abs(this.handle.scale.y);
        }
        else if (value == "horizontal") {
            this.handle.scale.x = -Math.abs(this.handle.scale.x);
            this.handle.scale.y = Math.abs(this.handle.scale.y);
        }
        else {
            this.handle.scale.x = Math.abs(this.handle.scale.x);
            this.handle.scale.y = Math.abs(this.handle.scale.y);
        }
    }
    on(event, arg1, arg2) {
        if (arg2 === undefined) {
            this.handle.on(event, arg1);
            return arg1;
        }
        else if (typeof arg1 == "string") {
            this.getElement(arg1).on(event, arg2);
            return arg2;
        }
        else {
            for (let i = 0; i < arg1.length; i += 1) {
                this.getElement(arg1[i]).on(event, arg2);
            }
            return arg2;
        }
    }
    /**
     * calculate the transform matrix for this element
     *
     * it will not necessary be the same as the underlying PIXI's objects localTransform
     *
     * the matrix is not cached and created on demand
     *
     * @param matrix - by default a new matrix is created each call, if an matrix is passed it will be used instead
     * of creating a new object
     *
     * @returns the resulting matrix
     */
    getLocalMatrix(matrix) {
        if (!matrix) {
            matrix = new Matrix();
        }
        else {
            matrix.identity();
        }
        matrix.translate(-this.computedWidth * this.xPivot, -this.computedHeight * this._yPivot);
        matrix.rotate(this.handle.rotation);
        matrix.scale(this._scale, this._scale);
        matrix.translate(this.pivotedLeft, this.pivotedTop);
        return matrix;
    }
    /**
     * get scale as set on pixi world transform
     * note that this value updates only when world transform updates so before render
     *
     * @returns element global scale
     */
    get globalScale() {
        const transform = this.handle.worldTransform;
        return Math.sqrt(transform.a * transform.a + transform.b * transform.b);
    }
    /** final left value that should be used by display objects */
    get pivotedLeft() {
        return this.computedLeft + this._scale * this._xPivot * this.computedWidth;
    }
    /** final top value that should be used by display objects */
    get pivotedTop() {
        return this.computedTop + this._scale * this._yPivot * this.computedHeight;
    }
    get enabled() {
        return this._enabled;
    }
    set enabled(value) {
        if (this._enabled != value) {
            this.handle.visible = value;
            this._enabled = value;
            this.setDirty();
        }
    }
    /** {@inheritDoc BaseElementConfig.zIndex} */
    get zIndex() {
        return this.handle.zIndex;
    }
    set zIndex(value) {
        this.handle.zIndex = value;
    }
    /** {@inheritDoc BaseElementConfig.alpha} */
    get alpha() {
        return this.handle.alpha;
    }
    set alpha(value) {
        this.handle.alpha = value;
    }
    /** {@inheritDoc BaseElementConfig.rotation} */
    get rotation() {
        return this.handle.angle;
    }
    set rotation(value) {
        this.handle.angle = value;
    }
    /** {@inheritDoc BaseElementConfig.flipped} */
    get flipped() {
        return this._flipped || false;
    }
    set flipped(value) {
        if (this._flipped != value) {
            this._flipped = value;
            this.setDirty();
        }
    }
    /** {@inheritDoc BaseElementConfig.interactive} */
    get interactive() {
        return this.handle.interactive || false;
    }
    set interactive(value) {
        this.handle.interactive = value;
    }
    /** {@inheritDoc BaseElementConfig.noPropagation} */
    get noPropagation() {
        return !this.handle.interactiveChildren;
    }
    set noPropagation(value) {
        this.handle.interactiveChildren = !value;
    }
    /** x component of rotation pivot point */
    get xPivot() {
        return this._xPivot;
    }
    set xPivot(value) {
        if (this._xPivot != value) {
            this._xPivot = value;
            this.setDirty();
        }
    }
    /** y component of rotation pivot point */
    get yPivot() {
        return this._yPivot;
    }
    set yPivot(value) {
        if (this._yPivot != value) {
            this._yPivot = value;
            this.setDirty();
        }
    }
    /** {@inheritDoc BaseElementConfig.buttonMode} */
    get buttonMode() {
        return this.handle.buttonMode;
    }
    set buttonMode(value) {
        this.handle.buttonMode = value;
    }
}
//# sourceMappingURL=BaseElement.js.map