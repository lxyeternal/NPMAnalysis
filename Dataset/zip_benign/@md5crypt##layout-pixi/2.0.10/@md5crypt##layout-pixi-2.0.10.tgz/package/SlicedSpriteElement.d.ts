import { BaseElementConfig, BlendMode } from "./BaseElement";
import { PixiLayoutFactory } from "./PixiLayoutFactory";
import { Texture } from "@pixi/core";
import { SpriteElement } from "./SpriteElement";
import { SliceConfiguration, SpriteSliced } from "./9slice/index";
export interface SlicedSpriteElementConfig extends BaseElementConfig<"sprite-sliced", SlicedSpriteElement> {
    image?: Texture | string;
    tint?: number;
    slices?: SliceConfiguration | number;
    scaling?: "width" | "height" | "none";
    roundPixels?: boolean;
    blendMode?: BlendMode;
}
export declare class SlicedSpriteElement extends SpriteElement {
    static register(factory: PixiLayoutFactory): void;
    protected constructor(factory: PixiLayoutFactory, config: SlicedSpriteElementConfig, handle: SpriteSliced);
    set scaling(value: any);
    get scaling(): any;
}
declare module "./ElementTypes" {
    interface ElementTypes {
        "sprite-sliced": SlicedSpriteElementConfig;
    }
}
