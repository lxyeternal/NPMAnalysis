import { BaseElement } from "./BaseElement";
import { RenderBarrier } from "./renderBarrier/RenderBarrier";
export class RenderBarrierElement extends BaseElement {
    static register(factory) {
        factory.register("render-barrier", config => new this(factory, config));
    }
    constructor(factory, config) {
        super(factory, config, new RenderBarrier());
        if (config.barrierId !== undefined) {
            this.handle.barrierId = config.barrierId;
        }
    }
    set barrierId(value) {
        this.handle.barrierId = value;
    }
    get barreirId() {
        return this.handle.barrierId;
    }
}
//# sourceMappingURL=RenderBarrierElement.js.map