import { Rectangle } from "@pixi/math";
import { BaseElement } from "./BaseElement";
import { ParticleContainer } from "./particles/ParticleContainer";
export class ParticleContainerElement extends BaseElement {
    static register(factory) {
        factory.register("container-particle", config => new this(factory, config));
    }
    constructor(factory, config) {
        super(factory, config, new ParticleContainer());
        if (config.blendMode !== undefined) {
            this.handle.blendMode = config.blendMode;
        }
        if (config.baseTexture) {
            this.baseTexture = config.baseTexture;
        }
    }
    onUpdate() {
        const width = this.computedWidth;
        const height = this.computedHeight;
        if (this.handle.interactive) {
            this.handle.hitArea = new Rectangle(0, 0, width, height);
        }
        this.handle.position.set(this.pivotedLeft, this.pivotedTop);
        this.handle.pivot.set(width * this._xPivot, height * this._yPivot);
        this.handle.scale.set(this._scale);
        this.applyFlip();
    }
    get blendMode() {
        return this.handle.blendMode;
    }
    set blendMode(value) {
        this.handle.blendMode = value;
    }
    get baseTexture() {
        return this.handle.baseTexture;
    }
    set baseTexture(value) {
        this.handle.baseTexture = typeof value == "string" ? this.factory.resolveAsset(value).baseTexture : value;
    }
}
//# sourceMappingURL=ParticleContainerElement.js.map