import { BaseElement, BaseElementConfig, BlendMode } from "./BaseElement";
import { PixiLayoutFactory } from "./PixiLayoutFactory";
import { Text, ITextStyle } from "@pixi/text";
export interface TextElementConfig extends BaseElementConfig<"text", TextElement> {
    text?: string;
    fit?: boolean;
    verticalAlign?: "top" | "bottom" | "middle";
    style?: Partial<ITextStyle>;
    resolution?: number;
    roundPixels?: boolean;
    blendMode?: BlendMode;
    tint?: number;
}
export declare class TextElement extends BaseElement<Text> {
    static defaultResolution: number;
    static register(factory: PixiLayoutFactory): void;
    private _style;
    private _text;
    private _textRect;
    private _fit;
    private _verticalAlign;
    private _lastSize;
    protected constructor(factory: PixiLayoutFactory, config: TextElementConfig);
    private meausreText;
    set resolution(value: number);
    get resolution(): number;
    get contentHeight(): number;
    get contentWidth(): number;
    get fit(): boolean;
    set fit(value: boolean);
    get roundPixels(): boolean;
    set roundPixels(value: boolean);
    get verticalAlign(): "top" | "bottom" | "middle";
    set verticalAlign(value: "top" | "bottom" | "middle");
    get text(): string;
    set text(value: string);
    get tint(): number;
    set tint(value: number);
    get style(): Readonly<Partial<ITextStyle>>;
    setStyle(style: Partial<ITextStyle>): void;
    updateStyle(style: Partial<ITextStyle>): void;
    setText(text: string, style?: Partial<ITextStyle>): void;
    get blendMode(): BlendMode;
    set blendMode(value: BlendMode);
    private updateFontSize;
    private fitText;
    private fitWrappedText;
    protected redraw(): void;
    protected onUpdate(): void;
}
export default TextElement;
declare module "./ElementTypes" {
    interface ElementTypes {
        text: TextElementConfig;
    }
}
