export {};
//# sourceMappingURL=ElementTypes.js.map