import { ContainerElement, ContainerElementConfig } from "./ContainerElement";
import type { PixiLayoutFactory } from "./PixiLayoutFactory";
import { Camera3d } from "./projection/proj3d/Camera3d";
export interface CameraElementConfig extends ContainerElementConfig<"camera", CameraElement> {
    position3d?: {
        x?: number;
        y?: number;
        z?: number;
    };
    focus?: number;
    near?: number;
    far?: number;
    orthographic?: boolean;
    projectionOffset?: number[];
    projectionAnchor?: number[] | number;
}
export declare class CameraElement extends ContainerElement<Camera3d> {
    private _projectionOffsetX;
    private _projectionOffsetY;
    private _projectionAnchorX;
    private _projectionAnchorY;
    static register(factory: PixiLayoutFactory): void;
    private constructor();
    set focus(value: number);
    get focus(): number;
    set near(value: number);
    get near(): number;
    set far(value: number);
    get far(): number;
    set orthographic(value: boolean);
    get orthographic(): boolean;
    get position3d(): import("./projection").ObservablePoint3d<any>;
    get pivot3d(): import("./projection").ObservablePoint3d<any>;
    get scale3d(): import("./projection").ObservablePoint3d<any>;
    set projectionOffsetX(value: number);
    get projectionOffsetX(): number;
    set projectionOffsetY(value: number);
    get projectionOffsetY(): number;
    set projectionAnchorX(value: number);
    get projectionAnchorX(): number;
    set projectionAnchorY(value: number);
    get projectionAnchorY(): number;
    protected onUpdate(): void;
}
export default CameraElement;
declare module "./ElementTypes" {
    interface ElementTypes {
        "camera": CameraElementConfig;
    }
}
