import { BaseElement, BaseElementConfig } from "./BaseElement";
import { PixiLayoutFactory } from "./PixiLayoutFactory";
import { SdfTextFlushBarrier } from "./sdfText/index";
export interface SdfTextFlushBarrierElementConfig extends BaseElementConfig<"text-sdf-barrier", SdfTextFlushBarrierElement> {
}
export declare class SdfTextFlushBarrierElement extends BaseElement<SdfTextFlushBarrier> {
    static register(factory: PixiLayoutFactory): void;
    protected constructor(factory: PixiLayoutFactory, config: SdfTextFlushBarrierElementConfig);
}
declare module "./ElementTypes" {
    interface ElementTypes {
        "text-sdf-barrier": SdfTextFlushBarrierElementConfig;
    }
}
