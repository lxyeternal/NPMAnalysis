import { BaseElement, BaseElementConfig, BlendMode } from "./BaseElement";
import { PixiLayoutFactory } from "./PixiLayoutFactory";
import { Texture } from "@pixi/core";
import { SliceConfiguration, SpriteSliced } from "./9slice/index";
type ScalingType = ("none" | "clipped" | "contain" | "stretch" | "cover" | "cover-vertical" | "cover-horizontal" | "sliced" | "sliced-horizontal" | "sliced-vertical");
export interface SpriteElementConfig<TYPE extends string = "sprite", SELF extends SpriteElement = SpriteElement> extends BaseElementConfig<TYPE, SELF> {
    image?: Texture | string;
    scaling?: ScalingType;
    slices?: SliceConfiguration | number;
    verticalAlign?: "top" | "middle" | "bottom";
    horizontalAlign?: "left" | "center" | "right";
    tint?: number;
    roundPixels?: boolean;
    blendMode?: BlendMode;
}
export declare class SpriteElement<HANDLE extends SpriteSliced = SpriteSliced> extends BaseElement<HANDLE> {
    private _scaling;
    private _texture;
    private _yAlign;
    private _xAlign;
    static register(factory: PixiLayoutFactory): void;
    protected constructor(factory: PixiLayoutFactory, config: Readonly<SpriteElementConfig<any, any>>, handle: HANDLE);
    get image(): Texture | string | null;
    set image(value: Texture | string | null);
    get tint(): number;
    set tint(value: number);
    get roundPixels(): boolean;
    set roundPixels(value: boolean);
    get scaling(): ScalingType;
    set scaling(value: ScalingType);
    get yAlign(): number;
    set yAlign(value: number);
    get xAlign(): number;
    set xAlign(value: number);
    get verticalAlign(): "top" | "middle" | "bottom";
    set verticalAlign(value: "top" | "middle" | "bottom");
    get horizontalAlign(): "left" | "center" | "right";
    set horizontalAlign(value: "left" | "center" | "right");
    get blendMode(): BlendMode;
    set blendMode(value: BlendMode);
    crop(rect: number[] | null, setDirty?: boolean): void;
    setSlices(slices: SliceConfiguration | number): void;
    protected onUpdate(): void;
    get contentHeight(): number;
    get contentWidth(): number;
}
export default SpriteElement;
declare module "./ElementTypes" {
    interface ElementTypes {
        sprite: SpriteElementConfig;
    }
}
