import { BaseElement } from "./BaseElement";
import { Container } from "@pixi/display";
import { Rectangle } from "@pixi/math";
import { Graphics } from "@pixi/graphics";
export class ContainerElement extends BaseElement {
    static register(factory) {
        factory.register("container", config => new this(factory, config, new Container()));
    }
    constructor(factory, config, handle) {
        super(factory, config, handle);
        this._mask = false;
        if (config.scale) {
            this._scale = config.scale;
        }
        if (config.mask) {
            this._mask = true;
        }
        if (config.sorted && this.handle) {
            this.handle.sortableChildren = true;
        }
    }
    set interactive(value) {
        if (super.interactive != value) {
            super.interactive = value;
            this.setDirty();
        }
    }
    get interactive() {
        return super.interactive;
    }
    get sorted() {
        return this.handle.sortableChildren;
    }
    set sorted(value) {
        this.handle.sortableChildren = value;
    }
    get mask() {
        return this.handle.mask != null;
    }
    set mask(value) {
        if (this._mask != value) {
            if (this._mask) {
                if (this.handle.mask) {
                    if (!this._maskObject) {
                        this.handle.removeChild(this.handle.mask);
                    }
                    this.handle.mask = null;
                }
            }
            else {
                this.setDirty();
            }
            this._mask = value;
        }
    }
    get maskObject() {
        return this._maskObject || null;
    }
    set maskObject(value) {
        if (this.handle.mask && !this._maskObject) {
            this.handle.removeChild(this.handle.mask);
        }
        this._maskObject = value instanceof BaseElement ? value.handle : (value || undefined);
        this.handle.mask = null;
        this.setDirty();
    }
    onRemoveElement(index) {
        this.handle.removeChild(this.children[index].handle);
    }
    onInsertElement(element, index) {
        if ((index >= this.children.length) || this.handle.sortableChildren) {
            this.handle.addChild(element.handle);
        }
        else {
            const position = this.handle.getChildIndex(this.children[index].handle);
            this.handle.addChildAt(element.handle, position);
        }
    }
    onUpdate() {
        const width = this.computedWidth;
        const height = this.computedHeight;
        if (this._mask) {
            if (this._maskObject) {
                this.handle.mask = this._maskObject;
            }
            else {
                const graphics = new Graphics();
                graphics.beginFill(0xFFFFFF);
                graphics.drawRect(0, 0, width, height);
                graphics.endFill();
                if (this.handle.mask) {
                    this.handle.removeChild(this.handle.mask);
                }
                this.handle.addChild(graphics);
                this.handle.mask = graphics;
            }
        }
        if (this.handle.interactive) {
            this.handle.hitArea = new Rectangle(0, 0, width, height);
        }
        this.handle.position.set(this.pivotedLeft, this.pivotedTop);
        this.handle.pivot.set(width * this._xPivot, height * this._yPivot);
        this.handle.scale.set(this._scale);
        this.applyFlip();
    }
}
export default ContainerElement;
//# sourceMappingURL=ContainerElement.js.map