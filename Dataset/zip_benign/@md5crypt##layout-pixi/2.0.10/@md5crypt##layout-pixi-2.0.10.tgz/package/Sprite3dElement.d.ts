import type { PixiLayoutFactory } from "./PixiLayoutFactory";
import { Sprite3d } from "./projection/proj3d/Sprite3d";
import { Texture } from "@pixi/core";
import { BaseElement, BaseElementConfig, BlendMode } from "./BaseElement";
export interface Sprite3dElementConfig extends BaseElementConfig<"sprite-3d", Sprite3dElement> {
    image?: Texture | string;
    backImage?: Texture | string;
    tint?: number;
    blendMode?: BlendMode;
    faces?: "both" | "front" | "back" | "none";
    mirrorBackImage?: "vertical" | "horizontal";
}
export declare class Sprite3dElement extends BaseElement<Sprite3d> {
    static register(factory: PixiLayoutFactory): void;
    protected constructor(factory: PixiLayoutFactory, config: Sprite3dElementConfig);
    protected onUpdate(): void;
    get contentHeight(): number;
    get contentWidth(): number;
    set interactive(value: boolean);
    get interactive(): boolean;
    get image(): Texture | string | null;
    set image(value: Texture | string | null);
    get backImage(): Texture | string | null;
    set backImage(value: Texture | string | null);
    get mirrorBackImage(): null | "vertical" | "horizontal";
    set mirrorBackImage(value: null | "vertical" | "horizontal");
    get faces(): "none" | "front" | "back" | "both";
    set faces(value: "none" | "front" | "back" | "both");
    get tint(): number;
    set tint(value: number);
    get blendMode(): BlendMode;
    set blendMode(value: BlendMode);
    get zScale(): number;
    set zScale(value: number);
    get zPosition(): number;
    set zPosition(value: number);
    get zPivot(): number;
    set zPivot(value: number);
    get euler(): import("./projection").ObservableEuler<any>;
}
export default Sprite3dElement;
declare module "./ElementTypes" {
    interface ElementTypes {
        "sprite-3d": Sprite3dElementConfig;
    }
}
