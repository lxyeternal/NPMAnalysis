import { BaseElement, BaseElementConfig } from "./BaseElement";
import { PixiLayoutFactory } from "./PixiLayoutFactory";
import { IBitmapTextStyle, BitmapText } from "@pixi/text-bitmap";
export interface BitmapTextElementConfig extends BaseElementConfig<"text-bitmap", BitmapTextElement> {
    text?: string;
    fit?: boolean;
    verticalAlign?: "top" | "bottom" | "middle";
    style?: Partial<IBitmapTextStyle & {
        wordWrap: boolean;
    }>;
}
export declare class BitmapTextElement extends BaseElement<BitmapText> {
    static register(factory: PixiLayoutFactory): void;
    private style;
    private _text;
    private textRect;
    private _fit;
    private _verticalAlign;
    private lastSize;
    private constructor();
    private get maxWidth();
    private meausreText;
    get contentHeight(): number;
    get contentWidth(): number;
    get fit(): boolean;
    set fit(value: boolean);
    get verticalAlign(): "top" | "bottom" | "middle";
    set verticalAlign(value: "top" | "bottom" | "middle");
    get text(): string;
    set text(value: string);
    setStyle(style: Partial<IBitmapTextStyle & {
        wordWrap: boolean;
    }>): void;
    updateStyle(style: Partial<IBitmapTextStyle & {
        wordWrap: boolean;
    }>): void;
    setText(text: string, style?: Partial<IBitmapTextStyle & {
        wordWrap: boolean;
    }>): void;
    private fitText;
    private fitWrappedText;
    protected redraw(): void;
    protected onUpdate(): void;
}
export default BitmapTextElement;
declare module "./ElementTypes" {
    interface ElementTypes {
        "text-bitmap": BitmapTextElementConfig;
    }
}
