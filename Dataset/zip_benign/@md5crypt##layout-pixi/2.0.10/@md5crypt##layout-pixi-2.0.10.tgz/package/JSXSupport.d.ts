import type { ElementTypes } from "./ElementTypes";
import type { BaseElementConfig } from "./BaseElement";
import type { PixiElementConfig } from "./PixiLayoutFactory";
type LayoutElementProps = {
    [K in keyof ElementTypes]: Omit<ElementTypes[K], "type" | "children"> & {
        children?: ReactNode;
    };
};
export declare namespace JSX {
    interface IntrinsicElements extends LayoutElementProps {
    }
    interface ElementChildrenAttribute {
        children: {};
    }
    interface Element extends BaseElementConfig {
    }
}
interface ReactNodeArray extends Array<ReactNode> {
}
export type ReactNode = JSX.Element | ReactNodeArray | false | null | undefined;
export type Slots<T extends string = string> = Record<T, ReactNode>;
export type ComponentFunction = ((props: any, slots: Slots) => JSX.Element);
export type IntrinsicElementNames = keyof LayoutElementProps;
export type ComponentProps<T extends IntrinsicElementNames | ComponentFunction> = T extends keyof LayoutElementProps ? LayoutElementProps[T] : T extends (arg0: infer K) => any ? Omit<K, "children"> : never;
export declare function Fragment(props: {
    children?: ReactNode;
}): JSX.Element;
export declare function Slot(props: {
    name: string;
    children?: ReactNode;
}): JSX.Element;
export declare function isFragment(data: JSX.Element): boolean;
export declare function toArray(data: JSX.Element): PixiElementConfig[];
export declare function createElement<T extends IntrinsicElementNames | ComponentFunction>(type: T, props: ComponentProps<T>, ...rawChildren: ReactNode[]): PixiElementConfig | JSX.Element;
export * as default from "./JSXSupport";
