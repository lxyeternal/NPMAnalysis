export function Fragment(props) {
    return { type: "jsx-fragment", children: props.children || [] };
}
export function Slot(props) {
    return { type: "jsx-slot", config: { name: props.name }, children: props.children || [] };
}
export function isFragment(data) {
    return data.type == "jsx-fragment";
}
export function toArray(data) {
    return (data.type == "jsx-fragment" ? data.children : [data]);
}
export function createElement(type, props, ...rawChildren) {
    const children = [];
    const slots = {};
    for (let i = 0; i < rawChildren.length; i += 1) {
        const value = rawChildren[i];
        const array = Array.isArray(value) ? value : [value];
        for (let j = 0; j < array.length; j += 1) {
            const item = array[j];
            if (!item) {
                continue;
            }
            else if (item.type == "jsx-fragment") {
                children.push(...item.children);
            }
            else if (item.type == "jsx-slot") {
                slots[item.name] = item.children;
            }
            else {
                children.push(item);
            }
        }
    }
    if (typeof type == "string") {
        const result = props;
        result.type = type;
        result.children = children;
        return result;
    }
    else {
        return type(Object.assign({ children }, props), slots);
    }
}
export * as default from "./JSXSupport";
//# sourceMappingURL=JSXSupport.js.map