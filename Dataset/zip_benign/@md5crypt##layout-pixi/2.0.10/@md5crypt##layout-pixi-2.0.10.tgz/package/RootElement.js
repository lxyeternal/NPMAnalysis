import { BaseElement } from "./BaseElement";
import { Container } from "@pixi/display";
export class RootElement extends BaseElement {
    static register(factory) {
        factory.register("root", config => new this(factory, config));
    }
    constructor(factory, config) {
        super(factory, config, new Container());
    }
    onUpdate() {
        this.handle.scale.set(this._scale);
    }
    onRemoveElement(index) {
        this.handle.removeChild(this.children[index].handle);
    }
    onInsertElement(element, index) {
        if (index >= this.children.length) {
            this.handle.addChild(element.handle);
        }
        else {
            const position = this.handle.getChildIndex(this.children[index].handle);
            this.handle.addChildAt(element.handle, position);
        }
    }
}
//# sourceMappingURL=RootElement.js.map