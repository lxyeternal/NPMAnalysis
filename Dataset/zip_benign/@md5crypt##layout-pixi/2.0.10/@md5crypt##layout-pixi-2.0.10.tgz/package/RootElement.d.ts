import { BaseElement, BaseElementConfig } from "./BaseElement";
import { PixiLayoutFactory } from "./PixiLayoutFactory";
import { Container } from "@pixi/display";
export interface RootElementConfig extends BaseElementConfig<"root", RootElement> {
}
export declare class RootElement extends BaseElement<Container> {
    static register(factory: PixiLayoutFactory): void;
    constructor(factory: PixiLayoutFactory, config: RootElementConfig);
    protected onUpdate(): void;
    protected onRemoveElement(index: number): void;
    protected onInsertElement(element: BaseElement, index: number): void;
}
declare module "./ElementTypes" {
    interface ElementTypes {
        "root": RootElementConfig;
    }
}
