import { BaseElement, BaseElementConfig, BlendMode } from "./BaseElement";
import { PixiLayoutFactory } from "./PixiLayoutFactory";
import { Graphics } from "@pixi/graphics";
export interface GraphicElementConfig extends BaseElementConfig<"graphic", GraphicElement> {
    onDraw?: (self: GraphicElement) => void;
    blendMode?: BlendMode;
    autoClear?: boolean;
    tint?: number;
}
export declare class GraphicElement extends BaseElement<Graphics> {
    static register(factory: PixiLayoutFactory): void;
    private _onDraw?;
    autoClear: boolean;
    private constructor();
    get onDraw(): ((self: GraphicElement) => void) | undefined;
    set onDraw(value: ((self: GraphicElement) => void) | undefined);
    get blendMode(): BlendMode;
    set blendMode(value: BlendMode);
    get tint(): number;
    set tint(value: number);
    protected onUpdate(): void;
}
export default GraphicElement;
declare module "./ElementTypes" {
    interface ElementTypes {
        graphic: GraphicElementConfig;
    }
}
