import { BaseTexture } from "@pixi/core";
import { BaseElement, BaseElementConfig, BlendMode } from "./BaseElement";
import { PixiLayoutFactory } from "./PixiLayoutFactory";
import { ParticleContainer } from "./particles/ParticleContainer";
export interface ParticleContainerElementConfig extends BaseElementConfig<"container-particle", ParticleContainerElement> {
    blendMode?: BlendMode;
    baseTexture?: string | BaseTexture;
}
export declare class ParticleContainerElement extends BaseElement<ParticleContainer> {
    static register(factory: PixiLayoutFactory): void;
    private constructor();
    protected onUpdate(): void;
    get blendMode(): BlendMode;
    set blendMode(value: BlendMode);
    get baseTexture(): BaseTexture;
    set baseTexture(value: BaseTexture | string);
}
declare module "./ElementTypes" {
    interface ElementTypes {
        "container-particle": ParticleContainerElementConfig;
    }
}
