import { ContainerElement } from "./ContainerElement";
import { Container3d } from "./projection/proj3d/Container3d";
export class Container3dElement extends ContainerElement {
    static register(factory) {
        factory.register("container-3d", config => new this(factory, config, new Container3d()));
    }
    get zScale() {
        return this.handle.transform.scale.z;
    }
    set zScale(value) {
        this.handle.transform.scale.z = value;
    }
    get zPosition() {
        return this.handle.transform.position.z;
    }
    set zPosition(value) {
        this.handle.transform.position.z = value;
    }
    get zPivot() {
        return this.handle.transform.pivot.z;
    }
    set zPivot(value) {
        this.handle.transform.pivot.z = value;
    }
    get euler() {
        return this.handle.transform.euler;
    }
}
export default Container3dElement;
//# sourceMappingURL=Container3dElement.js.map