import { BaseElement, BaseElementConfig } from "./BaseElement";
import { PixiLayoutFactory } from "./PixiLayoutFactory";
import { SdfText, SdfTextStyle } from "./sdfText/index";
export interface SdfTextElementConfig extends BaseElementConfig<"text-sdf", SdfTextElement> {
    text?: string;
    fit?: boolean;
    verticalAlign?: "top" | "bottom" | "middle";
    horizontalAlign?: "left" | "right" | "center";
    wordWrap?: boolean;
    flush?: boolean;
    forceBatch?: boolean;
    style?: Partial<SdfTextStyle>;
}
export declare class SdfTextElement extends BaseElement<SdfText> {
    private _fit;
    private _verticalAlign;
    private _horizontalAlign;
    private _lastSize;
    private _wordWrap;
    static register(factory: PixiLayoutFactory): void;
    protected constructor(factory: PixiLayoutFactory, config: SdfTextElementConfig);
    get contentHeight(): number;
    get contentWidth(): number;
    get fit(): boolean;
    set fit(value: boolean);
    get verticalAlign(): "top" | "bottom" | "middle" | "baseline";
    set verticalAlign(value: "top" | "bottom" | "middle" | "baseline");
    get horizontalAlign(): "left" | "right" | "center";
    set horizontalAlign(value: "left" | "right" | "center");
    get wordWrap(): boolean;
    set wordWrap(value: boolean);
    get text(): string;
    set text(value: string);
    get flush(): boolean;
    set flush(value: boolean);
    get forceBatch(): boolean;
    set forceBatch(value: boolean);
    setStyle(style: Partial<SdfTextStyle>): void;
    updateStyle(style: Partial<SdfTextStyle>): void;
    private fitWrappedText;
    protected onUpdate(): void;
}
declare module "./ElementTypes" {
    interface ElementTypes {
        "text-sdf": SdfTextElementConfig;
    }
}
