import { BaseElement } from "./BaseElement";
import { HtmlOverlay } from "./htmlOverlay/index";
import { Rectangle } from "@pixi/math";
export class HtmlOverlayElement extends BaseElement {
    static register(factory) {
        factory.register("html", config => new this(factory, config));
    }
    constructor(factory, config) {
        super(factory, config, new HtmlOverlay());
        if (config.style) {
            this.handle.style = config.style;
        }
        if (config.content) {
            this.handle.content = config.content;
        }
        if (config.persistent) {
            this.handle.persistent = config.persistent;
        }
    }
    onUpdate() {
        const width = this.computedWidth;
        const height = this.computedHeight;
        if (this.handle.interactive) {
            this.handle.hitArea = new Rectangle(0, 0, width, height);
        }
        this.handle.position.set(this.pivotedLeft, this.pivotedTop);
        this.handle.pivot.set(width * this._xPivot, height * this._yPivot);
        this.handle.scale.set(this._scale);
        this.handle.width = width;
        this.handle.height = height;
        this.applyFlip();
    }
    set style(value) {
        this.handle.style = value;
    }
    get style() {
        return this.handle.style;
    }
    set content(value) {
        this.handle.content = value;
    }
    get content() {
        return this.handle.content;
    }
    set persistent(value) {
        this.handle.persistent = value;
    }
    get persistent() {
        return this.handle.persistent;
    }
    detach() {
        this.handle.detach();
    }
    attach(renderer) {
        this.handle.attach(renderer);
    }
    get htmlRoot() {
        return this.handle.htmlRoot;
    }
}
export default HtmlOverlayElement;
//# sourceMappingURL=HtmlOverlayElement.js.map