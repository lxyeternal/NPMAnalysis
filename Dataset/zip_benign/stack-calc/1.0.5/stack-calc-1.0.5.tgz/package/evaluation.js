#!/usr/bin/env node
"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
exports.__esModule = true;
exports.addMacro = exports.macros = exports.readable = exports.isNumeric = exports.Status = void 0;
var Type;
(function (Type) {
    Type[Type["Number"] = 0] = "Number";
    Type[Type["Operator"] = 1] = "Operator";
    Type[Type["Intrinsic"] = 2] = "Intrinsic";
    Type[Type["Function"] = 3] = "Function";
    Type[Type["Macro"] = 4] = "Macro";
})(Type || (Type = {}));
var Operator;
(function (Operator) {
    Operator[Operator["Plus"] = 0] = "Plus";
    Operator[Operator["Minus"] = 1] = "Minus";
    Operator[Operator["Mul"] = 2] = "Mul";
    Operator[Operator["Div"] = 3] = "Div";
    Operator[Operator["FloorDiv"] = 4] = "FloorDiv";
    Operator[Operator["Mod"] = 5] = "Mod";
})(Operator || (Operator = {}));
var Intrinsic;
(function (Intrinsic) {
    Intrinsic[Intrinsic["Dup"] = 0] = "Dup";
    Intrinsic[Intrinsic["Over"] = 1] = "Over";
    Intrinsic[Intrinsic["Drop"] = 2] = "Drop";
    Intrinsic[Intrinsic["Swap"] = 3] = "Swap";
})(Intrinsic || (Intrinsic = {}));
var MFunction;
(function (MFunction) {
    MFunction[MFunction["Sqrt"] = 0] = "Sqrt";
    MFunction[MFunction["Sin"] = 1] = "Sin";
    MFunction[MFunction["Cos"] = 2] = "Cos";
    MFunction[MFunction["Tan"] = 3] = "Tan";
    MFunction[MFunction["Ctan"] = 4] = "Ctan";
    MFunction[MFunction["Asin"] = 5] = "Asin";
    MFunction[MFunction["Acos"] = 6] = "Acos";
    MFunction[MFunction["Atan"] = 7] = "Atan";
    MFunction[MFunction["Log"] = 8] = "Log";
    MFunction[MFunction["Ln"] = 9] = "Ln";
    MFunction[MFunction["Fact"] = 10] = "Fact";
    MFunction[MFunction["Pow"] = 11] = "Pow";
    MFunction[MFunction["Root"] = 12] = "Root";
})(MFunction || (MFunction = {}));
var Status;
(function (Status) {
    Status[Status["Error"] = 0] = "Error";
    Status[Status["Ok"] = 1] = "Ok";
})(Status = exports.Status || (exports.Status = {}));
var unreachable = function () { throw new Error('Unreachable'); };
var OkResult = function (res) { return ({ status: Status.Ok, value: res }); };
var ErrorResult = function (message) { return ({ status: Status.Error, value: message }); };
var factorial = function (n) {
    var acc = 1;
    var isNeg = n < 0;
    n = Math.abs(n);
    while (--n >= 1)
        acc *= (n + 1);
    return acc * (isNeg ? -1 : 1);
};
var root = function (n, r) {
    if (n < 0 && r % 2 !== 0 && Math.floor(r) === r)
        return -Math.pow(-n, 1 / r);
    return Math.pow(n, 1 / r);
};
var isNumeric = function (n) { return n && Boolean(n.match(/^\-?\d*\.?\d+$/)); };
exports.isNumeric = isNumeric;
var isOperator = function (n) { return Boolean(/^[\+|\-|\*|\/|\/\/|\%]$/.exec(n)); };
var whichOperator = function (n) {
    return n === '+' ? Operator.Plus :
        n === '-' ? Operator.Minus :
            n === '\/' ? Operator.Div :
                n === '*' ? Operator.Mul :
                    n === '\/\/' ? Operator.FloorDiv :
                        n === '%' ? Operator.Mod :
                            unreachable();
};
var isIntrinsic = function (n) { return ['drop', 'over', 'dup', 'swap'].some(function (i) { return i === n; }); };
var whichIntrinsic = function (n) {
    return n === 'drop' ? Intrinsic.Drop :
        n === 'over' ? Intrinsic.Over :
            n === 'dup' ? Intrinsic.Dup :
                n === 'swap' ? Intrinsic.Swap :
                    unreachable();
};
var isFunction = function (n) {
    return ['sqrt', 'sin', 'cos', 'tan', 'ctan', 'asin', 'acos', 'atan', 'log', 'ln', 'fact', 'pow', 'root']
        .some(function (i) { return i === n; });
};
var whichFunction = function (n) {
    return n === 'sqrt' ? MFunction.Sqrt :
        n === 'sin' ? MFunction.Sin :
            n === 'cos' ? MFunction.Cos :
                n === 'tan' ? MFunction.Tan :
                    n === 'ctan' ? MFunction.Ctan :
                        n === 'asin' ? MFunction.Asin :
                            n === 'acos' ? MFunction.Acos :
                                n === 'atan' ? MFunction.Atan :
                                    n === 'log' ? MFunction.Log :
                                        n === 'ln' ? MFunction.Ln :
                                            n === 'fact' ? MFunction.Fact :
                                                n === 'pow' ? MFunction.Pow :
                                                    n === 'root' ? MFunction.Root :
                                                        unreachable();
};
var reserved = [
    'sqrt', 'sin', 'cos', 'tan', 'ctan', 'asin', 'acos',
    'atan', 'log', 'ln', 'fact', 'pow', 'root', 'drop',
    'over', 'dup', 'swap', '+', '-', '*', '%', '//', '/'
];
var readable = function (statement) {
    switch (statement.type) {
        case Type.Number: return statement.value.toString();
        case Type.Operator:
            switch (statement.value) {
                case Operator.Plus: return '+';
                case Operator.Minus: return '-';
                case Operator.Div: return '/';
                case Operator.FloorDiv: return '//';
                case Operator.Mod: return '%';
                case Operator.Mul: return '*';
            }
        case Type.Function:
            switch (statement.value) {
                case MFunction.Sqrt: return "sqrt";
                case MFunction.Sin: return "sin";
                case MFunction.Cos: return "cos";
                case MFunction.Tan: return "tan";
                case MFunction.Ctan: return "ctan";
                case MFunction.Asin: return "asin";
                case MFunction.Acos: return "acos";
                case MFunction.Atan: return "atan";
                case MFunction.Log: return "log";
                case MFunction.Ln: return "ln";
                case MFunction.Fact: return "fact";
                case MFunction.Pow: return "pow";
                case MFunction.Root: return "root";
            }
        case Type.Intrinsic:
            switch (statement.value) {
                case Intrinsic.Drop: return "drop";
                case Intrinsic.Over: return "over";
                case Intrinsic.Dup: return "dup";
                case Intrinsic.Swap: return "swap";
            }
    }
};
exports.readable = readable;
exports.macros = {};
var isMacro = function (n) { return Object.keys(exports.macros).some(function (m) { return m === n; }); };
var addMacro = function (name, eq) {
    if (reserved.some(function (r) { return r === name; })) {
        return { status: Status.Error, message: "".concat(name, " is already reserved") };
    }
    var parseResult = parse(eq);
    if (parseResult.status === Status.Ok) {
        exports.macros[name] = parseResult.statements;
        return { status: Status.Ok };
    }
    return {
        status: Status.Error,
        message: parseResult.message
    };
};
exports.addMacro = addMacro;
var resultWrapper = function (stack, checks, // Checks
callback // Callback that is called if check is passed
) {
    var pairs = checks.map(function (check) { return check(__spreadArray([], stack, true)); }).filter(function (pair) { return !pair[0]; });
    //  if pairs are empty, then there's no errors
    if (pairs.length == 0)
        return OkResult(callback(__spreadArray([], stack, true)));
    else
        return ErrorResult(pairs[0][1]);
};
var isEnoughCheck = function (n) { return function (s) {
    return [s.length >= n, "Expected at least ".concat(n, " items on the stack")];
}; };
var isLastGreaterCheck = function (n) { return function (s) {
    return [s[s.length - 1] >= n, "Expected number that is greater or equal ".concat(n)];
}; };
var isLastLesserCheck = function (n) { return function (s) {
    return [s[s.length - 1] <= n, "Expected number that is lesser or equal ".concat(n)];
}; };
var operationResult = function (stack, operator) {
    var copy = __spreadArray([], stack, true);
    switch (operator) {
        case Operator.Plus:
            return resultWrapper(copy, [isEnoughCheck(2)], function (stack) {
                stack.push(stack.pop() + stack.pop());
                return stack;
            });
        case Operator.Minus:
            return resultWrapper(copy, [isEnoughCheck(2)], function (stack) {
                var tmp = stack.pop();
                stack.push(stack.pop() - tmp);
                return stack;
            });
        case Operator.Div:
            return resultWrapper(copy, [
                isEnoughCheck(2),
                function (stack) { return [stack[stack.length - 1] !== 0, 'division by zero']; }
            ], function (stack) {
                var tmp = stack.pop();
                stack.push(stack.pop() / tmp);
                return stack;
            });
        case Operator.Mul:
            return resultWrapper(copy, [isEnoughCheck(2)], function (stack) {
                stack.push(stack.pop() * stack.pop());
                return stack;
            });
        case Operator.FloorDiv:
            return resultWrapper(copy, [isEnoughCheck(2)], function (stack) {
                var tmp = stack.pop();
                stack.push(Math.floor(stack.pop() / tmp));
                return stack;
            });
        case Operator.Mod:
            return resultWrapper(copy, [
                isEnoughCheck(2),
                function (stack) { return [stack[stack.length - 1] !== 0, 'modulo by zero']; }
            ], function (stack) {
                var tmp = stack.pop();
                stack.push(stack.pop() % tmp);
                return stack;
            });
        default:
            unreachable();
    }
};
var intrinsicResult = function (stack, intrinsic) {
    var copy = __spreadArray([], stack, true);
    switch (intrinsic) {
        case Intrinsic.Dup:
            return resultWrapper(copy, [isEnoughCheck(1)], function (stack) {
                stack.push(stack[stack.length - 1]);
                return stack;
            });
        case Intrinsic.Drop:
            return resultWrapper(copy, [isEnoughCheck(1)], function (stack) {
                stack.pop();
                return stack;
            });
        case Intrinsic.Over:
            return resultWrapper(copy, [isEnoughCheck(2)], function (stack) {
                stack.push(stack[stack.length - 2]);
                return stack;
            });
        case Intrinsic.Swap:
            return resultWrapper(copy, [isEnoughCheck(2)], function (stack) {
                var _a = [stack.pop(), stack.pop()], tmp1 = _a[0], tmp2 = _a[1];
                stack = __spreadArray(__spreadArray([], stack, true), [tmp1, tmp2], false);
                return stack;
            });
        default:
            unreachable();
    }
};
var functionResult = function (stack, func) {
    var copy = __spreadArray([], stack, true);
    switch (func) {
        case MFunction.Sqrt:
            return resultWrapper(copy, [
                isEnoughCheck(1),
                isLastGreaterCheck(0)
            ], function (stack) {
                stack.push(Math.sqrt(stack.pop()));
                return stack;
            });
        case MFunction.Sin:
            return resultWrapper(copy, [isEnoughCheck(1)], function (stack) {
                stack.push(Math.sin(stack.pop()));
                return stack;
            });
        case MFunction.Cos:
            return resultWrapper(copy, [isEnoughCheck(1),], function (stack) {
                stack.push(Math.cos(stack.pop()));
                return stack;
            });
        case MFunction.Tan:
            return resultWrapper(copy, [isEnoughCheck(1)], function (stack) {
                stack.push(Math.tan(stack.pop()));
                return stack;
            });
        case MFunction.Asin:
            return resultWrapper(copy, [
                isEnoughCheck(1),
                isLastLesserCheck(1),
                isLastGreaterCheck(-1)
            ], function (stack) {
                stack.push(Math.asin(stack.pop()));
                return stack;
            });
        case MFunction.Acos:
            return resultWrapper(copy, [
                isEnoughCheck(1),
                isLastLesserCheck(1),
                isLastGreaterCheck(-1)
            ], function (stack) {
                stack.push(Math.acos(stack.pop()));
                return stack;
            });
        case MFunction.Atan:
            return resultWrapper(copy, [isEnoughCheck(1)], function (stack) {
                stack.push(Math.acos(stack.pop()));
                return stack;
            });
        case MFunction.Ctan:
            return resultWrapper(copy, [isEnoughCheck(1)], function (stack) {
                stack.push(1 / Math.tan(stack.pop()));
                return stack;
            });
        case MFunction.Log:
            return resultWrapper(copy, [
                isEnoughCheck(2),
                function (stack) { return [
                    stack[stack.length - 2] > 0 && stack[stack.length - 2] != 1,
                    'log base should be greater than 0 and not equal to 1'
                ]; },
                function (stack) { return [
                    stack[stack.length - 1] > 0,
                    'number from which you take log should be greater than 0'
                ]; }
            ], function (stack) {
                stack.push(Math.log(stack.pop()) / Math.log(stack.pop()));
                return stack;
            });
        case MFunction.Ln:
            return resultWrapper(copy, [
                isEnoughCheck(1),
                function (stack) { return [
                    stack[stack.length - 1] > 0,
                    'number from which you take log should be greater than 0'
                ]; }
            ], function (stack) {
                stack.push(Math.log(stack.pop()));
                return stack;
            });
        case MFunction.Fact:
            return resultWrapper(copy, [
                isEnoughCheck(1),
                function (stack) { return [
                    Math.floor(stack[stack.length - 1]) === stack[stack.length - 1],
                    'factorial can only accept integers'
                ]; }
            ], function (stack) {
                stack.push(factorial(stack.pop()));
                return stack;
            });
        case MFunction.Pow:
            return resultWrapper(copy, [
                isEnoughCheck(2),
                function (stack) {
                    var power = stack.pop();
                    var base = stack.pop();
                    var isOk = true;
                    if (Math.floor(power) !== power && base < 0)
                        isOk = false;
                    return [isOk, 'negative numbers can have only integer powers'];
                }
            ], function (stack) {
                var tmp = stack.pop();
                stack.push(Math.pow(stack.pop(), tmp));
                return stack;
            });
        case MFunction.Root:
            return resultWrapper(copy, [
                isEnoughCheck(2),
                function (stack) {
                    var rpower = stack.pop();
                    var power = 1 / rpower;
                    var base = stack.pop();
                    var isOk = true;
                    if (Math.floor(power) !== power && base < 0)
                        isOk = false;
                    if (base < 0 && rpower % 2 !== 0 && Math.floor(rpower) === rpower)
                        isOk = true;
                    return [isOk, "even and not integer roots of negative numbers are undefined"];
                }
            ], function (stack) {
                var tmp = stack.pop();
                stack.push(root(stack.pop(), tmp));
                return stack;
            });
        default:
            unreachable();
    }
};
var checkForBrackets = function (eq) {
    var count = 0;
    var correct = true;
    eq.replace(/\(|\)/g, function (match) {
        if (!correct)
            return '';
        if (match === '(')
            count++;
        else
            count--;
        if (count < 0)
            correct = false;
        return '';
    });
    if (count > 0 || !correct)
        return false;
    return true;
};
var clearAllBrackets = function (s) { return s.replace(/\(|\)/g, ''); };
function parse(eq, debug) {
    if (debug === void 0) { debug = false; }
    if (!checkForBrackets(eq)) {
        return {
            status: Status.Error,
            message: 'bracket placement is invalid'
        };
    }
    eq = clearAllBrackets(eq);
    var splitted = eq.split(/\s+/).filter(function (e) { return e; });
    if (debug)
        console.log("splitted to ".concat(JSON.stringify(splitted)));
    var parsed = [];
    var errorMessage = '';
    var isBreak = false;
    splitted.forEach(function (e, idx) {
        // for debugging purposes, basically acts like a comment
        if (e === ';')
            isBreak = true;
        if (isBreak || errorMessage)
            return;
        if (isMacro(e)) {
            if (debug)
                console.log("Macro ".concat(e));
            exports.macros[e].forEach(function (s) {
                s = __assign(__assign({}, s), { from: idx // we replace index generated on `addMacro` step with current
                 });
                parsed.push(s);
                if (debug)
                    console.log("  parsed ".concat(JSON.stringify(s), " - ").concat((0, exports.readable)(s)));
            });
            return;
        }
        var statement = ((0, exports.isNumeric)(e) ? { type: Type.Number, value: Number(e), from: idx } :
            isOperator(e) ? { type: Type.Operator, value: whichOperator(e), from: idx } :
                isIntrinsic(e) ? { type: Type.Intrinsic, value: whichIntrinsic(e), from: idx } :
                    isFunction(e) ? { type: Type.Function, value: whichFunction(e), from: idx } :
                        null);
        if (!statement)
            errorMessage = "'".concat(e, "' is undefined");
        if (debug)
            console.log("parsed ".concat(JSON.stringify(statement), " - ").concat((0, exports.readable)(statement)));
        parsed.push(statement);
    });
    if (errorMessage) {
        return {
            status: Status.Error,
            message: errorMessage
        };
    }
    return {
        status: Status.Ok,
        statements: parsed
    };
}
var placeByWordIdx = function (s, wordidx) {
    var count = 0;
    var found = -1;
    s.replace(/\S+/g, function (_, idx) {
        if (count++ === wordidx)
            found = idx;
        return '';
    });
    return found;
};
var repeat = function (s, c) {
    var res = '';
    for (var i = 0; i < c; i++)
        res += s;
    return res;
};
function evaluate(original, debug) {
    if (debug === void 0) { debug = false; }
    if (debug)
        console.log("parsing");
    var parseResult = parse(original, debug);
    var stack = [];
    var result;
    var errorMessage = '';
    if (parseResult.status === Status.Error) {
        return {
            status: Status.Error,
            message: parseResult.message
        };
    }
    var eq = parseResult.statements;
    var handleError = function (message, wordidx) {
        var place = placeByWordIdx(original, wordidx);
        errorMessage = ("".concat(original, "\n").concat(repeat(' ', place), "^ ").concat(message, "\nstack: [").concat(stack.join(', '), "]"));
    };
    eq.forEach(function (statement) {
        switch (statement.type) {
            case Type.Number:
                stack.push(statement.value);
                break;
            case Type.Operator:
                result = operationResult(stack, statement.value);
                if (result.status === Status.Ok)
                    stack = result.value;
                else
                    handleError(result.value, statement.from);
                break;
            case Type.Intrinsic:
                result = intrinsicResult(stack, statement.value);
                if (result.status === Status.Ok)
                    stack = result.value;
                else
                    handleError(result.value, statement.from);
                break;
            case Type.Function:
                result = functionResult(stack, statement.value);
                if (result.status === Status.Ok)
                    stack = result.value;
                else
                    handleError(result.value, statement.from);
                break;
            default:
                unreachable();
        }
        if (debug)
            console.log("encountered: ".concat((0, exports.readable)(statement), " -> current stack : ").concat(JSON.stringify(stack)));
        return;
    });
    if (errorMessage.length !== 0) {
        return {
            status: Status.Error,
            message: errorMessage
        };
    }
    else {
        return {
            status: Status.Ok,
            stack: stack
        };
    }
}
exports["default"] = evaluate;
// Special symbols
// ; - something like a comment, basically stops the execution and spits out current stack
// () - decorative brackets that are ignored, but still checked for correctness
//? TODO: Think about adding comments that can close  e.g. /* comment */
