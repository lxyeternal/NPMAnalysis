#!/usr/bin/env node
"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
exports.__esModule = true;
var evaluation_1 = require("./evaluation");
var fs = require('fs');
var path = require('path');
var inquirer = require('inquirer');
var logError = function (err) { return console.error(err); };
var debug = false;
// Flags
if (process.argv.some(function (a) { return a === '-h' || a === '--help'; })) {
    console.log("    \nBasics:\nEach number you type is being pushed on the stack, while\noperations, functions and intrinsics affect the stack\ne.g.\n1 .5 -1.4 -> [1, 0.5, -1.4]\n2 2 +     -> [4]\n3 8 log   -> [2]\n    \nOperators:\n+  - sum of 2 last items\n-  - substracts 1st item on the stack from the 2nd\n*  - multiplies 2 last items\n/  - divides 1st item on the stack by the 2nd\n// - the same as before but with flooring\n%  - modulus of 1st and 2nd items\n\nIntrinsics:\ndup  - duplicates last item\ndrop - drops last item\nswap - swaps 1st and 2nd items \nover - copies 2nd item on the stack\n\nOther Functions:\nsqrt, sin, cos, tan, ctan, asin, acos, atan, logm, ln, fact, pow, root\n\nMacros Definition:\nStarts with '!' and name, then implementation\n> !PI 3.1415\n> !log2 2 swap log\n\nCommands:\n:d or :debug - debug mode switch\n:m or :macros - list all defined macros\n\nFlags:\n-d or --debug - turn on debug mode on start up\n-m <file.json> or --macros <file.json> - predefine macros from json file\n");
    process.exit();
}
if (process.argv.some(function (a) { return a === '-d' || a === '--debug'; })) {
    debug = true;
}
process.argv.some(function (arg, idx) {
    if (arg === '-m' || arg === '--macro') {
        if (!process.argv[idx + 1]) {
            logError("flag -m accepts path as argument, but nothing was passed");
            return true;
        }
        var filename = process.argv[idx + 1];
        if (path.extname(filename) !== '.json') {
            logError("flag -m only accepts path to json files");
            return true;
        }
        var file = void 0;
        try {
            file = fs.readFileSync(filename, 'utf-8');
        }
        catch (err) {
            console.log("Couldn't get access to file ".concat(filename, ": ").concat(err));
            return;
        }
        var json_1 = {};
        try {
            json_1 = JSON.parse(file);
        }
        catch (err) {
            console.log("Couldn't parse the file: ".concat(err));
            return;
        }
        Object.keys(json_1).forEach(function (name) {
            if (typeof json_1[name] !== 'string') {
                console.log("Macros should be strings, but encountered ".concat(JSON.stringify(json_1[name])));
                return;
            }
            var result = (0, evaluation_1.addMacro)(name, json_1[name]);
            if (result.status === evaluation_1.Status.Ok)
                console.log("Added macro: ".concat(name, " -> ").concat(json_1[name]));
            else {
                console.log("Couldn't add macro '".concat(name, "'"));
                console.log('    ' + result.message);
            }
        });
        return arg === '-m' || arg === '--macro';
    }
    return false;
});
console.log('Input your equation:');
var getEquation = function () { return __awaiter(void 0, void 0, void 0, function () {
    var input;
    return __generator(this, function (_a) {
        switch (_a.label) {
            case 0: return [4 /*yield*/, inquirer.prompt({
                    name: 'equation',
                    prefix: '',
                    type: 'input',
                    message: '> '
                })];
            case 1:
                input = _a.sent();
                return [2 /*return*/, input.equation];
        }
    });
}); };
(function () { return __awaiter(void 0, void 0, void 0, function () {
    var equation, splitted, macroResult, result;
    return __generator(this, function (_a) {
        switch (_a.label) {
            case 0:
                if (!true) return [3 /*break*/, 2];
                return [4 /*yield*/, getEquation()];
            case 1:
                equation = _a.sent();
                if (equation.length === 0)
                    return [3 /*break*/, 0];
                // Commands
                if (equation === ':exit' || equation === ':e') {
                    console.log('exiting...');
                    return [3 /*break*/, 2];
                }
                if (equation === ':debug' || equation === ':d') {
                    debug = !debug;
                    console.log("debug mode: ".concat(debug ? 'ON' : 'OFF'));
                    return [3 /*break*/, 0];
                }
                if (equation === ':m' || equation === ':macros') {
                    console.log('Macros:');
                    Object.keys(evaluation_1.macros).forEach(function (name) {
                        console.log("  ".concat(name, " -> ").concat(evaluation_1.macros[name].map(evaluation_1.readable).join(' ')));
                    });
                    return [3 /*break*/, 0];
                }
                if (equation.length > 0 && equation[0] === '!') {
                    splitted = equation.slice(1).split(/\s+/).filter(function (a) { return a; });
                    // Macros errors
                    if (!splitted[0])
                        logError('ERROR:\nmacro definition should start with a name');
                    if (splitted[0][0] === '!')
                        logError("ERROR:\nmacro name can't start with a '!'");
                    if (splitted[0][0] === ':')
                        logError("ERROR:\nmacro name can't start with a ':'");
                    if ((0, evaluation_1.isNumeric)(splitted[0]))
                        logError("ERROR:\nmacro name can't be a number");
                    macroResult = (0, evaluation_1.addMacro)(splitted[0], splitted.slice(1).join(' '));
                    if (macroResult.status === evaluation_1.Status.Error) {
                        logError("ERROR:\n".concat(macroResult.message));
                    }
                    return [3 /*break*/, 0];
                }
                result = (0, evaluation_1["default"])(equation, debug);
                if (result.status === evaluation_1.Status.Ok)
                    console.log(result.stack);
                else
                    logError("ERROR:\n".concat(result.message));
                return [3 /*break*/, 0];
            case 2: return [2 /*return*/];
        }
    });
}); })();
