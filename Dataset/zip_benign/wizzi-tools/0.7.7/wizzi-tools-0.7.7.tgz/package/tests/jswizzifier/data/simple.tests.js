function alfa(beta, gamma) {
}