﻿function alfa(beta, gamma) {
}