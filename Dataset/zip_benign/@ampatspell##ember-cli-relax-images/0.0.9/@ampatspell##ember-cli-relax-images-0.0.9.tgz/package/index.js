/* jshint node: true */
'use strict';

module.exports = {
  name: 'relax-images',
  isDevelopingAddon: function() {
    return true;
  },
  contentFor: function(type, config) {
    if(type === 'body-footer') {
      return [
        '<div id="relax-images-window-padding"></div>',
        '<div id="relax-images-grid-image-size"></div>',
      ].join('\n');
    }
  }
};
