import Ember from 'ember';
import ENV from '../config/environment';

export default {
  name: 'ember-cli-relax-images:version',
  initialize: function() {
    Ember.libraries.register('@ampatspell/ember-cli-relax-images', ENV.relaxImages.version);
  }
}