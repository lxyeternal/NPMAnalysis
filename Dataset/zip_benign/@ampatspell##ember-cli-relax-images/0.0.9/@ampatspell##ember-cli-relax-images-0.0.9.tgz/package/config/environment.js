'use strict';

module.exports = function(/* environment, appConfig */) {
  return {
    relaxImages: {
      version: require('../package.json').version
    }
  };
};
