import Ember from 'ember';

const {
  get
} = Ember;

export default Ember.Mixin.create({

  model: null,
  store: Ember.inject.service(),

  url: function() {
    var url;
    var model = this.get('model');
    if(model) {
      url = get(model, 'url');
      if(url) {
        var adapter = this.get('store').lookupAdapter('attachment');
        if(adapter) {
          var namespace = adapter.get('namespace');
          if(namespace) {
            url = namespace + url;
          }
        }  
      }
    }
    return url;
  }.property('model.url'),

});
