import Ember from 'ember';

export default Ember.Mixin.create({

  url: null,
  preloaded: false,

  preloadImage: function(url, attempt) {
    if(attempt > 5) {
      return;
    }
    var mixin = this;
    var img = new Image();
    img.onload = function() {
      if(url === mixin.get("url")) {
        mixin.set("preloaded", true);
      }
    };
    img.onerror = function() {
      if(url === mixin.get("url")) {
        mixin.preloadImage(url, attempt + 1);
      }
    };
    img.src = url;
  },

  preloadURLDidChange: function() {
    var url = this.get("url");

    if(this.get("previousPreloadURL") === url) {
      return;
    }

    this.set("previousPreloadURL", url);
    this.set("preloaded", false);

    if(!url) {
      return;
    }
    
    this.preloadImage(url, 1);
  }.observes('url').on('didInsertElement'),

});
