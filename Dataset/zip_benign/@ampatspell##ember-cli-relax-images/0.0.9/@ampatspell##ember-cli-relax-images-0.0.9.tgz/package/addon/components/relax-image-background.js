import Ember from 'ember';
import layout from '../templates/components/relax-image-background';
import ModelURLMixin from '../mixins/model-url';
import transparent from '../utils/transparent';

export default Ember.Component.extend(ModelURLMixin, {
  layout: layout,
  classNameBindings: [':relax-image-background', 'url::blank'],
  attributeBindings: ['style'],

  src: transparent('url'),

  style: function() {
    var url = this.get('src');
    return 'background-image: url("%@")'.fmt(url).htmlSafe();
  }.property('src'),

});
