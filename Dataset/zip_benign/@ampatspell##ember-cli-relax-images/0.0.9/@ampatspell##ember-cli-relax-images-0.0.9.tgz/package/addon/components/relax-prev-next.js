import Ember from 'ember';
import layout from '../templates/components/relax-prev-next';

export default Ember.Component.extend({
  classNameBindings: [':relax-prev-next', 'over:over'],
  layout: layout,

  window: Ember.inject.service(),
  over: true,

  actions: {
    prev: function() {
      var model = this.get("prev");
      this.invokeAction(model);
    },
    next: function() {
      var model = this.get("next");
      this.invokeAction(model);
    }
  },

  invokeAction: function(model) {
    if(model && this.attrs.action) {
      this.updateTimer(true);
      this.attrs.action(model);
    }
  },
  
  wrapperStyle: function() {
    var style = "height: 100vh";
    var size = this.get("window.size");
    if(size) {
      style = "height: " + size.full.height + "px";
    }
    return style.htmlSafe();
  }.property('window.size'),

  removeOver: function() {
    this.updateTimer(true);
  }.on('didInsertElement'),

  updateTimer: function(schedule) {
    var over = this.get("_over");
    if(over) {
      Ember.run.cancel(over);
      over = null;
    }
    if(schedule) {
      over = Ember.run.later(this, function() {
        this.set("over", false);
      }, 2000);
    }
    this.set("_over", over);
  }.on('willDestroyElement'),

  mouseMove: function() {
    this.set("over", true);
    this.updateTimer(true);
  },

  mouseEnter: function() {
    this.set("over", true);
  },

  mouseLeave: function() {
    this.set("over", false);
    this.updateTimer(false);
  },

  focus: function() {
    this.$().attr({tabindex: 1});
    this.$().focus();
  }.on('didInsertElement'),

});
