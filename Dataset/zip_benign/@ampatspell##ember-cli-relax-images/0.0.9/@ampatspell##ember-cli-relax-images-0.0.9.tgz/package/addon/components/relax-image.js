import Ember from 'ember';
import ImagePreloadMixin from '../mixins/image-preload';
import ModelURLMixin from '../mixins/model-url';
import transparent from '../utils/transparent';

export default Ember.Component.extend(ImagePreloadMixin, ModelURLMixin, {
  tagName: 'img',
  classNameBindings: [':relax-image', 'preloaded:loaded:loading', 'attrs.action:clickable'],
  attributeBindings: ['src', 'style'],

  window: Ember.inject.service(),

  src: transparent('url'),
  scale: 1.0,

  calculateMaxImageSize: function(size, max) {
    if(!size) {
      return {};
    }

    var imageScale = this.get('scale');
    size = {
      width:  size.width * imageScale,
      height: size.height * imageScale
    };

    if(!max) {
      return size;
    }

    if(size.width < max.width && size.height < max.height) {
      return size;
    }

    var scale = {
      width:  max.width / size.width,
      height: max.height / size.height
    };

    scale.min = Math.min(scale.width, scale.height);

    return {
      width:  Math.ceil(size.width * scale.min),
      height: Math.ceil(size.height * scale.min)
    };
  },

  style: function() {
    var info = this.get('model.info');
    if(!info) {
      return "".htmlSafe();
    }
    var max = this.get('window.size').padded;
    var size = this.calculateMaxImageSize(info, max);
    return `width: ${size.width}px; height: ${size.height}`.htmlSafe();
  }.property('model.info', 'window.size'),

  click: function() {
    if(this.attrs.action) {
      this.attrs.action();
    }
  }

});
