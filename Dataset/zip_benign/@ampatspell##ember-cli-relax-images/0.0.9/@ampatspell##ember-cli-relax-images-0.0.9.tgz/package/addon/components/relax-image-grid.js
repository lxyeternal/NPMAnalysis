import Ember from 'ember';
import layout from '../templates/components/relax-image-grid';

const {
  get
} = Ember;

export default Ember.Component.extend({
  classNameBindings: [':relax-image-grid', 'model.length::blank'],
  layout: layout,

  window: Ember.inject.service(),

  imageSize: function() {
    var el = Ember.$('#relax-images-grid-image-size');
    if(el.length > 0) {
      return {
        height: parseInt(el.css('height').replace('px', '')),
        padding: parseInt(el.css('padding').replace('px', ''))
      };
    } else {
      return {
        height: 200,
        padding: 20
      };
    }
  }.property('window.size'),

  images: function() {
    var imageSize = this.get('imageSize');

    var ws = this.get("window.size");
    if(!ws) {
      return;
    }

    ws = ws.padded;
    if(!ws) {
      return;
    }

    var models = this.get("model");
    if(!models) {
      return;
    }
    
    var key = this.get("key");
    if(!key) {
      return;
    }

    var images = models.map(function(model) {
      var att = model.get(key);
      if(!att) {
        return;
      }
      return {
        model: model,
        attachment: att,
        size: {},
      };
    });

    //

    var max = {
      width:  ws.width,
      height: Math.min(ws.height, imageSize.height)
    };

    var row = {
      over: null,
      idx: 0,
      width: 0,
      height: 0,
      images: [],
    };

    function resizeRow(last) {
      var extras = (imageSize.padding * (row.images.length - 1));
  
      var over;
      if(last && row.over) {
        over = row.over;
      } else {
        over = Math.min(1.0, (ws.width - extras) / (row.width - extras));
        row.over = over;
      }

      row.images.forEach(function(item) {
        item.size = {
          width: Math.floor(item.size.width * over),
          height: Math.floor(item.size.height * over),
          row: row.idx,
          last: last,
          padding: imageSize.padding,
        };
        row.height = Math.max(row.height, item.size.height);
      });

      row.left = 0;

      row.width = 0;
      row.height = 0;
      row.images = [];
      row.idx++;
    }

    images.forEach(function(image, idx) {
      var size = get(image.attachment, "info");
      var scaled = {
        width: Math.floor(size.width / size.height * max.height),
        height: max.height,
      };

      image.size = scaled;

      row.width += (scaled.width + imageSize.padding);
      row.images.push(image);

      if(row.width >= max.width) {
        row.width -= imageSize.padding;
        var last = idx === images.get("length") - 1;
        resizeRow(last);
      }
    });

    resizeRow(true);
    
    return images;
  }.property('window.size', 'model.[]', 'key', 'imageHeight'),

  actions: {
    selectImage: function(image) {
      if(this.attrs.action) {
        this.attrs.action(image.model);
      }
    }    
  }

});
