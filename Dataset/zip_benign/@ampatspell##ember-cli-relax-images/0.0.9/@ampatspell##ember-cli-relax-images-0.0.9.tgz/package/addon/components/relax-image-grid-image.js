import Ember from 'ember';
import layout from '../templates/components/relax-image-grid-image';
import ImagePreloadMixin from '../mixins/image-preload';
import ModelURLMixin from '../mixins/model-url';
import transparent from '../utils/transparent';

export default Ember.Component.extend(ImagePreloadMixin, ModelURLMixin, {
  classNameBindings: [':relax-image-grid-image'],
  attributeBindings: ['style'],
  layout: layout,

  imgSrc: transparent('url'),
  
  imgStyle: function() {
    var size = this.get('image.size');
    if(!size) {
      return;
    }
    return `width: ${size.width}px; height: ${size.height}px`.htmlSafe();
  }.property('image.size'),

  style: function() {
    var size = this.get('image.size');
    if(!size) {
      return;
    }
    return `margin: 0 ${size.padding}px ${size.padding}px 0; width: ${size.width}px`.htmlSafe();
  }.property('image.size'),

  model: function() {
    var image = this.get('image');
    if(!image) {
      return;
    }
    return image.attachment;
  }.property('image'),

  actions: {
    select: function() {
      if(this.attrs.action) {
        this.attrs.action();
      }
    }
  }

});
