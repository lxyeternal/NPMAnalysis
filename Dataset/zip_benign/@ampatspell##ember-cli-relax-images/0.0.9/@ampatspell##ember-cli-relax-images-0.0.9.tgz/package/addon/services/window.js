import Ember from 'ember';

export default Ember.Service.extend(Ember.Evented, {

  size: null,
  paddingElementSelector: '#relax-images-window-padding',

  // iOS add to home screen
  isStandalone: function() {
    return window.navigator && window.navigator.standalone;
  }.property(),

  //

  startListeningResizeEvents: function() {
    this.updateWindowResize();
    Ember.$(window).on('resize', Ember.$.proxy(this.onWindowResize, this));
  }.on('init'),

  paddingElement: function() {
    if(!this.__paddingElement) {
      var el = Ember.$(this.get('paddingElementSelector'));      
      if(el.length > 0) {
        this.__paddingElement = el;
      }
    }
    return this.__paddingElement;
  }.property('paddingElementSelector').volatile(),

  loadPaddingSize: function() {
    var padding = this.get("paddingElement");
    if(padding) {
      var hash = {
        left:   parseInt(padding.css('padding-left').replace('px', '')),
        right:  parseInt(padding.css('padding-right').replace('px', '')),
        top:    parseInt(padding.css('padding-top').replace('px', '')),
        bottom: parseInt(padding.css('padding-bottom').replace('px', ''))
      };
      return {
        width:   hash.left + hash.right,
        height:  hash.top  + hash.bottom,
        padding: hash,
      };
    }
  },

  calculatePaddedSize: function(full) {
    var padding = this.loadPaddingSize();
    if(padding) {
      return {
        width:   full.width - padding.width,
        height:  full.height - padding.height,
        padding: padding.padding
      };
    }
  },

  updateWindowResize: function() {
    var e = document.documentElement;
    var full = {
      width: e.clientWidth,
      height: e.clientHeight,
    };
    var padded = this.calculatePaddedSize(full);
    this.set("size", {
      full:   full,
      padded: padded
    });
  },
  
  onWindowResize: function() {
    this.updateWindowResize();
    this.trigger("resize", this);
  },

});
