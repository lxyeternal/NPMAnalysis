const transparent = "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7";

export default function(key) {
  return function() {
    var value = this.get(key);
    if(!value) {
      return transparent;
    }
    return value;
  }.property(key);
}