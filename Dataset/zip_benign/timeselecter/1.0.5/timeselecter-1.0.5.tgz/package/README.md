# 介绍
时间段选择器基于echarts4或5
图形化快速选择一个星期中的时间段，精度为0.5小时
可以自适应传入的dom元素大小，但太小的话体验不好
# 界面
![image](https://github.com/pipipixx/timeSelecter/blob/main/interface.png)
# 使用
npm install timeselecter --save

import echarts from "echarts"

import timeSelecter from "timeselecter"

timeSelecter.init(echarts, domEle, (res)=> {
  console.log(res)
})
