/**
 * @typedef {object} AtomicRatioMF
 * @property {number} em
 * @property {number} mw
 * @property {string} mf
 * @property {Array<MFAtomicComposition>} mfAtomicComposition
 * @property {Array<AtomicRatio>} atomicRatios
 * @property {number} totalError
 */
/**
 * @typedef {object} MFAtomicComposition
 * @property {string} element
 * @property {number} count
 * @property {number} theoretical
 * @property {number} experimental
 * @property {number} error
 */
/**
 * @typedef {object} AtomicRatio
 * @property {string} element
 * @property {number} count
 * @property {number} theoretical
 */
/**
 * Returns possible combinations
 * @param {object} [ratios]
 * @param {object} [options={}]
 * @param {string} [options.ranges='C0-10 H0-10 O0-10 N0-10'] - range of mfs to search
 * @param {number} [options.maxElementError=0.05]
 * @param {number} [options.maxTotalError=0.1]
 * @param {number} [options.minMW=0] minimal molecular weight
 * @param {number} [options.maxMW=+Infinity] maximal molecular weight
 * @param {object} [options.unsaturation={}]
 * @param {number} [options.unsaturation.min=-Infinity] Minimal unsaturation
 * @param {number} [options.unsaturation.max=+Infinity] Maximal unsaturation
 * @param {boolean} [options.unsaturation.onlyInteger=false] Integer unsaturation
 * @param {boolean} [options.unsaturation.onlyNonInteger=false] Non integer unsaturation
 * @return {Promise<AtomicRatioMF[]>}
 */
export function mfFromAtomicRatio(ratios?: object, options?: {
    ranges?: string | undefined;
    maxElementError?: number | undefined;
    maxTotalError?: number | undefined;
    minMW?: number | undefined;
    maxMW?: number | undefined;
    unsaturation?: {
        min?: number | undefined;
        max?: number | undefined;
        onlyInteger?: boolean | undefined;
        onlyNonInteger?: boolean | undefined;
    } | undefined;
}): Promise<AtomicRatioMF[]>;
export type AtomicRatioMF = {
    em: number;
    mw: number;
    mf: string;
    mfAtomicComposition: Array<MFAtomicComposition>;
    atomicRatios: Array<AtomicRatio>;
    totalError: number;
};
export type MFAtomicComposition = {
    element: string;
    count: number;
    theoretical: number;
    experimental: number;
    error: number;
};
export type AtomicRatio = {
    element: string;
    count: number;
    theoretical: number;
};
//# sourceMappingURL=mfFromAtomicRatio.d.ts.map