export { version } from './version.js';
export * as numerical from './numerical/index.js';
//# sourceMappingURL=index.d.ts.map