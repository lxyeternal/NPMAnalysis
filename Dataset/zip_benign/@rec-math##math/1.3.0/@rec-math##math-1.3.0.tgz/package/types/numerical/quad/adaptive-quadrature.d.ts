import type { IntegrandCallback, IntegrationStep, QuadratureInfo, QuadratureOptions } from '.';
export declare const integrate: (integrationStep: IntegrationStep, f: IntegrandCallback, a: number, b: number, options?: QuadratureOptions) => [r: number, i: QuadratureInfo];
//# sourceMappingURL=adaptive-quadrature.d.ts.map