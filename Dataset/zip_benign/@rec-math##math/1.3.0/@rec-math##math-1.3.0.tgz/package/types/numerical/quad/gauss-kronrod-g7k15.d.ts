import type { IntegrationStep } from '.';
/**
 * Perform a single integration step.
 *
 * @param f Integrand callback.
 * @param a Lower limit.
 * @param b Upper limit.
 * @returns [current best estimate, poor estimate]
 */
export declare const integrationStep: IntegrationStep;
//# sourceMappingURL=gauss-kronrod-g7k15.d.ts.map