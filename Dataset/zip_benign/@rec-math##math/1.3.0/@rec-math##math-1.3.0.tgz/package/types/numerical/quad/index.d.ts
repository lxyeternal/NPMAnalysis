export declare type IntegrandCallback = (a: number) => number;
export interface QuadratureInfo {
    /** Number of steps _used_ in the integration. */
    steps: number;
    /** Estimate of the global error. */
    errorEstimate: number;
    /**
     * Set to true if there was a problem (e.g. could not reach required accuracy
     * with a step at machine precision).
     */
    isUnreliable?: true;
    /**
     * If the range has multiple (i.e. more than 2) points, contains the results
     * for intermediate ranges.
     */
    points?: [r: number, i: QuadratureInfo][];
    /** The maximum depth used. */
    depth: number;
}
export interface QuadratureOptions {
    /** Used to control global error. */
    epsilon?: number;
    /** Maximum depth to use for adaptive step length. */
    maxDepth?: number;
}
export declare type IntegrationStep = (
/** The integrand. */
f: (a: number) => number, a: number, // Lower limit.
b: number) => [a: number, b: number];
/**
 * Numerically compute a definite integral.
 *
 * @param f Callback returning value of integrand.
 * @param range A range of at least 2 endpoints.
 * @param options Options for the computation.
 *
 * @returns The results of the computation.
 */
export declare const quad: (f: IntegrandCallback, range: number[], options?: QuadratureOptions) => [r: number, i: QuadratureInfo];
//# sourceMappingURL=index.d.ts.map