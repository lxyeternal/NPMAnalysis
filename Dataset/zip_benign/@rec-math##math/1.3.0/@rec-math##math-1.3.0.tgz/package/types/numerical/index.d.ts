export { quad } from './quad/index.js';
//# sourceMappingURL=index.d.ts.map