import {
  type QueryObserverResult,
  type RefetchOptions,
  useQuery,
} from '@tanstack/react-query';
import { useEffect, useState } from 'react';

import {
  MAINNET_RELAY_API,
  TESTNET_RELAY_API,
  paths,
} from '@reservoir0x/relay-sdk';
import { Status } from 'ox/TransactionReceipt';
import {
  Bridge,
  BridgeStatus,
  FundsBridgeTransaction,
  Quote,
  QuoteProvider,
} from '../types';
import { FUNDS_BRIDGE_FIELDS } from '../utils/metaindexer';
import { useMetaRouter } from './MetaRouterProvider';

const FundsBridgeQuery = `
  query FundsBridgeQuery($sourceTransactionHash: String!, $sourceChainId: numeric) {
    FundsBridge(
      where: {
        sourceTransactionHash: { _eq: $sourceTransactionHash },
        sourceChainId: { _eq: $sourceChainId },
      }
    ) {
      ${FUNDS_BRIDGE_FIELDS}
    }
  }
`;

/**
 * Parameters for the funds bridge polling hook
 */
export interface FundsBridgePollingParams {
  /** The selected quote being executed */
  quote?: Quote | null;
  /** Transaction hash on the source chain */
  sourceTransactionHash?: string;
  /** Chain ID of the source chain */
  sourceChainId?: number;
  /** Indicates the status of the source transaction */
  sourceTransactionStatus?: Status;
}

/**
 * Result from the funds bridge polling hook
 */
export interface FundsBridgePollingResult {
  /** The transaction data */
  data: FundsBridgeTransaction | null;
  /** Whether the request is loading */
  isLoading: boolean;
  /** Any error that occurred while fetching */
  error: Error | null;
  /** Time in seconds until the next refresh */
  refreshIn: number;
  /** The refetch function */
  refetch: (
    options?: RefetchOptions,
  ) => Promise<QueryObserverResult<FundsBridgeTransaction | null, Error>>;
  /** Whether the data is currently being refreshed */
  isRefetching: boolean;
}

/**
 * Hook for polling funds bridge transaction status
 * @param params - The source transaction hash and chain ID
 * @param refetchInterval - Optional interval for refetching data in milliseconds. Default is 10 seconds.
 *
 * @returns Funds bridge transaction status with countdown timer
 */
export function useFundsBridgePolling(
  {
    quote,
    sourceTransactionHash,
    sourceChainId,
    sourceTransactionStatus,
  }: FundsBridgePollingParams,
  refetchInterval = 10000,
): FundsBridgePollingResult {
  const { router, queryClient } = useMetaRouter();
  const [refreshIn, setRefreshIn] = useState(refetchInterval / 1000);
  const [transactionStatus, setTransactionStatus] =
    useState<BridgeStatus | null>(null);

  const shouldFetchStatus = Boolean(
    sourceTransactionHash && sourceChainId && sourceTransactionStatus,
  );

  useEffect(() => {
    setTransactionStatus(null);
  }, [sourceTransactionHash, sourceChainId]);

  const { data, isLoading, error, isRefetching, dataUpdatedAt, refetch } =
    useQuery<FundsBridgeTransaction | null, Error>(
      {
        queryKey: ['fundsBridge', sourceTransactionHash, sourceChainId],
        queryFn: async (): Promise<FundsBridgeTransaction | null> => {
          if (!shouldFetchStatus || sourceTransactionStatus === undefined)
            return null;

          if (sourceTransactionStatus === 'success') {
            if (quote?.provider === QuoteProvider.RELAY) {
              return await fetchRelayBridgeStatus(quote);
            } else {
              if (!router.config.graphqlUrl) {
                throw new Error('GraphQL URL is required');
              }

              return await fetchMetaindexerBridgeStatus(
                router.config.graphqlUrl,
                sourceTransactionHash!,
                sourceChainId!,
              );
            }
          } else {
            // The sourceTransactionStatus is 'reverted', trigger the refunded status.
            return {
              id: '',
              status: BridgeStatus.REFUNDED,
            };
          }
        },
        refetchInterval:
          shouldFetchStatus &&
          (!transactionStatus || transactionStatus === BridgeStatus.PENDING)
            ? refetchInterval
            : false,
        enabled: shouldFetchStatus,
        staleTime: refetchInterval,
        gcTime: refetchInterval * 2,
      },
      queryClient,
    );

  // Update transaction status when data changes
  useEffect(() => {
    if (data?.status) {
      setTransactionStatus(data.status as BridgeStatus);
    } else if (!shouldFetchStatus || data === null) {
      setTransactionStatus(null);
    }
  }, [data, shouldFetchStatus]);

  // Update countdown timer
  useEffect(() => {
    if (
      !isLoading &&
      !isRefetching &&
      shouldFetchStatus &&
      transactionStatus === BridgeStatus.PENDING
    ) {
      const interval = setInterval(() => {
        const nextRefreshAt = dataUpdatedAt + refetchInterval;
        const now = Date.now();
        const timeLeft = Math.max(0, Math.ceil((nextRefreshAt - now) / 1000));

        setRefreshIn(timeLeft);
      }, 1000);

      return () => clearInterval(interval);
    } else if (
      transactionStatus &&
      transactionStatus !== BridgeStatus.PENDING
    ) {
      // Set refreshIn to 0 when we stop polling
      setRefreshIn(0);
    }
    return;
  }, [
    dataUpdatedAt,
    refetchInterval,
    isLoading,
    isRefetching,
    transactionStatus,
    shouldFetchStatus,
  ]);

  return {
    data: data ?? null,
    isLoading: shouldFetchStatus && isLoading,
    error: shouldFetchStatus ? (error as Error | null) : null,
    refetch,
    refreshIn,
    isRefetching: shouldFetchStatus && isRefetching,
  };
}

type RelayStatusResponse =
  paths['/intents/status/v2']['get']['responses']['200']['content']['application/json'];

async function fetchRelayBridgeStatus(
  quote: Quote,
): Promise<FundsBridgeTransaction> {
  const relayApiBaseUrl = quote.isTestnet
    ? TESTNET_RELAY_API
    : MAINNET_RELAY_API;

  const relayStatusApi = new URL(`${relayApiBaseUrl}/intents/status/v2`);

  relayStatusApi.searchParams.append('requestId', quote.quoteId);

  const response = await fetch(relayStatusApi, {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
    },
  });

  if (!response.ok) {
    throw new Error(`API request failed with status ${response.status}`);
  }
  const statusResponse = (await response.json()) as RelayStatusResponse;

  const status =
    statusResponse.status &&
    ['delayed', 'waiting', 'pending'].includes(statusResponse.status)
      ? BridgeStatus.PENDING
      : statusResponse.status === 'refund'
        ? BridgeStatus.REFUNDED
        : statusResponse.status === 'failure'
          ? BridgeStatus.REFUNDED // TODO: Failure for relay means that the transaction failed and was not refundable.
          : BridgeStatus.FULFILLED;

  return {
    id: quote.quoteId,
    /** Bridge type */
    bridge: Bridge.RELAY,
    /** Current status of the bridge transaction */
    status,
    /** Transaction hash on the source chain */
    sourceTransactionHash: statusResponse.inTxHashes?.[0],
    /** Transaction hash on the destination chain (if completed) */
    destinationTransactionHash: statusResponse.txHashes?.[0],
    /** Chain ID of the source chain */
    sourceChainId: statusResponse.originChainId,
    /** Chain ID of the destination chain */
    destinationChainId: statusResponse.destinationChainId,
    /** Timestamp when the bridge event was initiated */
    timestamp: statusResponse.time,
  };
}

async function fetchMetaindexerBridgeStatus(
  graphqlUrl: string,
  sourceTransactionHash: string,
  sourceChainId: number,
) {
  try {
    const variables = {
      sourceTransactionHash,
      sourceChainId,
    };

    const response = await fetch(graphqlUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        query: FundsBridgeQuery,
        variables,
      }),
    });

    if (!response.ok) {
      throw new Error(`API request failed with status ${response.status}`);
    }

    const json = await response.json();

    if (json.errors) {
      throw new Error(json.errors[0]?.message || 'GraphQL query failed');
    }

    const transactions = json.data?.FundsBridge;
    // Extract the first transaction from the response
    const transaction = transactions?.[0] ?? null;

    return transaction;
  } catch (error) {
    throw error instanceof Error ? error : new Error('Unknown error occurred');
  }
}
