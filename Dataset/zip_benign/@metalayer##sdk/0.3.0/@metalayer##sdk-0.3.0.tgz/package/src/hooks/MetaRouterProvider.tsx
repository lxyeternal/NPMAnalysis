import type { QueryClient } from '@tanstack/react-query';
import * as React from 'react';

import { MetaRouter } from '../metarouter';
import { MetaRouterConfig } from '../types';

interface MetaRouterContextValue {
  router: MetaRouter;
  queryClient: QueryClient;
}

const MetaRouterContext = React.createContext<MetaRouterContextValue | null>(
  null,
);

export function MetaRouterProvider({
  children,
  config,
  queryClient,
}: {
  children: React.ReactNode;
  config: MetaRouterConfig;
  queryClient: QueryClient;
}) {
  const router = React.useMemo(() => MetaRouter.init(config), [config]);

  return (
    <MetaRouterContext.Provider value={{ router, queryClient }}>
      {children}
    </MetaRouterContext.Provider>
  );
}

export function useMetaRouter() {
  const context = React.useContext(MetaRouterContext);
  if (!context) {
    throw new Error('useMetaRouter must be used within a MetaRouterProvider');
  }
  return context;
}
