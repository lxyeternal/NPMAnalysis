import type { Quote, QuoteStep, QuotesParams, QuotesResponse } from '../types';
import { useMetaRouter } from './MetaRouterProvider';

import { TransactionType } from '@metalayer/protocol-buffers/src/caldera/common/transaction_request_pb';
import {
  type QueryObserverResult,
  type RefetchOptions,
  useQuery,
} from '@tanstack/react-query';
import { useEffect, useState } from 'react';

export interface QuoteResult {
  /** The quote data */
  data: QuotesResponse | undefined;
  /** Whether the quote is currently loading */
  isLoading: boolean;
  /** Any error that occurred while fetching the quote */
  error: Error | null;
  /** Time in seconds until the next refresh */
  refreshIn: number;
  /** The refetch function */
  refetch: (
    options?: RefetchOptions,
  ) => Promise<QueryObserverResult<QuotesResponse, Error>>;
  /** Whether the quote is currently being refreshed */
  isRefetching: boolean;
  /** The selected quote (first quote from the response) */
  quote: Quote | undefined;
  /** The list of quotes */
  quotes: Quote[];
  /** The approval transaction(s) (only available if sender address is provided and has not yet approved the token(s)) */
  approvals: QuoteStep[] | undefined;
  /** Required transaction steps for the selected quote (only available if sender address is provided) */
  steps: QuoteStep[] | undefined;
  /** Whether approval is needed (only available if sender address is provided and has not yet approved the token(s)) */
  needsApproval: boolean;
}

/**
 * Hook for fetching quotes with countdown timer
 * @param params - Quote parameters
 * @param refetchInterval - Optional interval for refetching data in milliseconds
 * @returns Quote result with countdown timer
 */
export function useQuote(
  params: Partial<QuotesParams>,
  refetchInterval = 30000, // 30 seconds
): QuoteResult {
  const { router, queryClient } = useMetaRouter();
  const [refreshIn, setRefreshIn] = useState(refetchInterval / 1000);

  // Check if amount is valid before making the request
  const shouldFetchQuote = Boolean(
    params.chainInId &&
      params.chainOutId &&
      params.tokenInAddress &&
      params.tokenOutAddress &&
      params.amount &&
      params.amount !== 0n &&
      params.amount > 0n,
  );

  const { data, isLoading, error, isRefetching, refetch, dataUpdatedAt } =
    useQuery<QuotesResponse, Error>(
      {
        queryKey: [
          'quote',
          {
            ...params,
            amount: params.amount?.toString(),
          },
        ],
        queryFn: () => router.quote(params as QuotesParams),
        refetchInterval: shouldFetchQuote ? refetchInterval : false,
        enabled: shouldFetchQuote,
        staleTime: refetchInterval,
        gcTime: refetchInterval * 2,
        refetchOnWindowFocus: false,
      },
      queryClient,
    );

  // Update countdown timer only when we have data and are actively fetching
  useEffect(() => {
    if (!isLoading && !isRefetching && data && shouldFetchQuote) {
      const interval = setInterval(() => {
        const nextRefreshAt = dataUpdatedAt + refetchInterval;
        const now = Date.now();
        const timeLeft = Math.max(0, Math.ceil((nextRefreshAt - now) / 1000));

        setRefreshIn(timeLeft);
      }, 1000);

      return () => clearInterval(interval);
    }
    return;
  }, [
    dataUpdatedAt,
    refetchInterval,
    isLoading,
    isRefetching,
    data,
    shouldFetchQuote,
  ]);

  // Extract quote and transaction information
  const quote = selectBestQuote(data?.quotes, params as QuotesParams);
  const hasSteps = Boolean(params.senderAddress && quote?.steps?.length);
  const steps = hasSteps ? quote?.steps : undefined;
  const approvals = steps?.filter(
    (step) =>
      step.action.case === 'transactionRequest' &&
      step.action.value.type === TransactionType.ERC20_APPROVAL,
  );
  const needsApproval = (approvals?.length ?? 0) > 0;

  return {
    data: shouldFetchQuote ? data : undefined,
    isLoading: shouldFetchQuote && isLoading,
    error: shouldFetchQuote ? (error as Error | null) : null,
    refetch,
    refreshIn,
    isRefetching: shouldFetchQuote && isRefetching,
    quote,
    quotes: data?.quotes ?? [],
    steps,
    approvals,
    needsApproval,
  };
}

function selectBestQuote(
  quotes: Quote[] | undefined,
  _params: QuotesParams,
): Quote | undefined {
  // Use the preferences for selecting the best quote, as defined by the user
  // const _preferences = params.preferences;

  // define an algorithm for selecting the best quote.
  // right now we just select the first quote, if it exists.
  return quotes?.[0];
}
