import type { SupportedChainsParams, SupportedChainsResponse } from '../types';
import { useMetaRouter } from './MetaRouterProvider';

import { useQuery } from '@tanstack/react-query';

export interface SupportedChainsResult {
  /** The supported chains data */
  data: SupportedChainsResponse | undefined;
  /** Whether the chains data is currently loading */
  isLoading: boolean;
  /** Any error that occurred while fetching the chains */
  error: Error | null;
  /** Whether the data is currently being refreshed */
  isRefetching: boolean;
}

/**
 * Hook for fetching supported chains
 * @param params - Supported chains parameters
 * @param staleTime - Optional time in milliseconds before data is considered stale
 * @returns Supported chains result
 */
export function useSupportedChains(
  params: SupportedChainsParams,
  staleTime = 30 * 60 * 1000, // 30 minutes default stale time
): SupportedChainsResult {
  const { router, queryClient } = useMetaRouter();

  const { data, isLoading, error, isRefetching } = useQuery<
    SupportedChainsResponse,
    Error
  >(
    {
      queryKey: ['supportedChains', params],
      queryFn: () => router.getSupportedChains(params),
      staleTime: staleTime,
      gcTime: staleTime * 2,
    },
    queryClient,
  );

  return {
    data,
    isLoading,
    error: error as Error | null,
    isRefetching,
  };
}
