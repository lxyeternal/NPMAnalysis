import { useQuery } from '@tanstack/react-query';

import { FundsBridgeTransaction, isValidAddress } from '../types';
import { FUNDS_BRIDGE_FIELDS } from '../utils/metaindexer';
import { useMetaRouter } from './MetaRouterProvider';

const FundsBridgeQuery = `
  query FundsBridgeQuery($sourceAddress: String!) {
    FundsBridge(
      where: {
        sourceAddress: { _eq: $sourceAddress },
      },
      order_by: [
        {
          timestamp: desc
        }
      ]
    ) {
      ${FUNDS_BRIDGE_FIELDS}
    }
  }
`;

/**
 * Hook for fetching funds bridge transactions for a wallet
 * @param sourceAddress - The source wallet address
 *
 * @returns Funds bridge transactions
 */
export function useFundsBridgeWallet(sourceAddress?: string) {
  const { router, queryClient } = useMetaRouter();

  const shouldFetch = !!sourceAddress && isValidAddress(sourceAddress);

  return useQuery<FundsBridgeTransaction[], Error>(
    {
      queryKey: ['fundsBridgeWallet', sourceAddress],
      queryFn: async (): Promise<FundsBridgeTransaction[]> => {
        if (!shouldFetch) return [];

        const variables = { sourceAddress };

        try {
          if (!router.config.graphqlUrl) {
            throw new Error('GraphQL URL is required');
          }

          const response = await fetch(router.config.graphqlUrl, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              query: FundsBridgeQuery,
              variables,
            }),
          });

          if (!response.ok) {
            throw new Error(
              `API request failed with status ${response.status}`,
            );
          }

          const json = await response.json();

          if (json.errors) {
            throw new Error(json.errors[0]?.message || 'GraphQL query failed');
          }

          const transactions = json.data?.FundsBridge;
          // Extract the first transaction from the response
          return transactions ?? [];
        } catch (error) {
          throw error instanceof Error
            ? error
            : new Error('Unknown error occurred');
        }
      },
      enabled: shouldFetch,
      staleTime: 1000 * 60 * 5, // 5 minutes
      gcTime: 1000 * 60 * 10, // 10 minutes
    },
    queryClient,
  );
}
