import { useMetaRouter } from '../hooks/MetaRouterProvider';
import type { TokenRoutesParams, TokenRoutesResponse } from '../types';

import { Token } from '@metalayer/protocol-buffers/src/caldera/common/token_pb';
import { useQuery } from '@tanstack/react-query';
import { useEffect, useMemo, useState } from 'react';

/**
 * FALLBACK IMAGE URL FOR TOKENS THAT DON'T HAVE AN IMAGE URL
 */
const BASE_IMAGE_URL = 'https://dashboard.caldera.xyz/svgs/tokens';
const IMAGE_SYMBOL_MAP = {
  ETH: `${BASE_IMAGE_URL}/ETH.svg`,
  USDC: `${BASE_IMAGE_URL}/USDC.svg`,
  USDT: `${BASE_IMAGE_URL}/USDT.svg`,
  APE: `${BASE_IMAGE_URL}/APE.svg`,
};

function getTempFallbackImageUrl(symbol: string): string | undefined {
  return IMAGE_SYMBOL_MAP[
    symbol.toUpperCase() as keyof typeof IMAGE_SYMBOL_MAP
  ];
}

export interface TokenRoutesResult {
  /** The token routes data */
  data: TokenRoutesResponse | undefined;
  /** Whether the routes are currently loading */
  isLoading: boolean;
  /** Any error that occurred while fetching the routes */
  error: Error | null;
  /** Time in seconds until the next refresh */
  refreshIn: number;
  /** Whether the routes are currently being refreshed */
  isRefetching: boolean;
}

/**
 * Hook for fetching token routes with countdown timer
 * @param params - Token routes parameters
 * @param refetchInterval - Optional interval for refetching data in milliseconds
 * @returns Token routes result with countdown timer
 */
export function useTokenRoutes(
  params: TokenRoutesParams,
  refetchInterval = 30 * 60 * 1000, // 30 minutes default stale time
): TokenRoutesResult {
  const { router, queryClient } = useMetaRouter();
  const [refreshIn, setRefreshIn] = useState(refetchInterval / 1000);

  const { data, isLoading, error, isRefetching, dataUpdatedAt } = useQuery<
    TokenRoutesResponse,
    Error
  >(
    {
      queryKey: [
        'tokenRoutes',
        {
          ...params,
        },
      ],
      queryFn: () => router.getTokenRoutes(params),
      refetchInterval: refetchInterval,
      staleTime: refetchInterval,
      gcTime: refetchInterval * 2,
    },
    queryClient,
  );

  // Update countdown timer only when we have data and are actively fetching
  useEffect(() => {
    if (!isLoading && !isRefetching && data) {
      const interval = setInterval(() => {
        const nextRefreshAt = dataUpdatedAt + refetchInterval;
        const now = Date.now();
        const timeLeft = Math.max(0, Math.ceil((nextRefreshAt - now) / 1000));

        setRefreshIn(timeLeft);
      }, 1000);

      return () => clearInterval(interval);
    }
    return;
  }, [dataUpdatedAt, refetchInterval, isLoading, isRefetching, data]);

  const parsedData = useMemo(() => {
    const parsedTokens: Record<string, Token> = {};

    if (data?.tokens) {
      Object.entries(data.tokens).forEach(([key, token]) => {
        parsedTokens[key] = {
          ...token,
          imageUrl: token.imageUrl ?? getTempFallbackImageUrl(token.symbol),
        };
      });
    }

    return data && parsedTokens
      ? {
          ...data,
          tokens: parsedTokens,
        }
      : undefined;
  }, [data]);

  return {
    data: parsedData,
    isLoading,
    error: (error as Error | null) ?? null,
    refreshIn,
    isRefetching,
  };
}
