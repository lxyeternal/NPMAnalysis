import { WebSocketError } from '../errors';
import type { MiddlewareChain, Request, Response } from '../middleware';
import type {
  ChainId,
  EIP1193Provider,
  LogFilter,
  PairOptions,
  PairResponse,
  ProviderSubscription,
  TransactionFilter,
  TransactionStatus,
  Update,
} from '../types';

/** Observer interface for handling stream updates */
export type Observer<T> = {
  /** Handler for new values */
  next: (value: T) => void;
  /** Handler for errors */
  error: (error: Error) => void;
  /** Handler for stream completion */
  complete: () => void;
};

/**
 * Observable class for handling streaming data
 * Implements a simplified version of the Observable pattern
 */
export class Observable<T> {
  /**
   * Create a new Observable
   * @param subscribeFn - Function that sets up the subscription
   */
  constructor(private subscribeFn: (observer: Observer<T>) => () => void) {}

  /**
   * Apply an operator to transform the stream
   * @param operator - Function that transforms the Observable
   * @returns A new Observable with the transformation applied
   */
  pipe(operator: (source: Observable<T>) => Observable<T>): Observable<T> {
    return operator(this);
  }

  /**
   * Subscribe to the Observable
   * @param observer - Object containing handlers for stream events
   * @returns Function to unsubscribe from the stream
   */
  subscribe(observer: Observer<T>): () => void {
    return this.subscribeFn(observer);
  }
}

/** Internal subscription state tracking */
interface Subscription {
  /** Unique identifier for the subscription */
  id: string;
  /** Type of subscription (websocket or provider) */
  type: 'websocket' | 'provider';
  /** Chain ID for provider subscriptions */
  chainId?: ChainId;
  /** Set of observers for this subscription */
  observers: Set<Observer<Update<unknown>>>;
  /** Function to clean up the subscription */
  cleanup: () => Promise<void>;
}

/**
 * Client for handling real-time data streams
 * Manages WebSocket connections and provider subscriptions
 */
export class StreamingClient {
  private readonly subscriptions = new Map<string, Subscription>();

  /**
   * Create a new streaming client instance
   * @param config - Configuration including WebSocket URL, API key, and providers
   * @param middlewareChain - Middleware chain for request/response processing
   */
  constructor(
    private readonly config: {
      wsUrl: string;
      apiKey: string;
      providers: Record<number, EIP1193Provider>;
    },
    private readonly middlewareChain: MiddlewareChain,
  ) {}

  /**
   * Get a provider for a specific chain
   * @param chainId - ID of the chain to get provider for
   * @returns The provider for the specified chain
   * @throws {WebSocketError} If no provider is configured for the chain
   */
  private getProvider(chainId: ChainId): EIP1193Provider {
    const provider = this.config.providers[chainId];
    if (!provider) {
      throw new WebSocketError(`No provider configured for chain ${chainId}`);
    }
    return provider;
  }

  /**
   * Execute a provider request through the middleware chain
   * @param chainId - ID of the chain to execute on
   * @param method - JSON-RPC method to call
   * @param params - Parameters for the method
   * @returns Promise resolving to the response data
   */
  private async executeProviderRequest<T>(
    chainId: ChainId,
    method: string,
    params: unknown[],
  ): Promise<T> {
    const provider = this.getProvider(chainId);
    const request: Omit<Request, 'scope'> = {
      method,
      url: `provider://${chainId}`,
      headers: {},
      body: params,
    };

    try {
      // Execute pre-middleware
      const modifiedRequest = await this.middlewareChain.executePreMiddleware(
        request,
        'provider',
      );

      const result = await provider.request({
        method,
        params: modifiedRequest.body as unknown[],
      });

      const response: Omit<Response, 'scope'> = {
        status: 200,
        statusText: 'OK',
        headers: {},
        data: result,
      };

      // Execute post-middleware
      const modifiedResponse = await this.middlewareChain.executePostMiddleware(
        response,
        'provider',
      );
      return modifiedResponse.data as T;
    } catch (error) {
      // Execute error middleware
      await this.middlewareChain.executeErrorMiddleware(
        error as Error,
        'provider',
      );
      throw error;
    }
  }

  /**
   * Subscribe to blockchain logs
   * @param chainId - ID of the chain to subscribe on
   * @param filter - Filter criteria for the logs
   * @returns Promise resolving to the subscription ID
   */
  private async subscribeToLogs(
    chainId: ChainId,
    filter: LogFilter | TransactionFilter,
  ): Promise<string> {
    return this.executeProviderRequest<string>(chainId, 'eth_subscribe', [
      'logs',
      filter,
    ]);
  }

  /**
   * Unsubscribe from blockchain logs
   * @param chainId - ID of the chain to unsubscribe from
   * @param subscriptionId - ID of the subscription to cancel
   */
  private async unsubscribeFromLogs(
    chainId: ChainId,
    subscriptionId: string,
  ): Promise<void> {
    await this.executeProviderRequest<void>(chainId, 'eth_unsubscribe', [
      subscriptionId,
    ]);
  }

  /**
   * Create a stream from provider events
   * @param chainId - ID of the chain to stream from
   * @param filter - Filter criteria for the events
   * @returns Observable of provider events
   */
  private createProviderStream<T>(
    chainId: ChainId,
    filter: LogFilter | TransactionFilter,
  ): Observable<Update<T>> {
    return new Observable((observer) => {
      const subscriptionId = `provider-${chainId}-${Math.random()
        .toString(36)
        .substring(7)}`;
      const subscription: Subscription = {
        id: subscriptionId,
        type: 'provider',
        chainId,
        observers: new Set([observer as Observer<Update<unknown>>]),
        cleanup: async () => {
          const provider = this.getProvider(chainId);
          if (provider) {
            await this.unsubscribeFromLogs(chainId, subscriptionId);
          }
        },
      };

      this.subscriptions.set(subscriptionId, subscription);

      // Subscribe to provider events
      this.subscribeToLogs(chainId, filter)
        .then((id) => {
          this.executeProviderRequest<ProviderSubscription>(
            chainId,
            'eth_subscribe',
            ['subscription', id],
          ).then((sub) => {
            sub.on('data', (data) => {
              for (const obs of subscription.observers) {
                obs.next({
                  type: 'update',
                  data: data as T,
                });
              }
            });

            sub.on('error', (data) => {
              const error =
                data instanceof Error ? data : new Error(String(data));
              for (const obs of subscription.observers) {
                obs.error(error);
              }
            });
          });
        })
        .catch((error) => {
          for (const obs of subscription.observers) {
            obs.error(
              new WebSocketError('Failed to create provider stream', error),
            );
          }
        });

      // Return unsubscribe function
      return () => {
        const sub = this.subscriptions.get(subscriptionId);
        if (sub) {
          sub.observers.delete(observer as Observer<Update<unknown>>);
          if (sub.observers.size === 0) {
            sub.cleanup().catch((error) => {
              console.error('Failed to cleanup subscription:', error);
            });
            this.subscriptions.delete(subscriptionId);
          }
        }
      };
    });
  }

  /**
   * Create a WebSocket stream
   * @param channel - Channel name to subscribe to
   * @param params - Parameters for the subscription
   * @returns Observable of WebSocket events
   */
  private createWebSocketStream<T>(
    channel: string,
    params: Record<string, unknown>,
  ): Observable<Update<T>> {
    return new Observable((observer) => {
      const subscriptionId = `ws-${channel}-${Math.random()
        .toString(36)
        .substring(7)}`;
      const ws = new WebSocket(this.config.wsUrl);

      const subscription: Subscription = {
        id: subscriptionId,
        type: 'websocket',
        observers: new Set([observer as Observer<Update<unknown>>]),
        cleanup: async () => {
          ws.close();
        },
      };

      this.subscriptions.set(subscriptionId, subscription);

      ws.onmessage = async (event) => {
        const data = JSON.parse(event.data);
        const response: Omit<Response, 'scope'> = {
          status: 200,
          statusText: 'OK',
          headers: {},
          data,
        };

        try {
          // Execute post-middleware
          const modifiedResponse =
            await this.middlewareChain.executePostMiddleware(
              response,
              'websocket',
            );
          for (const obs of subscription.observers) {
            obs.next({
              type: 'update',
              data: modifiedResponse.data as T,
            });
          }
        } catch (error) {
          for (const obs of subscription.observers) {
            obs.error(
              error instanceof Error ? error : new Error(String(error)),
            );
          }
        }
      };

      ws.onerror = async (error) => {
        const wsError = new WebSocketError('WebSocket error', error);
        await this.middlewareChain.executeErrorMiddleware(wsError, 'websocket');
        for (const obs of subscription.observers) {
          obs.error(wsError);
        }
      };

      ws.onopen = async () => {
        const request: Omit<Request, 'scope'> = {
          method: 'SUBSCRIBE',
          url: this.config.wsUrl,
          headers: {},
          body: {
            type: 'subscribe',
            channel,
            ...params,
          },
        };

        try {
          // Execute pre-middleware
          const modifiedRequest =
            await this.middlewareChain.executePreMiddleware(
              request,
              'websocket',
            );
          ws.send(JSON.stringify(modifiedRequest.body));
        } catch (error) {
          for (const obs of subscription.observers) {
            obs.error(
              error instanceof Error ? error : new Error(String(error)),
            );
          }
        }
      };

      // Return unsubscribe function
      return () => {
        const sub = this.subscriptions.get(subscriptionId);
        if (sub) {
          sub.observers.delete(observer as Observer<Update<unknown>>);
          if (sub.observers.size === 0) {
            sub.cleanup().catch((error) => {
              console.error('Failed to cleanup subscription:', error);
            });
            this.subscriptions.delete(subscriptionId);
          }
        }
      };
    });
  }

  /**
   * Stream real-time price updates for token pairs
   * @param pairs - Array of token pairs to stream prices for
   * @returns Observable of price updates
   */
  prices(pairs: PairOptions[]): Observable<Update<PairResponse>> {
    return this.createWebSocketStream('prices', { pairs });
  }

  /**
   * Stream transaction status updates
   * @param txHash - Transaction hash or array of hashes to monitor
   * @param chainId - ID of the chain where the transaction was sent
   * @returns Observable of transaction status updates
   */
  transactions(
    txHash: string | string[],
    chainId: ChainId,
  ): Observable<Update<TransactionStatus>> {
    const hashes = Array.isArray(txHash) ? txHash : [txHash];

    // Create a filter for the transaction receipts
    const filter: TransactionFilter = {
      fromBlock: 'latest',
      toBlock: 'latest',
      transactionHashes: hashes,
    };

    return this.createProviderStream(chainId, filter);
  }

  /**
   * Stream blockchain events based on a filter
   * @param chainId - ID of the chain to stream events from
   * @param filter - Filter criteria for the events
   * @returns Observable of blockchain events
   */
  streamEvents<T>(chainId: ChainId, filter: LogFilter): Observable<Update<T>> {
    return this.createProviderStream(chainId, filter);
  }

  /**
   * Get information about active subscriptions
   * @returns Array of active subscription details
   */
  getActiveSubscriptions(): { id: string; type: string; observers: number }[] {
    return Array.from(this.subscriptions.entries()).map(([id, sub]) => ({
      id,
      type: sub.type,
      observers: sub.observers.size,
    }));
  }
}
