import { ApprovalError, ExecutionError } from '../errors';
import type { MiddlewareChain } from '../middleware';
import type {
  Address,
  Amount,
  ChainId,
  MetaRouterOptions,
  TransactionStatus,
} from '../types';

import { AbiFunction, TransactionRequest, Value } from 'ox';
import type { Provider } from 'ox/Provider';
import type { TransactionReceipt } from 'ox/TransactionReceipt';

/** Parameters for checking token approval */
export interface ApprovalCheckParams {
  /** Token contract address */
  token: string;
  /** Address of the token owner */
  owner: Address;
  /** Address of the spender contract */
  spender: Address;
  /** Amount to approve */
  amount: Amount;
  /** Chain ID where the token exists */
  chainId: ChainId;
}

/** Result of checking token approval status */
export interface ApprovalInfo {
  /** Whether the current allowance is sufficient */
  isApproved: boolean;
  /** Current allowance amount */
  currentAllowance: bigint;
  /** Required allowance amount */
  requiredAllowance: bigint;
  /** Transaction to approve the required amount, if needed */
  approvalTransaction?: TransactionRequest.TransactionRequest;
}

/**
 * Client for dispatching transaction requests to EIP-1193 providers
 */
export class ExecutionClient {
  constructor(
    private readonly providers: Record<number, Provider>,
    // @ts-ignore
    private readonly middlewareChains: MiddlewareChain,
  ) {}

  /**
   * Get a provider for a specific chain
   * @param chainId - ID of the chain to get provider for
   * @returns The provider for the specified chain
   * @throws {ExecutionError} If no provider is configured for the chain
   */
  private getProvider(chainId: number): Provider {
    const provider = this.providers[chainId];
    if (!provider) {
      throw new ExecutionError(`No provider configured for chain ${chainId}`);
    }
    return provider;
  }

  /**
   * Make a request to a provider
   * @param chainId - ID of the chain to execute on
   * @param method - JSON-RPC method to call
   * @param params - Parameters for the method
   * @returns Promise resolving to the response data
   */
  private async providerRequest<T>(
    chainId: number,
    method: string,
    params: unknown[],
  ): Promise<T> {
    const provider = this.getProvider(chainId);

    try {
      return (await provider.request({
        method,
        params,
      })) as T;
    } catch (error) {
      throw new ExecutionError(`Provider request failed: ${method}`, error);
    }
  }

  /**
   * Execute a transaction request on the appropriate chain
   * @param request - The transaction request to execute in RPC format (with hex strings)
   * @returns Promise resolving to the transaction hash
   * @throws {ExecutionError} If the transaction fails or no provider is available
   */
  async execute(
    request: Omit<TransactionRequest.TransactionRequest, 'type'> & {
      options?: Partial<MetaRouterOptions>;
    },
  ): Promise<string> {
    const rpcRequest = TransactionRequest.toRpc({
      chainId: request.chainId,
      from: request.from,
      to: request.to,
      data: request.data,
      value: request.value,
    });
    const provider = this.getProvider(request.chainId ?? 1);
    return provider.request({
      method: 'eth_sendTransaction',
      params: [rpcRequest],
    }) as Promise<string>;
  }

  /**
   * Get the status of a transaction
   * @param chainId - ID of the chain where the transaction was sent
   * @param txHash - Hash of the transaction to check
   * @returns Promise resolving to the transaction status
   * @throws {ExecutionError} If the status check fails
   */
  async getStatus(chainId: number, txHash: string): Promise<TransactionStatus> {
    try {
      const receipt = await this.providerRequest<TransactionReceipt>(
        chainId,
        'eth_getTransactionReceipt',
        [txHash],
      );

      if (!receipt) {
        return 'pending';
      }

      return receipt.status === 'success' ? 'confirmed' : 'reverted';
    } catch (error) {
      throw new ExecutionError('Failed to get transaction status', error);
    }
  }

  /**
   * Check if a token approval is needed and get approval transaction if required
   * @param params - Parameters for the approval check
   * @returns Promise resolving to the approval information
   * @throws {ApprovalError} If the approval check fails
   */
  async checkApproval(params: ApprovalCheckParams): Promise<ApprovalInfo> {
    const allowance = AbiFunction.from(
      'function allowance(address owner, address spender) view returns (uint256)',
    );

    try {
      const allowanceResult = await this.providerRequest<string>(
        Number(params.chainId),
        'eth_call',
        [
          {
            to: params.token as `0x${string}`,
            data: AbiFunction.encodeData(allowance, [
              params.owner,
              params.spender,
            ]),
          },
          'latest',
        ],
      );

      const decodedAllowance = AbiFunction.decodeResult(
        allowance,
        allowanceResult as `0x${string}`,
      );
      const requiredAllowance = Value.from(params.amount);
      const isApproved = decodedAllowance >= requiredAllowance;

      if (isApproved) {
        return {
          isApproved,
          currentAllowance: decodedAllowance,
          requiredAllowance,
        };
      }

      const approve = AbiFunction.from(
        'function approve(address spender, uint256 amount) returns (bool)',
      );
      const approveData = AbiFunction.encodeData(approve, [
        params.spender,
        requiredAllowance,
      ]);
      return {
        isApproved,
        currentAllowance: decodedAllowance,
        requiredAllowance,
        approvalTransaction: {
          from: params.owner,
          to: params.token as `0x${string}`,
          data: approveData,
        },
      };
    } catch (error) {
      throw new ApprovalError('Failed to check approval', error);
    }
  }
}
