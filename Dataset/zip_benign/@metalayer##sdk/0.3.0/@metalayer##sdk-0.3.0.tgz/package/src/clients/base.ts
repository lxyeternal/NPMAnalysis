import type { MiddlewareChain } from '../middleware';

/**
 * Abstract base client class that provides common functionality for all API clients
 * Handles API key management and middleware chain integration
 */
export abstract class BaseClient {
  /**
   * Create a new base client instance
   * @param apiKey - API key for authentication
   * @param middlewareChain - Middleware chain for request/response processing
   */
  protected constructor(
    /** API key for authentication */
    protected readonly apiKey: string,
    /** Middleware chain for request/response processing */
    protected readonly middlewareChain: MiddlewareChain,
  ) {}
}
