import type { MiddlewareChain } from '../middleware';
import type {
  QuotesParams,
  QuotesResponse,
  SupportedChainsParams,
  SupportedChainsResponse,
  TokenRoutesParams,
  TokenRoutesResponse,
} from '../types';
import { BaseClient } from './base';

import { Client, createClient } from '@connectrpc/connect';
import { createConnectTransport } from '@connectrpc/connect-web';
import { MetarouterService } from '@metalayer/protocol-buffers/src/caldera/metarouter/v1/service_pb';

/** Gas estimation for a route */
export interface GasEstimate {
  /** Estimated gas limit for the transaction */
  gasLimit: string;
  /** Current gas price */
  gasPrice: string;
  /** Estimated cost in native token */
  estimatedCost: string;
  /** Token used for gas payment */
  token: string;
}

/** Analysis of a route's execution and impact */
export interface RouteAnalysis {
  /** Unique identifier for the route */
  routeId: string;
  /** Simulation results of executing the route */
  simulation: {
    /** Whether the simulation was successful */
    success: boolean;
    /** Amount of gas used in the simulation */
    gasUsed: string;
    /** Return data from the simulation */
    returnData: string;
    /** Events emitted during simulation */
    events: Array<{
      /** Contract address that emitted the event */
      address: string;
      /** Event topics (first topic is the event signature) */
      topics: string[];
      /** ABI-encoded event data */
      data: string;
    }>;
  };
  /** Additional insights about the route */
  insights: {
    /** Price impact of executing the route */
    priceImpact: string;
    /** Minimum amount received after slippage */
    minimumReceived: string;
    /** Number of alternative routes available */
    alternativeRoutes: number;
  };
}

/**
 * Client for interacting with routing-related endpoints
 * Handles quote retrieval, route analysis, and gas estimation
 */
export class RoutingClient extends BaseClient {
  private readonly client: Client<typeof MetarouterService>;

  /**
   * Create a new routing client instance
   * @param apiKey - API key for authentication
   * @param middlewareChain - Middleware chain for request/response processing
   * @param baseUrl - Base URL for API requests
   */
  constructor(
    apiKey: string,
    middlewareChain: MiddlewareChain,
    baseUrl: string,
  ) {
    super(apiKey, middlewareChain);

    // Creates protobuf client with interceptor
    const transport = createConnectTransport({
      baseUrl,
      interceptors: [
        (next) => async (req) => {
          req.header.set('x-api-key', this.apiKey);
          req.header.set('accept', 'application/json');
          return next(req);
        },
      ],
      useBinaryFormat: false,
    });

    this.client = createClient(MetarouterService, transport);
  }

  /**
   * Get a quote for a token swap
   * @param params - Parameters for the quote request
   * @returns Promise resolving to the quote response
   */
  async getQuote(params: QuotesParams): Promise<QuotesResponse> {
    const { $typeName, $unknown, ...rest } = await this.client.getQuotes({
      ...params,
      amount: params.amount.toString(),
    });

    return {
      ...rest,
      quotes: rest.quotes.map((quote) => ({
        ...quote,
        amountIn: BigInt(quote.amountIn),
        amountOut: BigInt(quote.amountOut),
        totalFees: BigInt(quote.totalFees),
      })),
    };
  }

  /**
   * Get token routes for a token swap
   * @param parmas - Parameters to filter the token routes
   * @returns Promise resolving to the token routes
   */
  async getTokenRoutes(
    params: TokenRoutesParams,
  ): Promise<TokenRoutesResponse> {
    const { $typeName, $unknown, ...rest } =
      await this.client.getTokenRoutes(params);
    return rest;
  }

  /**
   * Get supported chains
   * @returns Promise resolving to the supported chains
   */
  async getSupportedChains(
    params: SupportedChainsParams,
  ): Promise<SupportedChainsResponse> {
    const { $typeName, $unknown, ...rest } =
      await this.client.getSupportedChains(params);

    return rest;
  }

  /**
   * Get quotes for a list of token swaps
   * @param requests - List of quote request parameters
   * @returns Promise resolving to a list of available quotes
   */
  async getQuotes(requests: QuotesParams[]): Promise<QuotesResponse[]> {
    const quotes: Promise<QuotesResponse>[] = requests.map((request) =>
      this.getQuote(request),
    );
    return Promise.all(quotes);
  }
}
