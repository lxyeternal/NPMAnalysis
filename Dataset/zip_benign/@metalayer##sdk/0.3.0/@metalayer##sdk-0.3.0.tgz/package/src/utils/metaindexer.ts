/**
 * GraphQL fragment for shared funds bridge transaction fields
 */
export const FUNDS_BRIDGE_FIELDS = `
  id
  bridge
  status
  destinationTransactionHash
  destinationToken
  destinationChainId
  destinationAmount
  destinationAddress
  sourceAddress
  sourceAmount
  sourceChainId
  sourceToken
  sourceTransactionHash
  timestamp
`;
