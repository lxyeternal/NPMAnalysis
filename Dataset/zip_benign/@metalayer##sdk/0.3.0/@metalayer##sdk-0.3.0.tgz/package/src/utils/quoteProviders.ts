import { QuoteProvider } from '@metalayer/protocol-buffers/src/caldera/metarouter/v1/quotes_pb';
import startCase from 'lodash.startcase';
import toLower from 'lodash.tolower';

export function formatQuoteProvider(provider: QuoteProvider): string {
  switch (provider) {
    case QuoteProvider.UNSPECIFIED:
      return 'Unspecified';
    case QuoteProvider.NITRO_BRIDGE:
      return 'Nitro Bridge';
    case QuoteProvider.BEDROCK_BRIDGE:
      return 'Bedrock Bridge';
    case QuoteProvider.ZKSYNC_BRIDGE:
      return 'zkSync Bridge';
    case QuoteProvider.ACROSS:
      return 'Across';
    case QuoteProvider.ECO:
      return 'Eco';
    case QuoteProvider.RELAY:
      return 'Relay';
    default:
      return QuoteProvider[provider]
        ? startCase(toLower(QuoteProvider[provider]))
        : 'Unknown Provider';
  }
}
