import type { Middleware } from '../middleware';

/**
 * Middleware for logging requests and responses
 * Logs request method, URL, status, and error messages
 */
export const loggingMiddleware: Middleware = {
  pre: async (request) => {
    console.log(`[Request] ${request.method} ${request.url}`);
    return request;
  },
  post: async (response) => {
    console.log(`[Response] Status: ${response.status}`);
    return response;
  },
  error: async (error) => {
    console.error(`[Error] ${error.message}`);
  },
  scopes: ['http', 'websocket', 'routing', 'quote', 'provider'],
};
