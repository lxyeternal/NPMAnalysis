import type { Middleware, MiddlewareScope } from '../middleware';

/**
 * Options for the retry middleware
 * @param maxRetries - The maximum number of retries
 * @param retryDelay - The delay between retries in milliseconds
 * @param shouldRetry - A function that determines if a request should be retried
 */
export interface RetryOptions {
  maxRetries?: number;
  retryDelay?: number;
  shouldRetry?: (error: Error) => boolean;
}

/**
 * Middleware for retrying failed requests
 * @param options - The options for the retry middleware
 * @returns The middleware function
 */
export function retryMiddleware(options: RetryOptions = {}): Middleware {
  const {
    maxRetries = 3,
    retryDelay = 1000,
    shouldRetry = (error: Error) =>
      error instanceof Error && error.message.includes('timeout'),
  } = options;

  return {
    scopes: ['http', 'quote', 'routing'] as MiddlewareScope[],
    pre: async (request) => {
      return request;
    },
    error: async (error: Error, _: MiddlewareScope) => {
      if (shouldRetry(error)) {
        let retryCount = 0;
        while (retryCount < maxRetries) {
          try {
            await new Promise((resolve) => setTimeout(resolve, retryDelay));
            retryCount++;
          } catch (retryError) {
            console.error(`Retry attempt ${retryCount} failed:`, retryError);
          }
        }
      }
    },
  };
}
