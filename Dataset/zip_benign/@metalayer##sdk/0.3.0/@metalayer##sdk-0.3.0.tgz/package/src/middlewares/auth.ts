import type { Middleware } from '../middleware';

/**
 * Middleware for adding an API key to requests
 * @param apiKey - The API key to add to requests
 * @returns The middleware function
 */
export const authMiddleware = (apiKey: string): Middleware => ({
  pre: async (request) => ({
    ...request,
    headers: {
      ...request.headers,
      'X-API-Key': apiKey,
    },
  }),
  scopes: ['routing', 'websocket'],
});
