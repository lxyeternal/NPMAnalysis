import { authMiddleware } from './middlewares/auth';
import { loggingMiddleware } from './middlewares/logging';
import { retryMiddleware } from './middlewares/retry';

/** Supported middleware scopes for request/response handling */
export type MiddlewareScope =
  | 'http'
  | 'quote'
  | 'websocket'
  | 'provider'
  | 'routing'
  | 'execution';

/** Represents an HTTP-like request with scope information */
export interface Request {
  /** HTTP method (GET, POST, etc.) */
  method: string;
  /** Target URL for the request */
  url: string;
  /** Request headers */
  headers: Record<string, string>;
  /** Optional request body */
  body?: unknown;
  /** Middleware scope for this request */
  scope: MiddlewareScope;
}

/** Represents an HTTP-like response with scope information */
export interface Response {
  /** HTTP status code */
  status: number;
  /** HTTP status text */
  statusText: string;
  /** Response headers */
  headers: Record<string, string>;
  /** Response data */
  data: unknown;
  /** Middleware scope for this response */
  scope: MiddlewareScope;
}

/**
 * Middleware interface for request/response processing
 * Each middleware can handle pre-request, post-response, and error scenarios
 */
export interface Middleware {
  /** List of scopes this middleware applies to */
  scopes: MiddlewareScope[];
  /** Pre-request handler */
  pre?: (request: Request) => Promise<Request>;
  /** Post-response handler */
  post?: (response: Response) => Promise<Response>;
  /** Error handler */
  error?: (error: Error, scope: MiddlewareScope) => Promise<void>;
}

/**
 * Interface for managing a chain of middleware
 * Handles the execution flow of requests through multiple middleware
 */
export interface MiddlewareChain {
  /** Add a middleware to the chain */
  use(middleware: Middleware): void;
  /** Execute pre-request middleware for a given scope */
  executePreMiddleware(
    request: Omit<Request, 'scope'>,
    scope: MiddlewareScope,
  ): Promise<Request>;
  /** Execute post-response middleware for a given scope */
  executePostMiddleware(
    response: Omit<Response, 'scope'>,
    scope: MiddlewareScope,
  ): Promise<Response>;
  /** Execute error middleware for a given scope */
  executeErrorMiddleware(error: Error, scope: MiddlewareScope): Promise<void>;
  /** Execute a complete request through the middleware chain */
  execute(request: Request): Promise<Response>;
}

/**
 * Implementation of the MiddlewareChain interface
 * Manages the execution of middleware in sequence
 */
export class MiddlewareChainImpl implements MiddlewareChain {
  private middlewares: Middleware[] = [];

  /** Add a middleware to the chain */
  use(middleware: Middleware): void {
    this.middlewares.push(middleware);
  }

  /** Execute pre-request middleware for a given scope */
  async executePreMiddleware(
    request: Omit<Request, 'scope'>,
    scope: MiddlewareScope,
  ): Promise<Request> {
    let currentRequest: Request = { ...request, scope };

    for (const middleware of this.middlewares) {
      if (middleware.pre && middleware.scopes.includes(scope)) {
        currentRequest = await middleware.pre(currentRequest);
      }
    }

    return currentRequest;
  }

  /** Execute post-response middleware for a given scope */
  async executePostMiddleware(
    response: Omit<Response, 'scope'>,
    scope: MiddlewareScope,
  ): Promise<Response> {
    let currentResponse: Response = { ...response, scope };

    for (const middleware of this.middlewares) {
      if (middleware.post && middleware.scopes.includes(scope)) {
        currentResponse = await middleware.post(currentResponse);
      }
    }

    return currentResponse;
  }

  /** Execute error middleware for a given scope */
  async executeErrorMiddleware(
    error: Error,
    scope: MiddlewareScope,
  ): Promise<void> {
    for (const middleware of this.middlewares) {
      if (middleware.error && middleware.scopes.includes(scope)) {
        await middleware.error(error, scope);
      }
    }
  }

  /**
   * Execute a complete request through the middleware chain
   * Handles pre-request, request execution, post-response, and error scenarios
   */
  async execute(request: Request): Promise<Response> {
    try {
      const modifiedRequest = await this.executePreMiddleware(
        request,
        request.scope,
      );

      const response = await fetch(modifiedRequest.url, {
        method: modifiedRequest.method,
        headers: modifiedRequest.headers,
        body: modifiedRequest.body
          ? JSON.stringify(modifiedRequest.body)
          : undefined,
      });

      const responseData = await response.json();
      const apiResponse: Omit<Response, 'scope'> = {
        status: response.status,
        statusText: response.statusText,
        headers: Object.fromEntries(response.headers.entries()),
        data: responseData,
      };

      const modifiedResponse = await this.executePostMiddleware(
        apiResponse,
        request.scope,
      );

      if (!response.ok) {
        throw new Error(modifiedResponse.statusText);
      }

      return modifiedResponse;
    } catch (error) {
      await this.executeErrorMiddleware(error as Error, request.scope);
      throw error;
    }
  }
}

/** Create a new middleware chain instance */
export function createMiddlewareChain(): MiddlewareChain {
  return new MiddlewareChainImpl();
}

/**
 * Create a logging middleware with configurable scopes
 * Logs request, response, and error information
 */
export const loggingMiddlewareWithScope = (
  scopes: MiddlewareScope[] = [
    'http',
    'quote',
    'websocket',
    'provider',
    'routing',
  ],
): Middleware => ({
  scopes,
  pre: async (request) => {
    console.log(`[${request.scope}] Request: ${request.method} ${request.url}`);
    return request;
  },
  post: async (response) => {
    console.log(`[${response.scope}] Response: ${response.status}`);
    return response;
  },
  error: async (error) => {
    console.error(`[Error] ${error.message}`);
  },
});

/**
 * Create a retry middleware with configurable scopes
 * Handles retrying failed requests with delay
 */
export const retryMiddlewareWithScope = (
  scopes: MiddlewareScope[] = ['http'],
  maxRetries = 3,
  delayMs = 1000,
): Middleware => ({
  scopes,
  pre: async (request) => request,
  post: async (response) => response,
  error: async (error) => {
    let retries = 0;
    while (retries < maxRetries) {
      try {
        await new Promise((resolve) => setTimeout(resolve, delayMs));
        retries++;
      } catch (retryError) {
        if (retries === maxRetries - 1) throw retryError;
      }
    }
    throw error;
  },
});

/**
 * Create an authentication middleware with configurable scopes
 * Adds API key to request headers
 */
export const authMiddlewareWithScope = (
  apiKey: string,
  scopes: MiddlewareScope[] = ['http'],
): Middleware => ({
  scopes,
  pre: async (request) => ({
    ...request,
    headers: {
      ...request.headers,
      'X-API-Key': apiKey,
    },
  }),
});

export { authMiddleware, retryMiddleware, loggingMiddleware };
