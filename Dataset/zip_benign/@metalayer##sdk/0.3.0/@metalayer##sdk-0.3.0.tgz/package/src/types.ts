import type {
  GetQuotesRequest,
  GetQuotesResponse,
} from '@metalayer/protocol-buffers/src/caldera/metarouter/v1/quotes_pb';
import type {
  GetSupportedChainsRequest,
  GetSupportedChainsResponse,
} from '@metalayer/protocol-buffers/src/caldera/metarouter/v1/supported_chains_pb';
import type {
  GetTokenRoutesRequest,
  GetTokenRoutesResponse,
} from '@metalayer/protocol-buffers/src/caldera/metarouter/v1/token_routes_pb';
import type { TransactionRequest } from 'ox';
import type { Provider } from 'ox/Provider';

export type { Token } from '@metalayer/protocol-buffers/src/caldera/common/token_pb';
export { QuoteProvider } from '@metalayer/protocol-buffers/src/caldera/metarouter/v1/quotes_pb';
export { TransactionType } from '@metalayer/protocol-buffers/src/caldera/common/transaction_request_pb';

// Branded Types
export type ChainId = number & { readonly brand: unique symbol };
export type Address = `0x${string}` & { readonly brand: unique symbol };
export type Amount = string & { readonly brand: unique symbol };

// Type Guards
export function isValidAddress(value: string): value is Address {
  return /^0x[a-fA-F0-9]{40}$/.test(value);
}

export function isValidAmount(value: string): value is Amount {
  return /^\d+$/.test(value) && BigInt(value) >= 0n;
}

// Provider Types
export interface EIP1193Provider extends Provider {}

export interface ProviderSubscription {
  on(event: 'data' | 'error', listener: (data: unknown) => void): void;
  off(event: 'data' | 'error', listener: (data: unknown) => void): void;
  unsubscribe(): Promise<void>;
}

export interface LogFilter {
  fromBlock?: string | number;
  toBlock?: string | number;
  address?: string | string[];
  topics?: (string | string[] | null)[];
}

export interface TransactionFilter {
  fromBlock?: string | number;
  toBlock?: string | number;
  transactionHashes?: string[];
}

// Configuration Types
export type GasSpeed = 'slow' | 'standard' | 'fast' | 'instant';

export interface MetaRouterOptions {
  slippageTolerance: number;
  deadline: number;
  gasSpeed: GasSpeed;
  referralCode?: string;
}

export interface MetaRouterConfig {
  apiKey: string;
  apiUrl?: string;
  environment: 'live' | 'test';
  defaultOptions?: MetaRouterOptions;
  providers?: Record<number, EIP1193Provider>;
  graphqlUrl?: string;
}

export interface Target {
  chain: ChainId;
  address: Address;
}

export interface TokenRoute {
  chainInId: number;
  chainOutId: number;
  tokenInAddress: string;
  tokenOutAddress: string;
}

declare type extraMessageFields = '$typeName' | '$unknown';

export interface Quote
  extends Omit<
    GetQuotesResponse['quotes'][number],
    'amountIn' | 'amountOut' | 'totalFees' | extraMessageFields
  > {
  amountIn: bigint;
  amountOut: bigint;
  totalFees: bigint;
}

export interface QuotesResponse
  extends Omit<GetQuotesResponse, 'quotes' | extraMessageFields> {
  quotes: Quote[];
}

export interface QuotesParams
  extends Omit<GetQuotesRequest, 'amount' | extraMessageFields> {
  amount: bigint;
}

export type QuoteStep = Omit<Quote['steps'][number], extraMessageFields>;

export type TokenRoutesParams = Omit<GetTokenRoutesRequest, extraMessageFields>;

export type TokenRoutesResponse = Omit<
  GetTokenRoutesResponse,
  extraMessageFields
>;

export type SupportedChainsParams = Omit<
  GetSupportedChainsRequest,
  extraMessageFields
>;

export type SupportedChainsResponse = Omit<
  GetSupportedChainsResponse,
  extraMessageFields
>;

// Execution Types
export interface ExecuteParams {
  chainId: Omit<TransactionRequest.Rpc, 'chainId'> extends Pick<
    Required<TransactionRequest.Rpc>,
    'chainId'
  >
    ? never
    : ChainId;
  request: Partial<TransactionRequest.Rpc>;
  options?: Partial<MetaRouterOptions>;
}

export interface ExecutionResult {
  transactionHash: string;
  status: TransactionStatus;
  events: unknown[];
}

export type TransactionStatus = 'pending' | 'confirmed' | 'failed' | 'reverted';

// Streaming Types
export interface Update<T> {
  type: 'update' | 'error' | 'complete';
  data?: T;
  error?: Error;
}

export interface PairOptions {
  baseToken: string | Target;
  quoteToken: string | Target;
}

export interface PairResponse {
  price: string;
  timestamp: number;
  volume24h?: string;
}

export interface StreamParams<T> {
  filter?: (data: T) => boolean;
  throttle?: number;
  retry?: boolean;
  data?: Record<string, unknown>;
}

export type StreamType = 'prices' | 'transactions' | 'events';

/** MetaIndexer Types */
/**
 * Supported bridge types
 */
export enum Bridge {
  ECO = 'ECO',
  NITRO_NATIVE = 'NITRO_NATIVE',
  BEDROCK_NATIVE = 'BEDROCK_NATIVE',
  RELAY = 'RELAY',
}

/**
 * The status of a funds bridge transaction
 */
export enum BridgeStatus {
  PENDING = 'PENDING',
  FULFILLED = 'FULFILLED',
  REFUNDED = 'REFUNDED',
  WAITING_TO_PROVE = 'WAITING_TO_PROVE',
  WITHDRAWAL_PROVEN = 'WITHDRAWAL_PROVEN',
}

/**
 * Represents a funds bridge transaction
 * This interface is designed to be flexible as the API schema may change
 */
export interface FundsBridgeTransaction {
  /** Unique identifier for the transaction */
  id: string;
  /** Bridge type */
  bridge?: Bridge;
  /** Current status of the bridge transaction */
  status?: BridgeStatus;
  /** Transaction hash on the source chain */
  sourceTransactionHash?: string;
  /** Transaction hash on the destination chain (if completed) */
  destinationTransactionHash?: string | null;
  /** Chain ID of the source chain */
  sourceChainId?: number | string;
  /** Chain ID of the destination chain */
  destinationChainId?: number | string;
  /** Source wallet address */
  sourceAddress?: string;
  /** Destination wallet address */
  destinationAddress?: string;
  /** Amount sent on the source chain */
  sourceAmount?: string;
  /** Amount received on the destination chain */
  destinationAmount?: string | null;
  /** Token address on source chain */
  sourceToken?: string;
  /** Token address on destination chain */
  destinationToken?: string;
  /** Timestamp when the bridge event was initiated */
  timestamp?: number;
  /** Timestamp of the last status update */
  lastUpdated?: number;
}
