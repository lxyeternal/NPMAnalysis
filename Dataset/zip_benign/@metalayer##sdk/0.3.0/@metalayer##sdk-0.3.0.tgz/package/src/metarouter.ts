import { ExecutionClient } from './clients/execution';
import { RoutingClient } from './clients/routing';
import { StreamingClient } from './clients/streaming';
import { ConfigurationError } from './errors';
import type { Middleware, MiddlewareChain } from './middleware';
import { MiddlewareChainImpl } from './middleware';
import type {
  ExecuteParams,
  MetaRouterConfig,
  QuotesParams,
  SupportedChainsParams,
  SupportedChainsResponse,
  TokenRoutesParams,
  TokenRoutesResponse,
} from './types';

/** Default configuration values for the MetaRouter SDK */
const DEFAULT_CONFIG: Partial<MetaRouterConfig> = {
  apiUrl: 'https://ogckjhagt5.execute-api.us-west-2.amazonaws.com',
  environment: 'live',
  defaultOptions: {
    slippageTolerance: 0.005, // 0.5%
    deadline: 20 * 60, // 20 minutes
    gasSpeed: 'standard',
  },
};

/**
 * Main entry point for the MetaRouter SDK
 * Provides access to routing, execution, and streaming functionality
 */
export class MetaRouter {
  readonly config: MetaRouterConfig;
  private readonly _routes: RoutingClient;
  private readonly _execution: ExecutionClient;
  private readonly _streams: StreamingClient;
  private readonly middlewareChain: MiddlewareChain;

  /**
   * Create a new MetaRouter instance
   * @param config - Partial configuration object
   * @throws {ConfigurationError} If required configuration values are missing
   */
  private constructor(config: Partial<MetaRouterConfig>) {
    if (!config.apiKey) {
      throw new ConfigurationError('API key is required');
    }

    this.config = {
      ...DEFAULT_CONFIG,
      ...config,
    } as MetaRouterConfig;

    const apiUrl = this.config.apiUrl;
    if (!apiUrl) {
      throw new ConfigurationError('API URL is required');
    }

    this.middlewareChain = new MiddlewareChainImpl();

    const baseConfig = {
      apiUrl,
      apiKey: this.config.apiKey,
      providers: this.config.providers ?? {},
    };

    this._routes = new RoutingClient(
      baseConfig.apiKey,
      this.middlewareChain,
      baseConfig.apiUrl,
    );
    this._execution = new ExecutionClient(baseConfig, this.middlewareChain);
    this._streams = new StreamingClient(
      {
        wsUrl: apiUrl.replace('http', 'ws'),
        apiKey: this.config.apiKey,
        providers: this.config.providers ?? {},
      },
      this.middlewareChain,
    );
  }

  /**
   * Initialize a new MetaRouter instance
   * @param config - Partial configuration object
   * @returns A new MetaRouter instance
   * @throws {ConfigurationError} If required configuration values are missing
   */
  static init(config: Partial<MetaRouterConfig>): MetaRouter {
    return new MetaRouter(config);
  }

  /**
   * Add middleware to the middleware chain
   * @param middleware - Middleware to add
   */
  use(middleware: Middleware): void {
    this.middlewareChain.use(middleware);
  }

  /**
   * Execute a token swap
   * @param params - Parameters for the swap execution
   * @returns Promise resolving to the execution result
   */
  async swap(params: ExecuteParams) {
    return this._execution.execute({
      ...params,
      options: {
        ...this.config.defaultOptions,
        ...params.options,
      },
    });
  }

  /**
   * Execute a cross-chain bridge transaction
   * @param params - Parameters for the bridge execution
   * @returns Promise resolving to the execution result
   */
  async bridge(params: ExecuteParams) {
    return this._execution.execute({
      ...params,
      options: {
        ...this.config.defaultOptions,
        ...params.options,
        // apply bridge-specific options?
      },
    });
  }

  /**
   * Get a quote for a token swap
   * @param params - Parameters for the quote request
   * @returns Promise resolving to the route quote
   */
  async quote(params: QuotesParams) {
    return this._routes.getQuote({
      ...params,
      // options: {
      //   ...this.config.defaultOptions,
      //   ...params.options,
      // },
    });
  }

  /**
   * Access the routing client for advanced routing operations
   * @returns The routing client instance
   */
  get routes() {
    return this._routes;
  }

  /**
   * Access the execution client for advanced execution operations
   * @returns The execution client instance
   */
  get execution() {
    return this._execution;
  }

  /**
   * Access the streaming client for WebSocket and provider streams
   * @returns The streaming client instance
   */
  get streams() {
    return this._streams;
  }

  async getTokenRoutes(
    params: TokenRoutesParams,
  ): Promise<TokenRoutesResponse> {
    return this._routes.getTokenRoutes(params);
  }

  async getSupportedChains(
    params: SupportedChainsParams,
  ): Promise<SupportedChainsResponse> {
    return this._routes.getSupportedChains(params);
  }
}
