import type { ChainId } from './types';

// Most of the stuff in this helper will actually come from the API
// so I'm just hacking something together for now. Pay no mind.
export const Chains = {
  // Mainnets
  ETHEREUM: 1 as ChainId,
  BSC: 56 as ChainId,
  POLYGON: 137 as ChainId,
  ARBITRUM: 42161 as ChainId,
  OPTIMISM: 10 as ChainId,
  AVALANCHE: 43114 as ChainId,
  FANTOM: 250 as ChainId,

  // Testnets
  GOERLI: 5 as ChainId,
  BSC_TESTNET: 97 as ChainId,
  MUMBAI: 80001 as ChainId,
  ARBITRUM_GOERLI: 421613 as ChainId,
  OPTIMISM_GOERLI: 420 as ChainId,
  AVALANCHE_FUJI: 43113 as ChainId,
  FANTOM_TESTNET: 4002 as ChainId,
} as const;

export interface ChainInfo {
  name: string;
  nativeCurrency: {
    name: string;
    symbol: string;
    decimals: number;
  };
  rpcUrls: string[];
  blockExplorers: {
    name: string;
    url: string;
  }[];
  testnet: boolean;
}

export const ChainData: Record<ChainId, ChainInfo> = {
  [Chains.ETHEREUM]: {
    name: 'Ethereum',
    nativeCurrency: {
      name: 'Ether',
      symbol: 'ETH',
      decimals: 18,
    },
    rpcUrls: ['https://eth.llamarpc.com'],
    blockExplorers: [
      {
        name: 'Etherscan',
        url: 'https://etherscan.io',
      },
    ],
    testnet: false,
  },
  [Chains.BSC]: {
    name: 'BNB Smart Chain',
    nativeCurrency: {
      name: 'BNB',
      symbol: 'BNB',
      decimals: 18,
    },
    rpcUrls: ['https://bsc.llamarpc.com'],
    blockExplorers: [
      {
        name: 'BscScan',
        url: 'https://bscscan.com',
      },
    ],
    testnet: false,
  },
} as const;

export interface CommonToken {
  address: string;
  chainId: ChainId;
  name: string;
  symbol: string;
  decimals: number;
  logoURI?: string;
}

export const CommonTokens: Record<ChainId, Record<string, CommonToken>> = {
  [Chains.ETHEREUM]: {
    WETH: {
      address: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
      chainId: Chains.ETHEREUM,
      name: 'Wrapped Ether',
      symbol: 'WETH',
      decimals: 18,
      logoURI:
        'https://raw.githubusercontent.com/trustwallet/assets/master/blockchains/ethereum/assets/0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2/logo.png',
    },
    USDC: {
      address: '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48',
      chainId: Chains.ETHEREUM,
      name: 'USD Coin',
      symbol: 'USDC',
      decimals: 6,
      logoURI:
        'https://raw.githubusercontent.com/trustwallet/assets/master/blockchains/ethereum/assets/0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48/logo.png',
    },
    USDT: {
      address: '0xdAC17F958D2ee523a2206206994597C13D831ec7',
      chainId: Chains.ETHEREUM,
      name: 'Tether USD',
      symbol: 'USDT',
      decimals: 6,
      logoURI:
        'https://raw.githubusercontent.com/trustwallet/assets/master/blockchains/ethereum/assets/0xdAC17F958D2ee523a2206206994597C13D831ec7/logo.png',
    },
  },
  [Chains.OPTIMISM]: {
    WETH: {
      address: '0x4200000000000000000000000000000000000006',
      chainId: Chains.OPTIMISM,
      name: 'Wrapped Ether',
      symbol: 'WETH',
      decimals: 18,
      logoURI:
        'https://raw.githubusercontent.com/trustwallet/assets/master/blockchains/ethereum/assets/0x4200000000000000000000000000000000000006/logo.png',
    },
    USDC: {
      address: '0x0b2c639c533813f4aa9d7837caf62653d097ff85',
      chainId: Chains.OPTIMISM,
      name: 'USD Coin',
      symbol: 'USDC',
      decimals: 6,
      logoURI:
        'https://raw.githubusercontent.com/trustwallet/assets/master/blockchains/ethereum/assets/0x0b2c639c533813f4aa9d7837caf62653d097ff85/logo.png',
    },
  },
} as const;

export function isNativeToken(_: ChainId, address: string): boolean {
  return address === '0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE';
}

export function getChainInfo(chainId: ChainId): ChainInfo {
  const chainInfo = ChainData[chainId];
  if (!chainInfo) {
    throw new Error(`Chain ID ${chainId} not supported`);
  }
  return chainInfo;
}

export function getCommonToken(chainId: ChainId, symbol: string): CommonToken {
  const chainTokens = CommonTokens[chainId];
  if (!chainTokens) {
    throw new Error(`Chain ID ${chainId} not supported`);
  }

  const token = chainTokens[symbol];
  if (!token) {
    throw new Error(`Token ${symbol} not found on chain ${chainId}`);
  }

  return token;
}
