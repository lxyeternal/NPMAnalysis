export class MetaRouterError extends Error {
  constructor(
    message: string,
    public code: string,
    public details?: unknown,
  ) {
    super(message);
    this.name = 'MetaRouterError';
  }
}

export class ValidationError extends MetaRouterError {
  constructor(message: string, details?: unknown) {
    super(message, 'VALIDATION_ERROR', details);
    this.name = 'ValidationError';
  }
}

export class QuoteError extends MetaRouterError {
  constructor(message: string, details?: unknown) {
    super(message, 'QUOTE_ERROR', details);
    this.name = 'QuoteError';
  }
}

export class ExecutionError extends MetaRouterError {
  constructor(message: string, details?: unknown) {
    super(message, 'EXECUTION_ERROR', details);
    this.name = 'ExecutionError';
  }
}

export class NetworkError extends MetaRouterError {
  constructor(message: string, details?: unknown) {
    super(message, 'NETWORK_ERROR', details);
    this.name = 'NetworkError';
  }
}

export class WebSocketError extends MetaRouterError {
  constructor(message: string, details?: unknown) {
    super(message, 'WEBSOCKET_ERROR', details);
    this.name = 'WebSocketError';
  }
}

export class ApprovalError extends MetaRouterError {
  constructor(message: string, details?: unknown) {
    super(message, 'APPROVAL_ERROR', details);
    this.name = 'ApprovalError';
  }
}

export class ConfigurationError extends MetaRouterError {
  constructor(message: string, details?: unknown) {
    super(message, 'CONFIGURATION_ERROR', details);
    this.name = 'ConfigurationError';
  }
}
