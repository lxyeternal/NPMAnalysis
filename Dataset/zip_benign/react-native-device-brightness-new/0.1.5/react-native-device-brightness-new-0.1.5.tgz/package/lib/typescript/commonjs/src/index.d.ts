export declare function getBrightness(): Promise<number>;
export declare function setBrightness(brightness: number): Promise<void>;
export declare function resetBrightness(): Promise<void>;
//# sourceMappingURL=index.d.ts.map