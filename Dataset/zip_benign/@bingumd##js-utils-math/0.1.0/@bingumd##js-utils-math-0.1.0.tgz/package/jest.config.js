module.exports = {
	verbose: true,
}
