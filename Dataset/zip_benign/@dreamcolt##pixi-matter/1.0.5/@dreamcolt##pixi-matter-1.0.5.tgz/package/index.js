import Matter from "matter-js";
var Engine = Matter.Engine,
    World = Matter.World,
    Bodies = Matter.Bodies,
    Render = Matter.Render,
    Body = Matter.Body;
var engine;

var pixiApp;

var bodyList = []; //刚体列表
var BodyAbstract = function() {};
//刚体抽象类圆形，所有刚体实例将继承自它
BodyAbstract.prototype = {
    constructor: BodyAbstract,
    update: function() {
        if (!this.displayObj) return;
        this.displayObj.x = this.body.position.x;
        this.displayObj.y = this.body.position.y;
        this.displayObj.rotation = this.body.angle;
    },
    destroy: function() {
        this.displayObj &&
            this.displayObj.parent &&
            this.displayObj.parent.removeChild(this.displayObj);
        this.removeBody();
    },
    removeBody: function() {
        World.remove(engine.world, this.body);
        for (let i = 0; i < bodyList.length; i++) {
            if (bodyList[i] == this.body) {
                bodyList.splice(i, 1);
                break;
            }
        }
    },
    setStatic: function(isStatic = false) {
        Body.setStatic(this.body, isStatic);
    },
    //设置位置

    setPosition: function(x = 0, y = 0) {
        if (this.displayObj) {
            this.displayObj.x = x;
            this.displayObj.y = y;
        }

        Body.setPosition(this.body, {
            x: x,
            y: y,
        });
    },
};
//添加到显示列表
BodyAbstract.prototype.addTo = function(_stage) {
    if (this.displayObj) {
        _stage.addChild(this.displayObj);
    }
};
//创建矩形刚体
var Rect = function(option = {}) {
    let _option = Object.assign({}, option);
    bodyList.push(this);

    let ctn = new PIXI.Container();
    let box = new PIXI.Graphics();

    let originPosX = _option.posX || 0;
    let originPosY = _option.posY || 0;
    let w = _option.width || 100;
    let h = _option.height || 100;

    this.body = Bodies.rectangle(originPosX, originPosY, w, h, _option);

    box.beginFill(0x55555);
    for (let i = 0; i < this.body.vertices.length; i++) {
        if (i == 0) {
            box.moveTo(
                this.body.vertices[i].x - originPosX,
                this.body.vertices[i].y - originPosY
            );
        } else {
            box.lineTo(
                this.body.vertices[i].x - originPosX,
                this.body.vertices[i].y - originPosY
            );
        }
    }

    box.endFill();
    ctn.addChild(box);
    this.displayObj = ctn;
    let _ox = this.displayObj.getBounds().width * this.body.render.sprite.xOffset;
    let _oy =
        this.displayObj.getBounds().height * this.body.render.sprite.yOffset;
    box.pivot.x = _ox;
    box.pivot.y = _oy;
    box.x += _ox;
    box.y += _oy;
};
Rect.prototype = Object.create(BodyAbstract.prototype);
Rect.prototype.constructor = Rect;
//创建任意边形刚体
var Vertices = function(option = {}) {
    let _option = Object.assign({}, option);
    bodyList.push(this);

    let ctn = new PIXI.Container();
    let box = new PIXI.Graphics();

    let originPosX = _option.posX || 0; // this.displayObj.x;
    let originPosY = _option.posY || 0; //this.displayObj.y;

    let vertices = _option.vertices || [
        { x: 0, y: 0 },
        { x: 180, y: 0 },
        { x: 100, y: 100 },
    ];

    this.body = Bodies.fromVertices(originPosX, originPosY, vertices, _option);

    box.beginFill(0x55555);
    for (let i = 0; i < this.body.vertices.length; i++) {
        if (i == 0) {
            box.moveTo(
                this.body.vertices[i].x - originPosX,
                this.body.vertices[i].y - originPosY
            );
        } else {
            box.lineTo(
                this.body.vertices[i].x - originPosX,
                this.body.vertices[i].y - originPosY
            );
        }
    }

    box.endFill();

    ctn.addChild(box);
    this.displayObj = ctn;
    let _ox = this.displayObj.getBounds().width * this.body.render.sprite.xOffset;
    let _oy =
        this.displayObj.getBounds().height * this.body.render.sprite.yOffset;
    box.pivot.x = _ox;
    box.pivot.y = _oy;
    box.x += _ox;
    box.y += _oy;
};
Vertices.prototype = Object.create(BodyAbstract.prototype);
Vertices.prototype.constructor = Vertices;

//创建正多边形刚体

var Polygon = function(option = {}) {
    let _option = Object.assign({}, option);
    bodyList.push(this);
    let ctn = new PIXI.Container();
    let box = new PIXI.Graphics();

    let originPosX = _option.posX || 0; // this.displayObj.x;
    let originPosY = _option.posY || 0; //this.displayObj.y;
    let _side = _option.sides || 5;
    let _radius = _option.radius || 50;

    this.body = Bodies.polygon(originPosX, originPosY, _side, _radius, _option);
    box.beginFill(0x55555);
    for (let i = 0; i < this.body.vertices.length; i++) {
        if (i == 0) {
            box.moveTo(
                this.body.vertices[i].x - originPosX,
                this.body.vertices[i].y - originPosY
            );
        } else {
            box.lineTo(
                this.body.vertices[i].x - originPosX,
                this.body.vertices[i].y - originPosY
            );
        }
    }

    box.endFill();
    ctn.addChild(box);
    this.displayObj = ctn;

    let _ox = this.displayObj.getBounds().width * this.body.render.sprite.xOffset;
    let _oy =
        this.displayObj.getBounds().height * this.body.render.sprite.yOffset;
    box.pivot.x = _ox;
    box.pivot.y = _oy;
    box.x += _ox;
    box.y += _oy;
};
Polygon.prototype = Object.create(BodyAbstract.prototype);
Polygon.prototype.constructor = Polygon;
//创建圆形刚体
var Circle = function(option = {}) {
    let _option = Object.assign({}, option);
    bodyList.push(this);
    let ctn = new PIXI.Container();
    let box = new PIXI.Graphics();

    let originPosX = _option.posX || 0; // this.displayObj.x;
    let originPosY = _option.posY || 0; //this.displayObj.y;

    let halfW = _option.radius || 50;

    this.body = Bodies.circle(originPosX, originPosY, halfW, _option);

    box.beginFill(0x55555);
    for (let i = 0; i < this.body.vertices.length; i++) {
        if (i == 0) {
            box.moveTo(
                this.body.vertices[i].x - originPosX,
                this.body.vertices[i].y - originPosY
            );
        } else {
            box.lineTo(
                this.body.vertices[i].x - originPosX,
                this.body.vertices[i].y - originPosY
            );
        }
    }

    box.endFill();
    ctn.addChild(box);
    this.displayObj = ctn;

    let _ox = this.displayObj.getBounds().width * this.body.render.sprite.xOffset;
    let _oy =
        this.displayObj.getBounds().height * this.body.render.sprite.yOffset;
    box.pivot.x = _ox;
    box.pivot.y = _oy;
    box.x += _ox;
    box.y += _oy;
};
Circle.prototype = Object.create(BodyAbstract.prototype);
Circle.prototype.constructor = Circle;
var Main = {
    Engine: Engine,
    World: World,
    Bodies: Bodies,
    Render: Render,
    Body: Body,

    Circle: Circle,
    Vertices: Vertices,
    Polygon: Polygon,
    Rect: Rect,
    setPixiApp: function(_app) {
        pixiApp = _app;
    },
    showDebug: function() {
        if (document.getElementById("canvasTest")) {
            var render = Render.create({
                element: document.getElementById("canvasTest"),
                engine: engine,
                options: {
                    width: 1920,
                    height: 1080,
                    showDebug: true,
                    wireframes: true,
                    showConvexHulls: true,
                },
            });

            Render.run(render);
            document.getElementById(
                "canvasTest"
            ).children[0].style.cssText = `position:relative;pointer-events:none;left:0;top:0;width:19.2rem;height:10.8rem; `;
        }
    },

    setUp: function() {
        if (!pixiApp) return;
        engine = Engine.create();
        Engine.run(engine);
        pixiApp.ticker.add(() => {
            for (let i = 0; i < bodyList.length; i++) {
                bodyList[i].update();
            }
        });
    },
    start: function() {
        pixiApp.ticker.start();
    },
    stop: function() {
        pixiApp.ticker.stop();
    },

    addToWorld: function($body) {
        if (!engine) return;
        World.add(engine.world, $body.body);
    },
};

export default Main;