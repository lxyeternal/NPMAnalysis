declare function interpolate(a: number | number[] | object, b: number | number[] | object, alpha: number, type?: string): number | number[] | object;
export default interpolate;
