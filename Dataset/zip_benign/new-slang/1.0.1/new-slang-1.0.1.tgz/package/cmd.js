#!/usr/bin/env node

var newSlang = require('./')
var fs = require('fs')
var jsonfile = require('jsonfile')

var argv = require('yargs')
  .alias('h', 'help')
  .help('help')
  .usage('replace letters with...other letters')
  .example('newSlang -l 1 -f kanye_lyrics.txt')
  .example('newSlang -l 0.5 wow what a cool tool!')
  .example('newSlang water fowl are my favorite treat -c convert.json')
  .example('echo demonstration | newSlang -l 0.8')
  .alias('c', 'conversions')
  .alias('l', 'level')
  .alias('f', 'file')
  .describe('c', 'path to a json file containing a conversion map')
  .describe('l', 'floating point frequency at which to convert letters. higher => more conversions')
  .describe('f', 'path to file containing text to transform')
  .argv

var level = argv.l !== undefined ? parseFloat(argv.l) : "0.5"

if(process.stdin.isTTY) {
  var conversionMap
  if(argv.c) conversionMap = jsonfile.readFileSync(argv.c)
  var text = argv.f ? fs.readFileSync(argv.f).toString() : argv._.join(" ")
  process.stdout.write(newSlang(text, level, conversionMap))
  process.stdout.write("\n")
} else {

  var data = ''
  process.stdin.resume()
  process.stdin.setEncoding('utf8')
  process.stdin.on('data', function(chunk) {
    data += chunk
  })

  process.stdin.on('end', function() {
    process.stdout.write(newSlang(datam, level))
    process.stdout.write("\n")
  })
}
