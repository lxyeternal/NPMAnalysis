export default function wrapCatchSync<T extends (...args: Array<any>) => any>(callback: T): (...args: Parameters<T>) => (ReturnType<T> | Error);
