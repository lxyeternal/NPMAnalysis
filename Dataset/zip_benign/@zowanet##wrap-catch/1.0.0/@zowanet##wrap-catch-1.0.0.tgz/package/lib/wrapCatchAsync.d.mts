export default function wrapCatchAsync<T extends (...args: Array<any>) => any>(callback: T): (...args: Parameters<T>) => (Promise<Awaited<ReturnType<T>> | Error>);
