var Bar = require('dchart-core/bar/barHorizontal');
var d3 = require('d3');
var _ = require('dchart-core/util');

function BarHoriBox(container, options) {
  var opt = {
    margin : {top: 20, right: 20, bottom: 30, left: 80},
    yaxis : {
      type: 'category',
      padding: [0.9, 0.4],
      dy: 40
    },
    xaxis: {
      orient: 'top'
    }
  };
  _.deepMerge(opt, options);
  Bar.call(this, container, opt);
};
BarHoriBox = Bar.extend(BarHoriBox, {
  afterRender : function () {
    Bar.prototype.afterRender.call(this);
    var opt = this.options;
    var svg = this.svg;

    var axis = this.getComs('axis', 'yaxis');
    var y = axis.getX();
    var bars = this.series.selectAll('.series-group');

    var ykey = opt.yaxis.key;
    var xkey = opt.xaxis.key;
    bars.each(function (data) {
      var that = d3.select(this);
      var bg = that.select('.serie-bg')[0][0] ? that.select('.serie-bg') : that.append('rect')
        .attr({
          'class' : 'serie-bg',
          'x' : -5
        }).style('fill', 'none');

      bg.attr({
        'y' : function (d) {return y(data[ykey]) - 5; },
        'width' : opt.innerWidth + 10,
        'height' : y.rangeBand() + 10,
      })

      var label = that.select('.serie-label')[0][0] ? that.select('.serie-label') : that.insert('text')
        .attr({
          'class': 'serie-label'
        });

      label.attr({
        'x' : opt.innerWidth + 30,
        'y' : function (d) {return y(data[ykey]) + 6; },
      }).text(function (d) {
        return data[xkey];
      })
    });
  },
  updateAfterRender : function () {
    BarHoriBox.prototype.afterRender.call(this);
  }
});

module.exports = BarHoriBox;
