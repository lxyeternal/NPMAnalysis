export interface IArgs {
    port: number;
    verbose: boolean;
    token: string;
    salt: string;
    source: string;
    filename: string;
    key: string;
    dest: string;
    testnet: boolean;
    count?: number;
    logKey?: string;
}
