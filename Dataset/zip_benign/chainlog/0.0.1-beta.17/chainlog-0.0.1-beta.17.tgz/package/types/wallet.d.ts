export interface ISendResponse {
    txId: string;
    destAddress: string;
    satoshis: number;
}

export interface IBalanceSummeryResponse {
    summery: {
        confirmed: number;
        unconfirmed: number;
    };
}

export interface IAddressResponse {
    address: string;
}

export interface ISendResponse {
    txId: string;
    destAddress: string;
    satoshis: number;
}

export interface IOutpout {
    to?: string;
    satoshis?: number;
    amount?: number;
    currency?: string;
    script?: string;
    purpos?: string;
}

export interface IWallet {
    write(scrript: string, cache: boolean = true): Promise<ISendResponse>;
    balance(): Promise<IBalanceSummeryResponse>;
    receiveAddress(): Promise<IAddressResponse>;
    split(count: number): Promise<ISendResponse>;
}
