export interface IConfig {
    zixo_token: string;
    salt?: string;
    network: "mainnet" | "testnet";
}
