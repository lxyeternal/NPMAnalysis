export interface ITerminalBaseResult {
    ok?: boolean;
    error?: any;
    message?: string;
}
export interface ITerminalResult extends ITerminalBaseResult {
    [key: string]: any;
}
