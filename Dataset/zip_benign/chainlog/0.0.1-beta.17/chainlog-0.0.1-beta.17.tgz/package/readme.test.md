100,000,000 satoshi = 1 BSV
1 BSV = 166$ in oct 2020

1B  = 0.5 satoshi = 0.00000001
1KB = 500 satoshi = 0.000005
1MB = 500,000 satoshi = 0.005 about 1$ in oct 2020