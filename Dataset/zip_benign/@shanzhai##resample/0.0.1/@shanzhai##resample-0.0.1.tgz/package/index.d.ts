export declare function resample(samples: ReadonlyArray<number>, inputSampleRate: number, outputSampleRate: number): ReadonlyArray<number>;
