export { GlossPropertySet } from './cssPropertySet';
export { configureCSS } from './config';
export { validCSSAttr } from './constants';
export { CSSPropertySet, CSSPropertySetResolved, CSSPropertySetStrict, CSSPropertySetLoose, CSSPropertyValThemeFn, } from './cssPropertySet';
export * from './helpers';
export { camelToSnake, snakeToCamel } from './helpers';
export { ThemeObject, ThemeValueLike, ThemeSet, ThemeCoats } from './ThemeObject';
export declare type CSSConfig = {
    errorMessage?: string;
    snakeCase?: boolean;
    ignoreCSSVariables?: boolean;
    resolveFunctionValue?: ((val: any) => any);
};
export declare function cssString(styles: Object, opts?: CSSConfig): string;
export declare function cssStringWithHash(styles: Object, opts?: CSSConfig): [number, string];
export declare function css(styles: Object, opts?: CSSConfig): Object;
export declare function cssValue(key: string, value: any, recurse?: boolean, options?: CSSConfig): any;
export declare function styleToClassName(style: string): string;
export declare function processArray(key: string, value: any[], level?: number, options?: CSSConfig): string;
export declare function processObject(key: string, object: any, options?: CSSConfig): string | undefined;
//# sourceMappingURL=css.d.ts.map