export declare const px: (x: import("./cssPropertySet").singleAnimation) => string;
export declare function camelToSnake(key: string): any;
export declare function snakeToCamel(key: string): any;
export declare function stringHash(str: string): number;
//# sourceMappingURL=helpers.d.ts.map