"use strict";
function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
Object.defineProperty(exports, "__esModule", { value: true });
const config_1 = require("./config");
const constants_1 = require("./constants");
const cssNameMap_1 = require("./cssNameMap");
const helpers_1 = require("./helpers");
var config_2 = require("./config");
exports.configureCSS = config_2.configureCSS;
var constants_2 = require("./constants");
exports.validCSSAttr = constants_2.validCSSAttr;
__export(require("./helpers"));
var helpers_2 = require("./helpers");
exports.camelToSnake = helpers_2.camelToSnake;
exports.snakeToCamel = helpers_2.snakeToCamel;
const emptyObject = Object.freeze({});
function cssString(styles, opts) {
    if (!styles)
        return '';
    const shouldSnake = !opts || opts.snakeCase !== false;
    let style = '';
    for (let key in styles) {
        let value = cssValue(key, styles[key], false, opts);
        if (value !== undefined) {
            if (constants_1.SHORTHANDS[key]) {
                for (let k of constants_1.SHORTHANDS[key]) {
                    k = shouldSnake ? cssNameMap_1.CAMEL_TO_SNAKE[k] || k : k;
                    style += `${k}:${helpers_1.px(value)};`;
                }
            }
            else {
                style += `${(shouldSnake && cssNameMap_1.CAMEL_TO_SNAKE[key]) || key}:${value};`;
            }
        }
    }
    return style;
}
exports.cssString = cssString;
const keyHashes = {};
function cssStringWithHash(styles, opts) {
    if (!styles)
        return [0, ''];
    const shouldSnake = !opts || opts.snakeCase !== false;
    let style = '';
    let hash = 0;
    for (let key in styles) {
        const rawVal = styles[key];
        let value = cssValue(key, rawVal, false, opts);
        if (value !== undefined) {
            if (hash == 0)
                hash = 5381;
            let keyHash = keyHashes[key];
            if (!keyHash) {
                keyHash = keyHashes[key] = helpers_1.stringHash(key);
            }
            hash = (hash * 33) ^ keyHash;
            if (typeof rawVal === 'number') {
                hash = (hash * 33) ^ ((Math.abs(rawVal) + 250) + (rawVal < 0 ? 100 : 0));
            }
            else {
                hash = (hash * 33) ^ helpers_1.stringHash(value);
            }
            if (constants_1.SHORTHANDS[key]) {
                for (let k of constants_1.SHORTHANDS[key]) {
                    k = shouldSnake ? cssNameMap_1.CAMEL_TO_SNAKE[k] || k : k;
                    style += `${k}:${helpers_1.px(value)};`;
                }
            }
            else {
                style += `${(shouldSnake && cssNameMap_1.CAMEL_TO_SNAKE[key]) || key}:${value};`;
            }
        }
    }
    return [Math.abs(hash), style];
}
exports.cssStringWithHash = cssStringWithHash;
function css(styles, opts) {
    if (!styles)
        return emptyObject;
    const shouldSnake = !opts || opts.snakeCase !== false;
    const toReturn = {};
    for (let key in styles) {
        let value = cssValue(key, styles[key], true, opts);
        if (value !== undefined) {
            if (constants_1.SHORTHANDS[key]) {
                for (let k of constants_1.SHORTHANDS[key]) {
                    k = shouldSnake ? cssNameMap_1.CAMEL_TO_SNAKE[k] || k : k;
                    toReturn[k] = helpers_1.px(value);
                }
            }
            else {
                toReturn[(shouldSnake && cssNameMap_1.CAMEL_TO_SNAKE[key]) || key] = value;
            }
        }
    }
    return toReturn;
}
exports.css = css;
function cssValue(key, value, recurse = false, options) {
    var _a, _b;
    if (((_a = options) === null || _a === void 0 ? void 0 : _a.resolveFunctionValue) && typeof value === 'function') {
        value = (_b = options) === null || _b === void 0 ? void 0 : _b.resolveFunctionValue(value);
    }
    if (value === false) {
        value === constants_1.FALSE_VALUES[key];
    }
    if (value === undefined || value === null || value === false) {
        return;
    }
    if (value && value.cssVariable && (!options || !options.ignoreCSSVariables)) {
        if (value.toCSS) {
            return value.toCSS();
        }
        return `var(--${value.cssVariable})`;
    }
    const valueType = typeof value;
    if (valueType === 'string' || valueType === 'number') {
        if (valueType === 'number' && !constants_1.unitlessNumberProperties.has(key)) {
            value += 'px';
        }
        return value;
    }
    else if (constants_1.COLOR_KEYS.has(key) && config_1.Config.isColor(value)) {
        return config_1.Config.toColor(value);
    }
    else if (Array.isArray(value)) {
        return processArray(key, value, 0, options);
    }
    else if (valueType === 'object') {
        if (value.getCSSValue) {
            return value.getCSSValue();
        }
        const res = processObject(key, value, options);
        if (res !== undefined) {
            return res;
        }
    }
    else if (key === 'isolate') {
        return value;
    }
    else {
        if (recurse) {
            const firstChar = key[0];
            if (firstChar === '&' ||
                firstChar === '@' ||
                key === 'from' ||
                key === 'to') {
                return css(value, options);
            }
        }
    }
    if (__DEV__) {
        console.error(`Invalid style value for ${key}`, value, options);
    }
}
exports.cssValue = cssValue;
function styleToClassName(style) {
    return `g${helpers_1.stringHash(style)}`;
}
exports.styleToClassName = styleToClassName;
const objectToCSS = {
    textShadow: ({ x, y, blur, color }) => `${helpers_1.px(x || 0)} ${helpers_1.px(y || 0)} ${helpers_1.px(blur || 0)} ${config_1.Config.toColor(color)}`,
    boxShadow: (v) => `${v.inset ? 'inset ' : ''}${helpers_1.px(v.x || 0)} ${helpers_1.px(v.y || 0)} ${helpers_1.px(v.blur || 0)} ${helpers_1.px(v.spread || 0)} ${config_1.Config.isColor(v.color) ? config_1.Config.toColor(v.color) : v.color || ''}`,
    background: v => config_1.Config.isColor(v)
        ? config_1.Config.toColor(v)
        : `${config_1.Config.toColor(v.color)} ${v.image || ''} ${(v.position
            ? v.position.join(' ')
            : v.position) || ''} ${v.repeat || ''}`,
};
function processArrayItem(key, val, level = 0, options) {
    if (Array.isArray(val)) {
        return processArray(key, val, level + 1, options);
    }
    return cssValue(key, val, false, options);
}
function processArray(key, value, level = 0, options) {
    if (constants_1.BORDER_KEY.has(key) && value.length === 2) {
        value.push('solid');
    }
    if (key === 'fontFamily') {
        return value.map(x => (x.includes(' ') ? `"${x}"` : x)).join(', ');
    }
    if (key === 'boxShadow') {
        value = value.filter(Boolean).map(x => processBoxShadow(x, options));
    }
    else {
        value = value.map(val => processArrayItem(key, val, level, options));
    }
    return value.join(level === 0 && constants_1.COMMA_JOINED.has(key) ? ', ' : ' ');
}
exports.processArray = processArray;
function processBoxShadow(val, options) {
    if (Array.isArray(val)) {
        return val
            .map(x => {
            return cssValue(config_1.Config.isColor(x) ? 'color' : '', x, false, options);
        })
            .join(' ');
    }
    if (val && typeof val === 'object') {
        return objectToCSS.boxShadow(val);
    }
    return val;
}
function objectValue(key, value) {
    if (objectToCSS[key]) {
        return objectToCSS[key](value);
    }
    if (key === 'scale' ||
        key === 'scaleX' ||
        key === 'scaleY' ||
        key === 'grayscale' ||
        key === 'brightness') {
        return value;
    }
    if (typeof value === 'number') {
        return `${value}px`;
    }
    return value;
}
function processObject(key, object, options) {
    if (constants_1.COLOR_KEYS.has(key)) {
        if (config_1.Config.isColor(object)) {
            return config_1.Config.toColor(object);
        }
    }
    if (!object.constructor || Object.prototype.toString.call(object) === '[object Object]') {
        const toReturn = [];
        for (const subKey in object) {
            if (!Object.hasOwnProperty.call(object, subKey)) {
                continue;
            }
            let value = object[subKey];
            if (Array.isArray(value)) {
                value = processArray(key, value, 0, options);
            }
            else {
                value = objectValue(subKey, value);
            }
            toReturn.push(`${constants_1.TRANSFORM_KEYS_MAP[subKey] || subKey}(${value})`);
        }
        return toReturn.join(' ');
    }
}
exports.processObject = processObject;
//# sourceMappingURL=css.js.map