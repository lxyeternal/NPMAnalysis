"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const cssNameMap_1 = require("./cssNameMap");
exports.px = (x) => typeof x === 'number' ? `${x}px` : `${+x}` === x ? `${x}px` : x;
function camelToSnake(key) {
    return cssNameMap_1.CAMEL_TO_SNAKE[key] || key;
}
exports.camelToSnake = camelToSnake;
function snakeToCamel(key) {
    return cssNameMap_1.SNAKE_TO_CAMEL[key] || key;
}
exports.snakeToCamel = snakeToCamel;
function stringHash(str) {
    let res = 5381;
    let i = 0;
    let len = str.length;
    while (i < len) {
        res = (res * 33) ^ str.charCodeAt(i++);
    }
    return res >>> 0;
}
exports.stringHash = stringHash;
//# sourceMappingURL=helpers.js.map