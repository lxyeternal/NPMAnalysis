"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validCSSAttr = process.env.RENDER_TARGET === 'node'
    ? require('./validCSSAttribute.node').default
    : require('./validCSSAttribute.dom').default;
exports.UNDEFINED = 'undefined';
exports.COLOR_KEYS = new Set([
    'color',
    'background',
    'backgroundColor',
    'borderColor',
    'borderBottomColor',
    'borderTopColor',
    'borderLeftColor',
    'borderRightColor',
    'textDecorationColor',
]);
exports.TRANSFORM_KEYS_MAP = {
    x: 'translateX',
    y: 'translateY',
    z: 'translateZ',
    dropShadow: 'drop-shadow',
};
exports.COMMA_JOINED = new Set(['boxShadow', 'transition']);
exports.SHORTHANDS = {
    borderLeftRadius: ['borderTopLeftRadius', 'borderBottomLeftRadius'],
    borderRightRadius: ['borderTopRightRadius', 'borderBottomRightRadius'],
    borderBottomRadius: ['borderBottomLeftRadius', 'borderBottomRightRadius'],
    borderTopRadius: ['borderTopRightRadius', 'borderTopLeftRadius'],
};
exports.FALSE_VALUES = {
    background: 'transparent',
    backgroundColor: 'transparent',
    borderColor: 'transparent',
};
exports.BORDER_KEY = new Set([
    'border',
    'borderLeft',
    'borderRight',
    'borderBottom',
    'borderTop',
]);
exports.unitlessNumberProperties = new Set([
    'animationIterationCount',
    'borderImageOutset',
    'borderImageSlice',
    'borderImageWidth',
    'columnCount',
    'flex',
    'flexGrow',
    'flexPositive',
    'flexShrink',
    'flexOrder',
    'gridRow',
    'gridColumn',
    'fontWeight',
    'lineClamp',
    'opacity',
    'order',
    'orphans',
    'tabSize',
    'widows',
    'zIndex',
    'zoom',
    'fillOpacity',
    'floodOpacity',
    'stopOpacity',
    'strokeDasharray',
    'strokeDashoffset',
    'strokeMiterlimit',
    'strokeOpacity',
    'strokeWidth',
]);
//# sourceMappingURL=constants.js.map