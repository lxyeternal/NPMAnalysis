declare const _default: {
    borderLeftRadius: boolean;
    borderRightRadius: boolean;
    borderBottomRadius: boolean;
    borderTopRadius: boolean;
    src: boolean;
    size: boolean;
};
export default _default;
//# sourceMappingURL=validCSSAttribute.dom.d.ts.map