export declare type CSSOptions = {
    toColor: (a: any) => string;
    isColor: (a: any) => boolean;
};
export declare let Config: CSSOptions;
export declare function configureCSS(options: Partial<CSSOptions>): void;
//# sourceMappingURL=config.d.ts.map