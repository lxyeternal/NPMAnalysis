"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Config = {
    isColor: _ => _ && !!_.toString,
    toColor: _ => _.toString(),
};
function configureCSS(options) {
    Object.assign(exports.Config, options);
    Object.freeze(exports.Config);
}
exports.configureCSS = configureCSS;
if (typeof module !== 'undefined' && module.hot) {
    module.hot.accept(() => {
        if (module.hot) {
            exports.Config = module.hot.data || exports.Config;
        }
    });
    module.hot.dispose(_ => {
        _.data = exports.Config;
    });
}
//# sourceMappingURL=config.js.map