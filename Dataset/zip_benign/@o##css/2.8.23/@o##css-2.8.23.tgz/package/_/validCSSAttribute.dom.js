"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const validCSSAttributeExtra_1 = require("./validCSSAttributeExtra");
const allCSSAttr = {};
if (typeof document !== 'undefined') {
    for (const key in document.body.style) {
        allCSSAttr[key] = true;
    }
}
exports.default = {
    ...allCSSAttr,
    ...validCSSAttributeExtra_1.validCSSAttributeExtra,
};
//# sourceMappingURL=validCSSAttribute.dom.js.map