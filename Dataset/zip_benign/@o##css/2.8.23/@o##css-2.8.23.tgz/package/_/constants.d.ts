import { CSSPropertySet } from './cssPropertySet';
declare type CSSPropertyKey = keyof CSSPropertySet;
declare type ValidCSSPropertyMap = {
    [key in CSSPropertyKey]: boolean;
};
export declare const validCSSAttr: Partial<ValidCSSPropertyMap>;
export declare const UNDEFINED = "undefined";
export declare const COLOR_KEYS: Set<string>;
export declare const TRANSFORM_KEYS_MAP: {
    x: string;
    y: string;
    z: string;
    dropShadow: string;
};
export declare const COMMA_JOINED: Set<string>;
export declare const SHORTHANDS: {
    borderLeftRadius: string[];
    borderRightRadius: string[];
    borderBottomRadius: string[];
    borderTopRadius: string[];
};
export declare const FALSE_VALUES: {
    background: string;
    backgroundColor: string;
    borderColor: string;
};
export declare const BORDER_KEY: Set<string>;
export declare const unitlessNumberProperties: Set<string>;
export {};
//# sourceMappingURL=constants.d.ts.map