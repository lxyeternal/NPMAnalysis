"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const cssNameMap_1 = require("./cssNameMap");
exports.validCSSAttributeExtra = {
    borderLeftRadius: true,
    borderRightRadius: true,
    borderBottomRadius: true,
    borderTopRadius: true,
    src: false,
    size: false,
};
for (const key in cssNameMap_1.CAMEL_TO_SNAKE) {
    exports.validCSSAttributeExtra[key] = true;
}
//# sourceMappingURL=validCSSAttributeExtra.js.map