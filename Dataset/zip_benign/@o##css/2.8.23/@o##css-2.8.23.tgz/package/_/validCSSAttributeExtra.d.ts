export declare const validCSSAttributeExtra: {
    borderLeftRadius: boolean;
    borderRightRadius: boolean;
    borderBottomRadius: boolean;
    borderTopRadius: boolean;
    src: boolean;
    size: boolean;
};
//# sourceMappingURL=validCSSAttributeExtra.d.ts.map