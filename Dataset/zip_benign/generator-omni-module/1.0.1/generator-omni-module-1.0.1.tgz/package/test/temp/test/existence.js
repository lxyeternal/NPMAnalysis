var Undefined = require('../module'),
  chai       = require('chai'),
  expect     = chai.expect;

describe('Undefined', function() {
  it('exists', function() {
    expect(Undefined).to.be.an('object');
  });
});
