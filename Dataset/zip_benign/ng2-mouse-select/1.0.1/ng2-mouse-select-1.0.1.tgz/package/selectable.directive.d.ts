import { ElementRef, Renderer2 } from '@angular/core';
import { ISelectFrame } from './ISelectorFrame';
/**
 * @description
 *  directive for items inside the 'select-frame'
 *  component with the corresponding Select input which regulates the data sent(JSON object).
 *
 * @example
 *
 * <div selectable></div>
 *
 * [Select]="{'palletId':pallet.Id,'GLN':pallet.AmazonWarehouseGLN,'ShippingType':pallet.ShippingType}"
 * [selectedClass]='selected'
 * @export
 * @class SelectableDirective
 */
export declare class SelectableDirective {
    private el;
    private renderer;
    private dimensions;
    private _data;
    private selected;
    private savedSelected;
    selectedClass: string;
    selectScope: string;
    data: any;
    private addElementClass(className);
    private removeElementClass(className);
    private getDimensions();
    determineCoordinates(): void;
    clicked(selectFrame: ISelectFrame): boolean;
    clickedOnSelected(selectFrame: ISelectFrame): boolean;
    getDataIfSelected(): any;
    saveSelected(): void;
    IsSelected(): boolean;
    toggle(filter?: Array<any>, scope?: string, continuation?: boolean): void;
    select(selectFrame: ISelectFrame, filter?: Array<any>, scope?: string, continuation?: boolean): void;
    private processNewSelection(selectFrame, filter?, scope?);
    private processSelect(className);
    private processUnSelect(className, continuation?);
    private passedFilter(filter?);
    private passedScope(scope?);
    private getData(intern?);
    constructor(el: ElementRef, renderer: Renderer2);
}
