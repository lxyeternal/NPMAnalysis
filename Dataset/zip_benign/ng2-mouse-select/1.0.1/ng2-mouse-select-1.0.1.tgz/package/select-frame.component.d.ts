import { ElementRef, Renderer2, QueryList, AfterViewInit, OnChanges, EventEmitter, NgZone, SimpleChanges } from '@angular/core';
import { ISelectionCoordinates } from './ISelectorFrame';
import { SelectableDirective } from './selectable.directive';
/**
 * @description
 * Component which defines frame for the selection area.
 *
 * Inside of it set 'selectable' directives on elements that need to be selected.
 * _______________________________
 * Inputs:
 *
 * filter - default null. { allowSelectElements: boolean, thisElement: boolean }
 *
 * clearOnUnselected - default false. If set to true, it will clear selected data
 * when clicking on
 * selectable but previously unselected items. Otherwise, it will clear selected data as
 * soon as it is clicked outside of the selectable directives.
 *
 * @export
 * @class SelectFrameComponent
 */
export declare class SelectFrameComponent implements AfterViewInit, OnChanges {
    el: ElementRef;
    private renderer;
    private zone;
    selectables: Array<any>;
    hasChildren: boolean;
    enabled: boolean;
    selectionFrameCoordinates: ISelectionCoordinates;
    private parent;
    private children;
    private mouseDown;
    private mouseMoveListener;
    private scrollListener;
    private mouseUpListener;
    private tempData;
    ensureSame: Array<string>;
    filter: {
        allowSelectElements: boolean;
        thisElement: boolean;
    };
    clearOnUnselected: boolean;
    selectorColor: string;
    data: EventEmitter<any>;
    selector: ElementRef;
    selectableDirectives: QueryList<SelectableDirective>;
    private onMouseDown(ev);
    private onMouseUp(ev);
    private onMouseMove(ev);
    private onMouseMoveContinue(ev);
    private onScrollContinue(ev);
    private onScroll(ev);
    private resetListeners();
    private startListeners();
    private startContinuationListeners();
    private refreshMoveCoordinates(ev);
    private refreshScrollCoordinates();
    private setStartFrameCoordinates(ev);
    private determineChildrenCoordinates();
    private determineParentCoordinates();
    private hideRectangle(delay?);
    private drawRectangle(frame, delay?);
    private getSelectorFrameCoordinates(data);
    private getFrameRelativeToParent(frame, parent);
    private startSelection(ev);
    private prepareStartOfSelection(ev);
    private prepareContinuationOfSelection(ev);
    private doStartOfSelection(ev);
    private doContinuationOfSelection(ev);
    private determineTypeOfContinuation(ev);
    private saveSelected();
    private toggleThisElement(ev, index);
    private getSelectedElement(ev);
    private setStartCoordinates(ev);
    private determineSelected(frame, directives);
    private determineSelectedContinuation(frame, directives);
    private getSelectedData();
    private filterComponents(frame, directives, continuation?);
    private selectComponents(frame, directives);
    private unselectComponents(directives);
    private resetComponents(frame, directives);
    private allowSelectionOnElements(ev);
    private getFilterAndScope();
    ngAfterViewInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    constructor(el: ElementRef, renderer: Renderer2, zone: NgZone);
}
