import { ElementRef, Renderer2 } from '@angular/core';
/**
 * @description
 * directive for dissalowing text-selection.
 *
 * @example
 *
 * <div noSelect></div>
 *
 * @export
 * @class NoSelectDirective
 */
export declare class NoSelectDirective {
    private el;
    private renderer;
    constructor(el: ElementRef, renderer: Renderer2);
}
