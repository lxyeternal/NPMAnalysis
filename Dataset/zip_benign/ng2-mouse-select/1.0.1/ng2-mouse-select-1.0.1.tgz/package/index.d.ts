import { ModuleWithProviders } from '@angular/core';
export * from './select-frame.component';
export * from './no-select.directive';
export * from './selectable.directive';
export * from './allow.select.directive';
export declare class SelectableModule {
    static forRoot(): ModuleWithProviders;
}
