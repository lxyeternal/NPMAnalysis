(function (global, factory) {
	typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/core'), require('@angular/common')) :
	typeof define === 'function' && define.amd ? define(['exports', '@angular/core', '@angular/common'], factory) :
	(factory((global['ng2-mouse-select'] = {}),global.core,global.common));
}(this, (function (exports,core,common) { 'use strict';

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * \@description
 *  directive for items inside the 'select-frame'
 *  component with the corresponding Select input which regulates the data sent(JSON object).
 *
 * \@example
 *
 * <div selectable></div>
 *
 * [Select]="{'palletId':pallet.Id,'GLN':pallet.AmazonWarehouseGLN,'ShippingType':pallet.ShippingType}"
 * [selectedClass]='selected'
 * @export
 */
var SelectableDirective = (function () {
    function SelectableDirective(el, renderer) {
        this.el = el;
        this.renderer = renderer;
        this.selectedClass = 'selected';
        this.selectScope = '';
    }
    Object.defineProperty(SelectableDirective.prototype, "data", {
        get: /**
         * @return {?}
         */
        function () {
            return JSON.stringify(this._data);
        },
        set: /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            this._data = value;
        },
        enumerable: true,
        configurable: true
    });
    /**
     * @param {?} className
     * @return {?}
     */
    SelectableDirective.prototype.addElementClass = /**
     * @param {?} className
     * @return {?}
     */
    function (className) {
        this.renderer.addClass(this.el.nativeElement, className);
    };
    /**
     * @param {?} className
     * @return {?}
     */
    SelectableDirective.prototype.removeElementClass = /**
     * @param {?} className
     * @return {?}
     */
    function (className) {
        this.renderer.removeClass(this.el.nativeElement, className);
    };
    /**
     * @return {?}
     */
    SelectableDirective.prototype.getDimensions = /**
     * @return {?}
     */
    function () {
        return this.dimensions;
    };
    /**
     * @return {?}
     */
    SelectableDirective.prototype.determineCoordinates = /**
     * @return {?}
     */
    function () {
        this.dimensions = this.el.nativeElement.getBoundingClientRect();
    };
    /**
     * @param {?} selectFrame
     * @return {?}
     */
    SelectableDirective.prototype.clicked = /**
     * @param {?} selectFrame
     * @return {?}
     */
    function (selectFrame) {
        if (selectFrame == null)
            return false;
        return !((this.dimensions.left > selectFrame.right) ||
            (this.dimensions.top > selectFrame.bottom) ||
            (this.dimensions.right < selectFrame.left) ||
            (this.dimensions.bottom < selectFrame.top));
    };
    /**
     * @param {?} selectFrame
     * @return {?}
     */
    SelectableDirective.prototype.clickedOnSelected = /**
     * @param {?} selectFrame
     * @return {?}
     */
    function (selectFrame) {
        return this.selected && this.clicked(selectFrame);
    };
    /**
     * @return {?}
     */
    SelectableDirective.prototype.getDataIfSelected = /**
     * @return {?}
     */
    function () {
        if (!this.selected)
            return null;
        return this.getData();
    };
    /**
     * @return {?}
     */
    SelectableDirective.prototype.saveSelected = /**
     * @return {?}
     */
    function () {
        this.savedSelected = this.selected;
    };
    /**
     * @return {?}
     */
    SelectableDirective.prototype.IsSelected = /**
     * @return {?}
     */
    function () {
        return this.selected;
    };
    /**
     * @param {?=} filter
     * @param {?=} scope
     * @param {?=} continuation
     * @return {?}
     */
    SelectableDirective.prototype.toggle = /**
     * @param {?=} filter
     * @param {?=} scope
     * @param {?=} continuation
     * @return {?}
     */
    function (filter, scope, continuation) {
        if (!this.passedScope(scope))
            return;
        if (!this.passedFilter(filter))
            return;
        if (this.selected)
            return this.processUnSelect(this.selectedClass);
        else {
            return this.processSelect(this.selectedClass);
        }
    };
    /**
     * @param {?} selectFrame
     * @param {?=} filter
     * @param {?=} scope
     * @param {?=} continuation
     * @return {?}
     */
    SelectableDirective.prototype.select = /**
     * @param {?} selectFrame
     * @param {?=} filter
     * @param {?=} scope
     * @param {?=} continuation
     * @return {?}
     */
    function (selectFrame, filter, scope, continuation) {
        if (!continuation)
            return this.processNewSelection(selectFrame, filter, scope);
        if (!this.passedScope(scope))
            return;
        if (!this.passedFilter(filter))
            return;
        if ((this.dimensions.left > selectFrame.right) ||
            (this.dimensions.top > selectFrame.bottom) ||
            (this.dimensions.right < selectFrame.left) ||
            (this.dimensions.bottom < selectFrame.top))
            return this.processUnSelect(this.selectedClass, continuation);
        return this.processSelect(this.selectedClass);
    };
    /**
     * @param {?} selectFrame
     * @param {?=} filter
     * @param {?=} scope
     * @return {?}
     */
    SelectableDirective.prototype.processNewSelection = /**
     * @param {?} selectFrame
     * @param {?=} filter
     * @param {?=} scope
     * @return {?}
     */
    function (selectFrame, filter, scope) {
        if (selectFrame == null)
            return this.processUnSelect(this.selectedClass);
        if (!this.passedScope(scope))
            return this.processUnSelect(this.selectedClass);
        if (!this.passedFilter(filter))
            return this.processUnSelect(this.selectedClass);
        if ((this.dimensions.left > selectFrame.right) ||
            (this.dimensions.top > selectFrame.bottom) ||
            (this.dimensions.right < selectFrame.left) ||
            (this.dimensions.bottom < selectFrame.top))
            return this.processUnSelect(this.selectedClass);
        return this.processSelect(this.selectedClass);
    };
    /**
     * @param {?} className
     * @return {?}
     */
    SelectableDirective.prototype.processSelect = /**
     * @param {?} className
     * @return {?}
     */
    function (className) {
        this.selected = true;
        this.addElementClass(className);
    };
    /**
     * @param {?} className
     * @param {?=} continuation
     * @return {?}
     */
    SelectableDirective.prototype.processUnSelect = /**
     * @param {?} className
     * @param {?=} continuation
     * @return {?}
     */
    function (className, continuation) {
        this.selected = (continuation) ? this.savedSelected : false;
        if (!this.selected)
            this.removeElementClass(className);
    };
    /**
     * @param {?=} filter
     * @return {?}
     */
    SelectableDirective.prototype.passedFilter = /**
     * @param {?=} filter
     * @return {?}
     */
    function (filter) {
        if (!filter)
            return true;
        var /** @type {?} */ passed = true;
        for (var /** @type {?} */ name_1 in filter) {
            if (filter[name_1] !== this.getData(true)[name_1])
                passed = false;
        }
        return passed;
    };
    /**
     * @param {?=} scope
     * @return {?}
     */
    SelectableDirective.prototype.passedScope = /**
     * @param {?=} scope
     * @return {?}
     */
    function (scope) {
        if (!scope)
            return true;
        return (scope === this.selectScope);
    };
    /**
     * @param {?=} intern
     * @return {?}
     */
    SelectableDirective.prototype.getData = /**
     * @param {?=} intern
     * @return {?}
     */
    function (intern) {
        if (this.selectScope === '' || intern)
            return JSON.parse(this.data);
        return { scope: this.selectScope, data: JSON.parse(this.data) };
    };
    SelectableDirective.decorators = [
        { type: core.Directive, args: [{ selector: '[selectable]' },] },
    ];
    /** @nocollapse */
    SelectableDirective.ctorParameters = function () { return [
        { type: core.ElementRef, decorators: [{ type: core.Inject, args: [core.ElementRef,] },] },
        { type: core.Renderer2, decorators: [{ type: core.Inject, args: [core.Renderer2,] },] },
    ]; };
    SelectableDirective.propDecorators = {
        "selectedClass": [{ type: core.Input },],
        "selectScope": [{ type: core.Input },],
        "data": [{ type: core.Input, args: ['select',] },],
    };
    return SelectableDirective;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * \@description
 * Component which defines frame for the selection area.
 *
 * Inside of it set 'selectable' directives on elements that need to be selected.
 * _______________________________
 * Inputs:
 *
 * filter - default null. { allowSelectElements: boolean, thisElement: boolean }
 *
 * clearOnUnselected - default false. If set to true, it will clear selected data
 * when clicking on
 * selectable but previously unselected items. Otherwise, it will clear selected data as
 * soon as it is clicked outside of the selectable directives.
 *
 * @export
 */
var SelectFrameComponent = (function () {
    function SelectFrameComponent(el, renderer, zone) {
        this.el = el;
        this.renderer = renderer;
        this.zone = zone;
        this.hasChildren = false;
        this.enabled = true;
        this.mouseDown = false;
        this.tempData = [];
        this.ensureSame = [];
        this.filter = null;
        this.clearOnUnselected = false;
        this.selectorColor = 'defaultYellow';
        this.data = new core.EventEmitter();
    }
    /**
     * @param {?} ev
     * @return {?}
     */
    SelectFrameComponent.prototype.onMouseDown = /**
     * @param {?} ev
     * @return {?}
     */
    function (ev) {
        if (ev.which !== 1)
            return;
        ev.stopPropagation();
        if (ev.ctrlKey)
            return this.determineTypeOfContinuation(ev);
        else
            return this.startSelection(ev);
    };
    /**
     * @param {?} ev
     * @return {?}
     */
    SelectFrameComponent.prototype.onMouseUp = /**
     * @param {?} ev
     * @return {?}
     */
    function (ev) {
        if (ev.which !== 1)
            return;
        this.mouseDown = false;
        this.resetListeners();
        this.hideRectangle(200);
        this.tempData = this.getSelectedData();
        this.data.emit(this.tempData);
        ev.stopPropagation();
        return false;
    };
    /**
     * @param {?} ev
     * @return {?}
     */
    SelectFrameComponent.prototype.onMouseMove = /**
     * @param {?} ev
     * @return {?}
     */
    function (ev) {
        if (!this.mouseDown)
            return;
        this.refreshMoveCoordinates(ev);
        var /** @type {?} */ frame = this.getSelectorFrameCoordinates(this.selectionFrameCoordinates);
        this.drawRectangle(this.getFrameRelativeToParent(frame, this.parent));
        this.determineSelected(frame, this.selectableDirectives.toArray());
    };
    /**
     * @param {?} ev
     * @return {?}
     */
    SelectFrameComponent.prototype.onMouseMoveContinue = /**
     * @param {?} ev
     * @return {?}
     */
    function (ev) {
        if (!this.mouseDown)
            return;
        this.refreshMoveCoordinates(ev);
        var /** @type {?} */ frame = this.getSelectorFrameCoordinates(this.selectionFrameCoordinates);
        this.drawRectangle(this.getFrameRelativeToParent(frame, this.parent));
        this.determineSelectedContinuation(frame, this.selectableDirectives.toArray());
    };
    /**
     * @param {?} ev
     * @return {?}
     */
    SelectFrameComponent.prototype.onScrollContinue = /**
     * @param {?} ev
     * @return {?}
     */
    function (ev) {
        if (!this.mouseDown)
            return;
        this.refreshScrollCoordinates();
        var /** @type {?} */ frame = this.getSelectorFrameCoordinates(this.selectionFrameCoordinates);
        this.drawRectangle(this.getFrameRelativeToParent(frame, this.parent));
        this.determineSelectedContinuation(frame, this.selectableDirectives.toArray());
    };
    /**
     * @param {?} ev
     * @return {?}
     */
    SelectFrameComponent.prototype.onScroll = /**
     * @param {?} ev
     * @return {?}
     */
    function (ev) {
        if (!this.mouseDown)
            return;
        this.refreshScrollCoordinates();
        var /** @type {?} */ frame = this.getSelectorFrameCoordinates(this.selectionFrameCoordinates);
        this.drawRectangle(this.getFrameRelativeToParent(frame, this.parent));
        this.determineSelected(frame, this.selectableDirectives.toArray());
    };
    /**
     * @return {?}
     */
    SelectFrameComponent.prototype.resetListeners = /**
     * @return {?}
     */
    function () {
        if (this.mouseMoveListener) {
            this.mouseMoveListener();
            this.mouseMoveListener = null;
        }
        
        if (this.mouseUpListener) {
            this.mouseUpListener();
            this.mouseUpListener = null;
        }
        
        if (this.scrollListener) {
            this.scrollListener();
            this.scrollListener = null;
        }
        
    };
    /**
     * @return {?}
     */
    SelectFrameComponent.prototype.startListeners = /**
     * @return {?}
     */
    function () {
        var _this = this;
        this.zone.runOutsideAngular(function () {
            _this.scrollListener = _this.renderer.listen(window, 'scroll', function (scrollEvent) { return _this.onScroll(scrollEvent); });
            _this.mouseMoveListener = _this.renderer.listen(document, 'mousemove', function (dragEvent) { return _this.onMouseMove(dragEvent); });
            _this.mouseUpListener = _this.renderer.listen(document, 'mouseup', function (mouseUpEvent) { return _this.onMouseUp(mouseUpEvent); });
        });
    };
    /**
     * @return {?}
     */
    SelectFrameComponent.prototype.startContinuationListeners = /**
     * @return {?}
     */
    function () {
        var _this = this;
        this.zone.runOutsideAngular(function () {
            _this.scrollListener = _this.renderer.listen(window, 'scroll', function (scrollEvent) { return _this.onScrollContinue(scrollEvent); });
            _this.mouseMoveListener =
                _this.renderer.listen(document, 'mousemove', function (dragEvent) { return _this.onMouseMoveContinue(dragEvent); });
            _this.mouseUpListener = _this.renderer.listen(document, 'mouseup', function (mouseUpEvent) { return _this.onMouseUp(mouseUpEvent); });
        });
    };
    /**
     * @param {?} ev
     * @return {?}
     */
    SelectFrameComponent.prototype.refreshMoveCoordinates = /**
     * @param {?} ev
     * @return {?}
     */
    function (ev) {
        this.selectionFrameCoordinates.endX = ev.clientX;
        this.selectionFrameCoordinates.endY = ev.clientY;
    };
    /**
     * @return {?}
     */
    SelectFrameComponent.prototype.refreshScrollCoordinates = /**
     * @return {?}
     */
    function () {
        this.selectionFrameCoordinates.endScrollX = window.pageXOffset;
        this.selectionFrameCoordinates.endScrollY = window.pageYOffset;
    };
    /**
     * @param {?} ev
     * @return {?}
     */
    SelectFrameComponent.prototype.setStartFrameCoordinates = /**
     * @param {?} ev
     * @return {?}
     */
    function (ev) {
        this.selectionFrameCoordinates = {
            startX: ev.clientX,
            startY: ev.clientY,
            endX: ev.clientX,
            endY: ev.clientY,
            startScrollX: window.pageXOffset,
            startScrollY: window.pageYOffset,
            endScrollX: window.pageXOffset,
            endScrollY: window.pageYOffset
        };
    };
    /**
     * @return {?}
     */
    SelectFrameComponent.prototype.determineChildrenCoordinates = /**
     * @return {?}
     */
    function () {
        this.selectableDirectives.map(function (x) { return x.determineCoordinates(); });
    };
    /**
     * @return {?}
     */
    SelectFrameComponent.prototype.determineParentCoordinates = /**
     * @return {?}
     */
    function () {
        return this.el.nativeElement.getBoundingClientRect();
    };
    /**
     * @param {?=} delay
     * @return {?}
     */
    SelectFrameComponent.prototype.hideRectangle = /**
     * @param {?=} delay
     * @return {?}
     */
    function (delay) {
        var _this = this;
        setTimeout(function () {
            _this.renderer.setStyle(_this.selector.nativeElement, 'display', 'none');
        }, delay || 0);
    };
    /**
     * @param {?} frame
     * @param {?=} delay
     * @return {?}
     */
    SelectFrameComponent.prototype.drawRectangle = /**
     * @param {?} frame
     * @param {?=} delay
     * @return {?}
     */
    function (frame, delay) {
        var _this = this;
        setTimeout(function () {
            _this.renderer.setStyle(_this.selector.nativeElement, 'display', 'block');
            _this.renderer.setStyle(_this.selector.nativeElement, 'left', frame.left + 'px');
            _this.renderer.setStyle(_this.selector.nativeElement, 'top', frame.top + 'px');
            _this.renderer.setStyle(_this.selector.nativeElement, 'width', frame.width + 'px');
            _this.renderer.setStyle(_this.selector.nativeElement, 'height', frame.height + 'px');
        }, delay || 0);
    };
    /**
     * @param {?} data
     * @return {?}
     */
    SelectFrameComponent.prototype.getSelectorFrameCoordinates = /**
     * @param {?} data
     * @return {?}
     */
    function (data) {
        var /** @type {?} */ xScroll = data.endScrollX - data.startScrollX;
        var /** @type {?} */ yScroll = data.endScrollY - data.startScrollY;
        return {
            top: Math.min(data.startY, data.endY + yScroll),
            left: Math.min(data.startX, data.endX + xScroll),
            right: Math.max(data.startX, data.endX + xScroll),
            bottom: Math.max(data.startY, data.endY + yScroll),
            width: Math.abs(data.endX + xScroll - data.startX),
            height: Math.abs(data.endY + yScroll - data.startY)
        };
    };
    /**
     * @param {?} frame
     * @param {?} parent
     * @return {?}
     */
    SelectFrameComponent.prototype.getFrameRelativeToParent = /**
     * @param {?} frame
     * @param {?} parent
     * @return {?}
     */
    function (frame, parent) {
        if (parent == null)
            return frame;
        return {
            left: frame.left - parent.left,
            top: frame.top - parent.top,
            right: frame.right - parent.right,
            bottom: frame.bottom - parent.bottom,
            width: frame.width,
            height: frame.height
        };
    };
    /**
     * @param {?} ev
     * @return {?}
     */
    SelectFrameComponent.prototype.startSelection = /**
     * @param {?} ev
     * @return {?}
     */
    function (ev) {
        this.prepareStartOfSelection(ev);
        return this.doStartOfSelection(ev);
    };
    /**
     * @param {?} ev
     * @return {?}
     */
    SelectFrameComponent.prototype.prepareStartOfSelection = /**
     * @param {?} ev
     * @return {?}
     */
    function (ev) {
        // actions indepentent of allowing selection
        this.setStartCoordinates(ev);
        var /** @type {?} */ frame = this.getSelectorFrameCoordinates(this.selectionFrameCoordinates);
        this.resetComponents(frame, this.selectableDirectives.toArray());
        this.resetListeners();
    };
    /**
     * @param {?} ev
     * @return {?}
     */
    SelectFrameComponent.prototype.prepareContinuationOfSelection = /**
     * @param {?} ev
     * @return {?}
     */
    function (ev) {
        this.setStartCoordinates(ev);
        this.saveSelected();
        this.resetListeners();
    };
    /**
     * @param {?} ev
     * @return {?}
     */
    SelectFrameComponent.prototype.doStartOfSelection = /**
     * @param {?} ev
     * @return {?}
     */
    function (ev) {
        // do nothing if start selection filter active
        // and element is not a member of the filter elements
        if (!this.allowSelectionOnElements(ev))
            return true;
        // new selection - clear tmpData
        this.tempData = [];
        this.mouseDown = true;
        this.startListeners();
        ev.stopPropagation();
        return false;
    };
    /**
     * @param {?} ev
     * @return {?}
     */
    SelectFrameComponent.prototype.doContinuationOfSelection = /**
     * @param {?} ev
     * @return {?}
     */
    function (ev) {
        // do nothing if start selection filter active
        // and element is not a member of the filter elements
        if (!this.allowSelectionOnElements(ev))
            return true;
        // new selection - clear tmpData
        this.mouseDown = true;
        this.startContinuationListeners();
        ev.stopPropagation();
        return false;
    };
    /**
     * @param {?} ev
     * @return {?}
     */
    SelectFrameComponent.prototype.determineTypeOfContinuation = /**
     * @param {?} ev
     * @return {?}
     */
    function (ev) {
        this.prepareContinuationOfSelection(ev);
        var /** @type {?} */ selectedElement = this.getSelectedElement(ev);
        if (selectedElement >= 0) {
            return this.toggleThisElement(ev, selectedElement);
        }
        if (Object.keys(this.tempData).length === 0) {
            // nothing was selected till now
            return this.startSelection(ev);
        }
        return this.doContinuationOfSelection(ev);
    };
    /**
     * @return {?}
     */
    SelectFrameComponent.prototype.saveSelected = /**
     * @return {?}
     */
    function () {
        this.selectableDirectives.map(function (x) { return x.saveSelected(); });
    };
    /**
     * @param {?} ev
     * @param {?} index
     * @return {?}
     */
    SelectFrameComponent.prototype.toggleThisElement = /**
     * @param {?} ev
     * @param {?} index
     * @return {?}
     */
    function (ev, index) {
        var _a = this.getFilterAndScope(), filter = _a.filter, scope = _a.scope;
        this.selectableDirectives.toArray()[index].toggle(filter, scope);
        this.tempData = this.getSelectedData();
        this.data.emit(this.tempData);
        ev.stopPropagation();
        return false;
    };
    /**
     * @param {?} ev
     * @return {?}
     */
    SelectFrameComponent.prototype.getSelectedElement = /**
     * @param {?} ev
     * @return {?}
     */
    function (ev) {
        var /** @type {?} */ frame = this.getSelectorFrameCoordinates(this.selectionFrameCoordinates);
        return this.selectableDirectives.map(function (x) { return x.clicked(frame); }).findIndex(function (member) { return member === true; });
    };
    /**
     * @param {?} ev
     * @return {?}
     */
    SelectFrameComponent.prototype.setStartCoordinates = /**
     * @param {?} ev
     * @return {?}
     */
    function (ev) {
        this.parent = this.determineParentCoordinates();
        this.determineChildrenCoordinates();
        this.setStartFrameCoordinates(ev);
    };
    /**
     * @param {?} frame
     * @param {?} directives
     * @return {?}
     */
    SelectFrameComponent.prototype.determineSelected = /**
     * @param {?} frame
     * @param {?} directives
     * @return {?}
     */
    function (frame, directives) {
        var _this = this;
        if (this.ensureSame.length === 0 || Object.keys(this.tempData).length === 0)
            this.selectComponents(frame, directives);
        else
            this.filterComponents(frame, directives);
        if (this.tempData.length === 0)
            this.selectableDirectives.map(function (x) {
                if (Object.keys(_this.tempData).length === 0) {
                    var /** @type {?} */ data = x.getDataIfSelected();
                    if (data) {
                        if (data.scope) {
                            if (!_this.tempData[data.scope])
                                _this.tempData[data.scope] = [];
                            _this.tempData[data.scope].push(data.data);
                        }
                        else
                            _this.tempData.push(data);
                    }
                }
            });
    };
    /**
     * @param {?} frame
     * @param {?} directives
     * @return {?}
     */
    SelectFrameComponent.prototype.determineSelectedContinuation = /**
     * @param {?} frame
     * @param {?} directives
     * @return {?}
     */
    function (frame, directives) {
        this.filterComponents(frame, directives, true);
    };
    /**
     * @return {?}
     */
    SelectFrameComponent.prototype.getSelectedData = /**
     * @return {?}
     */
    function () {
        var /** @type {?} */ returnData = [];
        this.selectableDirectives.map(function (x) {
            var /** @type {?} */ data = x.getDataIfSelected();
            if (data) {
                if (data.scope) {
                    if (!returnData[data.scope])
                        returnData[data.scope] = [];
                    returnData[data.scope].push(data.data);
                }
                else
                    returnData.push(data);
            }
        });
        return returnData;
    };
    /**
     * @param {?} frame
     * @param {?} directives
     * @param {?=} continuation
     * @return {?}
     */
    SelectFrameComponent.prototype.filterComponents = /**
     * @param {?} frame
     * @param {?} directives
     * @param {?=} continuation
     * @return {?}
     */
    function (frame, directives, continuation) {
        var _a = this.getFilterAndScope(), filter = _a.filter, scope = _a.scope;
        this.selectableDirectives.map(function (x) { return x.select(frame, filter, scope, continuation); });
    };
    /**
     * @param {?} frame
     * @param {?} directives
     * @return {?}
     */
    SelectFrameComponent.prototype.selectComponents = /**
     * @param {?} frame
     * @param {?} directives
     * @return {?}
     */
    function (frame, directives) {
        this.selectableDirectives.map(function (x) { return x.select(frame); });
    };
    /**
     * @param {?} directives
     * @return {?}
     */
    SelectFrameComponent.prototype.unselectComponents = /**
     * @param {?} directives
     * @return {?}
     */
    function (directives) {
        this.selectableDirectives.map(function (x) { return (x.select(null)); });
    };
    /**
     * @param {?} frame
     * @param {?} directives
     * @return {?}
     */
    SelectFrameComponent.prototype.resetComponents = /**
     * @param {?} frame
     * @param {?} directives
     * @return {?}
     */
    function (frame, directives) {
        var /** @type {?} */ i = 0;
        if (this.clearOnUnselected)
            i = this.selectableDirectives.map(function (x) { return x.clickedOnSelected(frame); }).findIndex(function (member) { return member === true; });
        else
            i = this.selectableDirectives.map(function (x) { return x.clicked(frame); }).findIndex(function (member) { return member === true; });
        if (i >= 0)
            return;
        this.unselectComponents(directives);
    };
    /**
     * @param {?} ev
     * @return {?}
     */
    SelectFrameComponent.prototype.allowSelectionOnElements = /**
     * @param {?} ev
     * @return {?}
     */
    function (ev) {
        if (this.filter == null)
            return true;
        var /** @type {?} */ element = document.elementFromPoint(ev.clientX, ev.clientY);
        var /** @type {?} */ result = false;
        if (this.filter.allowSelectElements === true)
            result = (element.hasAttribute('allow-select'));
        if (this.filter.thisElement)
            result = result || (element === this.el.nativeElement);
        return result;
    };
    /**
     * @return {?}
     */
    SelectFrameComponent.prototype.getFilterAndScope = /**
     * @return {?}
     */
    function () {
        if (Object.keys(this.tempData).length > 0) {
            var /** @type {?} */ filter_1 = [];
            var /** @type {?} */ scope = Object.keys(this.tempData)[0];
            var /** @type {?} */ filterData_1 = (+scope === 0) ? this.tempData[0] : this.tempData[scope][0];
            this.ensureSame.forEach(function (x) {
                filter_1[x] = filterData_1[x];
            });
            scope = (+scope === 0) ? null : scope;
            return { filter: filter_1, scope: scope };
        }
        else {
            return { filter: null, scope: null };
        }
    };
    //#endregion selection
    /**
     * @return {?}
     */
    SelectFrameComponent.prototype.ngAfterViewInit = /**
     * @return {?}
     */
    function () {
        if (this.selectorColor === 'defaultYellow')
            this.renderer.setStyle(this.selector.nativeElement, 'background', '#fac656');
        else
            this.renderer.setStyle(this.selector.nativeElement, 'background', this.selectorColor);
    };
    /**
     * @param {?} changes
     * @return {?}
     */
    SelectFrameComponent.prototype.ngOnChanges = /**
     * @param {?} changes
     * @return {?}
     */
    function (changes) {
        if (changes['selectorColor'])
            this.renderer.setStyle(this.selector.nativeElement, 'background', this.selectorColor);
    };
    SelectFrameComponent.decorators = [
        { type: core.Component, args: [{
                    selector: '[app-selectFrame]',
                    styles: [".selector-frame { position: absolute; opacity: 0.5; border: 1px dotted black; z-index: 99000; }"],
                    template: "<div> <div class=\"selector-frame\" #selectorFrame></div> <ng-content></ng-content> </div>"
                },] },
    ];
    /** @nocollapse */
    SelectFrameComponent.ctorParameters = function () { return [
        { type: core.ElementRef, decorators: [{ type: core.Inject, args: [core.ElementRef,] },] },
        { type: core.Renderer2, decorators: [{ type: core.Inject, args: [core.Renderer2,] },] },
        { type: core.NgZone, decorators: [{ type: core.Inject, args: [core.NgZone,] },] },
    ]; };
    SelectFrameComponent.propDecorators = {
        "ensureSame": [{ type: core.Input },],
        "filter": [{ type: core.Input },],
        "clearOnUnselected": [{ type: core.Input },],
        "selectorColor": [{ type: core.Input },],
        "data": [{ type: core.Output },],
        "selector": [{ type: core.ViewChild, args: ['selectorFrame',] },],
        "selectableDirectives": [{ type: core.ContentChildren, args: [SelectableDirective, { descendants: true },] },],
        "onMouseDown": [{ type: core.HostListener, args: ['window:mousedown', ['$event'],] },],
    };
    return SelectFrameComponent;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * \@description
 * directive for dissalowing text-selection.
 *
 * \@example
 *
 * <div noSelect></div>
 *
 * @export
 */
var NoSelectDirective = (function () {
    function NoSelectDirective(el, renderer) {
        this.el = el;
        this.renderer = renderer;
        this.renderer.setStyle(this.el.nativeElement, '-webkit-user-select', 'none');
        this.renderer.setStyle(this.el.nativeElement, '-moz-user-select', '-moz-none');
        this.renderer.setStyle(this.el.nativeElement, '-ms-user-select', 'none');
        this.renderer.setStyle(this.el.nativeElement, 'user-select', 'none');
    }
    NoSelectDirective.decorators = [
        { type: core.Directive, args: [{
                    selector: '[noSelect]',
                },] },
    ];
    /** @nocollapse */
    NoSelectDirective.ctorParameters = function () { return [
        { type: core.ElementRef, decorators: [{ type: core.Inject, args: [core.ElementRef,] },] },
        { type: core.Renderer2, decorators: [{ type: core.Inject, args: [core.Renderer2,] },] },
    ]; };
    return NoSelectDirective;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * \@description
 * directive for items inside the 'select-frame' * component.
 *
 * Start of selection is allowed on elements with these directive,
 * if filter on  'select-frame' component is set on
 * 'allowSelectElements'.
 *
 *
 * \@example
 *
 * <div appAllowSelect></div>
 *
 * @export
 */
var AllowSelectDirective = (function () {
    function AllowSelectDirective(el, renderer) {
        this.el = el;
        this.renderer = renderer;
        this.renderer.setAttribute(this.el.nativeElement, 'allow-select', 'true');
    }
    AllowSelectDirective.decorators = [
        { type: core.Directive, args: [{ selector: '[appAllowSelect]' },] },
    ];
    /** @nocollapse */
    AllowSelectDirective.ctorParameters = function () { return [
        { type: core.ElementRef, decorators: [{ type: core.Inject, args: [core.ElementRef,] },] },
        { type: core.Renderer2, decorators: [{ type: core.Inject, args: [core.Renderer2,] },] },
    ]; };
    return AllowSelectDirective;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
var SelectableModule = (function () {
    function SelectableModule() {
    }
    /**
     * @return {?}
     */
    SelectableModule.forRoot = /**
     * @return {?}
     */
    function () {
        return {
            ngModule: SelectableModule,
            providers: []
        };
    };
    SelectableModule.decorators = [
        { type: core.NgModule, args: [{
                    imports: [
                        common.CommonModule
                    ],
                    declarations: [
                        NoSelectDirective,
                        SelectFrameComponent,
                        SelectableDirective,
                        AllowSelectDirective
                    ],
                    exports: [
                        NoSelectDirective,
                        SelectFrameComponent,
                        SelectableDirective,
                        AllowSelectDirective
                    ]
                },] },
    ];
    /** @nocollapse */
    SelectableModule.ctorParameters = function () { return []; };
    return SelectableModule;
}());

exports.SelectableModule = SelectableModule;
exports.SelectFrameComponent = SelectFrameComponent;
exports.NoSelectDirective = NoSelectDirective;
exports.SelectableDirective = SelectableDirective;
exports.AllowSelectDirective = AllowSelectDirective;

Object.defineProperty(exports, '__esModule', { value: true });

})));
