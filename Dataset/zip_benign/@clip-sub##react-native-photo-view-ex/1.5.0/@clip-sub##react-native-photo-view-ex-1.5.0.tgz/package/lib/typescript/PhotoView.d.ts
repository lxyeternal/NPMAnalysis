import React from "react";
import { ViewProps } from "react-native";
interface Props extends ViewProps {
    source: {
        uri: string;
    };
    loadingIndicatorSource?: {
        uri: string;
    };
    fadeDuration?: number;
    minimumZoomScale: number;
    maximumZoomScale: number;
    resizeMode?: "center" | "contain" | "cover" | "fitEnd" | "fitStart" | "stretch";
    scale?: number;
    onError?: (error: any) => void;
    onLoad?: () => void;
    onLoadEnd?: () => void;
    onLoadStart?: () => void;
    onProgress?: (event: any) => void;
    onScale?: (event: any) => void;
    onTap?: (event: any) => void;
    onViewTap?: (event: any) => void;
}
export default function PhotoView({ source, ...props }: Props): React.JSX.Element | null;
export {};
//# sourceMappingURL=PhotoView.d.ts.map