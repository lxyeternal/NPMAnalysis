import PhotoView from './PhotoView';
export default PhotoView;
//# sourceMappingURL=index.d.ts.map