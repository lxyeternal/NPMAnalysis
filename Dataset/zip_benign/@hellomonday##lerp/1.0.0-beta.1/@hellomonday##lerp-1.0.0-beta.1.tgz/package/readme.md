# @hellomonday/lerp

> Linearly interpolate between two values (mix).


## Install

```
$ npm install --save @hellomonday/lerp
```

## Usage

```js
import lerp from '@hellomonday/lerp';

const value = lerp(0, 100, 0.5); // => 50
```

## License

MIT © [Hello Monday](https://hellomonday.com)
