
## 用途：
    用于语音编辑，对数据的格式进行初步校验，避免出现一些低级的格式错误；为了方便使用者对接api，所以单独提出一个模块用于在前端校验数据格式。

## 使用说明： 

### 引入
```javascript
    // npm i voice-verify
   import vioceVerify from 'voice-verify'
   // or  const vioceVerify = require('voice-verify')
   let verifyArr = [] // 需要校验的数组， 格式如下注解
   let codeInfo = vioceVerify(verifyArr) // codeInfo = { code: '状态码', message: '状态信息' }
```

>**待校验数组格式：** 
```
    [
        {
            typeEn: 'XXX',
            status: 'XXX',
            value: 'XXX'
        },
        {
            typeEn: 'XXX',
            status: 'XXX',
            value: 'XXX'
        },
        ....
    ]
```

> **元素对应的json**

|元素类型 | typeEn| status| value|
| ------ | ------ |------| ------|
|  形象  | 'avatar'| 'start' 或 'end' | 'P2A_female_def.bundle' (女主播)| 
|  背景  | 'background'| 'start' 或 'end' | 'P2A_Sence.bundle' (科技感)| 
|  文本  | 'text'| 'block' | '文本内容' | 
|  情绪  | 'emotion'| 'start' 或 'end' | 'smile'或'angry'或'sad' 分别对应微笑、生气、伤心| 
|  动作  | 'motion'| 'block' | 'P2A_female_DJ_02_anim.bundle'(单手放下)、'P2A_female_DJ_03_anim.bundle'(双手摊开)、'P2A_female_DJ_04_anim.bundle'(加油打气)、'P2A_female_JG_01_anim.bundle'(鞠躬)| 
|  同步动作  | 'motion'| 'start' 或 'end' | 'P2A_female_DJ_02_anim.bundle'(单手放下)、'P2A_female_DJ_03_anim.bundle'(双手摊开)、'P2A_female_DJ_04_anim.bundle'(加油打气)、'P2A_female_JG_01_anim.bundle'(鞠躬)| 
|  图片  | 'picture'| 'start' 或 'end' | File格式 | 
|  视频  | 'video'| 'block' | File格式 | 
|  延迟0.5s  | 'suspend'| 'block' | 0.5 (延时0.5s) | 

***注意: status为block即只有自己一个元素， 若为'start'或'end'那么必须有对应的另一个'end' 'start'，***

>**返回状态码对应的信息：**

|code | message
| ------ | ------ |
|"00" | '合格'|
|"01" | '元素结构太少'|
|"02" | '每个单元都应该是json'|
|"03" | '输入应为json数组'|
|"04" | '存在元素没有设置值'|
|"10" | 'json内部字段部分缺失'|
|"11" | '最外层必须用主播形象'|
|"12" | '第二次必须使用背景'|
|"13" | '非法嵌套'|
|"14" | '存在结束标签在对应开始标签的后面'|

