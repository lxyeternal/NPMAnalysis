const verify = require('./utils')
module.exports = function(arr) {
    var fieldCode = verify.fieldVerify(arr)
    if(fieldCode.code !== '00') {
        return fieldCode
    }
    var wrapOuterCode = verify.wrapOuter(arr)
    if(wrapOuterCode.code !== '00') {
        return wrapOuterCode
    }
    var doubleVerify = verify.doubleVerify(arr)
    return doubleVerify
}