var Message = {
    "00": '合格',
    "01": '元素结构太少',
    "02": '每个单元都应该是json',
    "03": '输入应为json数组',
    "04": '存在元素没有设置值',
    "10": 'json内部字段部分缺失',
    "11": '最外层必须用主播形象',
    "12": '第二层必须使用背景',
    "13": '非法嵌套',
    "14": '存在结束标签在对应开始标签的后面',
}
var fieldList = ['typeEn', 'status', 'value']
var codeMes = function(code, message) { // type 1 需要详细报错
    let obj = {
        code: code,
        message: Message[code]
    },
    newMes = message || ''
    if(newMes) {
        Object.assign(obj, {
            message: Message[code] +'('+ newMes+')'
        })
    }
    return obj
}
var fieldVerify = function(arr) {
    if(!Array.isArray(arr)) {
        return codeMes('03')
    }else if(arr.length < 4) {
        return codeMes('01')
    }
    var fieldLess = false,
        notObject = false,
        noValue = false
    arr.forEach(function(v) {
        if(Object.prototype.toString.call(v) !== '[object Object]') {
            notObject = true
            return
        }else if(!v.value){
            noValue = v.typeEn
            return
        }
        var filterArr = fieldList.filter(function(item) {
            return item in v
        })
        if(filterArr.length !== 3) {
            fieldLess = true
        }
    })
    if(notObject) return codeMes('02');
    if(noValue) return codeMes('04', noValue);
    if(fieldLess) return codeMes('10');
    return codeMes('00')
}
/**校验开头结尾包含形象背景
 * @param {要验证的数组} arr 
 */
var wrapOuter = function(arr) {
    var newArr = Array.from(arr)
    if(newArr[0].typeEn !== 'avatar' || newArr.pop().typeEn !== 'avatar') {
        return codeMes('11')
    }else if(newArr[1].typeEn !== 'background' || newArr.pop().typeEn !== 'background'){
        return codeMes('12')
    }
    console.log(newArr)
    return codeMes('00')
}

/**校验有开始结束的元素不能嵌套自己的同类
 * @param {要验证的数组} arr 
 */
var doubleVerify = function(arr) {
    var obj = {
            emotion: "",
            motion: "",
            picture: "",
            avatar: "",
            background: "",
        },
        keyArr = Object.keys(obj)
        // newArr = Array.from(arr)
    for(var i = 0; i < arr.length; i++) {
        var v = arr[i]
        for(var item = 0; item < keyArr.length; item++) {
            if((v.status === 'start' || v.status == 'block') && v.typeEn === keyArr[item]) {
                if(obj[keyArr[item]]) { // 没有经过对应end重置，也就是start后面还是start
                    return codeMes('13', '存在于' + v.typeEn + '类型的元素')
                }
                obj[keyArr[item]] = v.value
            }
            if(v.status === 'end' && v.typeEn === keyArr[item]) {
                if(obj[keyArr[item]] === '') { // end在start前面
                    return codeMes('13', '存在于' + v.typeEn + '类型的元素')
                }
                obj[keyArr[item]] = ''
            }
        }
    }
    return codeMes('00')
}
module.exports = {
    fieldVerify,
    wrapOuter,
    doubleVerify
}