# Changelog

# [2.0.0](https://github.com/podcast-data-lab/pubsubhubbub/compare/v1.0.1...v2.0.0) (2022-04-22)


### Bug Fixes

* build ([33f7373](https://github.com/podcast-data-lab/pubsubhubbub/commit/33f7373dfc757fc0c5db9e6acb061bc09b356232))
* imports ([b4fbddb](https://github.com/podcast-data-lab/pubsubhubbub/commit/b4fbddb33b580e720b8367c8646a05335c6cdec7))


### Features

* create subscription function ([d8f885d](https://github.com/podcast-data-lab/pubsubhubbub/commit/d8f885dc2d7f96f5fd09fad8e657ce06a6fedfa6))


### BREAKING CHANGES

* Does not implement the previous api. This assumes that you have set up your `get`
and `post` request endpoint for the hub to callback.
