export interface IOptions {
    secret: string
    maxContentSize?: number
    leaseSeconds?: number
    mode: 'subscribe' | 'unsubscribe'
    topic: `http${string}`
    hub: `http${string}`
    callbackUrl: `http${string}`
}
