import crypto from 'crypto'
import { IOptions } from '../models'
import fetch, { Headers } from 'node-fetch'

/**
 * Subsribe or unsubscribe a topic at selected hub
 */
export async function subscribeToHub(options: IOptions) {
    let { mode, topic, hub, callbackUrl, leaseSeconds, secret } = options

    // by default the topic url is added as a GET parameter to the callback url
    let hubCallbackUrl =
        callbackUrl ||
        callbackUrl +
            (callbackUrl.replace(/^https?:\/\//i, '').match(/\//) ? '' : '/') +
            (callbackUrl.match(/\?/) ? '&' : '?') +
            'topic=' +
            encodeURIComponent(topic) +
            '&hub=' +
            encodeURIComponent(hub)

    let body = new URLSearchParams({
        'hub.callback': hubCallbackUrl,
        'hub.mode': mode,
        'hub.topic': topic,
        'hub.verify': 'async',
    })

    if (leaseSeconds > 0) {
        body.append('hub.lease#seconds', JSON.stringify(leaseSeconds))
    }

    body.append('hub.secret', crypto.createHmac('sha1', secret).update(topic).digest('hex'))

    const headers = new Headers({ 'Content-Type': 'application/x-www-form-urlencoded' })

    return await fetch(hub, {
        headers,
        method: 'POST',
        body: JSON.stringify(body),
    })
}
