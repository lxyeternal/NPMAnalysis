/*
 *
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 *
 */

/* global cordova */

var argscheck = require('cordova/argscheck'),
    utils = require('cordova/utils'),
    exec = require('cordova/exec'),
    channel = require('cordova/channel');

var Keyboard = function () {};

Keyboard.fireOnShow = function (height) {
    Keyboard.isVisible = true;
    cordova.fireWindowEvent('keyboardDidShow', {
        'keyboardHeight': height
    });

    // To support the keyboardAttach directive listening events
    // inside Ionic's main bundle
    cordova.fireWindowEvent('native.keyboardshow', {
        'keyboardHeight': height
    });
};

Keyboard.fireOnHide = function () {
    Keyboard.isVisible = false;
    cordova.fireWindowEvent('keyboardDidHide');

    // To support the keyboardAttach directive listening events
    // inside Ionic's main bundle
    cordova.fireWindowEvent('native.keyboardhide');
};

Keyboard.fireOnHiding = function () {
    cordova.fireWindowEvent('keyboardWillHide');
};

Keyboard.fireOnShowing = function (height) {
    cordova.fireWindowEvent('keyboardWillShow', {
        'keyboardHeight': height
    });
};

Keyboard.hideFormAccessoryBar = Keyboard.hideKeyboardAccessoryBar = function (hide) {
    console.warn("Keyboard.hideKeyboardAccessoryBar() not supported in Android");
};

Keyboard.hide = function () {
    exec(null, null, "CustomStatusbar", "keyboardHide", []);
};

Keyboard.show = function () {
    exec(null, null, "CustomStatusbar", "keyboardShow", []);
};

Keyboard.disableScroll = function (disable) {
    console.warn("Keyboard.disableScroll() not supported in Android");
};

Keyboard.setResizeMode = function (mode) {
    console.warn("Keyboard.setResizeMode() not supported in Android");
}

Keyboard.setKeyboardStyle = function(style) {
    console.warn("Keyboard.setKeyboardStyle() not supported in Android");
};

var namedColors = {
    black: '#000000',
    darkGray: '#A9A9A9',
    lightGray: '#D3D3D3',
    white: '#FFFFFF',
    gray: '#808080',
    red: '#FF0000',
    green: '#00FF00',
    blue: '#0000FF',
    cyan: '#00FFFF',
    yellow: '#FFFF00',
    magenta: '#FF00FF',
    orange: '#FFA500',
    purple: '#800080',
    brown: '#A52A2A'
};

var CustomStatusbar = {
    statusBarIsVisible: true,
    hasCutout: function(success, error) {
        exec(success, error, "CustomStatusbar", "hasCutout");
    },

    setLayout: function(success, error) {
        exec(success, error, "CustomStatusbar", "setLayout");
    },

    getInsetTop: function (success, error) {
        exec(success, error, "CustomStatusbar", "getInsetsTop");
    },
    
    getInsetRight: function (success, error) {
        exec(success, error, "CustomStatusbar", "getInsetsRight");
    },
    
    getInsetBottom: function (success, error) {
        exec(success, error, "CustomStatusbar", "getInsetsBottom");
    },
    
    getInsetLeft: function (success, error) {
        exec(success, error, "CustomStatusbar", "getInsetsLeft");
    },
    statusBarOverlaysWebView: function (doOverlay) {
        exec(null, null, 'CustomStatusbar', 'statusBarOverlaysWebView', [doOverlay]);
    },

    statusBarBlackText: function () {
        // dark text ( to be used on a light background )
        exec(null, null, 'CustomStatusbar', 'statusBarBlackText', []);
    },
    statusBarWhiteText: function () {
        exec(null, null, 'CustomStatusbar', 'statusBarWhiteText', []);
    },

    statusBarBackgroundColorByName: function (colorname) {
        return CustomStatusbar.statusBarBackgroundColorByHexString(namedColors[colorname]);
    },

    statusBarBackgroundColorByHexString: function (hexString) {
        if (hexString.charAt(0) !== '#') {
            hexString = '#' + hexString;
        }

        if (hexString.length === 4) {
            var split = hexString.split('');
            hexString = '#' + split[1] + split[1] + split[2] + split[2] + split[3] + split[3];
        }

        exec(null, null, 'CustomStatusbar', 'statusBarBackgroundColorByHexString', [hexString]);
    },

    statusBarHide: function () {
        exec(null, null, 'CustomStatusbar', 'statusBarHide', []);
        CustomStatusbar.statusBarIsVisible = false;
    },

    statusBarShow: function () {
        exec(null, null, 'CustomStatusbar', 'statusBarShow', []);
        CustomStatusbar.statusBarIsVisible = true;
    },
    keyboardHide: function () {
        exec(null, null, "CustomStatusbar", "keyboardHide", []);
    },
    keyboardShow: function () {
        exec(null, null, "CustomStatusbar", "keyboardShow", []);
    },
};

channel.onCordovaReady.subscribe(function () {
    exec(success, null, 'CustomStatusbar', 'keyboardInit', []);

    function success(msg) {
        var action = msg.charAt(0);
        if (action === 'S') {
            var keyboardHeight = parseInt(msg.substr(1));
            Keyboard.fireOnShowing(keyboardHeight);
            Keyboard.fireOnShow(keyboardHeight);

        } else if (action === 'H') {
            Keyboard.fireOnHiding();
            Keyboard.fireOnHide();
        }
    }
});

Keyboard.isVisible = false;
// prime it. setTimeout so that proxy gets time to init
window.setTimeout(function () {
    exec(
        function (res) {
            if (typeof res === 'object') {
                if (res.type === 'tap') {
                    cordova.fireWindowEvent('statusTap');
                }
            } else {
                CustomStatusbar.statusBarIsVisible = res;
            }
        },
        null,
        'CustomStatusbar',
        '_ready',
        []
    );
}, 0);





module.exports = CustomStatusbar;
