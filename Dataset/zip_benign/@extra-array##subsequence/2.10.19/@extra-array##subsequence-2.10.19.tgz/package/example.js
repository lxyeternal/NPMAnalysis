const array = require("extra-array");

var x = [1, 2, 3, 4, 5];
array.subsequence(x);

array.subsequence(x, 3, 0.3);

array.subsequence(x, 2, 0.3);
