declare module "@extra-array/subsequence" {
/**
 * Picks an arbitrary subsequence.
 * @param x an array
 * @param n number of values (-1 => any)
 * @param r random seed 0->1
 */
declare function subsequence<T>(x: T[], n?: number, r?: number): T[];
export = subsequence;
//# sourceMappingURL=subsequence.d.ts.map}
