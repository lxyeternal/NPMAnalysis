function random(r) {
    var a = Math.floor(r * 2 ** 31);
    return function () {
        var t = a += 0x6D2B79F5;
        t = Math.imul(t ^ t >>> 15, t | 1);
        t ^= t + Math.imul(t ^ t >>> 7, t | 61);
        return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
}
function permutation$(x, n = -1, r = Math.random()) {
    if (n > x.length)
        return x;
    var X = x.length, rnd = random(r);
    var n = n >= 0 ? n : Math.floor((X + 1) * rnd());
    for (var i = 0; i < n; i++) {
        var j = i + Math.floor((X - i) * rnd());
        var t = x[i];
        x[i] = x[j];
        x[j] = t;
    }
    x.length = n;
    return x;
}
function fromRange(v, V = v, s = 1) {
    var a = [];
    if (s >= 0) {
        for (; v < V; v += s)
            a.push(v);
    }
    else {
        for (; v > V; v += s)
            a.push(v);
    }
    return a;
}
function index(x, i = 0) {
    return i < 0 ? Math.max(x.length + i, 0) : Math.min(i, x.length);
}
function get(x, i) {
    return x[index(x, i)];
}
function getAll(x, is) {
    return is.map(i => get(x, i));
}
function subsequenceNum(x, n, r) {
    var is = fromRange(0, x.length, 1);
    permutation$(is, n, r).sort();
    return getAll(x, is);
}
function subsequenceAny(x, r) {
    var rnd = random(r), a = [];
    for (var v of x)
        if (rnd() >= 0.5)
            a.push(v);
    return a;
}
function subsequence(x, n = -1, r = Math.random()) {
    var X = x.length;
    if (n >= 0)
        return n > X ? null : subsequenceNum(x, n, r);
    return subsequenceAny(x, r);
}
export { subsequence as default };
