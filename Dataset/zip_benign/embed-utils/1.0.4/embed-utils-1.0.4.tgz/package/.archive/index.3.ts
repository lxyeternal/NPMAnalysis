export type Embedding = number[];

/**
 * Normalizes an embedding vector to unit length (L2 norm = 1)
 */
export function normalizeEmbedding(embedding: Embedding): Embedding {
  const magnitude = Math.sqrt(embedding.reduce((sum, val) => sum + val * val, 0));
  if (magnitude === 0) return embedding;
  return embedding.map(val => val / magnitude);
}

/**
 * Calculates dot product between embeddings
 * @throws If embeddings have different lengths
 */
export function getDotProduct(a: Embedding, b: Embedding): number {
  if (a.length !== b.length) throw new Error('Embeddings must have same length');
  return a.reduce((sum, val, i) => sum + val * b[i], 0);
}

/**
 * Calculates Manhattan distance (L1 norm) between embeddings
 * @throws If embeddings have different lengths
 */
export function getManhattanDistance(a: Embedding, b: Embedding): number {
  if (a.length !== b.length) throw new Error('Embeddings must have same length');
  return a.reduce((sum, val, i) => sum + Math.abs(val - b[i]), 0);
}

/**
 * Adds two embeddings element-wise
 * @throws If embeddings have different lengths
 */
export function addEmbeddings(a: Embedding, b: Embedding): Embedding {
  if (a.length !== b.length) throw new Error('Embeddings must have same length');
  return a.map((val, i) => val + b[i]);
}

/**
 * Subtracts second embedding from first element-wise
 * @throws If embeddings have different lengths
 */
export function subtractEmbeddings(a: Embedding, b: Embedding): Embedding {
  if (a.length !== b.length) throw new Error('Embeddings must have same length');
  return a.map((val, i) => val - b[i]);
}

/**
 * Scales an embedding by a scalar value
 */
export function scaleEmbedding(embedding: Embedding, scalar: number): Embedding {
  return embedding.map(val => val * scalar);
}

/**
 * Calculates mean embedding from array of embeddings
 * @throws If embeddings have different lengths
 */
export function getMeanEmbedding(embeddings: Embedding[]): Embedding {
  if (!embeddings.length) throw new Error('Cannot calculate mean of empty array');

  const firstLength = embeddings[0].length;
  if (!embeddings.every(e => e.length === firstLength)) {
    throw new Error('All embeddings must have same length');
  }

  const sum = embeddings.reduce((acc, curr) => addEmbeddings(acc, curr));
  return scaleEmbedding(sum, 1/embeddings.length);
}


/**
 * Calculates cosine similarity between embeddings (range: -1 to 1)
 * @throws If embeddings have different lengths
 */
export function getCosineSimilarity(a: Embedding, b: Embedding): number {
  if (a.length !== b.length) throw new Error('Embeddings must have same length');

  let dot = 0, magA = 0, magB = 0;
  for (let i = 0; i < a.length; i++) {
    dot += a[i] * b[i];
    magA += a[i] * a[i];
    magB += b[i] * b[i];
  }

  magA = Math.sqrt(magA);
  magB = Math.sqrt(magB);

  return magA && magB ? dot / (magA * magB) : 0;
}

/**
 * Calculates Euclidean distance between embeddings
 * @throws If embeddings have different lengths
 */
export function getEuclideanDistance(a: Embedding, b: Embedding): number {
  if (a.length !== b.length) throw new Error('Embeddings must have same length');

  let sum = 0;
  for (let i = 0; i < a.length; i++) {
    const diff = a[i] - b[i];
    sum += diff * diff;
  }
  return Math.sqrt(sum);
}


// Q:
//   what are other popular embedding functions to implement ?
//
// A:
//   Here are other common embedding distance / similarity functions worth implementing:
//
//     1. Manhattan Distance (L1 norm) - Sum of absolute differences
//     2. Dot Product - Simple inner product without normalization
//     3. Angular Distance - Derived from cosine similarity: arccos(cosine_similarity) / π
//     4. Jaccard Similarity - For binary embeddings
//     5. Hamming Distance - For binary/discrete embeddings
//
//   The first three are most commonly used with continuous embeddings like yours.

