

$ bun index.bench.ts
clk: ~3.02 GHz
cpu: Apple M1 Max
runtime: bun 1.1.34 (arm64-darwin)

| benchmark                      |             avg  |          min |        p75 |        p99 |        max
| ------------------------------ | ---------------- | ------------ | ---------- | ---------- | ----------
| unif rand embed (2-d)          |   26.39 ns/iter  |    22.48 ns  |   25.51 ns |   91.14 ns |  201.34 ns
| unif rand embed (3-d)          |   27.60 ns/iter  |    24.65 ns  |   26.80 ns |   87.22 ns |  112.94 ns
| unif rand embed (4-d)          |   30.47 ns/iter  |    26.59 ns  |   30.14 ns |   91.52 ns |  121.69 ns
| unif rand embed (128-d)        |  322.72 ns/iter  |   293.02 ns  |  339.58 ns |  401.45 ns |  425.40 ns
| unif rand embed (384-d)        |  904.92 ns/iter  |   828.08 ns  |  930.42 ns |  984.16 ns |  991.97 ns
| unif rand embed (768-d)        |    1.77 µs/iter  |     1.66 µs  |    1.81 µs |    1.88 µs |    1.88 µs
| unif rand embed (1024-d)       |    2.16 µs/iter  |     2.04 µs  |    2.19 µs |    2.37 µs |    2.38 µs
| unif rand embed (1536-d)       |    3.34 µs/iter  |     3.16 µs  |    3.39 µs |    3.46 µs |    3.47 µs

| benchmark                      |             avg  |          min |        p75 |        p99 |        max
| ------------------------------ | ---------------- | ------------ | ---------- | ---------- | ----------
| getCosineSimilarity(2-d)       |    3.84 ns/iter  |     3.68 ns  |    3.76 ns |    5.98 ns |   32.38 ns
| getCosineSimilarity(3-d)       |    4.34 ns/iter  |     4.19 ns  |    4.25 ns |    6.84 ns |   39.16 ns
| getCosineSimilarity(4-d)       |    4.85 ns/iter  |     4.62 ns  |    4.78 ns |    8.09 ns |   35.07 ns
| getCosineSimilarity(128-d)     |   98.84 ns/iter  |    95.51 ns  |  100.03 ns |  119.89 ns |  131.07 ns
| getCosineSimilarity(384-d)     |  350.07 ns/iter  |   332.60 ns  |  356.89 ns |  440.20 ns |  479.95 ns
| getCosineSimilarity(768-d)     |  719.44 ns/iter  |   689.74 ns  |  728.79 ns |  804.05 ns |  992.59 ns
| getCosineSimilarity(1024-d)    |    1.55 µs/iter  |   931.86 ns  |    1.19 µs |    6.05 µs |    6.13 µs
| getCosineSimilarity(1536-d)    |    1.49 µs/iter  |     1.43 µs  |    1.51 µs |    1.70 µs |    1.72 µs

| benchmark                      |             avg  |          min |        p75 |        p99 |        max
| ------------------------------ | ---------------- | ------------ | ---------- | ---------- | ----------
| getEuclideanDistance(2-d)      |    1.32 ns/iter  |     1.22 ns  |    1.29 ns |    3.54 ns |   30.02 ns
| getEuclideanDistance(3-d)      |    1.97 ns/iter  |     1.84 ns  |    1.92 ns |    4.68 ns |   34.97 ns
| getEuclideanDistance(4-d)      |    2.65 ns/iter  |     2.46 ns  |    2.58 ns |    5.86 ns |   63.35 ns
| getEuclideanDistance(128-d)    |  111.57 ns/iter  |    97.45 ns  |  107.25 ns |  419.85 ns |  637.13 ns
| getEuclideanDistance(384-d)    |  532.32 ns/iter  |   340.79 ns  |  620.50 ns |    1.59 µs |    1.93 µs
| getEuclideanDistance(768-d)    |  775.23 ns/iter  |   696.77 ns  |  754.22 ns |    1.26 µs |    1.29 µs
| getEuclideanDistance(1024-d)   |  987.56 ns/iter  |   937.74 ns  |    1.01 µs |    1.13 µs |    1.27 µs
| getEuclideanDistance(1536-d)   |    1.47 µs/iter  |     1.41 µs  |    1.49 µs |    1.58 µs |    1.61 µs



