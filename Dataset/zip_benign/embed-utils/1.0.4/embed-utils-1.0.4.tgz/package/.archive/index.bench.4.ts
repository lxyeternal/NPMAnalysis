import { run, bench, group, compact } from 'mitata';

const dimsToTest = [2, 3, 4, 128, 384, 768, 1024, 1536];

function uniformRandomEmbedding(dimension: number): number[] {
  return Array.from({ length: dimension }, () => Math.random() * 2 - 1);
}
function getCosineSimilarity(a: number[], b: number[]): number {
  let dotProduct = 0, magA = 0, magB = 0;
  for (let i = 0; i < a.length; i++) {
    dotProduct += a[i] * b[i];
    magA += a[i] * a[i];
    magB += b[i] * b[i];
  }
  magA = Math.sqrt(magA);
  magB = Math.sqrt(magB);
  if (magA === 0 || magB === 0) return 0;
  return dotProduct / (magA * magB);
}
function getEuclideanDistance(a: number[], b: number[]): number {
  let sumSquaredDifferences = 0;
  for (let i = 0; i < a.length; i++) {
    const diff = a[i] - b[i];
    sumSquaredDifferences += diff * diff;
  }
  return Math.sqrt(sumSquaredDifferences);
}

compact(() => {
  bench('unif rand embed ($dimension-d)', function* (state: { get: (key: string) => number }) {
    const dim = state.get('dimension');
    yield () => uniformRandomEmbedding(dim);
  }).args('dimension', dimsToTest);
});
compact(() => {
  bench('getCosineSimilarity($dimension-d)', function* (state: { get: (key: string) => number }) {
    const dim = state.get('dimension');
    const vecA = uniformRandomEmbedding(dim);
    const vecB = uniformRandomEmbedding(dim);
    yield () => getCosineSimilarity(vecA, vecB);
  }).args('dimension', dimsToTest);
});
compact(() => {
  bench('getEuclideanDistance($dimension-d)', function* (state: { get: (key: string) => number }) {
    const dim = state.get('dimension');
    const vecA = uniformRandomEmbedding(dim);
    const vecB = uniformRandomEmbedding(dim);
    yield () => getEuclideanDistance(vecA, vecB);
  }).args('dimension', dimsToTest);
});
await run({ throw: false, colors: true, format: 'mitata' });


group(() => {
  bench('unif rand embed ($dimension-d)', function* (state: { get: (key: string) => number }) {
    const dim = state.get('dimension');
    yield () => uniformRandomEmbedding(dim);
  }).args('dimension', dimsToTest);
});
group(() => {
  bench('getCosineSimilarity($dimension-d)', function* (state: { get: (key: string) => number }) {
    const dim = state.get('dimension');
    const vecA = uniformRandomEmbedding(dim);
    const vecB = uniformRandomEmbedding(dim);
    yield () => getCosineSimilarity(vecA, vecB);
  }).args('dimension', dimsToTest);
});
group(() => {
  bench('getEuclideanDistance($dimension-d)', function* (state: { get: (key: string) => number }) {
    const dim = state.get('dimension');
    const vecA = uniformRandomEmbedding(dim);
    const vecB = uniformRandomEmbedding(dim);
    yield () => getEuclideanDistance(vecA, vecB);
  }).args('dimension', dimsToTest);
});
await run({ throw: false, colors: true, format: 'mitata' });
