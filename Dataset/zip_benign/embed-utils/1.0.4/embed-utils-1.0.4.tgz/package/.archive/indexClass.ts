
type Embedding = number[];

/**
 * Represents an embedding vector with utility methods for common operations
 */
export class Embed {
  private values: Embedding;

  constructor(values: Embedding) {
    this.values = [...values]; // Copy to prevent external mutation
  }

  /**
   * Get raw embedding values
   */
  toArray(): Embedding {
    return [...this.values]; // Return copy to prevent mutation
  }

  /**
   * Calculates the squared magnitude (L2 norm) of the embedding
   */
  magnitudeSquared(): number {
    let sum = 0;
    for (const val of this.values) sum += val * val;
    return sum;
  }

  /**
   * Calculates the magnitude (L2 norm) of the embedding
   */
  magnitude(): number {
    return Math.sqrt(this.magnitudeSquared());
  }

  /**
   * Normalizes the embedding to unit length (L2 norm = 1) in-place
   */
  normalize(): Embed {
    const magnitude = this.magnitude();
    if (magnitude === 0) return this;
    this.values = this.values.map(val => val / magnitude);
    return this;
  }

  /**
   * Returns a normalized copy of the embedding (L2 norm = 1)
   */
  normalized(): Embed {
    const magnitude = this.magnitude();
    if (magnitude === 0) return new Embed(this.values);
    return new Embed(this.values.map(val => val / magnitude));
  }

  private throwIfDifferentLength(other: Embed): void {
    if (this.values.length !== other.values.length) {
      throw new Error('Embeddings must have same length');
    }
  }

  /**
   * Calculates dot product with another embedding
   * @throws If embeddings have different lengths
   */
  dot(other: Embed): number {
    this.throwIfDifferentLength(other);
    return this.values.reduce((sum, val, i) => sum + val * other.values[i], 0);
  }

  /**
   * Calculates Manhattan distance (L1 norm) to another embedding
   * @throws If embeddings have different lengths
   */
  manhattanDistance(other: Embed): number {
    this.throwIfDifferentLength(other);
    return this.values.reduce((sum, val, i) => sum + Math.abs(val - other.values[i]), 0);
  }

  /**
   * Calculates Lp norm of the embedding
   * @param p The order of the norm (p >= 1). Common values:
   *          p=1: Manhattan/Taxicab norm (L1)
   *          p=2: Euclidean norm (L2)
   *          p=∞: Maximum norm (use maxNorm() instead)
   * @throws If p < 1
   */
  lpNorm(p: number): number {
    if (p < 1) {
      throw new Error('p must be >= 1 for Lp norm');
    }
    return Math.pow(
      this.values.reduce((sum, val) =>
        sum + Math.pow(Math.abs(val), p)
      , 0),
      1/p
    );
  }

  /**
   * Calculates maximum norm (L∞ norm) of the embedding
   * This is equivalent to taking the limit of Lp norm as p approaches infinity
   * Also known as Chebyshev norm or supremum norm
   */
  maxNorm(): number {
    return Math.max(...this.values.map(Math.abs));
  }

  /**
   * Calculates Lp norm distance to another embedding
   * @param other The embedding to calculate distance to
   * @param p The order of the norm (p >= 1). Common values:
   *          p=1: Manhattan distance
   *          p=2: Euclidean distance
   *          p=∞: Chebyshev distance (use maxDistance() instead)
   * @throws If embeddings have different lengths or if p < 1
   */
  lpDistance(other: Embed, p: number): number {
    this.throwIfDifferentLength(other);
    if (p < 1) {
      throw new Error('p must be >= 1 for Lp norm');
    }
    return Math.pow(
      this.values.reduce((sum, val, i) =>
        sum + Math.pow(Math.abs(val - other.values[i]), p)
      , 0),
      1/p
    );
  }

  /**
   * Adds another embedding element-wise
   * @throws If embeddings have different lengths
   */
  add(other: Embed, inPlace = false): Embed {
    this.throwIfDifferentLength(other);
    if (inPlace) {
      this.values = this.values.map((val, i) => val + other.values[i]);
      return this;
    }
    return new Embed(this.values.map((val, i) => val + other.values[i]));
  }

  /**
   * Subtracts another embedding element-wise
   * @throws If embeddings have different lengths
   */
  subtract(other: Embed, inPlace = false): Embed {
    this.throwIfDifferentLength(other);
    if (inPlace) {
      this.values = this.values.map((val, i) => val - other.values[i]);
      return this;
    }
    return new Embed(this.values.map((val, i) => val - other.values[i]));
  }

  /**
   * Scales the embedding by a scalar value
   */
  scale(scalar: number, inPlace = false): Embed {
    if (inPlace) {
      this.values = this.values.map(val => val * scalar);
      return this;
    }
    return new Embed(this.values.map(val => val * scalar));
  }

  /**
   * Calculates cosine similarity with another embedding (range: -1 to 1)
   * @throws If embeddings have different lengths
   */
  cosineSimilarity(other: Embed): number {
    this.throwIfDifferentLength(other);
    const dot = this.dot(other);
    const magA = this.magnitude();
    const magB = other.magnitude();
    return magA && magB ? dot / (magA * magB) : 0;
  }

  /**
   * Calculates Euclidean distance to another embedding
   * @throws If embeddings have different lengths
   */
  euclideanDistance(other: Embed): number {
    this.throwIfDifferentLength(other);

    let sum = 0;
    for (let i = 0; i < this.values.length; i++) {
      const diff = this.values[i] - other.values[i];
      sum += diff * diff;
    }
    return Math.sqrt(sum);
  }

  /**
   * Calculates mean embedding from array of embeddings
   * @throws If embeddings have different lengths or array is empty
   */
  static mean(embeddings: Embed[]): Embed {
    if (!embeddings.length) {
      throw new Error('Cannot calculate mean of empty array');
    }

    const firstLength = embeddings[0].values.length;
    if (!embeddings.every(e => e.values.length === firstLength)) {
      throw new Error('All embeddings must have same length');
    }

    const sum = embeddings.reduce((acc, curr) => acc.add(curr));
    return sum.scale(1/embeddings.length);
  }
}
