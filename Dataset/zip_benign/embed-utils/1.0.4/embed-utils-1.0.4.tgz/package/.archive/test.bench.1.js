import { run, bench, group } from 'mitata';

// import { run, bench, group, compact, summary } from 'mitata';


var err = new Error();
bench("Error.captureStackTrace(err)", () => {
  Error.captureStackTrace(err);
});

bench("Error.prototype.stack", () => {
  new Error().stack;
});

await run();


// async function sleep(ms) {
//   return await new Promise(resolve => setTimeout(resolve, ms));
// }
//
// // summary(() => {
// //   bench('$n x sleep($ms)', async (state) => {
// //     const n = state.get('n');
// //     const ms = state.get('ms');
// //
// //     for (const _ of state) {
// //       for (let o = 0; o < n; o++) await sleep(ms);
// //     }
// //   }).args({ ms: [1], n: [10, 20] });
// // });
// // await run();
//
// group(() => {
//   bench('$n x sleep($ms)', async (state) => {
//     const n = state.get('n');
//     const ms = state.get('ms');
//
//     for (const _ of state) {
//       for (let o = 0; o < n; o++) await sleep(ms);
//     }
//   }).args({ ms: [1], n: [10, 20] });
// });
// await run();
//
// // compact(() => {
// //   bench('$n x sleep($ms)', function* (state) {
// //     const n = state.get('n');
// //     const ms = state.get('ms');
// //
// //     yield async () => {
// //       for (let o = 0; o < n; o++) await sleep(ms);
// //     };
// //   }).args('ms', [1]).args('n', [10, 20]);
// // });
// // await run();
//
// // const out = await run();
// // console.log(out);
