import { run, bench, group, compact, boxplot, summary, barplot, lineplot, B, measure } from 'mitata';
import { getCosineSimilarity, getEuclideanDistance, uniformRandomEmbedding, type Embedding } from "./index";

// Dimensions to test
const dimsToTest = [2, 3, 4, 128, 384, 768, 1024, 1536];
// const dimsToTest = [100, 200, 300, 400, 500, 600, 700, 800, 900, 1000];
// const dimsToTest = [1023, 1024, 1025];

// uniformRandomEmbedding
// console.log("Running with summary");
// summary(() => {
//   bench('uniformRandomEmbedding($dimension-d)', function* (state: { get: (key: string) => number }) {
//     const dim = state.get('dimension');
//     yield () => uniformRandomEmbedding(dim);
//   }).args('dimension', dimsToTest);
// });

// console.log("Running with boxplot");
// boxplot(() => {
//   bench('uniformRandomEmbedding($dimension-d)', function* (state: { get: (key: string) => number }) {
//     const dim = state.get('dimension');
//     yield () => uniformRandomEmbedding(dim);
//   }).args('dimension', dimsToTest);
// });

// console.log("Running with compact");
// compact(() => {
//   bench('uniformRandomEmbedding($dimension-d)', function* (state: { get: (key: string) => number }) {
//     const dim = state.get('dimension');
//     yield () => uniformRandomEmbedding(dim);
//   }).args('dimension', dimsToTest);
// });

// console.log("Running with group");
group(() => {
  bench('unif rand embed ($dimension-d)', function* (state: { get: (key: string) => number }) {
    const dim = state.get('dimension');
    yield () => uniformRandomEmbedding(dim);
  }).args('dimension', dimsToTest);
});

// console.log("Running with barplot");
// barplot(() => {
//   bench('uniformRandomEmbedding($dimension-d)', function* (state: { get: (key: string) => number }) {
//     const dim = state.get('dimension');
//     yield () => uniformRandomEmbedding(dim);
//   }).args('dimension', dimsToTest);
// });
//
// console.log("Running with lineplot");
// lineplot(() => {
//   bench('uniformRandomEmbedding($dimension-d)', function* (state: { get: (key: string) => number }) {
//     const dim = state.get('dimension');
//     yield () => uniformRandomEmbedding(dim);
//   }).args('dimension', dimsToTest);
// });

// // getCosineSimilarity
// summary(() => {
//   bench('getCosineSimilarity($dimension-d)', function* (state: { get: (key: string) => number }) {
//     const dim = state.get('dimension');
//     const vecA = uniformRandomEmbedding(dim);
//     const vecB = uniformRandomEmbedding(dim);
//     yield () => getCosineSimilarity(vecA, vecB);
//   }).args('dimension', dimsToTest);
// });
//
// // getEuclideanDistance
// summary(() => {
//   bench('getEuclideanDistance($dimension-d)', function* (state: { get: (key: string) => number }) {
//     const dim = state.get('dimension');
//     const vecA = uniformRandomEmbedding(dim);
//     const vecB = uniformRandomEmbedding(dim);
//     yield () => getEuclideanDistance(vecA, vecB);
//   }).args('dimension', dimsToTest);
// });

// Run benchmarks
await run({ throw: false, colors: true, format: 'mitata' });
