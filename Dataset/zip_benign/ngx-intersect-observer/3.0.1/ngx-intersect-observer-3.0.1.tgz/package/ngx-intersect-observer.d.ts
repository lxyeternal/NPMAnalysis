/**
 * Generated bundle index. Do not edit.
 */
export * from './public-api';
//# sourceMappingURL=ngx-intersect-observer.d.ts.map