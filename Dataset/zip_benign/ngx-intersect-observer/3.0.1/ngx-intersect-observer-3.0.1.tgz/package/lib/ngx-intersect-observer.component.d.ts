import { ElementRef, OnChanges, OnDestroy, OnInit, SimpleChanges } from '@angular/core';
export declare class NgxIntersectObserverComponent implements OnInit, OnChanges, OnDestroy {
    private elementRef;
    intersectionObserver: IntersectionObserver;
    intersectionCondition: boolean;
    actionOnIntersection: () => void;
    intersectionObserverInit: IntersectionObserverInit;
    constructor(elementRef: ElementRef);
    ngOnDestroy(): void;
    ngOnChanges(changes: SimpleChanges): void;
    ngOnInit(): void;
    private intersectionObserverCB;
    private monitorForIntersection;
    private observeIntersection;
}
//# sourceMappingURL=ngx-intersect-observer.component.d.ts.map