export declare class NgxIntersectObserverModule {
}
//# sourceMappingURL=ngx-intersect-observer.module.d.ts.map