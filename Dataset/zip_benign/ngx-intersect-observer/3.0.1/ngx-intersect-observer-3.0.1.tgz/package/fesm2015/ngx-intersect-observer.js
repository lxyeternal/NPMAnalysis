import { Component, ElementRef, Input, NgModule } from '@angular/core';

class NgxIntersectObserverComponent {
    constructor(elementRef) {
        this.elementRef = elementRef;
        this.intersectionCondition = true;
        this.actionOnIntersection = () => { };
        this.intersectionObserverInit = {
            threshold: 0.5,
        };
        this.intersectionObserverCB = (entries, _) => {
            entries.forEach(entry => {
                if (entry.isIntersecting && this.intersectionCondition) {
                    this.actionOnIntersection();
                }
            });
        };
    }
    ngOnDestroy() {
        var _a;
        (_a = this.intersectionObserver) === null || _a === void 0 ? void 0 : _a.disconnect();
    }
    ngOnChanges(changes) {
        this.monitorForIntersection();
    }
    ngOnInit() { }
    monitorForIntersection() {
        const intersectDiv = this.elementRef.nativeElement.querySelector('#intersect-div');
        if (intersectDiv) {
            this.observeIntersection(intersectDiv, this.intersectionObserverCB);
        }
    }
    observeIntersection(intersectDiv, callback) {
        this.intersectionObserver = new IntersectionObserver(callback, this.intersectionObserverInit);
        this.intersectionObserver.observe(intersectDiv);
    }
}
NgxIntersectObserverComponent.decorators = [
    { type: Component, args: [{
                selector: 'ngx-intersect-observer',
                template: `
    <div class="row"
      id="intersect-div">
    </div>

  `,
                styles: [`
      .row {
        width: 100%;
        height: 1px;
      }
    `]
            },] }
];
NgxIntersectObserverComponent.ctorParameters = () => [
    { type: ElementRef }
];
NgxIntersectObserverComponent.propDecorators = {
    intersectionCondition: [{ type: Input }],
    actionOnIntersection: [{ type: Input }],
    intersectionObserverInit: [{ type: Input }]
};

class NgxIntersectObserverModule {
}
NgxIntersectObserverModule.decorators = [
    { type: NgModule, args: [{
                declarations: [
                    NgxIntersectObserverComponent
                ],
                imports: [],
                exports: [
                    NgxIntersectObserverComponent
                ]
            },] }
];

/*
 * Public API Surface of ngx-intersect-observer
 */

/**
 * Generated bundle index. Do not edit.
 */

export { NgxIntersectObserverComponent, NgxIntersectObserverModule };
//# sourceMappingURL=ngx-intersect-observer.js.map
