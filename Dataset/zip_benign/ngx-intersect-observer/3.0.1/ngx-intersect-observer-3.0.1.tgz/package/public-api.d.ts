export * from './lib/ngx-intersect-observer.component';
export * from './lib/ngx-intersect-observer.module';
//# sourceMappingURL=public-api.d.ts.map