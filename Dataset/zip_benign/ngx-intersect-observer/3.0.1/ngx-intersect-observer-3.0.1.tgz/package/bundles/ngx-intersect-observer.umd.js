(function (global, factory) {
  typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/core')) :
  typeof define === 'function' && define.amd ? define('ngx-intersect-observer', ['exports', '@angular/core'], factory) :
  (global = typeof globalThis !== 'undefined' ? globalThis : global || self, factory(global['ngx-intersect-observer'] = {}, global.ng.core));
}(this, (function (exports, core) { 'use strict';

  var NgxIntersectObserverComponent = /** @class */ (function () {
      function NgxIntersectObserverComponent(elementRef) {
          var _this = this;
          this.elementRef = elementRef;
          this.intersectionCondition = true;
          this.actionOnIntersection = function () { };
          this.intersectionObserverInit = {
              threshold: 0.5,
          };
          this.intersectionObserverCB = function (entries, _) {
              entries.forEach(function (entry) {
                  if (entry.isIntersecting && _this.intersectionCondition) {
                      _this.actionOnIntersection();
                  }
              });
          };
      }
      NgxIntersectObserverComponent.prototype.ngOnDestroy = function () {
          var _a;
          (_a = this.intersectionObserver) === null || _a === void 0 ? void 0 : _a.disconnect();
      };
      NgxIntersectObserverComponent.prototype.ngOnChanges = function (changes) {
          this.monitorForIntersection();
      };
      NgxIntersectObserverComponent.prototype.ngOnInit = function () { };
      NgxIntersectObserverComponent.prototype.monitorForIntersection = function () {
          var intersectDiv = this.elementRef.nativeElement.querySelector('#intersect-div');
          if (intersectDiv) {
              this.observeIntersection(intersectDiv, this.intersectionObserverCB);
          }
      };
      NgxIntersectObserverComponent.prototype.observeIntersection = function (intersectDiv, callback) {
          this.intersectionObserver = new IntersectionObserver(callback, this.intersectionObserverInit);
          this.intersectionObserver.observe(intersectDiv);
      };
      return NgxIntersectObserverComponent;
  }());
  NgxIntersectObserverComponent.decorators = [
      { type: core.Component, args: [{
                  selector: 'ngx-intersect-observer',
                  template: "\n    <div class=\"row\"\n      id=\"intersect-div\">\n    </div>\n\n  ",
                  styles: ["\n      .row {\n        width: 100%;\n        height: 1px;\n      }\n    "]
              },] }
  ];
  NgxIntersectObserverComponent.ctorParameters = function () { return [
      { type: core.ElementRef }
  ]; };
  NgxIntersectObserverComponent.propDecorators = {
      intersectionCondition: [{ type: core.Input }],
      actionOnIntersection: [{ type: core.Input }],
      intersectionObserverInit: [{ type: core.Input }]
  };

  var NgxIntersectObserverModule = /** @class */ (function () {
      function NgxIntersectObserverModule() {
      }
      return NgxIntersectObserverModule;
  }());
  NgxIntersectObserverModule.decorators = [
      { type: core.NgModule, args: [{
                  declarations: [
                      NgxIntersectObserverComponent
                  ],
                  imports: [],
                  exports: [
                      NgxIntersectObserverComponent
                  ]
              },] }
  ];

  /*
   * Public API Surface of ngx-intersect-observer
   */

  /**
   * Generated bundle index. Do not edit.
   */

  exports.NgxIntersectObserverComponent = NgxIntersectObserverComponent;
  exports.NgxIntersectObserverModule = NgxIntersectObserverModule;

  Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=ngx-intersect-observer.umd.js.map
