"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const Mat_1 = require("./mat/Mat");
module.exports = Mat_1.mat;
