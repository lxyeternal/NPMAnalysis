import { ZodType } from "zod";
type ResultFn<Output, Input> = (value: Input) => Output;
declare class MatchBuilder<Input = unknown, Output = never> {
    protected cases: {
        schema: ZodType<any, any, any>;
        result: any;
    }[];
    case<CaseInput, CaseOutput>(schema: ZodType<CaseInput, any, any>, result: CaseOutput | ResultFn<CaseOutput, CaseInput>): this;
    returnType<T>(): EnforcedMatchBuilder<Input, T>;
    default(value: Output | ResultFn<Output, Input>): Matcher<Input, Output>;
    default<T>(value: T | ResultFn<T, Input>): Matcher<Input, T>;
}
declare class EnforcedMatchBuilder<Input, Output> extends MatchBuilder<Input, Output> {
    constructor(cases: {
        schema: ZodType<any, any, any>;
        result: any;
    }[]);
    case<CaseInput>(schema: ZodType<CaseInput, any, any>, result: Output): this;
    case<CaseInput>(schema: ZodType<CaseInput, any, any>, result: ResultFn<Output, CaseInput>): this;
}
export declare class Matcher<Input = unknown, Output = never> {
    private cases;
    private defaultValue;
    constructor(cases: {
        schema: ZodType<any, any, any>;
        result: any;
    }[], defaultValue: Output | ResultFn<Output, Input>);
    match(value: Input): Output;
}
export declare function pattern<T = never>(): MatchBuilder<unknown, T>;
export {};
