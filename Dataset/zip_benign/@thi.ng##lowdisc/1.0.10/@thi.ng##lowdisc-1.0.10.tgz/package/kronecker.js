import { lowDiscrepancy } from "./lowdisc.js";
const __fract = (x) => x - Math.floor(x);
function* kronecker(alpha, start = 0) {
  while (true) yield start = __fract(start + alpha);
}
const kroneckerND = (alphas, offset = 0) => lowDiscrepancy(alphas.map(kronecker), offset);
export {
  kronecker,
  kroneckerND
};
