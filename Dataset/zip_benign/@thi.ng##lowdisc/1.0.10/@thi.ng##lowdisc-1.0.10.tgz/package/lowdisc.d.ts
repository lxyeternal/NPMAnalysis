/**
 * General purpose iterator yielding n-dimensional sequence values obtained from
 * given per-dimension sequence generators. Omits `offset` (default: 0) initial
 * values.
 *
 * @remarks
 * This function acts as shared impl for all other sequence generators in this
 * package.
 *
 * @param dims -
 * @param offset -
 */
export declare const lowDiscrepancy: (dims: Iterator<number>[], offset?: number) => Generator<number[], never, unknown>;
//# sourceMappingURL=lowdisc.d.ts.map