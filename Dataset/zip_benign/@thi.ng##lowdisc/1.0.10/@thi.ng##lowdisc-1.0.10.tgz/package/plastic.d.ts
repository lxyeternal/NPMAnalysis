/**
 * Computes the `d`-th Harmonious number, with:
 *
 * - d=1 PHI (Golden ratio)
 * - d=2 PLASTIC (Plastic number)
 *
 * @remarks
 * See {@link plasticND} for references.
 *
 * @param d -
 * @param i -
 */
export declare const phi: (d: number, i?: number) => number;
/**
 * Additive Recurrence R2 sequence using n-dimensional {@link kronecker}
 * configured with Harmonious Numbers (based on Plastic number).
 *
 * @remarks
 * References:
 *
 * - http://extremelearning.com.au/unreasonable-effectiveness-of-quasirandom-sequences/
 * - https://en.wikipedia.org/wiki/Plastic_number
 * - https://bib.irb.hr/datoteka/628836.Plastic_Number_-_Construct.pdf
 *
 * @param dim -
 */
export declare const plasticND: (dim: number, offset?: number) => Generator<number[], never, unknown>;
//# sourceMappingURL=plastic.d.ts.map