import { assert } from "@thi.ng/errors/assert";
import { kronecker } from "./kronecker.js";
import { lowDiscrepancy } from "./lowdisc.js";
const phi = (d, i = 18) => {
  assert(d > 0, `d must be > 0`);
  d = 1 / (d + 1);
  let x = 2;
  while (i-- > 0) x = (1 + x) ** d;
  return x;
};
const plasticND = (dim, offset = 0) => {
  const g = phi(dim);
  return lowDiscrepancy(
    new Array(dim).fill(0).map((_, i) => kronecker(1 / Math.pow(g, i + 1), 0.5)),
    offset
  );
};
export {
  phi,
  plasticND
};
