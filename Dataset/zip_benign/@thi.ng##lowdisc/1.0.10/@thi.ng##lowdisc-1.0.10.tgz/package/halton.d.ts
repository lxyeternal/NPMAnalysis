/**
 * Iterator yielding 1D Halton sequence for given `base` (preferably a prime).
 *
 * @remarks
 * Ported from Python version at: https://en.wikipedia.org/wiki/Halton_sequence
 *
 * @param base -
 */
export declare function halton(base: number): Generator<number, void, unknown>;
/**
 * n-dimensional version of {@link halton}. Takes a vector of `bases` (one per
 * dimension) and yields iterator of nD points. If `offset` > 0, the stated
 * number of initial iterations will be skipped.
 *
 * @param bases -
 * @param offset -
 */
export declare const haltonND: (bases: number[], offset?: number) => Generator<number[], never, unknown>;
//# sourceMappingURL=halton.d.ts.map