import { assert } from "@thi.ng/errors/assert";
const lowDiscrepancy = (dims, offset = 0) => {
  const num = dims.length;
  assert(num > 0, `invalid dimensions`);
  const [x, y, z] = dims;
  const iter = num === 1 ? function* () {
    while (true) yield [x.next().value];
  }() : num === 2 ? function* () {
    while (true)
      yield [x.next().value, y.next().value];
  }() : num === 3 ? function* () {
    while (true)
      yield [
        x.next().value,
        y.next().value,
        z.next().value
      ];
  }() : function* () {
    while (true) yield dims.map((d) => d.next().value);
  }();
  for (; offset-- > 0; ) iter.next();
  return iter;
};
export {
  lowDiscrepancy
};
