import { lowDiscrepancy } from "./lowdisc.js";
function* halton(base) {
  let n = 0;
  let d = 1;
  let invB = 1 / base;
  while (true) {
    let x = d - n;
    if (x === 1) {
      n = 1;
      d *= base;
    } else {
      let y = d * invB | 0;
      while (x <= y) {
        y = y * invB | 0;
      }
      n = (base + 1) * y - x;
    }
    yield n / d;
  }
}
const haltonND = (bases, offset = 0) => lowDiscrepancy(bases.map(halton), offset);
export {
  halton,
  haltonND
};
