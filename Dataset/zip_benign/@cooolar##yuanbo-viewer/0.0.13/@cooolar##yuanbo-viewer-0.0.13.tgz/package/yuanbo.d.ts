/**
 * 元播模型查看器
 */
declare class YuanboViewer {
	/** 容器 */
	private _container: HTMLElement | null;
	/** sku控制器 */
	private controller?: any;

	/** 获取到配置回调 */
	onConfig: (_config: any) => void;
	/** 加载进度回调 */
	onLoading: (_v: number) => void;
	/** 加载错误回调 */
	onError: (_err: string) => void;

	/** 私有化部署API路径 */
	skuApiUrl?: string;
	/** 调试模式 */
	debug: boolean;

	/**
	 * 元播模型查看器
	 * @param options
	 */
	constructor(options?: {
		/** 节点ID或DOM元素，用于挂载预览器内容元素 */
		container?: string | HTMLElement;
		/** SKU ID */
		skuId?: string;
		/** 模型大小比例，值越大模型越小，默认值: 1 */
		modelScalar?: number;
		/** 调试模式 */
		debug?: boolean;
		/** 私有化部署API路径 */
		skuApiUrl?: string;
		/** 获取到配置回调 */
		onConfig?: (_config: any) => void;
		/** 加载进度回调 */
		onLoading?: (v: number) => void;
		/** 加载错误回调 */
		onError?: (err: string) => void;
	});

	/**
	 * 初始化SKU
	 * @param skuId 产品ID
	 * @param options 参数
	 */
	initSKU(
		skuId?: string,
		options?: {
			/** 获取到配置回调 */
			onConfig?: (_config: any) => void;
			/** 加载进度回调 */
			onLoading?: (v: number) => void;
			/** 加载错误回调 */
			onError?: (err: string) => void;
		}
	): Promise<void>;

	/**
	 * 设置挂载节点
	 * @param container 节点ID或DOM元素，用于挂载预览器内容元素
	 */
	setContainer(container: string | HTMLElement): void;

	/**
	 * 控制渲染开始与停止
	 * @param enable true开始 | false停止
	 */
	setRendering(enable: boolean): void;

	/** 尺寸动画是否播放中 */
	private enableSizeAnimation: boolean;

	/**
	 * 调用尺寸动画
	 * @param enable 可选，true开启 | false关闭 尺寸动画，默认为当前状态取反
	 */
	playSizeAnimation(enable?: boolean): Promise<void>;

	/** 安装尺寸动画是否播放中 */
	private enableInstallSizeAnimation: boolean;

	/**
	 * 调用安装尺寸动画
	 * @param enable 可选，true开启 | false关闭 安装尺寸动画，默认为当前状态取反
	 */
	playInstallSizeAnimation(enable?: boolean): Promise<void>;

	/**
	 * 重置状态
	 */
	reset(): void;

	/**
	 * 资源释放
	 */
	dispose(): void;
}

export { YuanboViewer };
