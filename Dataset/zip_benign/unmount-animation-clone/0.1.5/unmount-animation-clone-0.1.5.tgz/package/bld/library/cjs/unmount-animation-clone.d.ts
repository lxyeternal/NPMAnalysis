import type { CSSProperties, FunctionComponent, ReactElement } from 'react';
export interface UnmountAnimationCloneProps {
    /**
     * Class name that adds to the DOM element clone for unmount animation.
     */
    className?: string;
    /**
     * Style that adds to the DOM element clone for unmount animation.
     */
    style?: CSSProperties;
    transitionClassName?: string;
    transitionStyle?: CSSProperties;
    /**
     * Do not remove the DOM element clone after animation (might be useful for
     * debugging).
     */
    persist?: boolean;
    onUnmountClone?(clone: HTMLElement): void;
    onUnmountRemove?(): void;
    children: ReactElement;
}
export declare const UnmountAnimationClone: FunctionComponent<UnmountAnimationCloneProps>;
