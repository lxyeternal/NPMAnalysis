# Browserslists config for modern browsers

> Reuse a list of modern browsers to target accross multiple projects

```
# Browsers that we support

>= 0.5% 
not ie 11
not op_mini all
not dead
```

## Tools target

### [Autoprefixer](https://github.com/postcss/autoprefixer)
Parse CSS and add vendor prefixes to rules by Can I Use

### [postcss-preset-env](https://github.com/csstools/postcss-preset-env)
Convert modern CSS into something browsers understand

### [@babel/preset-env](https://github.com/babel/babel/tree/master/packages/babel-preset-env)
allows you to use the latest JavaScript without needing to micromanage which syntax transforms (and optionally, browser polyfills)


## Built with

* [Browserslist](https://github.com/browserslist/browserslist)
* [https://browserl.ist/](https://browserl.ist/)

