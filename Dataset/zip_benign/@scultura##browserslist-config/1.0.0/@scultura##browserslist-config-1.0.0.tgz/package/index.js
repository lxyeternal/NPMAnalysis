'use strict';

module.exports = [
  '>= 0.5%', 
  'not ie 11', 
  'not op_mini all',
  'not dead'
];