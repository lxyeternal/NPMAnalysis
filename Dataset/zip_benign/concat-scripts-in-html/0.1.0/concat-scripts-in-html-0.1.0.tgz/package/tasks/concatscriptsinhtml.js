/**
 * @description concat-scripts-in-html
 * @see http://gruntjs.com/
 * @author yuhao@taobao
 * @license Licensed under the MIT license.
 **/

'use strict';

module.exports = function(grunt) {

    function checkFilesExists(filepath, options) {
        console.warn(filepath, options);
        if (!grunt.file.exists(filepath)) {
            return false;
        }
        grunt.log.write('start scan..');

        // Only delete cwd or outside cwd if --force enabled. Be careful, people!
        if (!options.force) {
            if (grunt.file.isPathCwd(filepath)) {
                grunt.verbose.error();
                grunt.fail.warn('Cannot delete the current working directory.');
                return false;
            } else if (!grunt.file.isPathInCwd(filepath)) {
                grunt.verbose.error();
                grunt.fail.warn('Cannot delete files outside the current working directory.');
                return false;
            }
        }

    }

    grunt.registerMultiTask('concatscriptsinhtml', 'concat scripts tag in html', function() {
        var options = this.options({
            force: grunt.option('force') === true,
            'no-write': grunt.option('no-write') === true,
        });

        grunt.verbose.writeflags(options, 'Options');

        this.filesSrc.forEach(function(filepath) {
            checkFilesExists(filepath, options);
        });
    });

};
