var END, SPLIT;

SPLIT = new Set('[](),> ');

END = ',]>)';

export default (prompt, gen) => {
  var i, is_lora, j, len1, n, p, push, r, t;
  if (!prompt) {
    return '';
  }
  r = [];
  t = [];
  push = () => {
    var len, s, slen, space_begin, space_end;
    if (t.length) {
      s = t.join('');
      len = s.length;
      s = s.trimStart();
      slen = s.length;
      space_begin = len - slen;
      s = s.trimEnd();
      space_end = slen - s.length;
      r.push(''.padEnd(space_begin) + gen(s) + ''.padEnd(space_end));
    }
    t = [];
  };
  for (p = j = 0, len1 = prompt.length; j < len1; p = ++j) {
    i = prompt[p];
    if (SPLIT.has(i)) {
      is_lora = i === '>';
      if (is_lora) {
        t.push(i);
      }
      push();
      if (!is_lora) {
        r.push(i);
      }
      if (END.includes(i)) {
        n = prompt[p + 1];
        if (n) {
          if (i === ',') {
            if (n !== ' ') {
              r.push(' ');
            }
          } else if (!END.includes(n)) {
            r.push(' ');
          }
        }
      }
    } else {
      t.push(i);
    }
  }
  push();
  return r.join('');
};
