#!/usr/bin/env -S node --loader=@w5/jsext --trace-uncaught --expose-gc --unhandled-rejections=strict --experimental-import-meta-resolve
import sdToken from './index.js';

import escape from '@w5/escape';

export default (txt, lora, embed) => {
  return sdToken(txt, (s) => {
    var auto_a, escaped, li;
    escaped = false;
    auto_a = (m, t) => {
      var url;
      url = m.get(t) || m.get(t.toLocaleLowerCase());
      if (url) {
        escaped = true;
        s = `<a href="${url}">${escape(s)}</a>`;
      }
    };
    if (s.startsWith('<')) {
      li = s.split(':');
      if (li.length > 1) {
        auto_a(lora, li[1]);
      } else {
        auto_a(embed, li[0].slice(1).replaceAll('>', '').trim());
      }
    } else {
      auto_a(embed, s);
    }
    if (false === escaped) {
      s = escape(s);
    }
    return s;
  });
};
