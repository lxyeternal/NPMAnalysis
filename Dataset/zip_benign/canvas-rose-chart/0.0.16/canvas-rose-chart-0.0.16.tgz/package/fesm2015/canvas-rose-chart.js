/**
 * @fileoverview added by tsickle
 * Generated from: lib/chart/chart.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/** @type {?} */
const defaultSerialConfig = {
    showIndicate: true,
    thickness: 40,
    indicatorPercent: 0.5,
    indicatorOffset: 0,
    indicatorLength: 40,
    indicatorOffsetAngle: 0
};
class RoseChart {
    /**
     * @param {?} opt
     */
    constructor(opt) {
        this.animationStep = 0.6;
        this.devicePixelRatio = 1;
        this.currentSelected = -1;
        this.initAngle = -Math.PI / 2;
        this.defaultOffset = true;
        this.option = opt;
    }
    /**
     * @return {?}
     */
    init() {
        this.initParams();
        this.create();
    }
    /**
     * @param {?=} op
     * @return {?}
     */
    update(op) {
        if (op) {
            this.option = op;
        }
        this.containerDom.innerHTML = '';
        this.init();
    }
    /**
     * @return {?}
     */
    initParams() {
        this.prodOption = JSON.parse(JSON.stringify(this.option));
        if (this.prodOption.hasOwnProperty('initAngle')) {
            this.initAngle = this.prodOption.initAngle;
        }
        if (this.prodOption.hasOwnProperty('defaultOffset')) {
            this.defaultOffset = this.prodOption.defaultOffset;
        }
        this.parentDom = document.getElementById(this.prodOption.id);
        if (!this.containerDom) {
            this.containerDom = document.createElement('div');
            this.containerDom.style.cssText += `position:relative;display:inline-block`;
        }
        /** @type {?} */
        const width = this.parentDom.offsetWidth;
        /** @type {?} */
        const height = this.parentDom.offsetHeight;
        this.width = width;
        this.height = height;
        this.can = document.createElement('canvas');
        this.containerDom.style.cssText += `width: ${width}px;height:${height}px;`;
        this.can.style.cssText += `width:${width}px;height:${height}px;`;
        this.can.width = width;
        this.can.height = height;
        this.centerX = width / 2;
        this.centerY = height / 2;
        this.pen = this.can.getContext('2d');
        this.minRadius = this.prodOption.radius[0];
        this.maxRadius = this.prodOption.radius[1];
        this.containerDom.appendChild(this.can);
        this.parentDom.appendChild(this.containerDom);
        if (this.maxRadius) {
            this.radiusGap = this.maxRadius - this.minRadius;
        }
    }
    /**
     * @return {?}
     */
    create() {
        this.calculateRadius();
        if (window.devicePixelRatio) {
            /** @type {?} */
            const ratio = window.devicePixelRatio;
            this.devicePixelRatio = ratio;
            this.can.height = this.height * ratio;
            this.can.width = this.width * ratio;
            this.pen.scale(ratio, ratio);
        }
        this.initDraw();
        this.drawHtml();
        this.addMoveHandler();
        this.addResizeHandler();
    }
    /**
     * @return {?}
     */
    destroy() {
        this.can.removeEventListener('mousemove', this.mouseMoveHandler.bind(this), false);
        if (this.prodOption.triggerType && this.prodOption.triggerType === 'click') {
            this.can.removeEventListener('click', this.clickOrMouseoverHandler.bind(this), false);
        }
        window.removeEventListener('resize', this.resizeHandler.bind(this), false);
        this.parentDom.removeChild(this.containerDom);
    }
    // calculate angle
    /**
     * @return {?}
     */
    calculateRadius() {
        /** @type {?} */
        const series = this.prodOption.series;
        /** @type {?} */
        const arr = [];
        /** @type {?} */
        const thickness = [];
        /** @type {?} */
        let total = 0;
        series.map((/**
         * @param {?} item
         * @return {?}
         */
        item => {
            total += item.value;
            arr.push(item.value);
            if (item.thickness) {
                thickness.push(item.thickness);
            }
        }));
        /** @type {?} */
        const maxVal = Math.max.apply(null, arr);
        if (thickness.length > 0) {
            /** @type {?} */
            const maxThickness = Math.max.apply(null, thickness);
            this.maxRadius = maxThickness + this.minRadius;
        }
        for (let i = 0, len = series.length; i < len; i++) {
            series[i] = Object.assign({}, defaultSerialConfig, series[i]);
            series[i].angleScope = (Math.PI * 2 * series[i].value) / total;
            if (i > 0) {
                series[i].startAngle = series[i - 1].endAngle;
            }
            else {
                series[i].startAngle = this.initAngle;
            }
            if (series[i].startAngle > Math.PI) {
                series[i].startAngle = series[i].startAngle - Math.PI * 2;
            }
            if (this.radiusGap) {
                series[i].radius =
                    this.minRadius + (this.radiusGap * series[i].value) / maxVal;
            }
            else {
                series[i].radius = this.minRadius + series[i].thickness;
            }
            if (i > 0) {
                series[i].endAngle = series[i - 1].endAngle + series[i].angleScope;
                series[i].indicatorAngle = series[i - 1].endAngle + series[i].angleScope * series[i].indicatorPercent;
            }
            else {
                series[i].endAngle = series[i].angleScope + this.initAngle;
                series[i].indicatorAngle = series[i].angleScope * series[i].indicatorPercent + this.initAngle;
            }
            if (series[i].endAngle > Math.PI && series.length > 1) {
                series[i].endAngle = series[i].endAngle - Math.PI * 2;
            }
            if (series[i].indicatorAngle > Math.PI && series.length > 1) {
                series[i].indicatorAngle = series[i].indicatorAngle - Math.PI * 2;
            }
            series[i].indicatorPointX1 =
                (series[i].radius + series[i].indicatorOffset) *
                    Math.cos(series[i].indicatorAngle) +
                    this.centerX;
            series[i].indicatorPointY1 =
                (series[i].radius + series[i].indicatorOffset) *
                    Math.sin(series[i].indicatorAngle) +
                    this.centerY;
            series[i].indicatorPointX2 =
                series[i].indicatorLength * Math.cos(series[i].indicatorAngle) +
                    series[i].indicatorPointX1;
            series[i].indicatorPointY2 =
                series[i].indicatorLength * Math.sin(series[i].indicatorAngle) +
                    series[i].indicatorPointY1;
            // custom offsetAngle
            /** @type {?} */
            const indicatorAngle = series[i].indicatorAngle;
            if (series[i].indicatorOffsetAngle) {
                if (series[i].indicatorOffsetAngle <= -Math.PI / 2) {
                    series[i].indicatorOffsetAngle = -Math.PI / 2;
                }
                if (series[i].indicatorOffsetAngle >= Math.PI / 2) {
                    series[i].indicatorOffsetAngle = Math.PI / 2;
                }
                /** @type {?} */
                const finalAngle = indicatorAngle + series[i].indicatorOffsetAngle;
                series[i].indicatorPointY2 = series[i].indicatorPointY1 + series[i].indicatorLength * Math.sin(finalAngle);
                series[i].indicatorPointX2 = series[i].indicatorPointX1 + series[i].indicatorLength * Math.cos(finalAngle);
            }
        }
        this.series = series;
    }
    /**
     * @param {?} drawEntity
     * @param {?=} isMask
     * @param {?=} fadeIn
     * @return {?}
     */
    draw(drawEntity, isMask, fadeIn) {
        this.pen.beginPath();
        this.pen.fillStyle = drawEntity.color;
        if (fadeIn && drawEntity.highLightColor) {
            this.pen.fillStyle = drawEntity.highLightColor;
        }
        this.pen.moveTo(this.centerX, this.centerY);
        this.pen.arc(this.centerX, this.centerY, drawEntity.radius, drawEntity.startAngle, drawEntity.endAngle);
        this.pen.fill();
        this.pen.closePath();
        if (drawEntity.indicatorPointX1 && drawEntity.showIndicate && !isMask) {
            this.pen.beginPath();
            this.pen.strokeStyle = drawEntity.color;
            if (fadeIn && drawEntity.highLightColor) {
                this.pen.strokeStyle = drawEntity.highLightColor;
            }
            this.pen.moveTo(drawEntity.indicatorPointX1, drawEntity.indicatorPointY1);
            this.pen.lineWidth = 1;
            this.pen.lineTo(drawEntity.indicatorPointX2, drawEntity.indicatorPointY2);
            this.pen.stroke();
            this.pen.closePath();
        }
        this.pen.save();
    }
    /**
     * @return {?}
     */
    drawMask() {
        this.draw({
            color: '#fff',
            highLightColor: '#fff',
            startAngle: 0,
            endAngle: Math.PI * 2,
            radius: this.minRadius,
            value: 100
        }, true);
    }
    /**
     * @return {?}
     */
    drawHtml() {
        if (this.prodOption.circleTxt) {
            /** @type {?} */
            const inner = document.createElement('div');
            inner.style.cssText += `position:absolute;top:${this.centerY}px;left:${this.centerX}px;
      transform:translate(-50%, -50%);z-index: 10;`;
            inner.innerHTML = this.prodOption.circleTxt;
            this.containerDom.appendChild(inner);
        }
        for (const item of this.series) {
            if (item.indicateTxt) {
                /** @type {?} */
                const tooltipDiv = document.createElement('div');
                tooltipDiv.style.cssText += `position:absolute;top:${item.indicatorPointY2}px;`;
                if (item.indicatorPointX2 > this.centerX) {
                    if (this.defaultOffset) {
                        tooltipDiv.style.cssText += `left:${item.indicatorPointX2 + 10 + (item.indicateOffsetX || 0)}px;`;
                    }
                    else {
                        tooltipDiv.style.cssText += `left:${item.indicatorPointX2 + (item.indicateOffsetX || 0)}px;`;
                    }
                }
                else {
                    if (this.defaultOffset) {
                        tooltipDiv.style.cssText += `right:${this.width -
                            item.indicatorPointX2 + 10 - (item.indicateOffsetX || 0)}px;`;
                    }
                    else {
                        tooltipDiv.style.cssText += `right:${this.width -
                            item.indicatorPointX2 - (item.indicateOffsetX || 0)}px;`;
                    }
                }
                if (item.indicatorPointY2 < this.centerY) {
                    if (this.defaultOffset) {
                        tooltipDiv.style.cssText += `top:${item.indicatorPointY2 - 10 + (item.indicateOffsetY || 0)}px;`;
                    }
                    else {
                        tooltipDiv.style.cssText += `top:${item.indicatorPointY2 + (item.indicateOffsetY || 0)}px;`;
                    }
                }
                else {
                    if (this.defaultOffset) {
                        tooltipDiv.style.cssText += `top:${item.indicatorPointY2 - 8 + (item.indicateOffsetY || 0)}px;`;
                    }
                    else {
                        tooltipDiv.style.cssText += `top:${item.indicatorPointY2 + (item.indicateOffsetY || 0)}px;`;
                    }
                }
                tooltipDiv.innerHTML = item.indicateTxt;
                this.containerDom.appendChild(tooltipDiv);
            }
        }
    }
    /**
     * @return {?}
     */
    initDraw() {
        this.pen.clearRect(0, 0, this.width, this.height);
        for (const item of this.series) {
            this.draw(item);
        }
        this.drawMask();
    }
    /**
     * @return {?}
     */
    addMoveHandler() {
        this.can.addEventListener('mousemove', this.mouseMoveHandler.bind(this), false);
        this.hoverScale = this.prodOption.hoverScale ? (this.prodOption.hoverScale < 1 ? 1 : this.prodOption.hoverScale) : 1;
        if (this.prodOption.triggerType && this.prodOption.triggerType === 'click') {
            this.can.addEventListener('click', this.clickOrMouseoverHandler.bind(this), false);
        }
    }
    /**
     * @return {?}
     */
    addResizeHandler() {
        window.addEventListener('resize', this.resizeHandler.bind(this), false);
    }
    /**
     * @return {?}
     */
    resizeHandler() {
        /** @type {?} */
        const width = this.parentDom.offsetWidth;
        /** @type {?} */
        const height = this.parentDom.offsetHeight;
        if (this.width !== width || this.height !== height) {
            this.update();
        }
    }
    /**
     * @param {?} e
     * @return {?}
     */
    mouseMoveHandler(e) {
        /** @type {?} */
        const x = e.clientX - this.can.getBoundingClientRect().left;
        /** @type {?} */
        const y = e.clientY - this.can.getBoundingClientRect().top;
        /** @type {?} */
        const result = this.isInPath(x, y);
        if (result) {
            this.inCircle = true;
            this.activeItem = result;
            this.can.style.cursor = 'pointer';
        }
        else {
            this.can.style.cursor = 'default';
            this.inCircle = false;
        }
        if (this.prodOption.triggerType && this.prodOption.triggerType === 'hover') {
            this.clickOrMouseoverHandler();
        }
    }
    /**
     * @return {?}
     */
    clickOrMouseoverHandler() {
        if (this.inCircle) {
            this.handleMoveIn(this.activeItem.item, this.activeItem.index);
            return;
        }
        if (this.currentSelected !== -1) {
            this.handleFadeOut();
            this.currentSelected = -1;
        }
    }
    /**
     * @param {?} x1
     * @param {?} x2
     * @param {?} y1
     * @param {?} y2
     * @return {?}
     */
    getDistance(x1, x2, y1, y2) {
        return Math.sqrt(Math.pow(Math.abs(x1 - x2), 2) + Math.pow(Math.abs(y1 - y2), 2));
    }
    /**
     * @param {?} x
     * @param {?} y
     * @param {?} obj
     * @return {?}
     */
    getClosePoint(x, y, obj) {
        /** @type {?} */
        const dis1 = Math.sqrt(Math.pow(Math.abs(obj.x1 - x), 2) + Math.pow(Math.abs(obj.y1 - y), 2));
        /** @type {?} */
        const dis2 = Math.sqrt(Math.pow(Math.abs(obj.x2 - x), 2) + Math.pow(Math.abs(obj.y2 - y), 2));
        return dis1 >= dis2 ? { x: obj.x2, y: obj.y2 } : { x: obj.x1, y: obj.y1 };
    }
    /**
     * @param {?} x
     * @param {?} y
     * @return {?}
     */
    isInPath(x, y) {
        /** @type {?} */
        const centerX = this.centerX;
        /** @type {?} */
        const centerY = this.centerY;
        /** @type {?} */
        const distance = this.getDistance(centerX, x, centerY, y);
        if (distance >= this.minRadius && distance <= this.maxRadius) {
            if (this.series.length > 1) {
                /** @type {?} */
                const point = this.getClosePoint(x, y, this.lineEquation(this.centerX, this.centerY, x, y));
                /** @type {?} */
                let negativeSymbol = 1;
                if (point.y < this.centerY) {
                    negativeSymbol = -1;
                }
                /** @type {?} */
                const angle = negativeSymbol * Math.acos((point.x - this.centerX) / this.minRadius);
                for (let i = 0, len = this.series.length; i < len; i++) {
                    /** @type {?} */
                    const item = this.series[i];
                    if (((item.startAngle >= 0 && item.endAngle >= 0) ||
                        (item.startAngle <= 0 && item.endAngle <= 0)) &&
                        item.angleScope <= Math.PI) {
                        if (angle >= item.startAngle && angle <= item.endAngle) {
                            return { item, index: i };
                        }
                    }
                    else if (item.startAngle <= 0 && item.endAngle >= 0) {
                        if (angle >= item.startAngle && angle <= item.endAngle) {
                            return { item, index: i };
                        }
                    }
                    else if (item.startAngle >= 0 && item.endAngle <= 0) {
                        if (angle <= 0 && angle <= item.endAngle) {
                            return { item, index: i };
                        }
                        else if (angle >= 0 && angle >= item.startAngle) {
                            return { item, index: i };
                        }
                    }
                    else if (((item.startAngle <= 0 && item.endAngle <= 0) ||
                        (item.startAngle >= 0 && item.endAngle >= 0)) &&
                        item.angleScope >= (Math.PI * 3) / 2) {
                        if (!(item.endAngle <= angle && item.startAngle >= angle)) {
                            return { item, index: i };
                        }
                    }
                }
            }
            else {
                return { item: this.series[0], index: 0 };
            }
        }
    }
    /**
     * @return {?}
     */
    handleFadeOut() {
        /** @type {?} */
        const prevSelected = this.series[this.currentSelected];
        /** @type {?} */
        const r = prevSelected.radius;
        /** @type {?} */
        let maxR = r * this.hoverScale;
        /** @type {?} */
        let step = 1;
        /**
         * @return {?}
         */
        function renderOut() {
            if (this.hoverScale > 1) {
                if (maxR > prevSelected.radius) {
                    step += this.animationStep;
                    maxR -= this.velocityCurve(step, 1);
                    this.drawOnce(Object.assign({}, prevSelected, { radius: maxR }), this.currentSelected, true);
                    this.drawMask();
                    if (maxR <= prevSelected.radius) {
                        this.drawOnce(prevSelected, this.currentSelected, true);
                        this.drawMask();
                    }
                    requestAnimationFrame(renderOut.bind(this));
                }
            }
            else {
                this.drawOnce(prevSelected, this.currentSelected);
                this.drawMask();
            }
        }
        renderOut.call(this);
    }
    /**
     * mouse click a specific target
     * @param {?} item -SingleSerial
     * @param {?} index -index
     * @return {?}
     */
    handleMoveIn(item, index) {
        if (this.currentSelected === index) {
            return;
        }
        /** @type {?} */
        let i = item.radius;
        /** @type {?} */
        let step = 1;
        /** @type {?} */
        let r = 0;
        /** @type {?} */
        let maxR = 0;
        /** @type {?} */
        let prevSelected = null;
        if (this.currentSelected !== -1) {
            prevSelected = this.series[this.currentSelected];
            r = prevSelected.radius;
            maxR = r * this.hoverScale;
        }
        /**
         * @return {?}
         */
        function render() {
            if (i < item.radius * this.hoverScale && this.hoverScale > 1) {
                step += this.animationStep;
                i += this.velocityCurve(step, 1);
                maxR -= this.velocityCurve(step, 1);
                this.drawOnce(Object.assign({}, item, { radius: i }), index);
                if (prevSelected) {
                    if (maxR <= r) {
                        maxR = r;
                    }
                    this.draw(Object.assign({}, prevSelected, { radius: maxR }), false, true);
                }
                this.drawMask();
                if (i >= item.radius * this.hoverScale) {
                    this.drawOnce(Object.assign({}, item, { radius: item.radius * this.hoverScale }), index, true);
                    if (prevSelected) {
                        this.draw(prevSelected);
                    }
                    this.drawMask();
                }
                requestAnimationFrame(render.bind(this));
            }
            else if (this.hoverScale === 1) {
                this.drawOnce(item, index, true);
                if (prevSelected) {
                    this.draw(prevSelected);
                }
                this.drawMask();
            }
        }
        render.call(this);
        this.currentSelected = index;
    }
    /**
     * @param {?} item
     * @param {?} index
     * @param {?=} fadeIn
     * @return {?}
     */
    drawOnce(item, index, fadeIn) {
        this.pen.clearRect(0, 0, this.width, this.height);
        for (let a = 0, l = this.series.length; a < l; a++) {
            if (a !== index && a !== this.currentSelected) {
                /** @type {?} */
                const item1 = this.series[a];
                this.draw(item1, false);
            }
        }
        this.draw(item, false, fadeIn);
    }
    /**
     * @param {?} x
     * @param {?} a
     * @return {?}
     */
    velocityCurve(x, a) {
        // return Math.pow(x, 3);
        return Math.atan(x);
        // return 8 * Math.pow(a, 3) / (Math.pow(x, 2) + 4 * Math.pow(a, 2));
    }
    /**
     * line equation
     *  y1 = kx1 + b
     *  y2 = kx2 + b
     *  => k = (y1 - y2) / (x1 - x2);
     *  => b = y1 - kx1;
     * @param {?} x1
     * @param {?} y1
     * @param {?} x2
     * @param {?} y2
     * @return {?}
     */
    lineEquation(x1, y1, x2, y2) {
        // consider vertical scenario
        if (x1 !== x2) {
            /** @type {?} */
            const k = (y1 - y2) / (x1 - x2);
            /** @type {?} */
            const b = y1 - k * x1;
            return this.intersectionOfLineAndCircle(this.centerX, this.centerY, this.minRadius, k, b);
        }
        else {
            return {
                x1,
                y1: this.centerY - this.minRadius,
                x2: x1,
                y2: this.centerY - this.minRadius
            };
        }
    }
    /**
     * circle equation
     * (x - o1) ^ 2 + (y - o2) ^ 2 = r ^ 2
     * @param {?} o1
     * @param {?} o2
     * @param {?} r
     * @param {?} k
     * @param {?} b
     * @return {?}
     */
    intersectionOfLineAndCircle(o1, o2, r, k, b) {
        /** @type {?} */
        const result = this.twoPowerEquationResult(1 + Math.pow(k, 2), 2 * (k * b - o1 - k * o2), Math.pow(o1, 2) +
            Math.pow(b, 2) +
            Math.pow(o2, 2) -
            Math.pow(r, 2) -
            2 * b * o2);
        /** @type {?} */
        const x1 = result.x1;
        /** @type {?} */
        const x2 = result.x2;
        /** @type {?} */
        const y1 = k * x1 + b;
        /** @type {?} */
        const y2 = k * x2 + b;
        return { x1, x2, y1, y2 };
    }
    /**
     * x1 = (-b+Math.sqrt(b^2-4ac))/2*a
     * x2 = (-b-Math.sqrt(b^2-4ac))/2*a
     * @param {?} a
     * @param {?} b
     * @param {?} c
     * @return {?}
     */
    twoPowerEquationResult(a, b, c) {
        /** @type {?} */
        const x1 = (-b + Math.sqrt(Math.pow(b, 2) - 4 * a * c)) / (2 * a);
        /** @type {?} */
        const x2 = (-b - Math.sqrt(Math.pow(b, 2) - 4 * a * c)) / (2 * a);
        return { x1, x2 };
    }
}
if (false) {
    /**
     * @type {?}
     * @private
     */
    RoseChart.prototype.width;
    /**
     * @type {?}
     * @private
     */
    RoseChart.prototype.height;
    /**
     * @type {?}
     * @private
     */
    RoseChart.prototype.centerX;
    /**
     * @type {?}
     * @private
     */
    RoseChart.prototype.centerY;
    /**
     * @type {?}
     * @private
     */
    RoseChart.prototype.radiusGap;
    /**
     * @type {?}
     * @private
     */
    RoseChart.prototype.minRadius;
    /**
     * @type {?}
     * @private
     */
    RoseChart.prototype.inCircle;
    /**
     * @type {?}
     * @private
     */
    RoseChart.prototype.hoverScale;
    /**
     * @type {?}
     * @private
     */
    RoseChart.prototype.animationStep;
    /**
     * @type {?}
     * @private
     */
    RoseChart.prototype.devicePixelRatio;
    /**
     * @type {?}
     * @private
     */
    RoseChart.prototype.currentSelected;
    /**
     * @type {?}
     * @private
     */
    RoseChart.prototype.series;
    /**
     * @type {?}
     * @private
     */
    RoseChart.prototype.can;
    /**
     * @type {?}
     * @private
     */
    RoseChart.prototype.parentDom;
    /**
     * @type {?}
     * @private
     */
    RoseChart.prototype.initAngle;
    /**
     * @type {?}
     * @private
     */
    RoseChart.prototype.containerDom;
    /**
     * @type {?}
     * @private
     */
    RoseChart.prototype.pen;
    /**
     * @type {?}
     * @private
     */
    RoseChart.prototype.maxRadius;
    /**
     * @type {?}
     * @private
     */
    RoseChart.prototype.activeItem;
    /**
     * @type {?}
     * @private
     */
    RoseChart.prototype.defaultOffset;
    /**
     * @type {?}
     * @private
     */
    RoseChart.prototype.prodOption;
    /**
     * @type {?}
     * @private
     */
    RoseChart.prototype.option;
}

/**
 * @fileoverview added by tsickle
 * Generated from: lib/chart/chart.interface.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * @record
 */
function SingleSerial() { }
if (false) {
    /** @type {?} */
    SingleSerial.prototype.color;
    /** @type {?} */
    SingleSerial.prototype.value;
    /** @type {?|undefined} */
    SingleSerial.prototype.thickness;
    /** @type {?|undefined} */
    SingleSerial.prototype.indicateTxt;
    /** @type {?|undefined} */
    SingleSerial.prototype.highLightColor;
    /** @type {?|undefined} */
    SingleSerial.prototype.showIndicate;
    /** @type {?|undefined} */
    SingleSerial.prototype.indicateOffsetX;
    /** @type {?|undefined} */
    SingleSerial.prototype.indicateOffsetY;
    /** @type {?|undefined} */
    SingleSerial.prototype.indicatorLength;
    /** @type {?|undefined} */
    SingleSerial.prototype.indicatorOffset;
    /** @type {?|undefined} */
    SingleSerial.prototype.indicatorPercent;
    /** @type {?|undefined} */
    SingleSerial.prototype.indicatorOffsetAngle;
}
/**
 * @record
 */
function ProdSerial() { }
if (false) {
    /** @type {?|undefined} */
    ProdSerial.prototype.radius;
    /** @type {?|undefined} */
    ProdSerial.prototype.endAngle;
    /** @type {?|undefined} */
    ProdSerial.prototype.startAngle;
    /** @type {?|undefined} */
    ProdSerial.prototype.angleScope;
    /** @type {?|undefined} */
    ProdSerial.prototype.indicatorAngle;
    /** @type {?|undefined} */
    ProdSerial.prototype.indicatorPointX1;
    /** @type {?|undefined} */
    ProdSerial.prototype.indicatorPointX2;
    /** @type {?|undefined} */
    ProdSerial.prototype.indicatorPointY1;
    /** @type {?|undefined} */
    ProdSerial.prototype.indicatorPointY2;
}
/**
 * @record
 */
function XPoint() { }
if (false) {
    /** @type {?} */
    XPoint.prototype.x1;
    /** @type {?} */
    XPoint.prototype.x2;
}
/**
 * @record
 */
function DoublePoint() { }
if (false) {
    /** @type {?} */
    DoublePoint.prototype.y1;
    /** @type {?} */
    DoublePoint.prototype.y2;
}
/**
 * @record
 */
function SerialAndIndex() { }
if (false) {
    /** @type {?} */
    SerialAndIndex.prototype.item;
    /** @type {?} */
    SerialAndIndex.prototype.index;
}
/**
 * @record
 */
function Point() { }
if (false) {
    /** @type {?} */
    Point.prototype.x;
    /** @type {?} */
    Point.prototype.y;
}
/**
 * @record
 */
function ChartOption() { }
if (false) {
    /** @type {?} */
    ChartOption.prototype.id;
    /** @type {?} */
    ChartOption.prototype.radius;
    /** @type {?|undefined} */
    ChartOption.prototype.circleTxt;
    /** @type {?|undefined} */
    ChartOption.prototype.initAngle;
    /** @type {?|undefined} */
    ChartOption.prototype.hoverScale;
    /** @type {?} */
    ChartOption.prototype.series;
    /** @type {?|undefined} */
    ChartOption.prototype.triggerType;
    /** @type {?|undefined} */
    ChartOption.prototype.defaultOffset;
}

/**
 * @fileoverview added by tsickle
 * Generated from: public-api.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * Generated from: canvas-rose-chart.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

export { RoseChart };
//# sourceMappingURL=canvas-rose-chart.js.map
