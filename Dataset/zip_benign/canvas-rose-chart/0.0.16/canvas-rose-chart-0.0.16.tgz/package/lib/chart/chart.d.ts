import { ChartOption, DoublePoint, Point, ProdSerial, SerialAndIndex, XPoint } from './chart.interface';
export declare class RoseChart {
    private width;
    private height;
    private centerX;
    private centerY;
    private radiusGap;
    private minRadius;
    private inCircle;
    private hoverScale;
    private animationStep;
    private devicePixelRatio;
    private currentSelected;
    private series;
    private can;
    private parentDom;
    private initAngle;
    private containerDom;
    private pen;
    private maxRadius;
    private activeItem;
    private defaultOffset;
    private prodOption;
    private option;
    constructor(opt: ChartOption);
    init(): void;
    update(op?: ChartOption): void;
    initParams(): void;
    create(): void;
    destroy(): void;
    calculateRadius(): void;
    draw(drawEntity: ProdSerial, isMask?: boolean, fadeIn?: boolean): void;
    drawMask(): void;
    drawHtml(): void;
    initDraw(): void;
    addMoveHandler(): void;
    addResizeHandler(): void;
    resizeHandler(): void;
    mouseMoveHandler(e: MouseEvent): void;
    clickOrMouseoverHandler(): void;
    getDistance(x1: number, x2: number, y1: number, y2: number): number;
    getClosePoint(x: number, y: number, obj: {
        x1: number;
        x2: number;
        y1: number;
        y2: number;
    }): Point;
    isInPath(x: number, y: number): SerialAndIndex;
    handleFadeOut(): void;
    /**
     * mouse click a specific target
     * @param item -SingleSerial
     * @param  index -index
     */
    handleMoveIn(item: ProdSerial, index: number): void;
    drawOnce(item: ProdSerial, index: number, fadeIn?: boolean): void;
    velocityCurve(x: number, a: number): number;
    /**
     * line equation
     *  y1 = kx1 + b
     *  y2 = kx2 + b
     *  => k = (y1 - y2) / (x1 - x2);
     *  => b = y1 - kx1;
     */
    lineEquation(x1: number, y1: number, x2: number, y2: number): DoublePoint;
    /**
     * circle equation
     * (x - o1) ^ 2 + (y - o2) ^ 2 = r ^ 2
     */
    intersectionOfLineAndCircle(o1: number, o2: number, r: number, k: number, b: number): DoublePoint;
    /**
     * x1 = (-b+Math.sqrt(b^2-4ac))/2*a
     * x2 = (-b-Math.sqrt(b^2-4ac))/2*a
     */
    twoPowerEquationResult(a: number, b: number, c: number): XPoint;
}
