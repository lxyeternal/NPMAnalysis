(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports) :
    typeof define === 'function' && define.amd ? define('canvas-rose-chart', ['exports'], factory) :
    (global = global || self, factory(global['canvas-rose-chart'] = {}));
}(this, (function (exports) { 'use strict';

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation. All rights reserved.
    Licensed under the Apache License, Version 2.0 (the "License"); you may not use
    this file except in compliance with the License. You may obtain a copy of the
    License at http://www.apache.org/licenses/LICENSE-2.0

    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
    KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
    WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
    MERCHANTABLITY OR NON-INFRINGEMENT.

    See the Apache Version 2.0 License for specific language governing permissions
    and limitations under the License.
    ***************************************************************************** */
    /* global Reflect, Promise */

    var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };

    function __extends(d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }

    var __assign = function() {
        __assign = Object.assign || function __assign(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
            }
            return t;
        };
        return __assign.apply(this, arguments);
    };

    function __rest(s, e) {
        var t = {};
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
            t[p] = s[p];
        if (s != null && typeof Object.getOwnPropertySymbols === "function")
            for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
                if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                    t[p[i]] = s[p[i]];
            }
        return t;
    }

    function __decorate(decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    }

    function __param(paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); }
    }

    function __metadata(metadataKey, metadataValue) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
    }

    function __awaiter(thisArg, _arguments, P, generator) {
        function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
            function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
            function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    }

    function __generator(thisArg, body) {
        var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f) throw new TypeError("Generator is already executing.");
            while (_) try {
                if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
                if (y = 0, t) op = [op[0] & 2, t.value];
                switch (op[0]) {
                    case 0: case 1: t = op; break;
                    case 4: _.label++; return { value: op[1], done: false };
                    case 5: _.label++; y = op[1]; op = [0]; continue;
                    case 7: op = _.ops.pop(); _.trys.pop(); continue;
                    default:
                        if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                        if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                        if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                        if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                        if (t[2]) _.ops.pop();
                        _.trys.pop(); continue;
                }
                op = body.call(thisArg, _);
            } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
            if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
        }
    }

    function __exportStar(m, exports) {
        for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
    }

    function __values(o) {
        var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
        if (m) return m.call(o);
        if (o && typeof o.length === "number") return {
            next: function () {
                if (o && i >= o.length) o = void 0;
                return { value: o && o[i++], done: !o };
            }
        };
        throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
    }

    function __read(o, n) {
        var m = typeof Symbol === "function" && o[Symbol.iterator];
        if (!m) return o;
        var i = m.call(o), r, ar = [], e;
        try {
            while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
        }
        catch (error) { e = { error: error }; }
        finally {
            try {
                if (r && !r.done && (m = i["return"])) m.call(i);
            }
            finally { if (e) throw e.error; }
        }
        return ar;
    }

    function __spread() {
        for (var ar = [], i = 0; i < arguments.length; i++)
            ar = ar.concat(__read(arguments[i]));
        return ar;
    }

    function __spreadArrays() {
        for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
        for (var r = Array(s), k = 0, i = 0; i < il; i++)
            for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
                r[k] = a[j];
        return r;
    };

    function __await(v) {
        return this instanceof __await ? (this.v = v, this) : new __await(v);
    }

    function __asyncGenerator(thisArg, _arguments, generator) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var g = generator.apply(thisArg, _arguments || []), i, q = [];
        return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
        function verb(n) { if (g[n]) i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
        function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
        function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
        function fulfill(value) { resume("next", value); }
        function reject(value) { resume("throw", value); }
        function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
    }

    function __asyncDelegator(o) {
        var i, p;
        return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
        function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; } : f; }
    }

    function __asyncValues(o) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var m = o[Symbol.asyncIterator], i;
        return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
        function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
        function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
    }

    function __makeTemplateObject(cooked, raw) {
        if (Object.defineProperty) { Object.defineProperty(cooked, "raw", { value: raw }); } else { cooked.raw = raw; }
        return cooked;
    };

    function __importStar(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
        result.default = mod;
        return result;
    }

    function __importDefault(mod) {
        return (mod && mod.__esModule) ? mod : { default: mod };
    }

    function __classPrivateFieldGet(receiver, privateMap) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to get private field on non-instance");
        }
        return privateMap.get(receiver);
    }

    function __classPrivateFieldSet(receiver, privateMap, value) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to set private field on non-instance");
        }
        privateMap.set(receiver, value);
        return value;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: lib/chart/chart.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /** @type {?} */
    var defaultSerialConfig = {
        showIndicate: true,
        thickness: 40,
        indicatorPercent: 0.5,
        indicatorOffset: 0,
        indicatorLength: 40,
        indicatorOffsetAngle: 0
    };
    var RoseChart = /** @class */ (function () {
        function RoseChart(opt) {
            this.animationStep = 0.6;
            this.devicePixelRatio = 1;
            this.currentSelected = -1;
            this.initAngle = -Math.PI / 2;
            this.defaultOffset = true;
            this.option = opt;
        }
        /**
         * @return {?}
         */
        RoseChart.prototype.init = /**
         * @return {?}
         */
        function () {
            this.initParams();
            this.create();
        };
        /**
         * @param {?=} op
         * @return {?}
         */
        RoseChart.prototype.update = /**
         * @param {?=} op
         * @return {?}
         */
        function (op) {
            if (op) {
                this.option = op;
            }
            this.containerDom.innerHTML = '';
            this.init();
        };
        /**
         * @return {?}
         */
        RoseChart.prototype.initParams = /**
         * @return {?}
         */
        function () {
            this.prodOption = JSON.parse(JSON.stringify(this.option));
            if (this.prodOption.hasOwnProperty('initAngle')) {
                this.initAngle = this.prodOption.initAngle;
            }
            if (this.prodOption.hasOwnProperty('defaultOffset')) {
                this.defaultOffset = this.prodOption.defaultOffset;
            }
            this.parentDom = document.getElementById(this.prodOption.id);
            if (!this.containerDom) {
                this.containerDom = document.createElement('div');
                this.containerDom.style.cssText += "position:relative;display:inline-block";
            }
            /** @type {?} */
            var width = this.parentDom.offsetWidth;
            /** @type {?} */
            var height = this.parentDom.offsetHeight;
            this.width = width;
            this.height = height;
            this.can = document.createElement('canvas');
            this.containerDom.style.cssText += "width: " + width + "px;height:" + height + "px;";
            this.can.style.cssText += "width:" + width + "px;height:" + height + "px;";
            this.can.width = width;
            this.can.height = height;
            this.centerX = width / 2;
            this.centerY = height / 2;
            this.pen = this.can.getContext('2d');
            this.minRadius = this.prodOption.radius[0];
            this.maxRadius = this.prodOption.radius[1];
            this.containerDom.appendChild(this.can);
            this.parentDom.appendChild(this.containerDom);
            if (this.maxRadius) {
                this.radiusGap = this.maxRadius - this.minRadius;
            }
        };
        /**
         * @return {?}
         */
        RoseChart.prototype.create = /**
         * @return {?}
         */
        function () {
            this.calculateRadius();
            if (window.devicePixelRatio) {
                /** @type {?} */
                var ratio = window.devicePixelRatio;
                this.devicePixelRatio = ratio;
                this.can.height = this.height * ratio;
                this.can.width = this.width * ratio;
                this.pen.scale(ratio, ratio);
            }
            this.initDraw();
            this.drawHtml();
            this.addMoveHandler();
            this.addResizeHandler();
        };
        /**
         * @return {?}
         */
        RoseChart.prototype.destroy = /**
         * @return {?}
         */
        function () {
            this.can.removeEventListener('mousemove', this.mouseMoveHandler.bind(this), false);
            if (this.prodOption.triggerType && this.prodOption.triggerType === 'click') {
                this.can.removeEventListener('click', this.clickOrMouseoverHandler.bind(this), false);
            }
            window.removeEventListener('resize', this.resizeHandler.bind(this), false);
            this.parentDom.removeChild(this.containerDom);
        };
        // calculate angle
        // calculate angle
        /**
         * @return {?}
         */
        RoseChart.prototype.calculateRadius = 
        // calculate angle
        /**
         * @return {?}
         */
        function () {
            /** @type {?} */
            var series = this.prodOption.series;
            /** @type {?} */
            var arr = [];
            /** @type {?} */
            var thickness = [];
            /** @type {?} */
            var total = 0;
            series.map((/**
             * @param {?} item
             * @return {?}
             */
            function (item) {
                total += item.value;
                arr.push(item.value);
                if (item.thickness) {
                    thickness.push(item.thickness);
                }
            }));
            /** @type {?} */
            var maxVal = Math.max.apply(null, arr);
            if (thickness.length > 0) {
                /** @type {?} */
                var maxThickness = Math.max.apply(null, thickness);
                this.maxRadius = maxThickness + this.minRadius;
            }
            for (var i = 0, len = series.length; i < len; i++) {
                series[i] = Object.assign({}, defaultSerialConfig, series[i]);
                series[i].angleScope = (Math.PI * 2 * series[i].value) / total;
                if (i > 0) {
                    series[i].startAngle = series[i - 1].endAngle;
                }
                else {
                    series[i].startAngle = this.initAngle;
                }
                if (series[i].startAngle > Math.PI) {
                    series[i].startAngle = series[i].startAngle - Math.PI * 2;
                }
                if (this.radiusGap) {
                    series[i].radius =
                        this.minRadius + (this.radiusGap * series[i].value) / maxVal;
                }
                else {
                    series[i].radius = this.minRadius + series[i].thickness;
                }
                if (i > 0) {
                    series[i].endAngle = series[i - 1].endAngle + series[i].angleScope;
                    series[i].indicatorAngle = series[i - 1].endAngle + series[i].angleScope * series[i].indicatorPercent;
                }
                else {
                    series[i].endAngle = series[i].angleScope + this.initAngle;
                    series[i].indicatorAngle = series[i].angleScope * series[i].indicatorPercent + this.initAngle;
                }
                if (series[i].endAngle > Math.PI && series.length > 1) {
                    series[i].endAngle = series[i].endAngle - Math.PI * 2;
                }
                if (series[i].indicatorAngle > Math.PI && series.length > 1) {
                    series[i].indicatorAngle = series[i].indicatorAngle - Math.PI * 2;
                }
                series[i].indicatorPointX1 =
                    (series[i].radius + series[i].indicatorOffset) *
                        Math.cos(series[i].indicatorAngle) +
                        this.centerX;
                series[i].indicatorPointY1 =
                    (series[i].radius + series[i].indicatorOffset) *
                        Math.sin(series[i].indicatorAngle) +
                        this.centerY;
                series[i].indicatorPointX2 =
                    series[i].indicatorLength * Math.cos(series[i].indicatorAngle) +
                        series[i].indicatorPointX1;
                series[i].indicatorPointY2 =
                    series[i].indicatorLength * Math.sin(series[i].indicatorAngle) +
                        series[i].indicatorPointY1;
                // custom offsetAngle
                /** @type {?} */
                var indicatorAngle = series[i].indicatorAngle;
                if (series[i].indicatorOffsetAngle) {
                    if (series[i].indicatorOffsetAngle <= -Math.PI / 2) {
                        series[i].indicatorOffsetAngle = -Math.PI / 2;
                    }
                    if (series[i].indicatorOffsetAngle >= Math.PI / 2) {
                        series[i].indicatorOffsetAngle = Math.PI / 2;
                    }
                    /** @type {?} */
                    var finalAngle = indicatorAngle + series[i].indicatorOffsetAngle;
                    series[i].indicatorPointY2 = series[i].indicatorPointY1 + series[i].indicatorLength * Math.sin(finalAngle);
                    series[i].indicatorPointX2 = series[i].indicatorPointX1 + series[i].indicatorLength * Math.cos(finalAngle);
                }
            }
            this.series = series;
        };
        /**
         * @param {?} drawEntity
         * @param {?=} isMask
         * @param {?=} fadeIn
         * @return {?}
         */
        RoseChart.prototype.draw = /**
         * @param {?} drawEntity
         * @param {?=} isMask
         * @param {?=} fadeIn
         * @return {?}
         */
        function (drawEntity, isMask, fadeIn) {
            this.pen.beginPath();
            this.pen.fillStyle = drawEntity.color;
            if (fadeIn && drawEntity.highLightColor) {
                this.pen.fillStyle = drawEntity.highLightColor;
            }
            this.pen.moveTo(this.centerX, this.centerY);
            this.pen.arc(this.centerX, this.centerY, drawEntity.radius, drawEntity.startAngle, drawEntity.endAngle);
            this.pen.fill();
            this.pen.closePath();
            if (drawEntity.indicatorPointX1 && drawEntity.showIndicate && !isMask) {
                this.pen.beginPath();
                this.pen.strokeStyle = drawEntity.color;
                if (fadeIn && drawEntity.highLightColor) {
                    this.pen.strokeStyle = drawEntity.highLightColor;
                }
                this.pen.moveTo(drawEntity.indicatorPointX1, drawEntity.indicatorPointY1);
                this.pen.lineWidth = 1;
                this.pen.lineTo(drawEntity.indicatorPointX2, drawEntity.indicatorPointY2);
                this.pen.stroke();
                this.pen.closePath();
            }
            this.pen.save();
        };
        /**
         * @return {?}
         */
        RoseChart.prototype.drawMask = /**
         * @return {?}
         */
        function () {
            this.draw({
                color: '#fff',
                highLightColor: '#fff',
                startAngle: 0,
                endAngle: Math.PI * 2,
                radius: this.minRadius,
                value: 100
            }, true);
        };
        /**
         * @return {?}
         */
        RoseChart.prototype.drawHtml = /**
         * @return {?}
         */
        function () {
            var e_1, _a;
            if (this.prodOption.circleTxt) {
                /** @type {?} */
                var inner = document.createElement('div');
                inner.style.cssText += "position:absolute;top:" + this.centerY + "px;left:" + this.centerX + "px;\n      transform:translate(-50%, -50%);z-index: 10;";
                inner.innerHTML = this.prodOption.circleTxt;
                this.containerDom.appendChild(inner);
            }
            try {
                for (var _b = __values(this.series), _c = _b.next(); !_c.done; _c = _b.next()) {
                    var item = _c.value;
                    if (item.indicateTxt) {
                        /** @type {?} */
                        var tooltipDiv = document.createElement('div');
                        tooltipDiv.style.cssText += "position:absolute;top:" + item.indicatorPointY2 + "px;";
                        if (item.indicatorPointX2 > this.centerX) {
                            if (this.defaultOffset) {
                                tooltipDiv.style.cssText += "left:" + (item.indicatorPointX2 + 10 + (item.indicateOffsetX || 0)) + "px;";
                            }
                            else {
                                tooltipDiv.style.cssText += "left:" + (item.indicatorPointX2 + (item.indicateOffsetX || 0)) + "px;";
                            }
                        }
                        else {
                            if (this.defaultOffset) {
                                tooltipDiv.style.cssText += "right:" + (this.width -
                                    item.indicatorPointX2 + 10 - (item.indicateOffsetX || 0)) + "px;";
                            }
                            else {
                                tooltipDiv.style.cssText += "right:" + (this.width -
                                    item.indicatorPointX2 - (item.indicateOffsetX || 0)) + "px;";
                            }
                        }
                        if (item.indicatorPointY2 < this.centerY) {
                            if (this.defaultOffset) {
                                tooltipDiv.style.cssText += "top:" + (item.indicatorPointY2 - 10 + (item.indicateOffsetY || 0)) + "px;";
                            }
                            else {
                                tooltipDiv.style.cssText += "top:" + (item.indicatorPointY2 + (item.indicateOffsetY || 0)) + "px;";
                            }
                        }
                        else {
                            if (this.defaultOffset) {
                                tooltipDiv.style.cssText += "top:" + (item.indicatorPointY2 - 8 + (item.indicateOffsetY || 0)) + "px;";
                            }
                            else {
                                tooltipDiv.style.cssText += "top:" + (item.indicatorPointY2 + (item.indicateOffsetY || 0)) + "px;";
                            }
                        }
                        tooltipDiv.innerHTML = item.indicateTxt;
                        this.containerDom.appendChild(tooltipDiv);
                    }
                }
            }
            catch (e_1_1) { e_1 = { error: e_1_1 }; }
            finally {
                try {
                    if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
                }
                finally { if (e_1) throw e_1.error; }
            }
        };
        /**
         * @return {?}
         */
        RoseChart.prototype.initDraw = /**
         * @return {?}
         */
        function () {
            var e_2, _a;
            this.pen.clearRect(0, 0, this.width, this.height);
            try {
                for (var _b = __values(this.series), _c = _b.next(); !_c.done; _c = _b.next()) {
                    var item = _c.value;
                    this.draw(item);
                }
            }
            catch (e_2_1) { e_2 = { error: e_2_1 }; }
            finally {
                try {
                    if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
                }
                finally { if (e_2) throw e_2.error; }
            }
            this.drawMask();
        };
        /**
         * @return {?}
         */
        RoseChart.prototype.addMoveHandler = /**
         * @return {?}
         */
        function () {
            this.can.addEventListener('mousemove', this.mouseMoveHandler.bind(this), false);
            this.hoverScale = this.prodOption.hoverScale ? (this.prodOption.hoverScale < 1 ? 1 : this.prodOption.hoverScale) : 1;
            if (this.prodOption.triggerType && this.prodOption.triggerType === 'click') {
                this.can.addEventListener('click', this.clickOrMouseoverHandler.bind(this), false);
            }
        };
        /**
         * @return {?}
         */
        RoseChart.prototype.addResizeHandler = /**
         * @return {?}
         */
        function () {
            window.addEventListener('resize', this.resizeHandler.bind(this), false);
        };
        /**
         * @return {?}
         */
        RoseChart.prototype.resizeHandler = /**
         * @return {?}
         */
        function () {
            /** @type {?} */
            var width = this.parentDom.offsetWidth;
            /** @type {?} */
            var height = this.parentDom.offsetHeight;
            if (this.width !== width || this.height !== height) {
                this.update();
            }
        };
        /**
         * @param {?} e
         * @return {?}
         */
        RoseChart.prototype.mouseMoveHandler = /**
         * @param {?} e
         * @return {?}
         */
        function (e) {
            /** @type {?} */
            var x = e.clientX - this.can.getBoundingClientRect().left;
            /** @type {?} */
            var y = e.clientY - this.can.getBoundingClientRect().top;
            /** @type {?} */
            var result = this.isInPath(x, y);
            if (result) {
                this.inCircle = true;
                this.activeItem = result;
                this.can.style.cursor = 'pointer';
            }
            else {
                this.can.style.cursor = 'default';
                this.inCircle = false;
            }
            if (this.prodOption.triggerType && this.prodOption.triggerType === 'hover') {
                this.clickOrMouseoverHandler();
            }
        };
        /**
         * @return {?}
         */
        RoseChart.prototype.clickOrMouseoverHandler = /**
         * @return {?}
         */
        function () {
            if (this.inCircle) {
                this.handleMoveIn(this.activeItem.item, this.activeItem.index);
                return;
            }
            if (this.currentSelected !== -1) {
                this.handleFadeOut();
                this.currentSelected = -1;
            }
        };
        /**
         * @param {?} x1
         * @param {?} x2
         * @param {?} y1
         * @param {?} y2
         * @return {?}
         */
        RoseChart.prototype.getDistance = /**
         * @param {?} x1
         * @param {?} x2
         * @param {?} y1
         * @param {?} y2
         * @return {?}
         */
        function (x1, x2, y1, y2) {
            return Math.sqrt(Math.pow(Math.abs(x1 - x2), 2) + Math.pow(Math.abs(y1 - y2), 2));
        };
        /**
         * @param {?} x
         * @param {?} y
         * @param {?} obj
         * @return {?}
         */
        RoseChart.prototype.getClosePoint = /**
         * @param {?} x
         * @param {?} y
         * @param {?} obj
         * @return {?}
         */
        function (x, y, obj) {
            /** @type {?} */
            var dis1 = Math.sqrt(Math.pow(Math.abs(obj.x1 - x), 2) + Math.pow(Math.abs(obj.y1 - y), 2));
            /** @type {?} */
            var dis2 = Math.sqrt(Math.pow(Math.abs(obj.x2 - x), 2) + Math.pow(Math.abs(obj.y2 - y), 2));
            return dis1 >= dis2 ? { x: obj.x2, y: obj.y2 } : { x: obj.x1, y: obj.y1 };
        };
        /**
         * @param {?} x
         * @param {?} y
         * @return {?}
         */
        RoseChart.prototype.isInPath = /**
         * @param {?} x
         * @param {?} y
         * @return {?}
         */
        function (x, y) {
            /** @type {?} */
            var centerX = this.centerX;
            /** @type {?} */
            var centerY = this.centerY;
            /** @type {?} */
            var distance = this.getDistance(centerX, x, centerY, y);
            if (distance >= this.minRadius && distance <= this.maxRadius) {
                if (this.series.length > 1) {
                    /** @type {?} */
                    var point = this.getClosePoint(x, y, this.lineEquation(this.centerX, this.centerY, x, y));
                    /** @type {?} */
                    var negativeSymbol = 1;
                    if (point.y < this.centerY) {
                        negativeSymbol = -1;
                    }
                    /** @type {?} */
                    var angle = negativeSymbol * Math.acos((point.x - this.centerX) / this.minRadius);
                    for (var i = 0, len = this.series.length; i < len; i++) {
                        /** @type {?} */
                        var item = this.series[i];
                        if (((item.startAngle >= 0 && item.endAngle >= 0) ||
                            (item.startAngle <= 0 && item.endAngle <= 0)) &&
                            item.angleScope <= Math.PI) {
                            if (angle >= item.startAngle && angle <= item.endAngle) {
                                return { item: item, index: i };
                            }
                        }
                        else if (item.startAngle <= 0 && item.endAngle >= 0) {
                            if (angle >= item.startAngle && angle <= item.endAngle) {
                                return { item: item, index: i };
                            }
                        }
                        else if (item.startAngle >= 0 && item.endAngle <= 0) {
                            if (angle <= 0 && angle <= item.endAngle) {
                                return { item: item, index: i };
                            }
                            else if (angle >= 0 && angle >= item.startAngle) {
                                return { item: item, index: i };
                            }
                        }
                        else if (((item.startAngle <= 0 && item.endAngle <= 0) ||
                            (item.startAngle >= 0 && item.endAngle >= 0)) &&
                            item.angleScope >= (Math.PI * 3) / 2) {
                            if (!(item.endAngle <= angle && item.startAngle >= angle)) {
                                return { item: item, index: i };
                            }
                        }
                    }
                }
                else {
                    return { item: this.series[0], index: 0 };
                }
            }
        };
        /**
         * @return {?}
         */
        RoseChart.prototype.handleFadeOut = /**
         * @return {?}
         */
        function () {
            /** @type {?} */
            var prevSelected = this.series[this.currentSelected];
            /** @type {?} */
            var r = prevSelected.radius;
            /** @type {?} */
            var maxR = r * this.hoverScale;
            /** @type {?} */
            var step = 1;
            /**
             * @return {?}
             */
            function renderOut() {
                if (this.hoverScale > 1) {
                    if (maxR > prevSelected.radius) {
                        step += this.animationStep;
                        maxR -= this.velocityCurve(step, 1);
                        this.drawOnce(Object.assign({}, prevSelected, { radius: maxR }), this.currentSelected, true);
                        this.drawMask();
                        if (maxR <= prevSelected.radius) {
                            this.drawOnce(prevSelected, this.currentSelected, true);
                            this.drawMask();
                        }
                        requestAnimationFrame(renderOut.bind(this));
                    }
                }
                else {
                    this.drawOnce(prevSelected, this.currentSelected);
                    this.drawMask();
                }
            }
            renderOut.call(this);
        };
        /**
         * mouse click a specific target
         * @param item -SingleSerial
         * @param  index -index
         */
        /**
         * mouse click a specific target
         * @param {?} item -SingleSerial
         * @param {?} index -index
         * @return {?}
         */
        RoseChart.prototype.handleMoveIn = /**
         * mouse click a specific target
         * @param {?} item -SingleSerial
         * @param {?} index -index
         * @return {?}
         */
        function (item, index) {
            if (this.currentSelected === index) {
                return;
            }
            /** @type {?} */
            var i = item.radius;
            /** @type {?} */
            var step = 1;
            /** @type {?} */
            var r = 0;
            /** @type {?} */
            var maxR = 0;
            /** @type {?} */
            var prevSelected = null;
            if (this.currentSelected !== -1) {
                prevSelected = this.series[this.currentSelected];
                r = prevSelected.radius;
                maxR = r * this.hoverScale;
            }
            /**
             * @return {?}
             */
            function render() {
                if (i < item.radius * this.hoverScale && this.hoverScale > 1) {
                    step += this.animationStep;
                    i += this.velocityCurve(step, 1);
                    maxR -= this.velocityCurve(step, 1);
                    this.drawOnce(Object.assign({}, item, { radius: i }), index);
                    if (prevSelected) {
                        if (maxR <= r) {
                            maxR = r;
                        }
                        this.draw(Object.assign({}, prevSelected, { radius: maxR }), false, true);
                    }
                    this.drawMask();
                    if (i >= item.radius * this.hoverScale) {
                        this.drawOnce(Object.assign({}, item, { radius: item.radius * this.hoverScale }), index, true);
                        if (prevSelected) {
                            this.draw(prevSelected);
                        }
                        this.drawMask();
                    }
                    requestAnimationFrame(render.bind(this));
                }
                else if (this.hoverScale === 1) {
                    this.drawOnce(item, index, true);
                    if (prevSelected) {
                        this.draw(prevSelected);
                    }
                    this.drawMask();
                }
            }
            render.call(this);
            this.currentSelected = index;
        };
        /**
         * @param {?} item
         * @param {?} index
         * @param {?=} fadeIn
         * @return {?}
         */
        RoseChart.prototype.drawOnce = /**
         * @param {?} item
         * @param {?} index
         * @param {?=} fadeIn
         * @return {?}
         */
        function (item, index, fadeIn) {
            this.pen.clearRect(0, 0, this.width, this.height);
            for (var a = 0, l = this.series.length; a < l; a++) {
                if (a !== index && a !== this.currentSelected) {
                    /** @type {?} */
                    var item1 = this.series[a];
                    this.draw(item1, false);
                }
            }
            this.draw(item, false, fadeIn);
        };
        /**
         * @param {?} x
         * @param {?} a
         * @return {?}
         */
        RoseChart.prototype.velocityCurve = /**
         * @param {?} x
         * @param {?} a
         * @return {?}
         */
        function (x, a) {
            // return Math.pow(x, 3);
            return Math.atan(x);
            // return 8 * Math.pow(a, 3) / (Math.pow(x, 2) + 4 * Math.pow(a, 2));
        };
        /**
         * line equation
         *  y1 = kx1 + b
         *  y2 = kx2 + b
         *  => k = (y1 - y2) / (x1 - x2);
         *  => b = y1 - kx1;
         */
        /**
         * line equation
         *  y1 = kx1 + b
         *  y2 = kx2 + b
         *  => k = (y1 - y2) / (x1 - x2);
         *  => b = y1 - kx1;
         * @param {?} x1
         * @param {?} y1
         * @param {?} x2
         * @param {?} y2
         * @return {?}
         */
        RoseChart.prototype.lineEquation = /**
         * line equation
         *  y1 = kx1 + b
         *  y2 = kx2 + b
         *  => k = (y1 - y2) / (x1 - x2);
         *  => b = y1 - kx1;
         * @param {?} x1
         * @param {?} y1
         * @param {?} x2
         * @param {?} y2
         * @return {?}
         */
        function (x1, y1, x2, y2) {
            // consider vertical scenario
            if (x1 !== x2) {
                /** @type {?} */
                var k = (y1 - y2) / (x1 - x2);
                /** @type {?} */
                var b = y1 - k * x1;
                return this.intersectionOfLineAndCircle(this.centerX, this.centerY, this.minRadius, k, b);
            }
            else {
                return {
                    x1: x1,
                    y1: this.centerY - this.minRadius,
                    x2: x1,
                    y2: this.centerY - this.minRadius
                };
            }
        };
        /**
         * circle equation
         * (x - o1) ^ 2 + (y - o2) ^ 2 = r ^ 2
         */
        /**
         * circle equation
         * (x - o1) ^ 2 + (y - o2) ^ 2 = r ^ 2
         * @param {?} o1
         * @param {?} o2
         * @param {?} r
         * @param {?} k
         * @param {?} b
         * @return {?}
         */
        RoseChart.prototype.intersectionOfLineAndCircle = /**
         * circle equation
         * (x - o1) ^ 2 + (y - o2) ^ 2 = r ^ 2
         * @param {?} o1
         * @param {?} o2
         * @param {?} r
         * @param {?} k
         * @param {?} b
         * @return {?}
         */
        function (o1, o2, r, k, b) {
            /** @type {?} */
            var result = this.twoPowerEquationResult(1 + Math.pow(k, 2), 2 * (k * b - o1 - k * o2), Math.pow(o1, 2) +
                Math.pow(b, 2) +
                Math.pow(o2, 2) -
                Math.pow(r, 2) -
                2 * b * o2);
            /** @type {?} */
            var x1 = result.x1;
            /** @type {?} */
            var x2 = result.x2;
            /** @type {?} */
            var y1 = k * x1 + b;
            /** @type {?} */
            var y2 = k * x2 + b;
            return { x1: x1, x2: x2, y1: y1, y2: y2 };
        };
        /**
         * x1 = (-b+Math.sqrt(b^2-4ac))/2*a
         * x2 = (-b-Math.sqrt(b^2-4ac))/2*a
         */
        /**
         * x1 = (-b+Math.sqrt(b^2-4ac))/2*a
         * x2 = (-b-Math.sqrt(b^2-4ac))/2*a
         * @param {?} a
         * @param {?} b
         * @param {?} c
         * @return {?}
         */
        RoseChart.prototype.twoPowerEquationResult = /**
         * x1 = (-b+Math.sqrt(b^2-4ac))/2*a
         * x2 = (-b-Math.sqrt(b^2-4ac))/2*a
         * @param {?} a
         * @param {?} b
         * @param {?} c
         * @return {?}
         */
        function (a, b, c) {
            /** @type {?} */
            var x1 = (-b + Math.sqrt(Math.pow(b, 2) - 4 * a * c)) / (2 * a);
            /** @type {?} */
            var x2 = (-b - Math.sqrt(Math.pow(b, 2) - 4 * a * c)) / (2 * a);
            return { x1: x1, x2: x2 };
        };
        return RoseChart;
    }());
    if (false) {
        /**
         * @type {?}
         * @private
         */
        RoseChart.prototype.width;
        /**
         * @type {?}
         * @private
         */
        RoseChart.prototype.height;
        /**
         * @type {?}
         * @private
         */
        RoseChart.prototype.centerX;
        /**
         * @type {?}
         * @private
         */
        RoseChart.prototype.centerY;
        /**
         * @type {?}
         * @private
         */
        RoseChart.prototype.radiusGap;
        /**
         * @type {?}
         * @private
         */
        RoseChart.prototype.minRadius;
        /**
         * @type {?}
         * @private
         */
        RoseChart.prototype.inCircle;
        /**
         * @type {?}
         * @private
         */
        RoseChart.prototype.hoverScale;
        /**
         * @type {?}
         * @private
         */
        RoseChart.prototype.animationStep;
        /**
         * @type {?}
         * @private
         */
        RoseChart.prototype.devicePixelRatio;
        /**
         * @type {?}
         * @private
         */
        RoseChart.prototype.currentSelected;
        /**
         * @type {?}
         * @private
         */
        RoseChart.prototype.series;
        /**
         * @type {?}
         * @private
         */
        RoseChart.prototype.can;
        /**
         * @type {?}
         * @private
         */
        RoseChart.prototype.parentDom;
        /**
         * @type {?}
         * @private
         */
        RoseChart.prototype.initAngle;
        /**
         * @type {?}
         * @private
         */
        RoseChart.prototype.containerDom;
        /**
         * @type {?}
         * @private
         */
        RoseChart.prototype.pen;
        /**
         * @type {?}
         * @private
         */
        RoseChart.prototype.maxRadius;
        /**
         * @type {?}
         * @private
         */
        RoseChart.prototype.activeItem;
        /**
         * @type {?}
         * @private
         */
        RoseChart.prototype.defaultOffset;
        /**
         * @type {?}
         * @private
         */
        RoseChart.prototype.prodOption;
        /**
         * @type {?}
         * @private
         */
        RoseChart.prototype.option;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: lib/chart/chart.interface.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /**
     * @record
     */
    function SingleSerial() { }
    if (false) {
        /** @type {?} */
        SingleSerial.prototype.color;
        /** @type {?} */
        SingleSerial.prototype.value;
        /** @type {?|undefined} */
        SingleSerial.prototype.thickness;
        /** @type {?|undefined} */
        SingleSerial.prototype.indicateTxt;
        /** @type {?|undefined} */
        SingleSerial.prototype.highLightColor;
        /** @type {?|undefined} */
        SingleSerial.prototype.showIndicate;
        /** @type {?|undefined} */
        SingleSerial.prototype.indicateOffsetX;
        /** @type {?|undefined} */
        SingleSerial.prototype.indicateOffsetY;
        /** @type {?|undefined} */
        SingleSerial.prototype.indicatorLength;
        /** @type {?|undefined} */
        SingleSerial.prototype.indicatorOffset;
        /** @type {?|undefined} */
        SingleSerial.prototype.indicatorPercent;
        /** @type {?|undefined} */
        SingleSerial.prototype.indicatorOffsetAngle;
    }
    /**
     * @record
     */
    function ProdSerial() { }
    if (false) {
        /** @type {?|undefined} */
        ProdSerial.prototype.radius;
        /** @type {?|undefined} */
        ProdSerial.prototype.endAngle;
        /** @type {?|undefined} */
        ProdSerial.prototype.startAngle;
        /** @type {?|undefined} */
        ProdSerial.prototype.angleScope;
        /** @type {?|undefined} */
        ProdSerial.prototype.indicatorAngle;
        /** @type {?|undefined} */
        ProdSerial.prototype.indicatorPointX1;
        /** @type {?|undefined} */
        ProdSerial.prototype.indicatorPointX2;
        /** @type {?|undefined} */
        ProdSerial.prototype.indicatorPointY1;
        /** @type {?|undefined} */
        ProdSerial.prototype.indicatorPointY2;
    }
    /**
     * @record
     */
    function XPoint() { }
    if (false) {
        /** @type {?} */
        XPoint.prototype.x1;
        /** @type {?} */
        XPoint.prototype.x2;
    }
    /**
     * @record
     */
    function DoublePoint() { }
    if (false) {
        /** @type {?} */
        DoublePoint.prototype.y1;
        /** @type {?} */
        DoublePoint.prototype.y2;
    }
    /**
     * @record
     */
    function SerialAndIndex() { }
    if (false) {
        /** @type {?} */
        SerialAndIndex.prototype.item;
        /** @type {?} */
        SerialAndIndex.prototype.index;
    }
    /**
     * @record
     */
    function Point() { }
    if (false) {
        /** @type {?} */
        Point.prototype.x;
        /** @type {?} */
        Point.prototype.y;
    }
    /**
     * @record
     */
    function ChartOption() { }
    if (false) {
        /** @type {?} */
        ChartOption.prototype.id;
        /** @type {?} */
        ChartOption.prototype.radius;
        /** @type {?|undefined} */
        ChartOption.prototype.circleTxt;
        /** @type {?|undefined} */
        ChartOption.prototype.initAngle;
        /** @type {?|undefined} */
        ChartOption.prototype.hoverScale;
        /** @type {?} */
        ChartOption.prototype.series;
        /** @type {?|undefined} */
        ChartOption.prototype.triggerType;
        /** @type {?|undefined} */
        ChartOption.prototype.defaultOffset;
    }

    exports.RoseChart = RoseChart;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=canvas-rose-chart.umd.js.map
