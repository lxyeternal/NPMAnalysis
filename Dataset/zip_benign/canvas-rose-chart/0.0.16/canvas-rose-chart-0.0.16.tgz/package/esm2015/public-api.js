/**
 * @fileoverview added by tsickle
 * Generated from: public-api.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/*
 * Public API Surface of canvas-rose-chart
 */
export { RoseChart } from './lib/chart/chart';
export {} from './lib/chart/chart.interface';
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHVibGljLWFwaS5qcyIsInNvdXJjZVJvb3QiOiJuZzovL2NhbnZhcy1yb3NlLWNoYXJ0LyIsInNvdXJjZXMiOlsicHVibGljLWFwaS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUlBLDBCQUFjLG1CQUFtQixDQUFDO0FBQ2xDLGVBQWMsNkJBQTZCLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogUHVibGljIEFQSSBTdXJmYWNlIG9mIGNhbnZhcy1yb3NlLWNoYXJ0XG4gKi9cblxuZXhwb3J0ICogZnJvbSAnLi9saWIvY2hhcnQvY2hhcnQnO1xuZXhwb3J0ICogZnJvbSAnLi9saWIvY2hhcnQvY2hhcnQuaW50ZXJmYWNlJztcbiJdfQ==