interface VisualizerProps {
	audioBlob: Blob;
	width: number;
	height: number;
	lineWidth?: number;
	gap?: number;
	progress?: number;
	waveColor?: string;
	incompleteWaveColor?: string;
	backgroundColor?: string;
	incompleteAlphaValue?: number;
}

interface WithoutProgress extends VisualizerProps {
	progress?: never;
	isPlaying?: never;
}

interface WithProgress extends VisualizerProps {
	progress: number;
	isPlaying: boolean;
}

export type UnilateralVisualizerProps = (WithoutProgress | WithProgress) & {
	onChange?: (percent: number) => void;
};

export type RangedVisualizerProps = (WithProgress | WithoutProgress) & {
	onChange?: (start: number, end: number) => void;
};
