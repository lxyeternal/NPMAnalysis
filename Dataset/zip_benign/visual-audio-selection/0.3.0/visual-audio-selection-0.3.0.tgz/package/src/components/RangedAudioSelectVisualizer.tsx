import { useRef, useCallback } from "react";
import { AudioVisualizer } from "./Visualizer";
import { RangedVisualizerProps } from "../types/visualizer";

/**
 * JSX Component for audio visualization select
 * @param {Blob} props.audioBlob blob of audio file
 * @param {number} props.width width of the canvas
 * @param {number} props.height height of the canvas
 * @param {number} props.gap gap between the lines - default is 0
 * @param {number} props.lineWidth width of the lines - default is 1
 * @param {number} props.progress progress of the audio
 * @param {boolean} props.isPlaying indicates if the audio is playing
 * @param {(start: number, end: number) => void} props.onChange callback function to be called when a new range is selected - args 0-1
 * @param {string} props.waveColor color of the lines
 * @param {string} props.incompleteWaveColor color of the lines when not selected
 * @param {string} props.backgroundColor color of the background
 * @param {number} props.incompleteAlphaValue alpha value of the lines when not selected
 * @returns
 */

const RangedAudioSelectVisualizer = ({
	audioBlob,
	width,
	height,
	gap = 0,
	lineWidth = 1,
	progress,
	isPlaying,
	onChange,
	waveColor = "#ab1717",
	incompleteWaveColor,
	backgroundColor = "#f0f0f0",
	incompleteAlphaValue = 0.5,
}: RangedVisualizerProps) => {
	// useRef to sync updates
	const start = useRef(0); // 0 to width
	const end = useRef(width); // width to 0
	const direction = useRef<"left" | "rigth" | null>(null);

	const adjustedLineWidth = Math.max(lineWidth, 1); // floor is 1
	const adjustedGap = Math.max(gap, 0); // floor is 0

	const calculateDirection = (canvas: HTMLCanvasElement, positionX: number) => {
		const shrinkingCanvasRef = canvas.parentElement;
		if (!shrinkingCanvasRef) return;
		const ShrinkingCanvasRect = shrinkingCanvasRef.getBoundingClientRect();
		const midPoint = ShrinkingCanvasRect.x + ShrinkingCanvasRect.width / 2;

		direction.current = positionX >= midPoint ? "rigth" : "left";
	};

	const handleMove = useCallback(
		(
			singleLineCanvas: HTMLCanvasElement,
			shrinkingCanvasRef: HTMLCanvasElement,
			mousePositionX: number,
			offset: number,
			margin: number,
		) => {
			if (!shrinkingCanvasRef.parentElement) return false;

			const { width } = singleLineCanvas;
			const x = adjustedGap + adjustedLineWidth;

			// index relative to how many lines fit in the mouse x-position
			const index = Math.floor((mousePositionX - offset) / x);

			// Clip the progress to a line
			const clip = (index * x) / width;
			if (direction.current === "rigth") {
				if (start.current + x > clip * width + x) return false;
				end.current = Math.min(clip * width + x, width);
				shrinkingCanvasRef.parentElement.style.width =
					Math.min(clip * width - start.current + x - 1 + margin / 2, width) +
					"px";
			} else if (direction.current === "left") {
				const translate = Math.max(clip * width + margin / 2, 0);
				if (end.current - x < translate) return false;

				shrinkingCanvasRef.parentElement.style.width =
					end.current - translate + margin / 2 + "px";
				start.current = translate;
				shrinkingCanvasRef.parentElement.style.transform = `translateX(${translate}px)`;
				shrinkingCanvasRef.style.transform = `translateX(-${translate}px)`;
			} else return false;

			if (onChange) onChange(start.current / width, end.current / width);
			return true;
		},
		[adjustedGap, adjustedLineWidth, direction, onChange, start, end],
	);

	return (
		<AudioVisualizer
			audioBlob={audioBlob}
			height={height}
			width={width}
			handleMoveCallback={handleMove}
			onStartMoving={calculateDirection}
			progress={
				isPlaying
					? Math.max((progress || 0) - start.current / width, 0)
					: undefined
			}
			gap={adjustedGap}
			lineWidth={adjustedLineWidth}
			waveColor={waveColor}
			incompleteWaveColor={incompleteWaveColor}
			backgroundColor={backgroundColor}
			incompleteAlphaValue={incompleteAlphaValue}
		/>
	);
};

export default RangedAudioSelectVisualizer;
