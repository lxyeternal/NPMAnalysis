import { useRef, useEffect, useState, useCallback } from "react";
import hexToRgb from "../utils/hexToRgb";

interface Props {
	audioBlob: Blob;
	width: number;
	height: number;
	handleMoveCallback: (
		overlayCanvas: HTMLCanvasElement,
		shrinkingCanvasRef: HTMLCanvasElement,
		mousePositionX: number,
		offset: number,
		margin: number,
	) => boolean;
	onStartMoving?: (canvas: HTMLCanvasElement, positionX: number) => void;
	lineWidth: number;
	gap: number;
	progress?: number | undefined;
	waveColor?: string;
	incompleteWaveColor?: string;
	backgroundColor?: string;
	incompleteAlphaValue?: number;
}

export const AudioVisualizer = ({
	audioBlob,
	width,
	height,
	handleMoveCallback,
	onStartMoving, // for ranged select specific functions
	progress,
	lineWidth,
	gap,
	waveColor = "#ab1717",
	incompleteWaveColor,
	backgroundColor = "#f0f0f0",
	incompleteAlphaValue = 0.5,
}: Props) => {
	const canvasRef = useRef<HTMLCanvasElement>(null);
	const backgroundCanvas = useRef<HTMLCanvasElement>(null);
	const overlayCanvasRef = useRef<HTMLCanvasElement>(null);

	const [arr, setArr] = useState<number[]>([]);
	const [isMoving, setIsMoving] = useState(false);

	const singleWaveWidth = gap + lineWidth;

	const handleProgressChange = useCallback(
		(percent: number) => {
			const waveformRef = canvasRef.current;
			if (!waveformRef || !waveformRef.parentElement) return;

			// mouse pos div canvas container width - 2 (constant offset)
			const firstCanvasWidth = percent * width;
			waveformRef.parentElement.style.width =
				Math.max(Math.min(firstCanvasWidth, width), 0) + "px";
		},
		[width],
	);

	useEffect(() => {
		if (progress !== undefined) {
			handleProgressChange(progress);
		}
	}, [handleProgressChange, progress]);

	useEffect(() => {
		if (audioBlob) {
			const audioContext = new AudioContext();
			const reader = new FileReader();

			reader.onload = async () => {
				const arrayBuffer = reader.result as ArrayBuffer;
				const audioBuffer = await audioContext.decodeAudioData(arrayBuffer);
				drawWaveform(audioBuffer, canvasRef.current!);
				drawWaveform(audioBuffer, backgroundCanvas.current!, true);
			};

			reader.readAsArrayBuffer(audioBlob);
		}
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [audioBlob, gap, lineWidth, width, height]);

	const drawWaveform = (
		audioBuffer: AudioBuffer,
		canvas: HTMLCanvasElement,
		alpha: boolean = false,
	) => {
		if (!canvas) return;
		const canvasCtx = canvas.getContext("2d");
		if (!canvasCtx) return;
		const { width, height } = canvas;

		const channelData = audioBuffer.getChannelData(0); // Use the first channel

		const step =
			Math.ceil(channelData.length / (width - singleWaveWidth)) *
			(singleWaveWidth > 0 ? singleWaveWidth : 1); // Samples per pixel
		const amp = height / 2; // Vertical scaling factor

		const arr = [];
		const length = Math.ceil(channelData.length / step);
		for (let i = 0; i < length; i++) {
			const data = channelData.slice(i * step, (i + 1) * step);
			arr.push(Math.max(...data));
		}
		setArr(arr);

		canvasCtx.clearRect(0, 0, width, height);
		canvasCtx.fillStyle = backgroundColor; // Background color
		canvasCtx.fillRect(0, 0, width, height);

		canvasCtx.lineWidth = lineWidth;
		const [r, g, b] = hexToRgb(incompleteWaveColor || waveColor);

		// default to black
		canvasCtx.strokeStyle = `rgb(${r | 0} ${g | 0} ${b | 0} / ${
			alpha ? incompleteAlphaValue : 1
		})`; // Waveform color
		canvasCtx.lineCap = "round";

		// margin to center the waveform
		const margin = width - arr.length * singleWaveWidth;

		canvasCtx.beginPath();
		for (let i = 0; i < arr.length; i++) {
			// + lineWidth / 2 to center the line
			canvasCtx.moveTo(
				i * singleWaveWidth + lineWidth / 2 + Math.abs(margin / 2),
				amp - amp * arr[i],
			);
			canvasCtx.lineTo(
				i * singleWaveWidth + lineWidth / 2 + Math.abs(margin / 2),
				amp + amp * arr[i],
			);
		}

		canvasCtx.stroke();
	};

	const handleMove = useCallback(
		(
			e:
				| MouseEvent
				| TouchEvent
				| React.MouseEvent<HTMLDivElement>
				| React.TouchEvent<HTMLDivElement>,
		) => {
			const shrinkingCanvasRef = canvasRef.current;
			const overlayCanvas = overlayCanvasRef.current;
			if (
				!shrinkingCanvasRef ||
				!overlayCanvas ||
				!shrinkingCanvasRef.parentElement ||
				!arr.length
			)
				return;

			const { width, height } = overlayCanvas;
			const singleSpaceWidth = gap + lineWidth;
			const margin = width - arr.length * singleWaveWidth;
			const positionX =
				("clientX" in e ? e.clientX : e.touches[0].clientX) - margin / 2;
			const offset = shrinkingCanvasRef.getClientRects()[0].x;
			const index = Math.floor((positionX - offset) / singleSpaceWidth);

			const shouldContinue = handleMoveCallback(
				overlayCanvas,
				shrinkingCanvasRef,
				positionX,
				offset,
				margin,
			);
			if (!shouldContinue) return;

			const canvasCtx = overlayCanvas.getContext("2d");
			if (!canvasCtx) return;
			const amp = height / 2; // Vertical scaling factor
			canvasCtx.clearRect(0, 0, width, height);

			canvasCtx.lineWidth = lineWidth;
			canvasCtx.strokeStyle = waveColor; // Waveform color
			canvasCtx.lineCap = "round";
			canvasCtx.beginPath();

			canvasCtx.moveTo(
				index * singleSpaceWidth + lineWidth / 2 + margin / 2,
				// the round cap equals half of the line width _ plus a margin
				Math.max(amp - amp * arr[index] * 1.5, lineWidth / 2 + 5),
			);
			canvasCtx.lineTo(
				index * singleSpaceWidth + lineWidth / 2 + margin / 2,
				// the round cap equals half of the line width _ plus a margin
				Math.min(amp + amp * arr[index] * 1.5, height - lineWidth / 2 - 5),
			);
			canvasCtx.stroke();
		},
		[arr, gap, lineWidth, singleWaveWidth, handleMoveCallback, waveColor],
	);

	const handleEndEvent = useCallback(() => {
		setIsMoving(false);
		document.removeEventListener("mousemove", handleMove);
		document.removeEventListener("touchmove", handleMove);
	}, [handleMove]);

	useEffect(() => {
		if (isMoving) {
			document.addEventListener("mousemove", handleMove);
			document.addEventListener("touchmove", handleMove);
			document.addEventListener("mouseup", handleEndEvent);
			document.addEventListener("touchend", handleEndEvent);
		}

		return () => {
			document.removeEventListener("mousemove", handleMove);
			document.removeEventListener("touchmove", handleMove);
			document.removeEventListener("mouseup", handleEndEvent);
			document.removeEventListener("touchend", handleEndEvent);
		};
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [isMoving]);

	return (
		<div
			id="wrapper"
			style={{
				position: "relative",
				width: width + "px",
			}}
			onTouchStart={(e) => {
				if (onStartMoving)
					onStartMoving(canvasRef.current!, e.touches[0].clientX);
				setIsMoving(true);
				handleMove(e);
			}}
			onMouseDown={(e) => {
				if (onStartMoving) onStartMoving(canvasRef.current!, e.clientX);
				setIsMoving(true);
				handleMove(e);
			}}
		>
			<div
				id="first-canvas-container"
				style={{
					position: "absolute",
					left: "0",
					overflow: "hidden",
				}}
			>
				<canvas ref={canvasRef} width={width} height={height} />
			</div>
			<div
				id="second-canvas-container"
				style={{
					left: "0",
				}}
			>
				<canvas ref={backgroundCanvas} width={width} height={height} />
			</div>
			<canvas
				ref={overlayCanvasRef}
				width={width}
				height={isMoving ? height : 0}
				style={{
					position: "absolute",
					left: "0",
					top: "0",
				}}
			/>
		</div>
	);
};
