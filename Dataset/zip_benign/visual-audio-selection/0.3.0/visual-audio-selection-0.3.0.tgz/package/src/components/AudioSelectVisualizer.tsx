import { useCallback } from "react";
import { AudioVisualizer } from "./Visualizer";
import { UnilateralVisualizerProps } from "../types/visualizer";

/**
 * JSX Component for audio visualization select
 * @param {Blob} props.audioBlob blob of audio file
 * @param {number} props.width width of the canvas
 * @param {number} props.height height of the canvas
 * @param {number} props.gap gap between the lines - default is 0
 * @param {number} props.lineWidth width of the lines - default is 1
 * @param {number} props.progress progress of the audio
 * @param {boolean} props.isPlaying indicates if the audio is playing
 * @param {(percent: number) => void} props.onChange callback function to be called when a new range is selected - percent 0-1.
 * @param {string} props.waveColor hex value of the lines color
 * @param {string} props.incompleteWaveColor hex value of the lines color when not selected
 * @param {string} props.backgroundColor hex value of the background color
 * @param {number} props.incompleteAlphaValue alpha value of the lines when not selected - default is 0.5
 * @returns
 */
const AudioSelectVisualizer = ({
	audioBlob,
	width,
	height,
	gap = 0,
	lineWidth = 1,
	progress,
	isPlaying,
	onChange,
	waveColor = "#ab1717",
	incompleteWaveColor,
	backgroundColor = "#f0f0f0",
	incompleteAlphaValue = 0.5,
}: UnilateralVisualizerProps) => {
	const adjustedLineWidth = Math.max(lineWidth, 0); // floor is 0
	const adjustedGap = Math.max(gap, 0); // floor is 0

	const handleMove = useCallback(
		(
			singleLineCanvas: HTMLCanvasElement,
			shrinkingCanvasRef: HTMLCanvasElement,
			mousePositionX: number,
			offset: number,
			margin: number,
		) => {
			const { width } = singleLineCanvas;
			const x = adjustedGap + adjustedLineWidth;

			// index relative to how many lines fit in the mouse x-position
			const index = Math.floor((mousePositionX - offset) / x);

			// Clip the progress to a line
			const clip = ((index * x + adjustedLineWidth + margin / 2) / width) * 100;
			shrinkingCanvasRef.parentElement!.style.width =
				Math.max(Math.min(clip, 100), 0).toString() + "%";

			// Get the mouse position relative to the shrank canvas container in percentage
			const firstCanvasWidth =
				(mousePositionX - offset) / Number(shrinkingCanvasRef.width);
			if (onChange) onChange(firstCanvasWidth);

			return true;
		},
		[adjustedLineWidth, adjustedGap, onChange],
	);

	return (
		<AudioVisualizer
			audioBlob={audioBlob}
			height={height}
			width={width}
			handleMoveCallback={handleMove}
			progress={isPlaying ? progress : undefined}
			gap={adjustedGap}
			lineWidth={adjustedLineWidth}
			waveColor={waveColor}
			incompleteWaveColor={incompleteWaveColor}
			backgroundColor={backgroundColor}
			incompleteAlphaValue={incompleteAlphaValue}
		/>
	);
};

export default AudioSelectVisualizer;
