const hexToRgb = (hex: string) =>
	hex
		.replace(
			/^#?([a-f\d])([a-f\d])([a-f\d])$/i,
			(r, g, b) => "#" + r + r + g + g + b + b,
		)
		.substring(1)
		.match(/.{2}/g)
		?.map((x) => parseInt(x, 16)) ?? [];

export default hexToRgb;
