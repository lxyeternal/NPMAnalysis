/**
 * JSX Component for audio visualization select
 * @param {Blob} props.audioBlob blob of audio file
 * @param {number} props.width width of the canvas
 * @param {number} props.height height of the canvas
 * @param {number} props.gap gap between the lines - default is 0
 * @param {number} props.lineWidth width of the lines - default is 1
 * @param {number} props.progress progress of the audio
 * @param {(percent: number) => void} props.onChange callback function to be called when a new range is selected
 * @param {string} props.waveColor hex value of the lines color
 * @param {string} props.incompleteWaveColor hex value of the lines color when not selected
 * @param {string} props.backgroundColor hex value of the background color
 * @param {number} props.incompleteAlphaValue alpha value of the lines when not selected - default is 0.5
 * @returns
 */
declare const AudioSelectVisualizer: ({ audioBlob, width, height, gap, lineWidth, progress, onChange, waveColor, incompleteWaveColor, backgroundColor, incompleteAlphaValue, }: {
    audioBlob: Blob;
    width: number;
    height: number;
    lineWidth?: number;
    gap?: number;
    progress?: number;
    onChange?: (percent: number) => void;
    waveColor?: string;
    incompleteWaveColor?: string;
    backgroundColor?: string;
    incompleteAlphaValue?: number;
}) => import("react/jsx-runtime").JSX.Element;
export default AudioSelectVisualizer;
