/**
 * JSX Component for audio visualization select
 * @param {Blob} props.audioBlob blob of audio file
 * @param {number} props.width width of the canvas
 * @param {number} props.height height of the canvas
 * @param {number} props.gap gap between the lines - default is 0
 * @param {number} props.lineWidth width of the lines - default is 1
 * @param {number} props.progress progress of the audio
 * @param {(percent: number) => void} props.onChange callback function to be called when a new range is selected
 * @param {string} props.waveColor color of the lines
 * @param {string} props.incompleteWaveColor color of the lines when not selected
 * @param {string} props.backgroundColor color of the background
 * @param {number} props.incompleteAlphaValue alpha value of the lines when not selected
 * @returns
 */
declare const RangedAudioSelectVisualizer: ({ audioBlob, width, height, gap, lineWidth, progress, onChange, waveColor, incompleteWaveColor, backgroundColor, incompleteAlphaValue, }: {
    audioBlob: Blob;
    width: number;
    height: number;
    lineWidth?: number;
    gap?: number;
    progress?: number;
    onChange?: (start: number, end: number) => void;
    waveColor?: string;
    incompleteWaveColor?: string;
    backgroundColor?: string;
    incompleteAlphaValue?: number;
}) => import("react/jsx-runtime").JSX.Element;
export default RangedAudioSelectVisualizer;
