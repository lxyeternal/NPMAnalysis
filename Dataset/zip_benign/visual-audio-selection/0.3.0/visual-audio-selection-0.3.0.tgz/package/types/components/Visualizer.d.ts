export declare const AudioVisualizer: ({ audioBlob, width, height, handleMoveCallback, onProgressChange, onStartMoving, progress, lineWidth, gap, waveColor, incompleteWaveColor, backgroundColor, incompleteAlphaValue, }: {
    audioBlob: Blob;
    width: number;
    height: number;
    handleMoveCallback: (overlayCanvas: HTMLCanvasElement, shrinkingCanvasRef: HTMLCanvasElement, mousePositionX: number, offset: number, margin: number) => boolean;
    onProgressChange?: (percent: number) => void;
    onStartMoving?: (canvas: HTMLCanvasElement, positionX: number) => void;
    lineWidth: number;
    gap: number;
    progress?: number;
    waveColor?: string;
    incompleteWaveColor?: string;
    backgroundColor?: string;
    incompleteAlphaValue?: number;
}) => import("react/jsx-runtime").JSX.Element;
