declare const hexToRgb: (hex: string) => number[];
export default hexToRgb;
