import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import path from "path";
import dts from "vite-plugin-dts";
// import * as packageJson from "./package.json";

// https://vitejs.dev/config/
export default defineConfig({
	plugins: [
		react(),
		dts({
			tsconfigPath: "./tsconfig.app.json",
			entryRoot: "./src",
			outDir: "./dist/types",
			insertTypesEntry: true,
		}),
	],
	build: {
		lib: {
			entry: path.resolve(__dirname, "src/index.ts"),
			name: "AudioSelectVisualizer",
			fileName: (format) => `audio-select-visualizer.${format}.js`,
		},
		rollupOptions: {
			external: ["react", "react-dom"],
			// external: [...Object.keys(packageJson.dependencies)],
			output: {
				globals: {
					react: "React",
				},
			},
		},
		sourcemap: true,
		emptyOutDir: true,
	},
});
