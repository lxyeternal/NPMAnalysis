'use strict';

function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var postcss = _interopDefault(require('postcss'));

const NUMBER = /^(?!0+\d?$)^[+-]?\d*\.?\d*$/g;
const QUANTITY = /(?<number>[+-]?\d*\.?\d)(?<unit>\w+)?/;

const object = {
  padding: [{
    name: "top",
    raw: null,
    number: 0,
    unit: "",
    ratio: false,
    value: null
  }, {
    name: "right",
    raw: null,
    number: 0,
    unit: "",
    ratio: false,
    value: null
  }, {
    name: "bottom",
    raw: null,
    number: 0,
    unit: "",
    ratio: false,
    value: null
  }, {
    name: "left",
    raw: null,
    number: 0,
    unit: "",
    ratio: false,
    value: null
  }],
  margin: [{
    name: "top",
    raw: null,
    number: 0,
    unit: "",
    ratio: false,
    value: null
  }, {
    name: "right",
    raw: null,
    number: 0,
    unit: "",
    ratio: false,
    value: null
  }, {
    name: "bottom",
    raw: null,
    number: 0,
    unit: "",
    ratio: false,
    value: null
  }, {
    name: "left",
    raw: null,
    number: 0,
    unit: "",
    ratio: false,
    value: null
  }]
};
function getProperties(rule, property) {
  var ratio = false; // Check if properties in rule contain a unitless number

  rule.walkDecls(/padding|margin/, decl => {
    const values = postcss.list.space(decl.value);

    for (let a = 0; a < values.length; a++) {
      if (values[a].match(NUMBER)) {
        ratio = true;
      }
    }
  });

  if (ratio) {
    // For each property which matches property
    rule.walkDecls(decl => {
      var regex2 = new RegExp("^" + property + "$");
      var regex3 = new RegExp("^" + property + "-");
      let sides = object[property]; // For shorthand properties

      if (decl.prop.match(regex2)) {
        // Populate values from shorthand notation
        let values = postcss.list.space(decl.value);

        switch (values.length) {
          case 1:
            values.push(values[0]);
          // falls through

          case 2:
            values.push(values[0]);
          // falls through

          case 3:
            values.push(values[1]);
        } // For each side record value in object


        for (let a = 0; a < sides.length; a++) {
          let side = sides[a];
          sides[a].raw = values[a];

          if (values[a].match(QUANTITY)) {
            sides[a].number = Number(values[a].match(QUANTITY)[1]);
            sides[a].unit = values[a].match(QUANTITY)[2] ? values[a].match(QUANTITY)[2] : "";
            sides[a].ratio = values[a].match(NUMBER) ? true : false;
          }
        }
      } // / For sub properties


      if (decl.prop.match(regex3)) {
        for (let a = 0; a < sides.length; a++) {
          let side = sides[a];

          if (decl.prop === property + "-" + side.name) {
            sides[a].raw = decl.value;
            sides[a].number = Number(decl.value.match(QUANTITY)[1]);
            sides[a].unit = decl.value.match(QUANTITY)[2] ? decl.value.match(QUANTITY)[2] : "";
            sides[a].ratio = decl.value.match(NUMBER) ? true : false;
          }
        }
      }
    });
  } // console.log("-------");
  // console.log(object);


  return object[property];
}
function setValues(property) {
  let sides = object[property];

  for (let a = 0; a < sides.length; a++) {
    let current = sides[a];
    let total = sides.length;
    let x = (total - (a + 1)) % 2;
    let y = a + (Math.floor(a / (total / 2)) * -total + total / 2);
    let topOrRight = sides[x];
    let bottomOrLeft = sides[x + 2];
    let opposite = sides[y];

    if (current.number === 0) {
      current.value = 0;
    }

    if (current.ratio) {
      if (topOrRight.ratio || topOrRight.raw === null) {
        if (bottomOrLeft.ratio || bottomOrLeft.raw === null) {
          if (opposite.ratio || opposite.raw === null) {
            current.value = current.number * topOrRight.number * opposite.number + topOrRight.unit;
          } else {
            current.value = opposite.number * topOrRight.number * current.number + opposite.unit;
          }
        } else {
          current.value = bottomOrLeft.number * current.number + bottomOrLeft.unit;
        }
      } else {
        current.value = current.number * topOrRight.number + topOrRight.unit;
      }
    } else {
      current.value = current.raw;
    }
  }
}

const NUMBER$1 = /^(?!0+\d?$)^[+-]?\d*\.?\d*$/g;
function replaceValues(rule, name) {
  rule.walkDecls(decl => {
    // More accurate way of processing CSS
    var regex2 = new RegExp("^" + name + "$");
    var regex3 = new RegExp("^" + name + "-");
    let values = postcss.list.space(decl.value);
    let newValue = [];

    if (decl.prop.match(regex2)) {
      for (let a = 0; a < values.length; a++) {
        if (values[a].match(NUMBER$1)) {
          if (a === 0) {
            newValue.push(object[name][a].value);
          }

          if (a === 1) {
            newValue.push(object[name][a].value);
          }

          if (a === 2) {
            newValue.push(object[name][a].value);
          }

          if (a === 3) {
            newValue.push(object[name][a].value);
          }
        } else {
          newValue.push(values[a]);
        }
      }

      decl.value = newValue.join(" ");
    }

    if (decl.prop.match(regex3)) {
      if (decl.value.match(NUMBER$1)) {
        if (decl.prop === name + "-top") {
          decl.value = object[name][0].value;
        }

        if (decl.prop === name + "-right") {
          decl.value = object[name][1].value;
        }

        if (decl.prop === name + "-bottom") {
          decl.value = object[name][2].value;
        }

        if (decl.prop === name + "-left") {
          decl.value = object[name][3].value;
        }
      }
    }
  });
} // Simpler but not as accurate
// for (let side in padding) {
//
// 	if (padding[side].match(NUMBER)) {
// 		let number;
// 		let unit;
// 		if (side === "top" || side === "bottom") {
// 			number = padding["right"].match(QUANTITY)[1];
// 			unit = padding["right"].match(QUANTITY)[2];
// 			number *= padding[side];
// 		}
// 		if (side === "right" || side === "left") {
//
// 			number = padding["top"].match(QUANTITY)[1];
// 			unit = padding["top"].match(QUANTITY)[2];
// 			number *= padding[side];
// 		}
// 		rule.append({ prop: 'padding-' + side, value: number + unit })
// 	}
// 	else {
// 		rule.append({ prop: 'padding-' + side, value: padding[side] })
// 	}
//
// }

var index = postcss.plugin("postcss-proportional-spacing", opts => {
  console.log("opts", opts);
  return root => {
    root.walkRules(rule => {
      getProperties(rule, "padding");
      setValues("padding");
      replaceValues(rule, "padding");
      getProperties(rule, "margin");
      setValues("margin");
      replaceValues(rule, "margin");
    });
  };
});

module.exports = index;
//# sourceMappingURL=index.cjs.js.map
