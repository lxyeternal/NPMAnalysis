package com.library.rnrecyclerview.collapsed;

import androidx.annotation.NonNull;

import com.facebook.react.uimanager.ThemedReactContext;
import com.facebook.react.uimanager.ViewGroupManager;

public class NormalItemViewManager extends ViewGroupManager<NormalItemView> {

    private final static String NAME = "NormalItemView";

    @NonNull
    @Override
    public String getName() {
        return NAME;
    }

    @NonNull
    @Override
    protected NormalItemView createViewInstance(@NonNull ThemedReactContext reactContext) {
        return new NormalItemView(reactContext);
    }
}
