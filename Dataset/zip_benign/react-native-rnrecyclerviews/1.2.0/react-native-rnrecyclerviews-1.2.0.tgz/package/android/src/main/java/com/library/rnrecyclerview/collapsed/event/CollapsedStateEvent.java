package com.library.rnrecyclerview.collapsed.event;

import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.uimanager.events.Event;
import com.facebook.react.uimanager.events.RCTEventEmitter;

public class CollapsedStateEvent extends Event<CollapsedStateEvent> {

    public static final String EVENT_NAME = "CollapsedState";

    private final int state;

    public CollapsedStateEvent(int viewTag, int state) {
        super(viewTag);
        this.state = state;
    }

    @Override
    public String getEventName() {
        return EVENT_NAME;
    }


    @Override
    public void dispatch(RCTEventEmitter rctEventEmitter) {
        WritableMap data = Arguments.createMap();
        data.putInt("state", state);
        rctEventEmitter.receiveEvent(getViewTag(), EVENT_NAME, data);
    }
}
