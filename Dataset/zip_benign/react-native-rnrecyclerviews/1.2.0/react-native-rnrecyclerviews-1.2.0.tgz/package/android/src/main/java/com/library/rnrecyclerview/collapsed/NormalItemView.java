package com.library.rnrecyclerview.collapsed;

import android.content.Context;
import android.view.View;
import android.widget.FrameLayout;

/**
 * 折叠布局
 */
public class NormalItemView extends FrameLayout {

    public NormalItemView(Context context) {
        super(context);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        if (getChildCount() > 0) {
            View child = getChildAt(0);
            if (child.getMeasuredHeight() > 0 && child.getMeasuredWidth() > 0) {
                int mLastMeasuredWidth = child.getMeasuredWidth();
                int mLastMeasuredHeight = child.getMeasuredHeight();
                setMeasuredDimension(mLastMeasuredWidth, mLastMeasuredHeight);
                return;
            }
        }
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);

    }
}
