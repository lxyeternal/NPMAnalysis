package com.library.rnrecyclerview.collapsed;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;

/**
 * 折叠布局
 */
public class CollapsedItemView extends ViewGroup {

    private int mLastMeasuredWidth;
    private int mLastMeasuredHeight;

    public CollapsedItemView(Context context) {
        super(context);
        mLastMeasuredHeight = 1;
        mLastMeasuredWidth = 1;
    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {

    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        if (getChildCount() > 0) {
            View child = getChildAt(0);
            mLastMeasuredWidth = child.getMeasuredWidth();
            mLastMeasuredHeight = child.getMeasuredHeight();
        }
        setMeasuredDimension(mLastMeasuredWidth, mLastMeasuredHeight);
    }
}
