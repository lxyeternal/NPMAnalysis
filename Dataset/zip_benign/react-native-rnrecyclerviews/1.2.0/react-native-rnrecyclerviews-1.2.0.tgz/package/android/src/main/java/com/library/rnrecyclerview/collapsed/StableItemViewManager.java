package com.library.rnrecyclerview.collapsed;

import androidx.annotation.NonNull;

import com.facebook.react.uimanager.ThemedReactContext;
import com.facebook.react.uimanager.ViewGroupManager;

public class StableItemViewManager extends ViewGroupManager<StableItemView> {

    private final static String NAME = "StableItemView";

    @NonNull
    @Override
    public String getName() {
        return NAME;
    }

    @NonNull
    @Override
    protected StableItemView createViewInstance(@NonNull ThemedReactContext reactContext) {
        return new StableItemView(reactContext);
    }
}
