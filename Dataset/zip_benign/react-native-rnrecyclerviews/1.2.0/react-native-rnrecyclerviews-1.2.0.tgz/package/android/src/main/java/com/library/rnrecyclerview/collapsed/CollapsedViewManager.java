package com.library.rnrecyclerview.collapsed;

import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.facebook.react.common.MapBuilder;
import com.facebook.react.uimanager.ThemedReactContext;
import com.facebook.react.uimanager.ViewGroupManager;
import com.library.rnrecyclerview.collapsed.event.CollapsedStateEvent;

import java.util.Map;

public class CollapsedViewManager extends ViewGroupManager<CollapsedView> {

    private static final String NAME = "CollapsedView";

    @NonNull
    @Override
    public String getName() {
        return NAME;
    }

    @NonNull
    @Override
    protected CollapsedView createViewInstance(@NonNull ThemedReactContext reactContext) {
        return new CollapsedView(reactContext);
    }

    @Override
    public void addView(CollapsedView parent, View child, int index) {
        if (child instanceof CollapsedItemView) {
            parent.addCollapseView(((CollapsedItemView) child));
        } else if (child instanceof StableItemView) {
            parent.addStableView(((StableItemView) child));
        } else if (child instanceof NormalItemView) {
            parent.addNormalView(((NormalItemView) child));
        }
    }

    @Override
    public int getChildCount(CollapsedView parent) {
        return parent.getChildCount();
    }

    @Override
    public View getChildAt(CollapsedView parent, int index) {
        return parent.getChildAt(0);
    }

    @Override
    public void removeViewAt(CollapsedView parent, int index) {
        parent.removeViewAt(0);
    }

    @Nullable
    @Override
    public Map<String, Object> getExportedCustomBubblingEventTypeConstants() {
        return MapBuilder.<String, Object>builder()
                .put(CollapsedStateEvent.EVENT_NAME, MapBuilder.of("phasedRegistrationNames", MapBuilder.of("bubbled", "onCollapsedState")))
                .build();
    }
}
