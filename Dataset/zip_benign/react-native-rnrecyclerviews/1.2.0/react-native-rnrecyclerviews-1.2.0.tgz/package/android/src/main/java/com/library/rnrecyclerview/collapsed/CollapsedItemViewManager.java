package com.library.rnrecyclerview.collapsed;

import androidx.annotation.NonNull;

import com.facebook.react.uimanager.ThemedReactContext;
import com.facebook.react.uimanager.ViewGroupManager;

public class CollapsedItemViewManager extends ViewGroupManager<CollapsedItemView>{

    private final static String NAME = "CollapsedItemView";

    @NonNull
    @Override
    public String getName() {
        return NAME;
    }

    @NonNull
    @Override
    protected CollapsedItemView createViewInstance(@NonNull ThemedReactContext reactContext) {
        return new CollapsedItemView(reactContext);
    }
}
