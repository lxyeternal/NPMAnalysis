
package com.library.rnrecyclerview;

import androidx.annotation.NonNull;

import com.facebook.react.ReactPackage;
import com.facebook.react.bridge.NativeModule;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.uimanager.ViewManager;
import com.library.rnrecyclerview.collapsed.CollapsedItemViewManager;
import com.library.rnrecyclerview.collapsed.CollapsedViewManager;
import com.library.rnrecyclerview.collapsed.NormalItemViewManager;
import com.library.rnrecyclerview.collapsed.StableItemViewManager;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class RNRecyclerviewPackage implements ReactPackage {
    @NonNull
    @Override
    public List<NativeModule> createNativeModules(@NonNull ReactApplicationContext reactContext) {
        return Collections.emptyList();
    }

    @NonNull
    @Override
    public List<ViewManager> createViewManagers(@NonNull ReactApplicationContext reactContext) {
        return Arrays.asList(
                new RecyclerViewBackedScrollViewManager(),
                new RecyclerViewItemViewManager(),
                new RecyclerViewEmptyViewManager(),
                new RecyclerViewHeaderViewManager(),
                new RecyclerViewFooterViewManager(),

                new CollapsedViewManager(),
                new CollapsedItemViewManager(),
                new StableItemViewManager(),
                new NormalItemViewManager()
        );
    }
}
