package com.library.rnrecyclerview.collapsed;

import android.content.Context;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;
import androidx.coordinatorlayout.widget.CoordinatorLayout;

import com.facebook.react.bridge.ReactContext;
import com.facebook.react.uimanager.ThemedReactContext;
import com.facebook.react.uimanager.UIManagerModule;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.appbar.CollapsingToolbarLayout;
import com.library.rnrecyclerview.R;
import com.library.rnrecyclerview.collapsed.event.CollapsedStateEvent;

public class CollapsedView extends FrameLayout {

    private final AppBarLayout appBarLayout;
    private final CoordinatorLayout coordinatorLayout;
    private final CollapsingToolbarLayout collapsingToolbarLayout;
    private final UIManagerModule nativeModule;

    public CollapsedView(@NonNull Context context) {
        super(context);
        inflate(context, R.layout.collapsed_layout, this);
        coordinatorLayout = findViewById(R.id.coordinator);
        appBarLayout = findViewById(R.id.app_bar_layout);
        collapsingToolbarLayout = findViewById(R.id.collapsing_toolbar_layout);
        collapsedListener();
        nativeModule = getReactContext().getNativeModule(UIManagerModule.class);
    }

    private ReactContext getReactContext() {
        return ((ThemedReactContext) getContext());
    }

    private void collapsedListener() {
        appBarLayout.addOnOffsetChangedListener(new CollapsedStateListener() {
            @Override
            public void onStateChanged(AppBarLayout appBarLayout, State state, int offset) {
                if (state == State.EXPANDED) {
                    //展开
                    nativeModule.getEventDispatcher().dispatchEvent(new CollapsedStateEvent(getId(), 0));

                } else if (state == State.COLLAPSED) {
                    //折叠
                    nativeModule.getEventDispatcher().dispatchEvent(new CollapsedStateEvent(getId(), 1));

                } else {
                    //中间状态
                    nativeModule.getEventDispatcher().dispatchEvent(new CollapsedStateEvent(getId(), 2));
                }
            }
        });
    }

    /**
     * 折叠 view
     *
     * @param view v
     */
    public void addCollapseView(CollapsedItemView view) {
        ViewParent parent = view.getParent();
        if (parent instanceof ViewGroup) {
            ((ViewGroup) parent).removeView(view);
        }
        collapsingToolbarLayout.addView(view, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    /**
     * 吸顶 view
     *
     * @param view v
     */
    public void addStableView(StableItemView view) {
        ViewParent parent = view.getParent();
        if (parent instanceof ViewGroup) {
            ((ViewGroup) parent).removeView(view);
        }
        appBarLayout.addView(view, 1, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    /**
     * 正常 view
     *
     * @param view v
     */
    public void addNormalView(NormalItemView view) {
        ViewParent parent = view.getParent();
        if (parent instanceof ViewGroup) {
            ((ViewGroup) parent).removeView(view);
        }
        CoordinatorLayout.LayoutParams layoutParams = new CoordinatorLayout.LayoutParams(-1, -1);
        AppBarLayout.ScrollingViewBehavior scrollingViewBehavior = new AppBarLayout.ScrollingViewBehavior();
        layoutParams.setBehavior(scrollingViewBehavior);
        coordinatorLayout.addView(view, layoutParams);
    }

}
