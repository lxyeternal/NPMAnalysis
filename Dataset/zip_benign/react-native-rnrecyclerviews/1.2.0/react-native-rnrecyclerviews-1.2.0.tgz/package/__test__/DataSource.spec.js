import DataSource from '../src/DataSource';

describe('DataSource class unit test launched without crashing', () => {
    it('should be contructed with expected properties and values', async () => {
        const mockData = [1, 2, 3, 4];
        const mockKeyExtractor = (item, index) => {
            return JSON.stringify(item) + '_' + index;
        };
        const testitate = new DataSource(mockData, mockKeyExtractor);
        await expect(testitate).toHaveProperty(['_data'], [1, 2, 3, 4]);
        await expect(testitate).toHaveProperty(['_keyExtractor'], mockKeyExtractor);
        await expect(testitate).toHaveProperty(['_listeners'], []);
        console.info('测试对象1    DataSource');
        console.info('mockData:::', mockData);
        console.info('mockKeyExtractor:::', mockKeyExtractor);
    });
});
