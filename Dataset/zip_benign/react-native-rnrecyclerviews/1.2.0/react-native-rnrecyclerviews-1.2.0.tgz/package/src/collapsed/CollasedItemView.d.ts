export default class CollapsedItemView {
    static propTypes: {
        style: any;
        renderItem: any;
    };

    render(): any;
}
