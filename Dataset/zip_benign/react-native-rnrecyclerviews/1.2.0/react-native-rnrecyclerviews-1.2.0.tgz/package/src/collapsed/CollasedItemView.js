import React, {Component} from 'react';
import {requireNativeComponent, ViewPropTypes} from 'react-native';
import PropTypes from 'prop-types';

export default class CollapsedItemView extends Component {
    static propTypes = {
        style: ViewPropTypes.style,
        renderItem: PropTypes.func | PropTypes.element,
    };

    render() {
        const {style, renderItem} = this.props;
        return (
            <NativeCollapsedView
                style={style}>
                {renderItem}
            </NativeCollapsedView>
        );
    }
}

const NativeCollapsedView = requireNativeComponent('CollapsedItemView');
