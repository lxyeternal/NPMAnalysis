import React from 'react';
import {ViewProps} from "react-native";


export interface CollapsedViewInterface {
    CollapseComponent?: React.ComponentType<any> | React.ReactElement;
    StableComponent: React.ComponentType<any> | React.ReactElement;
    NormalComponent: React.ComponentType<any> | React.ReactElement;
    onCollapsedState?: Function;
}

/**
 * 吸顶布局，结合RNRecyclerView使用
 */
export default class CollapsedView extends React.Component<CollapsedViewInterface & ViewProps> {

    static propTypes: any;

    render(): any;
}
