export default class NormalItemView {
    static propTypes: {
        style: any;
        renderItem: any;
    };
    render(): any;
}
