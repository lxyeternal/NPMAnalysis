import React, {PureComponent} from 'react';
import {requireNativeComponent, StyleSheet, View} from 'react-native';
import PropTypes from 'prop-types';
import NormalItemView from './NormalItemView';
import CollapsedItemView from './CollasedItemView';
import StableItemView from './StableItemView';


export default class CollapsedView extends PureComponent {
    static propTypes = {
        ...View.propTypes,
        onCollapsedState: PropTypes.func,
        CollapseComponent: PropTypes.element,
        StableComponent: PropTypes.element.isRequired,
        NormalComponent: PropTypes.element.isRequired,
    };

    render() {
        const {
            style,
            onCollapsedState,
            CollapseComponent,
            StableComponent,
            NormalComponent,
            ...rest
        } = this.props;
        let body = [];//item集合
        if (CollapseComponent) {
            body.push(
                <CollapsedItemView
                    style={styles.absolute}
                    renderItem={CollapseComponent}/>,
            );
        }
        if (StableComponent) {
            body.push(
                <StableItemView
                    style={styles.absolute}
                    renderItem={StableComponent}/>,
            );
        }
        if (NormalComponent) {
            body.push(
                <NormalItemView
                    style={styles.absolute}
                    renderItem={NormalComponent}/>,
            );
        }
        return (
            <NativeCollapsedView
                onCollapsedState={this._onState}
                style={style}
                {...rest}>
                {body}
            </NativeCollapsedView>
        );
    }

    _onState = (event) => {
        const {onState} = this.props;
        if (onState) {
            onState(event.nativeEvent.state);
        }
    };
}
const nativeOnlyProps = {
    nativeOnly: {
        onCollapsedState: true,
    },
};

const styles = StyleSheet.create({
    absolute: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
    },
});

const NativeCollapsedView = requireNativeComponent('CollapsedView', CollapsedView, nativeOnlyProps);

module.exports = CollapsedView;
