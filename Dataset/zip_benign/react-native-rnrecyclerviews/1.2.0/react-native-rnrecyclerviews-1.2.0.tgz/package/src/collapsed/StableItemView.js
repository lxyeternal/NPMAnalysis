import React, {Component} from 'react';
import {requireNativeComponent, ViewPropTypes} from 'react-native';
import PropTypes from 'prop-types';

export default class StableItemView extends Component {
    static propTypes = {
        style: ViewPropTypes.style,
        renderItem: PropTypes.func | PropTypes.element,
    };

    render() {
        const {style, renderItem} = this.props;
        return (
            <NativeStableItemView
                style={style}>
                {renderItem}
            </NativeStableItemView>
        );
    }
}

const NativeStableItemView = requireNativeComponent('StableItemView');
