export default class StableItemView {
    static propTypes: {
        style: any;
        renderItem: any;
    };
    render(): any;
}
