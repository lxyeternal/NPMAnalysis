import React, {Component} from 'react';
import {Button, Image, StyleSheet, Text, ToastAndroid, TouchableNativeFeedback, View,} from 'react-native';
import DataSource from '../DataSource';
import CollapsedView from '../collapsed/CollapsedView';
import RNRecyclerView from '../RNRecyclerView';

let _gCounter = 1;

function newItem() {
    return {
        id: _gCounter++,
        counter: 0,
    };
}

const layoutArray = [1, 2, 4];


/**
 * the example of RNRecyclerView
 */
export default class CollapsedViewTest extends Component {
    constructor(props) {
        super(props);
        const data = Array(100).fill().map((e, i) => newItem());

        this.state = {
            dataSource: new DataSource(data, (item, index) => item.id),
            inverted: false,
        };
    }

    render() {
        const {dataSource, inverted} = this.state;
        return (
            <CollapsedView
                style={styles.container}
                onState={this._onStates}
                CollapseComponent={this.renderCollapseView()}
                StableComponent={
                    <View style={{
                        flexDirection: 'column',
                        padding: 5,
                        zIndex: 10,
                        alignItems: 'center',
                        justifyContent: 'center',
                        backgroundColor: '#e7e7e7',
                    }}>
                        {this.renderTopControlPanel()}
                        {this.renderTopControlPanel2()}
                    </View>
                }
                NormalComponent={
                    <RNRecyclerView
                        layoutType={layoutArray}
                        onBottom={this.onBottom}
                        onTop={this.onTop}
                        onLoadMore={this.onLoadMore}
                        ref={(component) => this._recycler = component}
                        style={{
                            flex: 1,
                            width: '100%',
                            height: '100%',
                        }}
                        inverted={inverted}
                        dataSource={dataSource}
                        renderItem={this.renderItem}
                        ListHeaderComponent={header()}
                        ListFooterComponent={footer()}
                        ListEmptyComponent={empty()}
                    />
                }

            />
        );
    }

    renderItem = (item, index) => {
        return (
            <Item
                item={item}
                index={index}
                onRemove={() => this.remove(index)}
                onAddAbove={() => this.addAbove(index)}
                onMoveUp={() => this.moveUp(index)}
                onMoveDown={() => this.moveDown(index)}
                onAddBelow={() => this.addBelow(index)}
                onIncrementCounter={() => this.incrementCounter(index)}
                dataSource={this.state.dataSource}/>
        );
    };


    renderCollapseView() {
        return <View style={{
            flex: 1,
            alignItems: 'center',
            backgroundColor: '#fff',
            justifyContent: 'center',
            width: '100%',
            height: 100,
        }}>
            <Text style={{fontSize: 15}}>折叠区域</Text>
        </View>;
    }

    renderTopControlPanel() {
        return (
            <View style={{
                flexDirection: 'row',
                padding: 5,
                zIndex: 10,
                alignItems: 'center',
                justifyContent: 'center',
                backgroundColor: '#e7e7e7',
            }}>
                <Button
                    title={'加载20条'}
                    onPress={() => this.addToBottom(20)}/>
                <View style={{width: 10}}/>
                <Button
                    title={'重新加载30条'}
                    onPress={() => this.reset(30)}/>

                <View style={{width: 10}}/>
                <Button
                    title={'滚动到顶'}
                    onPress={() => this.toTop()}/>

                <View style={{width: 10}}/>
                <Button
                    title={'滚动到底'}
                    onPress={() => this.toBottom()}/>
            </View>
        );
    }

    renderTopControlPanel2() {
        return (
            <View style={{
                flexDirection: 'row',
                padding: 5,
                zIndex: 10,
                alignItems: 'center',
                justifyContent: 'center',
                backgroundColor: '#e7e7e7',
            }}>
                <Button
                    title={'反转'}
                    onPress={() => this.inverted()}/>
                <View style={{width: 10}}/>

                <Button
                    title={'置空'}
                    onPress={() => this.clear()}/>
                <View style={{width: 10}}/>

                <Button
                    title={'数据变空'}
                    onPress={() => this.empty()}/>
                <View style={{width: 10}}/>

                <Button
                    title={'更新第一条数据'}
                    onPress={() => this.updateFirst()}/>
                <View style={{width: 10}}/>

            </View>
        );
    }

    inverted() {
        this.setState({
            inverted: !this.state.inverted,
        });
    }

    updateFirst() {
        this.state.dataSource.set(1, newItem());
    }

    empty() {
        this.state.dataSource.splice(0, this.state.dataSource.size());
        this._recycler._setLayoutManager(layoutArray);//重新设置layoutManager可解决刷新问题
    }

    clear() {
        if (this.state.dataSource.size() === 0) {
            return;
        }
        this._recycler._setLayoutManager(layoutArray);//重新设置layoutManager可解决刷新问题
        this.setState({
            dataSource: new DataSource([], (item, index) => item.id),
            inverted: false,
        });

    }

    onBottom() {
        ToastAndroid.showWithGravity('~~~到底了~~~', ToastAndroid.SHORT, ToastAndroid.CENTER);
    }

    onLoadMore() {
        ToastAndroid.showWithGravity('~~~加载更多~~~', ToastAndroid.SHORT, ToastAndroid.CENTER);
    }

    onTop() {

    }

    reset(size) {
        // this._recycler.scrollToTop();
        const data = Array(size).fill().map((e, i) => newItem());
        this._recycler._setLayoutManager(layoutArray);//重新设置layoutManager可解决刷新问题
        // this.state.dataSource.splice(0, this.state.dataSource.size(), ...data);
        this.setState({
            dataSource: new DataSource(data, (item, i) => item.id),
        });
    }

    toTop() {
        this._recycler.scrollToTop();
    }

    toBottom() {
        this._recycler.scrollToBottom();
    }


    remove(index) {
        this.state.dataSource.splice(index, 1);
    }

    addAbove(index) {
        this.state.dataSource.splice(index, 0, newItem());
    }

    addBelow(index) {
        const {dataSource} = this.state;
        if (index === dataSource.size() - 1 && this._recycler) {
            this._recycler.scrollToIndex({
                animated: true,
                index: dataSource.size(),
                velocity: 120,
            });
        }

        this.state.dataSource.splice(index + 1, 0, newItem());
    }

    incrementCounter(index) {
        ToastAndroid.showWithGravity('你点击了第' + index + '条数据图片', ToastAndroid.SHORT, ToastAndroid.CENTER);
        let item = this.state.dataSource.get(index);
        item.counter++;
        this.state.dataSource.set(index, item);
    }

    moveUp(index) {
        this.state.dataSource.moveUp(index);
    }

    moveDown(index) {
        this.state.dataSource.moveDown(index);
    }

    addToTop(size) {
        const currCount = this.state.dataSource.size();
        const newItems = Array(size).fill().map((e, i) => newItem());
        this.state.dataSource.splice(0, 0, ...newItems);
    }

    addToBottom(size) {
        const currCount = this.state.dataSource.size() + 1;
        const newItems = Array(size).fill().map((e, i) => newItem());
        this.state.dataSource.splice(currCount, 0, ...newItems);
    }

    _onStates(states) {
        if (states === 0) {//展开状态
            ToastAndroid.showWithGravity('当前为展开状态', ToastAndroid.SHORT, ToastAndroid.TOP);
        } else if (states === 1) {//折叠吸顶状态
            ToastAndroid.showWithGravity('当前为吸顶状态', ToastAndroid.SHORT, ToastAndroid.TOP);
        } else if (states === 2) {//中间状态
            ToastAndroid.showWithGravity('当前为中间状态', ToastAndroid.SHORT, ToastAndroid.TOP);
        }
    }
}


const header = () => {
    return <View style={{
        alignItems: 'center',
        borderColor: '#ff0000',
        borderWidth: 1,
    }}>
        <Text style={{fontSize: 15}}>文字自动换行文字自动换行文字自动换行文字自动换行文字自动换行文字自动换行文字自动换行文字自动换行文字自动换行</Text>
    </View>;
};

const empty = () => {
    return <View style={{
        alignItems: 'center',
        borderColor: '#ff0000',
        borderWidth: 1,
    }}>
        <Text style={{fontSize: 15}}>empty...</Text>
    </View>;
};

const footer = () => {
    return <View style={{
        alignItems: 'center',
        borderColor: '#ff0000',
        borderWidth: 1,
    }}>
        <Text style={{fontSize: 15}}>footer...</Text>
    </View>;
};

class Item extends Component {
    render() {
        const {item, index, onRemove, onAddAbove, onAddBelow, onMoveUp, onMoveDown, onIncrementCounter, dataSource} = this.props;
        const {id, counter} = item;
        const imageWidth = 70;
        const imageHeight = 70 + (index % 5 === 2 ? 20 : 0);
        return (
            // <TouchableNativeFeedback
            //     onPress={onIncrementCounter}>
            <View style={{flexDirection: 'row', alignItems: 'center', marginHorizontal: 5, marginVertical: 5}}>
                <TouchableNativeFeedback
                    onPress={onIncrementCounter}>
                    <Image
                        source={{uri: 'http://loremflickr.com/320/240?t=' + (index % 9)}}
                        style={{
                            width: imageWidth,
                            height: imageHeight,
                            marginRight: 10,
                        }}/>
                </TouchableNativeFeedback>
                <View style={{flex: 1}}>
                    <Text style={{
                        fontSize: 16,
                        color: 'black',
                    }}>Item #{id}</Text>
                    <Text style={{
                        fontSize: 14,
                        color: 'black',
                    }}>total size:{dataSource.size()}</Text>
                    <Text style={{
                        fontSize: 13,
                        color: '#888',
                    }}>count {counter ?
                        <Text style={{fontWeight: 'bold', color: 'black'}}>{counter}</Text>
                        : null}</Text>
                </View>
                <View style={{
                    borderBottomWidth: 1,
                    borderColor: '#e7e7e7',
                    marginHorizontal: 5,
                    marginVertical: 5,
                }}/>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#F5FCFF',
    },
});
