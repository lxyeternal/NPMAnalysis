export default class CollapsedView extends PureComponent<any, any, any> {
    static propTypes: {
        style: import("prop-types").Validator<import("react-native").StyleProp<import("react-native").ViewStyle>>;
        onCollapsedState: any;
        CollapseComponent: any;
        StableComponent: any;
        NormalComponent: any;
    };
    constructor(props: any);
    constructor(props: any, context: any);
    _onState: (event: any) => void;
}
import { PureComponent } from "react";
