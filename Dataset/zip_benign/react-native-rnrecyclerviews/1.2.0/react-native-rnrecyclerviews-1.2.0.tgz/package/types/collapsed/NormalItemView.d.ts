export default class NormalItemView extends Component<any, any, any> {
    static propTypes: {
        style: import("prop-types").Validator<import("react-native").StyleProp<import("react-native").ViewStyle>>;
        renderItem: number;
    };
    constructor(props: any);
    constructor(props: any, context: any);
}
import { Component } from "react";
