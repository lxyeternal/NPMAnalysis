module.exports = function (api) {
    api.cache(false);
    const plugins = [
        ['@babel/plugin-transform-runtime'],
        [
            'module-resolver',
            {
                root: ['./src'],
                extensions: ['.ios.js', '.android.js', '.js', '.ts', '.tsx', '.json', '.png'],
                alias: {
                    '@': ['./src'],
                    '@config': ['./config'],
                },
            },
        ],
    ];
    return {
        presets: ['module:metro-react-native-babel-preset'],
        plugins,
    };
};
