import type { RspressPlugin } from "@rspress/shared";
type ChangeFreq = "always" | "hourly" | "daily" | "weekly" | "monthly" | "yearly" | "never";
type Priority = "0.0" | "0.1" | "0.2" | "0.3" | "0.4" | "0.5" | "0.6" | "0.7" | "0.8" | "0.9" | "1.0";
interface Sitemap {
    loc: string;
    lastmod?: string;
    changefreq?: ChangeFreq;
    priority?: Priority;
}
interface CustomMaps {
    [prop: string]: Sitemap;
}
interface Options {
    domain?: string;
    customMaps?: CustomMaps;
    defaultPriority?: Priority;
    defaultChangeFreq?: ChangeFreq;
}
export default function rspressPluginSitemap(options: Options): RspressPlugin;
export {};
