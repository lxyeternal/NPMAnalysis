import { FC, SVGProps } from "react";
import { Label, Note } from "./types";
export interface ChordProps extends SVGProps<SVGSVGElement> {
    notes: Note[];
    title?: string;
    labels?: Label[];
    watermark?: string;
    startAtFret?: number;
    numberOfFrets?: number;
    numberOfStrings?: number;
}
declare const ChordSVG: FC<ChordProps>;
export default ChordSVG;
