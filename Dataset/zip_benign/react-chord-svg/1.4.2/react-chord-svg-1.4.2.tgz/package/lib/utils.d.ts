export declare const times: <T = number>(n: number, cb: (i: number) => any) => T[];
export declare const clamp: (n: number, lower: number, upper: number) => number;
