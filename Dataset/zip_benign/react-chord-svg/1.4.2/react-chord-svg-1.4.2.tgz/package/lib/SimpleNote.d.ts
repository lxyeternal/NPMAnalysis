import { FC, SVGProps } from "react";
import { Note } from "./types";
export interface SimpleNoteProps extends SVGProps<SVGCircleElement> {
    x: number;
    y: number;
    note: Note;
}
declare const SimpleNote: FC<SimpleNoteProps>;
export default SimpleNote;
