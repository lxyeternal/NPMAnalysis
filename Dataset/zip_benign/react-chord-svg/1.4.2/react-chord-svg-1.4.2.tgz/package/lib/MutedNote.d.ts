import { FC } from "react";
export interface MutedNoteProps {
    x: number;
}
declare const MutedNote: FC<MutedNoteProps>;
export default MutedNote;
