import { FC, SVGProps } from "react";
interface Props extends SVGProps<SVGSVGElement> {
    width: number;
}
declare const Title: FC<Props>;
export default Title;
