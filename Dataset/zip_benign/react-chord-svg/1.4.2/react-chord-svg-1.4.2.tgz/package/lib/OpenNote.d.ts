import { FC } from "react";
import { Note } from "./types";
export interface OpenNoteProps {
    x: number;
    note: Note;
}
declare const OpenNote: FC<OpenNoteProps>;
export default OpenNote;
