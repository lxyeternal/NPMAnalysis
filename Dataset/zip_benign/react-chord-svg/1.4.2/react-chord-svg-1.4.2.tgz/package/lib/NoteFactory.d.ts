import { FC } from "react";
import { Note } from "./types";
export interface NoteFactoryProps {
    note: Note;
}
declare const NoteFactory: FC<NoteFactoryProps>;
export default NoteFactory;
