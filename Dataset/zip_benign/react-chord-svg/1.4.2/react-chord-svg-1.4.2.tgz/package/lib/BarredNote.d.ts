import { FC } from "react";
import { Note } from "./types";
export interface BarredNoteProps {
    x: number;
    y: number;
    note: Note;
    bar: number;
}
declare const BarredNote: FC<BarredNoteProps>;
export default BarredNote;
