import { FC, PropsWithChildren, SVGProps } from "react";
import { Label } from "./types";
export interface FretboardProps extends SVGProps<SVGSVGElement> {
    y: number;
    width: number;
    height: number;
    labels: Label[];
    startAtFret: number;
    numberOfFrets: number;
    numberOfStrings: number;
}
declare const Fretboard: FC<PropsWithChildren<FretboardProps>>;
export default Fretboard;
