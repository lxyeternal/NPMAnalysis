import { FC, SVGProps } from "react";
interface Props extends SVGProps<SVGTextElement> {
    fontSize?: number;
}
declare const Text: FC<Props>;
export default Text;
