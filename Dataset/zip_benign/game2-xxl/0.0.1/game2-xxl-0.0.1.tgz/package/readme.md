# 消消乐

# 游戏

##### 安装

```
npm install game2-xxl
```

##### 使用
```
必须开启 "enableSkia": "true"
```
- json

```
{
    "usingComponents": {
        "game": "game2-xxl/xxl"
    }
}
```

- mini.project.json
```
{
  "node_modules_es6_whitelist": [
    "common-game2"
  ]
}
```

- js

```
Page({
  data: {
    gameSource: {
      clickDelayTime: 300,//两次点击最小间隔时间
      row: 6,//行
      col: 6,//列
      autoStart: true,//自动开始游戏
      // fadeBoomTop: !false,//消除动画是否在元素之上显示，然后一起消失 默认false（元素消失了再播放动画）
      showRect: { x: 30, y: 30, width: 690, height: 690 },
      moveSpeed: 0.1,//移动一格的时间 时间越大，速度越慢
      syncMove: !true,//同步移动
      startNoSkill: true,//开始游戏布局不生成技能元素
      gameStartPlayAudio: false,
      // boomNum: 4,//生成炸弹的个数
      // crossNum: 4,//配置合成十字消除
      singleCross: 4,//配置横向或者纵向消除（需要配置horizontal(横向) 或 vertical(纵向)数据才有效）
      // 游戏元素
      items: [
        {
          src: "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01YwKszW1EUdMxcpUv5_!!2185320355.png",
          noMove: true,//不能移动----------------------------
          maxCount: 3,//出现的最多个数-------------------------------
          noSkill: true,//不生成技能元素-----------------------------------
          val: 1,
          probability: 1,//出现概率
          hideSelf: true,
          otherBoomHide: true,//此元素爆炸时，其他消除元素是否隐藏
          selectObj: {
            src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01eQDTui1FJvi3xtOGA_!!1080040467.png",
            type: "animate",//标识为动画
            imgType: "max",//标识为大图
            width: "330",//大图宽度
            height: "880",//大图高度
            fWidth: 110,//一帧宽度
            fHeight: 110,//一帧高度
            count: 24,//总共帧数
            boomSpeed: 0.5,//播放速度
            loop: true,//是否循环
          },
          // 爆炸动画序列帧
          boomObj: {
            src: "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01MeTNmg1EUdMqnMtWv_!!2185320355.png",
            type: "animate",//标识为动画
            imgType: "max",//标识为大图
            width: "672",//大图宽度
            height: "448",//大图高度
            fWidth: 112,//一帧宽度
            fHeight: 112,//一帧高度
            count: 26,//总共帧数
            boomSpeed: 0.4,//播放速度
            loop: !true,//是否循环
          },
          audioName: "default"
        },
        {
          src: "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01Zcm8x41EUdMqEL9zU_!!2185320355.png",
          val: 1,
          probability: 1,//出现概率
          hideSelf: true,
          otherBoomHide: true,//此元素爆炸时，其他消除元素是否隐藏
          selectObj: {
            src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01eQDTui1FJvi3xtOGA_!!1080040467.png",
            type: "animate",//标识为动画
            imgType: "max",//标识为大图
            width: "330",//大图宽度
            height: "880",//大图高度
            fWidth: 110,//一帧宽度
            fHeight: 110,//一帧高度
            count: 24,//总共帧数
            boomSpeed: 0.5,//播放速度
            loop: true,//是否循环
          },
          // 爆炸动画序列帧
          boomObj: {
            src: "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01MeTNmg1EUdMqnMtWv_!!2185320355.png",
            type: "animate",//标识为动画
            imgType: "max",//标识为大图
            width: "672",//大图宽度
            height: "448",//大图高度
            fWidth: 112,//一帧宽度
            fHeight: 112,//一帧高度
            count: 26,//总共帧数
            boomSpeed: 0.4,//播放速度
            loop: !true,//是否循环
          },
          audioName: "default"
        },
        {
          src: "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01zQcQVQ1EUdMxcn9Ne_!!2185320355.png",
          val: 1,
          probability: 1,//出现概率
          hideSelf: true,
          otherBoomHide: true,//此元素爆炸时，其他消除元素是否隐藏
          selectObj: {
            src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01eQDTui1FJvi3xtOGA_!!1080040467.png",
            type: "animate",//标识为动画
            imgType: "max",//标识为大图
            width: "330",//大图宽度
            height: "880",//大图高度
            fWidth: 110,//一帧宽度
            fHeight: 110,//一帧高度
            count: 24,//总共帧数
            boomSpeed: 0.5,//播放速度
            loop: true,//是否循环
          },
          // 爆炸动画序列帧
          boomObj: {
            src: "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01MeTNmg1EUdMqnMtWv_!!2185320355.png",
            type: "animate",//标识为动画
            imgType: "max",//标识为大图
            width: "672",//大图宽度
            height: "448",//大图高度
            fWidth: 112,//一帧宽度
            fHeight: 112,//一帧高度
            count: 26,//总共帧数
            boomSpeed: 0.4,//播放速度
            loop: !true,//是否循环
          },
          audioName: "default"
        },
        {
          src: "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01YFbPXB1EUdMumFHXz_!!2185320355.png",
          val: 1,
          probability: 1,//出现概率
          hideSelf: true,
          otherBoomHide: true,//此元素爆炸时，其他消除元素是否隐藏
          selectObj: {
            src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01eQDTui1FJvi3xtOGA_!!1080040467.png",
            type: "animate",//标识为动画
            imgType: "max",//标识为大图
            width: "330",//大图宽度
            height: "880",//大图高度
            fWidth: 110,//一帧宽度
            fHeight: 110,//一帧高度
            count: 24,//总共帧数
            boomSpeed: 0.5,//播放速度
            loop: true,//是否循环
          },
          // 爆炸动画序列帧
          boomObj: {
            src: "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01MeTNmg1EUdMqnMtWv_!!2185320355.png",
            type: "animate",//标识为动画
            imgType: "max",//标识为大图
            width: "672",//大图宽度
            height: "448",//大图高度
            fWidth: 112,//一帧宽度
            fHeight: 112,//一帧高度
            count: 26,//总共帧数
            boomSpeed: 0.4,//播放速度
            loop: !true,//是否循环
          },
          audioName: "default"
        },
      ],
      // 横向消除
      horizontal: {
        name: "horizontal",
        isSkill: true,
        // src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01GLto4W1FJvfvRdaJP_!!1080040467.png",
        srcArr: [
          { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01lRxPws1EUdMzccJE7_!!2185320355.png", "name": "瓶子_00000.png", "width": "112", "height": "112" },
          { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01M2OeUD1EUdMq9zsrw_!!2185320355.png", "name": "瓶子_00001.png", "width": "112", "height": "112" },
          { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01o5XW5h1EUdMtlc9jL_!!2185320355.png", "name": "瓶子_00002.png", "width": "112", "height": "112" },
          { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01oWsN6r1EUdMrz0REO_!!2185320355.png", "name": "瓶子_00003.png", "width": "112", "height": "112" },
          { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01YAo2Ak1EUdMsS79Gp_!!2185320355.png", "name": "瓶子_00004.png", "width": "112", "height": "112" },
          { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN010zRmpl1EUdMyly646_!!2185320355.png", "name": "瓶子_00005.png", "width": "112", "height": "112" },
          { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01O2ojPw1EUdMq9z0no_!!2185320355.png", "name": "瓶子_00006.png", "width": "112", "height": "112" },
          { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01Kirv3d1EUdMq9xjmd_!!2185320355.png", "name": "瓶子_00007.png", "width": "112", "height": "112" },
          { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN015Rg7KA1EUdMqsR5JR_!!2185320355.png", "name": "瓶子_00008.png", "width": "112", "height": "112" },
        ],
        type: "animate",
        imgType: "max",
        width: 112,
        height: 1008,
        fWidth: 112,
        fHeight: 112,
        count: 9,
        boomSpeed: 0.5,
        loop: true,
        bgImg: {
          src: "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01LXNE3T1EUdMzdNEXN_!!2185320355.png"
        },

        isLine: true,//动画占用整行
        val: 10,
        // 爆炸动画序列帧 先播放boom2Arr再播放boomArr
        boomObj: {
          srcArr: [
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01xlXDN81EUdMnbjimZ_!!2185320355.png", "name": "横00.png", "width": "700", "height": "150" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN014KSNKY1EUdMq3b7ZX_!!2185320355.png", "name": "横01.png", "width": "700", "height": "150" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01Grfbny1EUdMrsfdSs_!!2185320355.png", "name": "横02.png", "width": "700", "height": "150" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01jTWJJT1EUdMwfIqeN_!!2185320355.png", "name": "横03.png", "width": "700", "height": "150" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01UWklIM1EUdMpw6sjJ_!!2185320355.png", "name": "横04.png", "width": "700", "height": "150" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01wwEkL11EUdMrsdckK_!!2185320355.png", "name": "横05.png", "width": "700", "height": "150" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01JxXyG21EUdMlJuv8c_!!2185320355.png", "name": "横06.png", "width": "700", "height": "150" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01evSHW31EUdMlJtZyl_!!2185320355.png", "name": "横07.png", "width": "700", "height": "150" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01Alp4oE1EUdMgQI2Sn_!!2185320355.png", "name": "横08.png", "width": "700", "height": "150" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01DiAfyi1EUdMwfFxtN_!!2185320355.png", "name": "横09.png", "width": "700", "height": "150" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01QhqcKe1EUdMqlzlo3_!!2185320355.png", "name": "横10.png", "width": "700", "height": "150" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN016lbLht1EUdMubpmbV_!!2185320355.png", "name": "横11.png", "width": "700", "height": "150" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01uXHuY81EUdMvRC6Yx_!!2185320355.png", "name": "横12.png", "width": "700", "height": "150" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01l4lVjP1EUdMsLn5H9_!!2185320355.png", "name": "横13.png", "width": "700", "height": "150" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01HTzy4y1EUdMyffJE1_!!2185320355.png", "name": "横14.png", "width": "700", "height": "150" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01ANqqkW1EUdMlJtFCY_!!2185320355.png", "name": "横15.png", "width": "700", "height": "150" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN016cxqe11EUdMtfIpYi_!!2185320355.png", "name": "横16.png", "width": "700", "height": "150" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01lU3Tk01EUdMq3bj0i_!!2185320355.png", "name": "横17.png", "width": "700", "height": "150" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01QrZMmq1EUdMtfIYwF_!!2185320355.png", "name": "横18.png", "width": "700", "height": "150" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01OpjXqM1EUdMpw50Jn_!!2185320355.png", "name": "横19.png", "width": "700", "height": "150" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01w5n4yO1EUdMyfeZSN_!!2185320355.png", "name": "横20.png", "width": "700", "height": "150" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01Yp4tKX1EUdMqlzR09_!!2185320355.png", "name": "横21.png", "width": "700", "height": "150" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01sDYkyy1EUdMnbn4hy_!!2185320355.png", "name": "横22.png", "width": "700", "height": "150" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01fJF7pE1EUdMwfINZw_!!2185320355.png", "name": "横23.png", "width": "700", "height": "150" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01kBnJYe1EUdMzWIJLg_!!2185320355.png", "name": "横24.png", "width": "700", "height": "150" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01v5bpNF1EUdMzWK7bW_!!2185320355.png", "name": "横25.png", "width": "700", "height": "150" },
          ],
          type: "animate",//标识为动画
          imgType: "max",//标识为大图
          width: "700",//大图宽度
          height: "3900",//大图高度
          fWidth: 700,//一帧宽度
          fHeight: 150,//一帧高度
          count: 26,//总共帧数
          boomSpeed: 0.5,//播放速度
          loop: !true,//是否循环
          offset: {
            x: 0,
            y: -20,
          }
        },
        selectObj: {
          src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01eQDTui1FJvi3xtOGA_!!1080040467.png",
          type: "animate",//标识为动画
          imgType: "max",//标识为大图
          width: "330",//大图宽度
          height: "880",//大图高度
          fWidth: 110,//一帧宽度
          fHeight: 110,//一帧高度
          count: 24,//总共帧数
          boomSpeed: 0.5,//播放速度
          loop: true,//是否循环
        },
        audioName: "bomb2"
      },
      // 纵向消除
      vertical: {
        name: "vertical",
        isSkill: true,
        // src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01xj3XjJ1FJvfxnefTU_!!1080040467.png",
        srcArr: [
          { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01lRxPws1EUdMzccJE7_!!2185320355.png", "name": "瓶子_00000.png", "width": "112", "height": "112" },
          { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01M2OeUD1EUdMq9zsrw_!!2185320355.png", "name": "瓶子_00001.png", "width": "112", "height": "112" },
          { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01o5XW5h1EUdMtlc9jL_!!2185320355.png", "name": "瓶子_00002.png", "width": "112", "height": "112" },
          { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01oWsN6r1EUdMrz0REO_!!2185320355.png", "name": "瓶子_00003.png", "width": "112", "height": "112" },
          { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01YAo2Ak1EUdMsS79Gp_!!2185320355.png", "name": "瓶子_00004.png", "width": "112", "height": "112" },
          { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN010zRmpl1EUdMyly646_!!2185320355.png", "name": "瓶子_00005.png", "width": "112", "height": "112" },
          { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01O2ojPw1EUdMq9z0no_!!2185320355.png", "name": "瓶子_00006.png", "width": "112", "height": "112" },
          { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01Kirv3d1EUdMq9xjmd_!!2185320355.png", "name": "瓶子_00007.png", "width": "112", "height": "112" },
          { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN015Rg7KA1EUdMqsR5JR_!!2185320355.png", "name": "瓶子_00008.png", "width": "112", "height": "112" },
        ],
        type: "animate",
        imgType: "max",
        width: 112,
        height: 1008,
        fWidth: 112,
        fHeight: 112,
        count: 9,
        boomSpeed: 0.5,
        loop: true,
        bgImg: {
          src: "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01LXNE3T1EUdMzdNEXN_!!2185320355.png"
        },

        isLine: true,//动画占用整行
        val: 10,
        // 爆炸动画序列帧
        boomObj: {
          srcArr: [
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01khGudb1EUdMtgpHzI_!!2185320355.png", "name": "竖00.png", "width": "150", "height": "700" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN014mbTm51EUdMzXwDhy_!!2185320355.png", "name": "竖01.png", "width": "150", "height": "700" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01w6k88x1EUdMyhD6rV_!!2185320355.png", "name": "竖02.png", "width": "150", "height": "700" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN010zUJSk1EUdMtgpguM_!!2185320355.png", "name": "竖03.png", "width": "150", "height": "700" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01XxGhdl1EUdMwgpqZ1_!!2185320355.png", "name": "竖04.png", "width": "150", "height": "700" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01dewe0x1EUdMudP7yN_!!2185320355.png", "name": "竖05.png", "width": "150", "height": "700" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01w0yGL51EUdMlLWgK9_!!2185320355.png", "name": "竖06.png", "width": "150", "height": "700" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01QLAMCu1EUdMpximQI_!!2185320355.png", "name": "竖07.png", "width": "150", "height": "700" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01SU0RTH1EUdMq5Dcb2_!!2185320355.png", "name": "竖08.png", "width": "150", "height": "700" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01AMygkW1EUdMtgqA1D_!!2185320355.png", "name": "竖09.png", "width": "150", "height": "700" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01LOAThf1EUdMyhCuOI_!!2185320355.png", "name": "竖10.png", "width": "150", "height": "700" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN012RWQSQ1EUdMvSlS2k_!!2185320355.png", "name": "竖11.png", "width": "150", "height": "700" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN017qag6I1EUdMlLUKoI_!!2185320355.png", "name": "竖12.png", "width": "150", "height": "700" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01hKgQUf1EUdMgRpq4h_!!2185320355.png", "name": "竖13.png", "width": "150", "height": "700" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01W1LvwT1EUdMndPi4u_!!2185320355.png", "name": "竖14.png", "width": "150", "height": "700" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01bXdSCm1EUdMruC1or_!!2185320355.png", "name": "竖15.png", "width": "150", "height": "700" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01THV2oM1EUdMyhDyv5_!!2185320355.png", "name": "竖16.png", "width": "150", "height": "700" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN015hit5x1EUdMyhGKRj_!!2185320355.png", "name": "竖17.png", "width": "150", "height": "700" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01d3Hqcf1EUdMyhDVop_!!2185320355.png", "name": "竖18.png", "width": "150", "height": "700" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01pf0VOb1EUdMlLWLY9_!!2185320355.png", "name": "竖19.png", "width": "150", "height": "700" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01FugJKi1EUdMruDIpL_!!2185320355.png", "name": "竖20.png", "width": "150", "height": "700" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN017put6J1EUdMxTxKc0_!!2185320355.png", "name": "竖21.png", "width": "150", "height": "700" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01CMQzpi1EUdMpxl7zp_!!2185320355.png", "name": "竖22.png", "width": "150", "height": "700" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01Z2A6jt1EUdMmtt6tU_!!2185320355.png", "name": "竖23.png", "width": "150", "height": "700" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01wp716s1EUdMruEAs0_!!2185320355.png", "name": "竖24.png", "width": "150", "height": "700" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01GRM35s1EUdMyhFj3S_!!2185320355.png", "name": "竖25.png", "width": "150", "height": "700" },
          ],
          type: "animate",//标识为动画
          imgType: "max",//标识为大图
          width: "3900",//大图宽度
          height: "700",//大图高度
          fWidth: 150,//一帧宽度
          fHeight: 700,//一帧高度
          count: 26,//总共帧数
          boomSpeed: 0.5,//播放速度
          loop: !true,//是否循环
          offset: {
            x: -20,
            y: 0
          }
        },
        selectObj: {
          src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01eQDTui1FJvi3xtOGA_!!1080040467.png",
          type: "animate",//标识为动画
          imgType: "max",//标识为大图
          width: "330",//大图宽度
          height: "880",//大图高度
          fWidth: 110,//一帧宽度
          fHeight: 110,//一帧高度
          count: 24,//总共帧数
          boomSpeed: 0.5,//播放速度
          loop: true,//是否循环
        },
        audioName: "bomb2"
      },
      audio: {
        default: { srcAudio: "http://isv-vod.alibabausercontent.com/mk8pOHtSi7MPYyhqseq/IkmmyXfFa1Y7NqXjCZz?auth_key=1656898315-0-0-f4f78b31d26030a01d7a3eaf8dec72c5&w=0&h=0&e=sd&t=2132c91a16566391149857420e3428&b=tb_rcpaasm&p=*_null&tr=aac-264-sd" },//炸弹音乐
        bomb2: { srcAudio: "http://isv-vod.alibabausercontent.com/mk8pOHtSi7MPYyhqseq/2GbqzXZIG2vg7L4jDgD?auth_key=1656898307-0-0-66658c05cb7326b18b1e5f26f07fd4ad&w=0&h=0&e=sd&t=2132c91a16566391073076820e3428&b=tb_rcpaasm&p=*_null&tr=aac-264-sd" },//默认音效
      }
    }
  },
  onLoad() {
    this.time1 = +new Date();
  },

  overFun() {
    this.gameComponent.onEvent("gameOver");
  },
  beginFun() {
    /* my.alert({
      content: "游戏开始"
    }) */
    // this.gameComponent.onEvent("start");
  },
  muteFun() {
    // 静音
    this.gameComponent.onEvent("mute");
  },
  playFun() {
    // 播放
    this.gameComponent.onEvent("play");
  },
  resetFun() {
    this.gameComponent.onEvent("reset");
  },
  clearFun() {
    this.gameComponent.onEvent("clear");
  },
  refreshFun() {
    console.log("刷新")
    this.gameComponent.onEvent("refresh");
  },
  onRef(ref) {
    this.gameComponent = ref;
  },

  onGameOver(score) {
    console.log("游戏结束：", score)
  },
  onInitDone(obj) {
    // 游戏重置也会回调
    /* my.alert({
      content: "游戏初始化完成" + obj.renderTime + "--" + (obj.endTime - this.time1)
    }) */
    this.beginFun();
  },
  onUpdate(item) {
    // curFadeArr：本次消除的元素个数（fadeNum）totalFadeArr：本局消除的元素个数（fadeNum）
    // {curScore,totalScore,curFadeArr,totalFadeArr}
    this.setData({
      totalScore: item.totalScore,
      curScore: item.curScore
    })
    let fadeNum = 0;
    item.totalFadeArr.forEach(item => {
      if (item.noMove) {
        fadeNum = item.fadeNum;
      }
    })
    console.error("不能移动的元素消除个数", fadeNum)
    console.log("update:", item)
    // my.alert({
    //   content: "游戏消除了"
    // })
  },
  onRefreshCallback(bl) {
    console.log("刷新回调：", bl)
  },
  onClearCallback(bl) {
    console.log("全消回调：", bl)
  },
  onSkillCallback(obj) {
    // 返回技能
    // {new:[新生成的技能],all:[所有技能]}
    console.log("生成技能回调：", obj)
  },
  onNoMoveCallback() {
    // this.refreshFun();
    // 没有可移动元素回调
    console.log("页面上没有可移动的元素了")
    my.alert({
      content: "页面上没有可移动的元素了"
    })
  },
});

```

- xaml

```
  <view class="pageBox">
    <view class="gameBox">
      <game gameSource="{{gameSource}}" onRef="onRef" onInitDone="onInitDone" onUpdate="onUpdate" onGameOver="onGameOver" onRefreshCallback="onRefreshCallback" 
        onClearCallback="onClearCallback" onSkillCallback="onSkillCallback" />
    </view>
    
    <view style="height: 10vh;">总分数：{{totalScore || 0}} 本次消除分数：{{curScore|| 0}}</view>
    <view onTap="clearFun" style="position:absolute;left: 0rpx;bottom: 0;">全消</view>
    <view onTap="beginFun" style="position:absolute;left: 100rpx;bottom: 0;">开始</view>
    <view onTap="overFun" style="position:absolute;left: 200rpx;bottom: 0;">停止</view>
    <view onTap="resetFun" style="position:absolute;left: 300rpx;bottom: 0;">重置</view>
    <view onTap="refreshFun" style="position:absolute;left: 400rpx;bottom: 0;">刷新</view>
    <view onTap="muteFun" style="position:absolute;left: 500rpx;bottom: 0;">静音</view>
    <view onTap="playFun" style="position:absolute;left: 600rpx;bottom: 0;">播放</view>
  </view>
```