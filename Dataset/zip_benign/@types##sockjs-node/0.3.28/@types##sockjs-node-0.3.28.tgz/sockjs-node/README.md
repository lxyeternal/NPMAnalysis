# Installation
> `npm install --save @types/sockjs-node`

# Summary
This package contains type definitions for sockjs-node 0.3.x (https://github.com/sockjs/sockjs-node).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/types-2.0/sockjs-node

Additional Details
 * Last updated: Mon, 19 Sep 2016 17:28:59 GMT
 * File structure: ProperModule
 * Library Dependencies: node
 * Module Dependencies: http
 * Global values: none

# Credits
These definitions were written by Phil McCloghry-Laing <https://github.com/pmccloghrylaing>.
