import { Texture } from '@pixi/core';
export interface IFrameObject {
    texture: Texture;
    time: number;
}
export interface ITextureAnimationTarget {
    texture: Texture;
    animState: AnimationState;
}
export declare class AnimationState {
    texture: Texture;
    _textures: Array<Texture>;
    _durations: Array<number>;
    _autoUpdate: boolean;
    animationSpeed: number;
    _target: ITextureAnimationTarget;
    loop: boolean;
    onComplete?: () => void;
    onFrameChange?: (currentFrame: number) => void;
    onLoop?: () => void;
    _currentTime: number;
    playing: boolean;
    constructor(textures: Array<Texture> | Array<IFrameObject>, autoUpdate?: boolean);
    /**
     * Stops the AnimatedSprite
     *
     */
    stop(): void;
    /**
     * Plays the AnimatedSprite
     *
     */
    play(): void;
    /**
     * Stops the AnimatedSprite and goes to a specific frame
     *
     * @param {number} frameNumber - frame index to stop at
     */
    gotoAndStop(frameNumber: number): void;
    /**
     * Goes to a specific frame and begins playing the AnimatedSprite
     *
     * @param {number} frameNumber - frame index to start at
     */
    gotoAndPlay(frameNumber: number): void;
    /**
     * Updates the object transform for rendering.
     *
     * @private
     * @param {number} deltaTime - Time since last tick.
     */
    update(deltaTime: number): void;
    /**
     * Updates the displayed texture to match the current frame index
     *
     * @private
     */
    updateTexture(): void;
    bind(target: ITextureAnimationTarget): void;
    /**
     * A short hand way of creating a movieclip from an array of frame ids
     *
     * @static
     * @param {string[]} frames - The array of frames ids the movieclip will use as its texture frames
     * @return {AnimatedSprite} The new animated sprite with the specified frames.
     */
    static fromFrames(frames: Array<string>): AnimationState;
    /**
     * A short hand way of creating a movieclip from an array of image ids
     *
     * @static
     * @param {string[]} images - the array of image urls the movieclip will use as its texture frames
     * @return {AnimatedSprite} The new animate sprite with the specified images as frames.
     */
    static fromImages(images: Array<string>): AnimationState;
    /**
     * totalFrames is the total number of frames in the AnimatedSprite. This is the same as number of textures
     * assigned to the AnimatedSprite.
     *
     * @readonly
     * @member {number}
     * @default 0
     */
    get totalFrames(): number;
    /**
     * The array of textures used for this AnimatedSprite
     *
     * @member {Texture[]}
     */
    get textures(): Texture[] | IFrameObject[];
    set textures(value: Texture[] | IFrameObject[]);
    get currentFrame(): number;
}
