import { ISpineClass } from './base';
import { Renderer, Texture } from '@pixi/core';
import { SpriteH, SimpleMeshH } from '../twotint';
import { Container } from '@pixi/display';
export declare class SpineSprite extends SpriteH {
    spine: Container;
    constructor(tex: Texture, spine: Container);
    _render(renderer: Renderer): void;
}
export declare class SpineMesh extends SimpleMeshH {
    spine: Container;
    constructor(texture: Texture, vertices?: Float32Array, uvs?: Float32Array, indices?: Uint16Array, drawMode?: number, spine?: Container);
    _render(renderer: Renderer): void;
}
export declare function applySpineMixin(spineClassPrototype: ISpineClass): void;
