export declare enum CLAMP_OPTIONS {
    NEVER = 0,
    AUTO = 1,
    ALWAYS = 2
}
export interface ISettings {
    MESH_CLAMP: CLAMP_OPTIONS;
    BLEND_ADD_UNITY: boolean;
}
export declare const settings: ISettings;
