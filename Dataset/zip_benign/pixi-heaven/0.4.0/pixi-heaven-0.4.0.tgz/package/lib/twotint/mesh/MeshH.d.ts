import { ColorTransform } from '../ColorTransform';
import { Mesh as MeshBase } from '@pixi/mesh';
import { SpriteH } from '../sprites/SpriteH';
import { Geometry, Renderer, State, Texture } from '@pixi/core';
import { DoubleTintMeshMaterial } from './DoubleTintMeshMaterial';
export declare class MeshH extends MeshBase {
    color: ColorTransform;
    maskSprite: SpriteH;
    maskVertexData: Float32Array;
    useSpriteMask: boolean;
    constructor(geometry: Geometry, shader: DoubleTintMeshMaterial, state: State, drawMode?: number);
    _renderDefault(renderer: Renderer): void;
    _render(renderer: Renderer): void;
    _renderToBatch(renderer: Renderer): void;
    calculateMaskVertices(): void;
}
export declare class SimpleMeshH extends MeshH {
    constructor(texture: Texture, vertices?: Float32Array, uvs?: Float32Array, indices?: Uint16Array, drawMode?: number);
    autoUpdate: boolean;
    get vertices(): Float32Array;
    set vertices(value: Float32Array);
    _render(renderer: Renderer): void;
}
