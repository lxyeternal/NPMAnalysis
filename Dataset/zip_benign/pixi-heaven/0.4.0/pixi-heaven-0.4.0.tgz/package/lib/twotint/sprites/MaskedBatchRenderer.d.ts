import { BatchRenderer, Buffer, Geometry, Renderer, ViewableBuffer, ExtensionType } from '@pixi/core';
export declare class MaskedGeometry extends Geometry {
    _buffer: Buffer;
    _indexBuffer: Buffer;
    constructor(_static?: boolean);
}
export declare class MaskedBatchRenderer extends BatchRenderer {
    static extension: {
        name: string;
        type: ExtensionType;
    };
    static MAX_TEXTURES: number;
    constructor(renderer: Renderer);
    setShaderGenerator({ vertex, fragment }?: {
        vertex?: string;
        fragment?: string;
    }): void;
    contextChange(): void;
    buildTexturesAndDrawCalls(): void;
    packInterleavedGeometry(element: any, attributeBuffer: ViewableBuffer, indexBuffer: Uint16Array, aIndex: number, iIndex: number): void;
}
