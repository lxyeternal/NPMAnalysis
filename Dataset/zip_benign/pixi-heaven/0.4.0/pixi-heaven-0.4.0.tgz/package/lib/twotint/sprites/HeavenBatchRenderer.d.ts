import { BatchRenderer, BatchTextureArray, Buffer, ExtensionType, Geometry, Renderer, ViewableBuffer } from '@pixi/core';
export declare class DarkLightGeometry extends Geometry {
    _buffer: Buffer;
    _indexBuffer: Buffer;
    constructor(_static?: boolean);
}
export declare class HeavenBatchRenderer extends BatchRenderer {
    static extension: {
        name: string;
        type: ExtensionType;
    };
    constructor(renderer: Renderer);
    setShaderGenerator({ vertex, fragment }?: {
        vertex?: string;
        fragment?: string;
    }): void;
    packInterleavedGeometry(element: any, attributeBuffer: ViewableBuffer, indexBuffer: Uint16Array, aIndex: number, iIndex: number): void;
    /**
     * I override this method because of special alpha case that can be batched and work with any masks
     * @param texArray
     * @param start
     * @param finish
     */
    buildDrawCalls(texArray: BatchTextureArray, start: number, finish: number): void;
}
