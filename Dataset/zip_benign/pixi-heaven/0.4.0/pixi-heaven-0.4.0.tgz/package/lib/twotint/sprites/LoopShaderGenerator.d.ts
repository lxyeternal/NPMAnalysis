import { Program, Shader, UniformGroup } from '@pixi/core';
export interface ILoopDescriptor {
    loopLabel: string;
    inTex: string;
    inCoord: string;
    outColor: string;
}
export declare class LoopShaderGenerator {
    vertexSrc: string;
    fragTemplate: string;
    loops: Array<ILoopDescriptor>;
    programCache: {
        [key: number]: Program;
    };
    defaultGroupCache: {
        [key: number]: UniformGroup;
    };
    constructor(vertexSrc: string, fragTemplate: string, loops: Array<ILoopDescriptor>);
    generateShader(maxTextures: number): Shader;
    generateSampleSrc(maxTextures: number, loop: ILoopDescriptor): string;
}
