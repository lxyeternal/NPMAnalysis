import { ColorTransform } from './ColorTransform';
import { DisplayObject } from '@pixi/display';
import { Renderer } from '@pixi/core';
import { BitmapText } from '@pixi/text-bitmap';
export declare class BitmapTextH extends BitmapText {
    constructor(text: string, style?: any);
    color: ColorTransform;
    get tint(): number;
    set tint(value: number);
    addChild(...additionalChildren: DisplayObject[]): any;
    _render(renderer: Renderer): void;
}
