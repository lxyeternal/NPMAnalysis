import { Shader, Texture, TextureMatrix } from '@pixi/core';
import { ColorTransform } from '../ColorTransform';
export declare class DoubleTintMeshMaterial extends Shader {
    uvMatrix: TextureMatrix;
    batchable: boolean;
    readonly allowTrim: boolean;
    pluginName: string;
    color: ColorTransform;
    _colorId: number;
    constructor(uSampler: Texture, options?: any);
    /**
     * Reference to the texture being rendered.
     * @member {Texture}
     */
    get texture(): any;
    set texture(value: any);
    /**
     * This gets automatically set by the object using this.
     *
     * @default 1
     * @member {number}
     */
    set alpha(value: number);
    get alpha(): number;
    /**
     * Multiply tint for the material.
     * @member {number}
     * @default 0xFFFFFF
     */
    set tint(value: number);
    get tint(): number;
    /**
     * Gets called automatically by the Mesh. Intended to be overridden for custom
     * MeshMaterial objects.
     */
    update(): void;
}
