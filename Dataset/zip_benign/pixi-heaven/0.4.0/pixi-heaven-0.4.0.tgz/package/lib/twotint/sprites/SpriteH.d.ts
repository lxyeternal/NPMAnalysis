import { AnimationState, ITextureAnimationTarget } from '../../animation/AnimationState';
import { ColorTransform } from '../ColorTransform';
import { Renderer, Texture } from '@pixi/core';
import { Sprite } from '@pixi/sprite';
export declare class SpriteH extends Sprite implements ITextureAnimationTarget {
    color: ColorTransform;
    maskSprite: SpriteH;
    maskVertexData: Float32Array;
    uvs: Float32Array;
    indices: Uint16Array;
    animState: AnimationState;
    blendAddUnity: boolean;
    constructor(texture: Texture);
    get tint(): number;
    set tint(value: number);
    _onTextureUpdate(): void;
    _render(renderer: Renderer): void;
    _calculateBounds(): void;
    calculateVertices(): void;
    calculateMaskVertices(): void;
    destroy(options?: any): void;
}
