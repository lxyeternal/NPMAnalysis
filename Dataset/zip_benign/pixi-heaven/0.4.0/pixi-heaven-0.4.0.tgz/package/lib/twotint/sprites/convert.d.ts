export declare function applyConvertMixins(): void;
