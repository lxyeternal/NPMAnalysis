export declare class TexturePolygon {
    vertices: ArrayLike<number>;
    uvs: ArrayLike<number>;
    indices: ArrayLike<number>;
    constructor(vertices: ArrayLike<number>, uvs: ArrayLike<number>, indices: ArrayLike<number>);
}
export declare function applySpritesheetMixin(): void;
