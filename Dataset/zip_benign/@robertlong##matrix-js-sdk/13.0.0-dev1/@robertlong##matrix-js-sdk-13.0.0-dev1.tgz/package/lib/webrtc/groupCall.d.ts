/// <reference types="node" />
import EventEmitter from "events";
import { CallFeed } from "./callFeed";
import { MatrixClient } from "../client";
import { MatrixCall } from "./call";
import { RoomMember } from "../models/room-member";
import { Room } from "../models/room";
import { MatrixEvent } from "../models/event";
export declare const GROUP_CALL_ROOM_EVENT = "org.matrix.msc3401.call";
export declare const GROUP_CALL_MEMBER_EVENT = "org.matrix.msc3401.call.member";
export declare enum GroupCallIntent {
    Ring = "m.ring",
    Prompt = "m.prompt",
    Room = "m.room"
}
export declare enum GroupCallType {
    Video = "m.video",
    Voice = "m.voice"
}
export declare enum GroupCallTerminationReason {
    CallEnded = "call_ended"
}
export declare enum GroupCallEvent {
    GroupCallStateChanged = "group_call_state_changed",
    ActiveSpeakerChanged = "active_speaker_changed",
    CallsChanged = "calls_changed",
    UserMediaFeedsChanged = "user_media_feeds_changed",
    ScreenshareFeedsChanged = "screenshare_feeds_changed",
    LocalScreenshareStateChanged = "local_screenshare_state_changed",
    LocalMuteStateChanged = "local_mute_state_changed",
    ParticipantsChanged = "participants_changed",
    Error = "error"
}
export declare enum GroupCallErrorCode {
    NoUserMedia = "no_user_media"
}
export declare class GroupCallError extends Error {
    code: string;
    constructor(code: GroupCallErrorCode, msg: string, err: Error);
}
export interface IGroupCallDataChannelOptions {
    ordered: boolean;
    maxPacketLifeTime: number;
    maxRetransmits: number;
    protocol: string;
}
export interface IGroupCallRoomMemberCallState {
    "m.call_id": string;
    "m.foci"?: string[];
    "m.sources"?: any[];
}
export interface IGroupCallRoomMemberState {
    "m.calls": IGroupCallRoomMemberCallState[];
}
export declare enum GroupCallState {
    LocalCallFeedUninitialized = "local_call_feed_uninitialized",
    InitializingLocalCallFeed = "initializing_local_call_feed",
    LocalCallFeedInitialized = "local_call_feed_initialized",
    Entering = "entering",
    Entered = "entered",
    Ended = "ended"
}
export declare class GroupCall extends EventEmitter {
    private client;
    room: Room;
    type: GroupCallType;
    intent: GroupCallIntent;
    private dataChannelsEnabled?;
    private dataChannelOptions?;
    activeSpeakerSampleCount: number;
    activeSpeakerInterval: number;
    speakingThreshold: number;
    participantTimeout: number;
    state: GroupCallState;
    activeSpeaker?: string;
    localCallFeed?: CallFeed;
    localScreenshareFeed?: CallFeed;
    localDesktopCapturerSourceId?: string;
    calls: MatrixCall[];
    participants: RoomMember[];
    userMediaFeeds: CallFeed[];
    screenshareFeeds: CallFeed[];
    groupCallId: string;
    private userMediaFeedHandlers;
    private callHandlers;
    private activeSpeakerSamples;
    private activeSpeakerLoopTimeout?;
    private reEmitter;
    constructor(client: MatrixClient, room: Room, type: GroupCallType, intent: GroupCallIntent, dataChannelsEnabled?: boolean, dataChannelOptions?: IGroupCallDataChannelOptions);
    create(): Promise<this>;
    private setState;
    getLocalFeeds(): CallFeed[];
    initLocalCallFeed(): Promise<CallFeed>;
    enter(): Promise<void>;
    private dispose;
    leave(): void;
    terminate(emitStateEvent?: boolean): Promise<void>;
    /**
     * Local Usermedia
     */
    isLocalVideoMuted(): boolean;
    isMicrophoneMuted(): boolean;
    setMicrophoneMuted(muted: any): void;
    setLocalVideoMuted(muted: any): void;
    setScreensharingEnabled(enabled: boolean, desktopCapturerSourceId?: string): Promise<boolean>;
    isScreensharing(): boolean;
    /**
     * Call Setup
     *
     * There are two different paths for calls to be created:
     * 1. Incoming calls triggered by the Call.incoming event.
     * 2. Outgoing calls to the initial members of a room or new members
     *    as they are observed by the RoomState.members event.
     */
    private onIncomingCall;
    /**
     * Room Member State
     */
    private sendEnteredMemberStateEvent;
    private sendLeftMemberStateEvent;
    private updateMemberCallState;
    onMemberStateChanged: (event: MatrixEvent) => void;
    /**
     * Call Event Handlers
     */
    getCallByUserId(userId: string): MatrixCall;
    private addCall;
    private replaceCall;
    private removeCall;
    private initCall;
    private disposeCall;
    private onCallFeedsChanged;
    private onCallStateChanged;
    private onCallHangup;
    /**
     * UserMedia CallFeed Event Handlers
     */
    getUserMediaFeedByUserId(userId: string): CallFeed;
    private addUserMediaFeed;
    private replaceUserMediaFeed;
    private removeUserMediaFeed;
    private initUserMediaFeed;
    private disposeUserMediaFeed;
    private onCallFeedVolumeChanged;
    private onCallFeedMuteStateChanged;
    private onActiveSpeakerLoop;
    /**
     * Screenshare Call Feed Event Handlers
     */
    getScreenshareFeedByUserId(userId: string): CallFeed;
    private addScreenshareFeed;
    private replaceScreenshareFeed;
    private removeScreenshareFeed;
    /**
     * Participant Management
     */
    private addParticipant;
    private removeParticipant;
}
