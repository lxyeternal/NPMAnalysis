import { MatrixEvent } from '../models/event';
import { MatrixCall } from './call';
import { MatrixClient } from '../client';
export declare class CallEventHandler {
    client: MatrixClient;
    calls: Map<string, MatrixCall>;
    callEventBuffer: MatrixEvent[];
    candidateEventsByCall: Map<string, Array<MatrixEvent>>;
    private toDeviceCallEventBuffer;
    constructor(client: MatrixClient);
    start(): void;
    stop(): void;
    private onSync;
    private evaluateEventBuffer;
    private onRoomTimeline;
    private onToDeviceEvent;
    private evaluateToDeviceEventBuffer;
    private eventIsACall;
    private handleCallEvent;
}
