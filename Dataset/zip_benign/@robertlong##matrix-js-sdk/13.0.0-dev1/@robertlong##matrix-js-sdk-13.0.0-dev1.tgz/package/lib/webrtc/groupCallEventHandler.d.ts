import { MatrixClient } from '../client';
import { GroupCall } from "./groupCall";
export declare class GroupCallEventHandler {
    private client;
    groupCalls: Map<string, GroupCall>;
    constructor(client: MatrixClient);
    start(): void;
    stop(): void;
    getGroupCallById(groupCallId: string): GroupCall;
    private createGroupCallForRoom;
    private createGroupCallFromRoomStateEvent;
    private onRoomsChanged;
    private onRoomStateChanged;
}
