export declare class NumberUtil {
    /**
     * Returns TRUE if it only has digits (no accept negative integer).
     */
    static isDigit(str: any): boolean;
    /**
     * Returns TRUE if it is a positive or negative integer.
     */
    static isInteger(str: any): boolean;
    static isNumber(value: any): boolean;
    /**
     * Returns the integer part of a number (previous to decimal point).
     * Does not apply rounding.
     *
     * Ex:
     *      '012.9 euros' > '12'
     *      'euros' > NaN
     *      '-0.010' > '-0'
     */
    static getIntPart(value: any): string | null;
    /**
     * Returns the decimal part of a number. If it does not return the empty string.
     */
    static getDecPart(value: any): string;
    /**
     * Returns how many decimals digits a number has.
     */
    static countDecimals(value: any): number;
    static trim(str: string, decimalSep?: string): string;
    /**
     * Add the decimal point to an integer. Account 'precision' digits on the left.
     *
     * @param value integer
     * @param precision integer
     */
    static setPrecisionToInt(value: string | number, precision: number): string;
}
