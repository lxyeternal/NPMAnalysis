declare type InTypes = string | number | Decimal | undefined | null;
/**
 * A simple arbitrary-precision Decimal class.
 * Inmutable class.
 */
export declare class Decimal {
    static MAX_DECIMALS: number;
    static ERROR_PREFIX: string;
    private static NaN;
    protected intPart: string | null;
    protected decPart: string;
    constructor(value: InTypes, precision?: number);
    /**
     * Returns the number of digits of decimal part.
     */
    getPrecision(): number;
    /**
     * Internally change the number of decimals of the current value
     */
    protected updatePrecision(newPrecision: number | undefined | null): void;
    /**
     * Changes number of decimals. Round if necessary.
     *
     * @param newPrecision
     */
    changePrecision(newPrecision: number): Decimal;
    /**
     * Does it contain a number? (NaN not included).
     */
    hasValue(): boolean;
    isNaN(): boolean;
    isNull(): boolean;
    isPos(): boolean;
    /**
     * Return true if the value of this Decimal is 0.
     */
    isZero(): boolean;
    isNeg(): boolean;
    /**
     * Returns value as a number. NaN is a valid value.
     */
    getValue(): number | null;
    /**
     * Returns value as a integer (join int part with decimal part without decimal point).
     * NaN is a valid value.
     */
    getValueAsInt(): number | null;
    toString(dft?: any, dftNaN?: any): string;
    clone(): Decimal;
    trim(): Decimal;
    abs(): Decimal;
    protected calc(value: InTypes, func: (op1: number, op2: number) => number): Decimal;
    /**
     * Returns a new Decimal object that represents the sum of this and an other Decimal object.
     * If objects have a different precision, they will be first converted to the highest.
     *
     * @param value
     */
    add(value: InTypes): Decimal;
    /**
     * Returns a new Decimal object that represents the difference of this and an other Decimal object.
     * If objects have a different precision, they will be first converted to the highest.
     *
     * @param value
     */
    sub(value: InTypes): Decimal;
    /**
     * Returns a new Decimal object that represents the multiplied of this and an other Decimal object.
     * If objects have a different precision, they will be first converted to the highest.
     *
     * @param value
     */
    mult(value: InTypes): Decimal;
    /**
     * Returns a new Decimal object that represents the divided of this by an other Decimal object.
     * If objects have a different precision, they will be first converted to the highest.
     *
     * @param value
     */
    div(value: InTypes, precision?: number): Decimal;
    percentage(percentage: any): Decimal;
    protected compare(value: InTypes, func: (op1: number, op2: number) => boolean): boolean;
    /**
     * Checks whether the value represented by this object equals to the other.
     * Note: NaN always returns FALSE.
     *
     * @param value
     */
    eq(value: InTypes): boolean;
    /**
     * Checks whether the value represented by this object is less than the other.
     *
     * @param value
     */
    lt(value: InTypes): boolean;
    /**
     * Checks whether the value represented by this object is less than or equal to the other.
     *
     * @param value
     */
    lte(value: InTypes): boolean;
    /**
     * Checks whether the value represented by this object is greater than the other.
     *
     * @param value
     */
    gt(value: InTypes): boolean;
    /**
     * Checks whether the value represented by this object is greater than or equal to the other.
     *
     * @param value
     */
    gte(value: InTypes): boolean;
    /**
     * It is defined so that calling `JSON.stringify` on a Decimal object will automatically extract the relevant data.
     * Note: "NaN" is a valid value.
     */
    toJSON(): string | null;
    protected static checkParamPrecision(precision: number | undefined | null): number | null;
}
export {};
