# Task's requirement
1. Create new package ()
2. Name it as jsmp-infra-{package name}
3. Write source code following next requirements
o Code must be written with use of ES2015 import/export syntax and may use other ES2015 features (e.g. default parameters, destructuring etc.)
o Code must use at least one external dependency (e.g. lodash)
o Create file that export function which accepts array, other parameter(s) and returns updated array
o Create file that export function which accepts string, other parameter(s) and returns updated string
o Create file that will be entry point for your package and will export functions from files created in previous steps.
4. Write simplest tests for your functions:
o Code must be written with use of ES2015 import/export syntax and may use other ES2015 features (e.g. default parameters, destructuring etc.)
o Use standard assert Node.js package
Example:
assert(myFunction('ABc', 'upper') === 'ABC', 'should convert string to uppercase')
o Create 3 tests for each of two functions (better to have 1 simple and 2 edge cases)
5. Write next npm scripts:
    a. compile - script(s) that transpiles original source and tests files to ES5.
You have to use babel-cli package and create simple .babelrc file for this purpose
    b. clean - script(s) removes all files and folders that are created during by compile scripts
    c. test - script(s) that runs transpiled test files.
    d. Create tasks that will perform cleanup, transpilation and run tests before package will be published. (check official docs and presentation)
6. Add readme file that contains short description and examples how to use your package. (check readme files for other packages)
7. Create proper .gitignore file to exclude generated files from repository
8. Create proper .npmignore file to publish only files that are required for consumers of your package (npm will bundle meta files and readme by itself)
9. Register on npmjs.com
10. Publish your package
11. Made some updates and publish updated version
12. Provide mentor with link(+ access) to package repository and link to package on npmjs.com
13. (Optional) Create separate file and use your package.
    a. Try to install it from registry
    b. Try to install it from your filesystem (relative or absolute path)
    c. Try to consume it via npm link
    d. Notice differences in ways of how you can receive updates made to jsmp-infra-{package name} package
 
# What will be checked
1. Package installs and works without errors and warnings. – 2 points
2. NPM scripts contains all required commands. – max 2 points (0.5 point per item)
3. Package has full meta information. Link to docs: https://docs.npmjs.com/files/package.json. – 1 point
4. Package has correctly configured dependencies (proper dependency types). – 0.5 point
5. Package has lock file. – 0.5 point
6. Package doesn't contain files that are not required for consumers. – 1 point
7. Package can be used as on examples in readme. For example, https://github.com/MikeMcl/decimal.js/. – 1 point
8. Package is cross platform. (there is no native commands in NPM scripts) – 1 point
9. Package works on specified engines (Node, NPM versions). – 1point
# How to use
    package.json contains 4 scripts which you can use
    run in terminal npm 
    Package provide 2 methods: 
        1. `modifyString()` method which modify recieve string transform option for it. 
        For example modifyString('my string', 'upper') will return 'MY STRING';
        The second should to be equal 'upper' or 'lower' if this parameter doesn't transfered the string will be 
        capitalize;
        2. `sortArray()` method which accept two arguments array and value, and return new sorted array. This method
        works only with numbers. Example invoke sortArray([10, 1, 3, 1020], 18) return [1, 3, 10, 18, 1020];
# How to run
**1. Сhoose the root directory**
  `open terminal and run corresponding script`
