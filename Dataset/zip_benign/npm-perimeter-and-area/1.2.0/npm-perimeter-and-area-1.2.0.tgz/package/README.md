# Easily Import Perimeter and Area

With this package, you can easily import the area and perimeter.

You can import it using:

```js
const {area, perimeter} = require('npm-helloworld-ritihk7547');
```
# How you can use it

```js
console.log(area(1));
console.log(perimeter(0.5));
```

👆 This for example would print the value of PI